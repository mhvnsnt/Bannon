
const fs = require('fs');
const content = fs.readFileSync('server.ts', 'utf8');
const newContent = content.replace(/gemini-2.5-flash/g, 'gemini-1.5-flash');
fs.writeFileSync('server.ts', newContent);
console.log('Done');
