// ==UserScript==
// @name         God-Mode OS Living Nexus Session Exporter
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Export session snapshots directly to the local God-Mode OS Living Nexus unified archive
// @author       God Mode OS
// @match        https://claude.ai/*
// @match        https://aistudio.google.com/*
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function() {
    'use strict';

    const NEXUS_URL = 'http://localhost:3000/api/godmode/session-export'; // Assuming your God-Mode OS Living Nexus instance is running locally

    function createExportButton() {
        const btn = document.createElement('button');
        btn.textContent = '⚡ Export to God-Mode OS';
        btn.style.position = 'fixed';
        btn.style.bottom = '20px';
        btn.style.right = '20px';
        btn.style.zIndex = '9999';
        btn.style.padding = '10px 15px';
        btn.style.backgroundColor = '#10b981'; // Emerald
        btn.style.color = 'white';
        btn.style.border = 'none';
        btn.style.borderRadius = '5px';
        btn.style.cursor = 'pointer';
        btn.style.fontWeight = 'bold';
        btn.style.fontFamily = 'monospace';

        btn.onclick = async () => {
            btn.textContent = 'Extracting...';
            
            // Note: Automating the prompt injection in Claude or AI Studio via DOM can be fragile.
            // The cleanest way is often: You manually ask the LLM for the JSON format, copy it to your clipboard,
            // and this button simply reads the clipboard and POSTs it, OR we can show a prompt dialog to paste it.

            const clipboardText = await navigator.clipboard.readText();
            let snapshotData;
            
            try {
                // Try to parse the clipboard text directly as JSON if it's already copied
                // Extract JSON block if it's wrapped in markdown ```json
                const jsonMatch = clipboardText.match(/```json\n([\s\S]*?)\n```/);
                const rawJson = jsonMatch ? jsonMatch[1] : clipboardText;
                snapshotData = JSON.parse(rawJson);
            } catch (e) {
                // Fallback to manual entry dialog
                const manualEntry = prompt("Could not parse clipboard as JSON. Please paste the JSON Session Snapshot:");
                if (!manualEntry) {
                    btn.textContent = '⚡ Export to God-Mode OS';
                    return;
                }
                try {
                    const jsonMatch = manualEntry.match(/```json\n([\s\S]*?)\n```/);
                    const rawJson = jsonMatch ? jsonMatch[1] : manualEntry;
                    snapshotData = JSON.parse(rawJson);
                } catch (err) {
                    alert('Invalid JSON structured format.');
                    btn.textContent = '⚡ Export to God-Mode OS';
                    return;
                }
            }

            const platform = window.location.hostname.includes('claude') ? 'claude' : 'aistudio';

            const payload = {
                session_id: "auto-" + Date.now(),
                platform: platform,
                project: snapshotData.project || 'unknown',
                summary: snapshotData.summary || '',
                files_touched: snapshotData.files_touched || [],
                key_decisions: snapshotData.key_decisions || '',
                next_target: snapshotData.next_target || ''
            };

            GM_xmlhttpRequest({
                method: "POST",
                url: NEXUS_URL,
                headers: {
                    "Content-Type": "application/json"
                },
                data: JSON.stringify(payload),
                onload: function(response) {
                    if (response.status === 200) {
                        btn.textContent = '✓ Saved to God-Mode OS';
                        btn.style.backgroundColor = '#3b82f6'; // Blue
                    } else {
                        btn.textContent = 'Error saving';
                        btn.style.backgroundColor = '#ef4444'; // Red
                    }
                    setTimeout(() => {
                        btn.textContent = '⚡ Export to God-Mode OS';
                        btn.style.backgroundColor = '#10b981';
                    }, 3000);
                },
                onerror: function(err) {
                    btn.textContent = 'Offline';
                    btn.style.backgroundColor = '#ef4444';
                    console.error(err);
                }
            });
        };

        document.body.appendChild(btn);
    }

    // Wait for page load
    setTimeout(createExportButton, 2000);
})();
