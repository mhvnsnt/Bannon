#!/bin/bash
# Pre-deployment integrity check and compression script for God-Mode OS Living Nexus

echo "============================================================="
echo "   GOD-MODE OS REALITY COMPILER DEPLOY PREPARATION"
echo "============================================================="

# 1. Run tsc --noEmit
echo "▶ Running TypeScript validation (tsc --noEmit)..."
npx tsc --noEmit
if [ $? -ne 0 ]; then
    echo "❌ TypeScript compilation errors detected. Halting export."
    exit 1
fi
echo "✅ TypeScript check successful. No errors found."

# 2. Run npm run build
echo "▶ Executing production build (npm run build)..."
npm run build
if [ $? -ne 0 ]; then
    echo "❌ Production build failed. Halting export."
    exit 1
fi
echo "✅ Production build successfully compiled."

# 3. Create zip of the project
TIMESTAMP=$(date +%s)
ZIP_NAME="godmode-os-${TIMESTAMP}.zip"
echo "▶ Creating deployment package: ${ZIP_NAME}..."

# Build exclude flags for zip
# Excluding node_modules, .git, dist, .env, and all SQLite files/directories (*.db, data/*.db, etc.)
zip -r "${ZIP_NAME}" . -x "node_modules/*" ".git/*" "dist/*" ".env" "*.db" "data/*.db" "database/*.db" ".env.example" "esbuild.log" > /dev/null

if [ $? -eq 0 ]; then
    FILE_SIZE=$(du -h "${ZIP_NAME}" | cut -f1)
    FILE_PATH=$(realpath "${ZIP_NAME}")
    echo "============================================================="
    echo "✅ EXPORT PACKAGE CREATED SUCCESSFULLY!"
    echo "📦 Path: ${FILE_PATH}"
    echo "💾 Size: ${FILE_SIZE}"
    echo "============================================================="
else
    echo "❌ Failed to create zip package. Ensure zip utility is installed."
fi

echo ""
echo "📢 REMINDER:"
echo 'Push "server.ts", "package.json", "nixpacks.toml", and "railway.json" to GitHub for Railway deploy.'
echo "UI components compiled inside your workspace do not affect Railway backend directly if not deployed via remote git."
echo "============================================================="
