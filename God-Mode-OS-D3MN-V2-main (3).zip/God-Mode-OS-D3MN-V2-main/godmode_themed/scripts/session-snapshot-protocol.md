# Unified Session Protocol

## End of Session Prompt Template
Paste this at the end of every Claude or AI Studio session when you hit a limit or are wrapping up:

```text
Before this session ends — give me a Session Snapshot for this project.
Format the output EXACTLY as a single JSON object with the following keys. Do not include extra conversational text outside the JSON block.

{
  "project": "project_name_here",
  "summary": "Brief explanation of what was built or decided.",
  "files_touched": ["file1.ts", "file2.tsx"],
  "key_decisions": "Exact locked-in logic, e.g. distinct hand paths for hooks/uppercuts and impact scaling logic",
  "next_target": "Exact concrete step to start the next session with"
}
```

## How to Export
1. Install [Tampermonkey](https://www.tampermonkey.net/) in your browser.
2. Create a new script and copy/paste the contents of `/scripts/tampermonkey-session-export.js`.
3. Save the script.
4. When Claude/Gemini generates the JSON from the prompt above:
   a. **Copy the JSON block to your clipboard**.
   b. Click the **"⚡ Export to God-Mode OS"** button that appears in the bottom right corner of Claude or AI Studio.
5. The script will read your clipboard and send it directly to your God-Mode OS backend (`/api/godmode/session-export`), saving it into the `godmode_unified_sessions` SQLite table.

## Start of Session Extraction
When you start a new session, query your local database or check the Nexus UI. Provide the last session's `key_decisions` and `next_target` to the new AI context so it picks up exactly where the last one left off.
