// src/server/modelRouter.ts
import { createRequire } from "module";

// src/server/geminiProxy.ts
import { GoogleGenAI as OriginalGoogleGenAI } from "@google/genai";
var sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
var globalBackoffUntil = 0;
async function retryWithBackoff(fn, retries = 10, delay = 5e3) {
  if (Date.now() < globalBackoffUntil) {
    throw new Error(`[Gemini] Rate limit backoff active \u2014 pausing for ${Math.ceil((globalBackoffUntil - Date.now()) / 1e3)}s`);
  }
  try {
    return await fn();
  } catch (error) {
    if ((error.status === 429 || error.code === 429 || error.message?.includes("429")) && retries > 0) {
      if (retries <= 8) {
        const now = Date.now();
        if (now - (globalBackoffUntil - 3e5) < 6e4) {
        } else {
        }
        globalBackoffUntil = Date.now() + 3e5;
        console.error("[Gemini] Rate limit backoff active \u2014 pausing for 5 minutes.");
        throw new Error(`[Gemini] Rate limit backoff active`);
      }
      let retryDelay = delay;
      try {
        const details = error.details || [];
        const retryInfo = details.find((d) => d["@type"]?.includes("RetryInfo"));
        if (retryInfo?.retryDelay) {
          const delayStr = retryInfo.retryDelay;
          if (typeof delayStr === "string" && delayStr.endsWith("s")) {
            retryDelay = parseInt(delayStr) * 1e3;
          } else if (typeof delayStr === "number") {
            retryDelay = delayStr * 1e3;
          }
          console.log(`[GoogleGenAI Proxy] Extracted retry delay: ${retryDelay}ms`);
        }
      } catch (e) {
        console.warn(`[GoogleGenAI Proxy] Failed to extract retry delay from error`, e);
      }
      retryDelay = Math.max(retryDelay, 5e3);
      console.warn(`[GoogleGenAI Proxy] Rate limit hit (429), retrying in ${retryDelay}ms... (Retries left: ${retries})`);
      await sleep(retryDelay);
      return retryWithBackoff(fn, retries - 1, retryDelay * 1.5);
    }
    throw error;
  }
}
var GoogleGenAI = class extends OriginalGoogleGenAI {
  constructor(config) {
    super(config);
    if (this.models) {
      const origGenerateContent = this.models.generateContent.bind(this.models);
      this.models.generateContent = async (params, ...args) => {
        if (params && params.model) {
          if (params.model === "gemini-1.5-flash" || params.model === "gemini-2.0-flash" || params.model === "gemini-2.0-flash-thinking" || params.model === "gemini-3.5-flash") {
            console.log(`[GoogleGenAI Proxy] Mapping model ${params.model} -> gemini-1.5-flash`);
            params.model = "gemini-1.5-flash";
          } else if (params.model === "gemini-1.5-pro" || params.model === "gemini-2.0-pro" || params.model === "gemini-pro-1.5" || params.model === "gemini-pro" || params.model === "gemini-3.1-pro-preview") {
            console.log(`[GoogleGenAI Proxy] Mapping model ${params.model} -> gemini-1.5-pro`);
            params.model = "gemini-1.5-pro";
          }
        }
        return retryWithBackoff(() => origGenerateContent(params, ...args));
      };
      const origGenerateContentStream = this.models.generateContentStream.bind(this.models);
      this.models.generateContentStream = async (params, ...args) => {
        if (params && params.model) {
          if (params.model === "gemini-1.5-flash" || params.model === "gemini-2.0-flash" || params.model === "gemini-2.0-flash-thinking" || params.model === "gemini-3.5-flash") {
            console.log(`[GoogleGenAI Proxy] Mapping stream model ${params.model} -> gemini-1.5-flash`);
            params.model = "gemini-1.5-flash";
          } else if (params.model === "gemini-1.5-pro" || params.model === "gemini-2.0-pro" || params.model === "gemini-pro-1.5" || params.model === "gemini-pro" || params.model === "gemini-3.1-pro-preview") {
            console.log(`[GoogleGenAI Proxy] Mapping stream model ${params.model} -> gemini-1.5-pro`);
            params.model = "gemini-1.5-pro";
          }
        }
        return retryWithBackoff(() => origGenerateContentStream(params, ...args));
      };
    }
  }
};

// src/server/db.ts
import Database from "better-sqlite3";
import path from "path";
var dbPath = path.resolve("bannon_physics.db");
var memoryVault = new Database(dbPath, { verbose: console.log });
memoryVault.pragma("journal_mode = WAL");
memoryVault.pragma("synchronous = NORMAL");
memoryVault.pragma("foreign_keys = ON");
console.log("\u2705 SQLite WAL mode enabled and DB initialized");

// src/server/embeddingEngine.ts
import crypto from "crypto";
var EmbeddingEngine = class {
  static cache = /* @__PURE__ */ new Map();
  // in-memory cache of embeddings
  static cacheKeys = [];
  // to manage LRU size of 500
  static totalRequests = 0;
  static cacheHits = 0;
  static totalLatencyMs = 0;
  static fallbackActive = false;
  static getEngineStats() {
    return {
      totalRequests: this.totalRequests,
      cacheHitRate: this.totalRequests > 0 ? this.cacheHits / this.totalRequests : 0,
      avgLatencyMs: this.totalRequests - this.cacheHits > 0 ? this.totalLatencyMs / (this.totalRequests - this.cacheHits) : 0,
      fallbackModeActive: this.fallbackActive
    };
  }
  // Helper hash for cache lookup
  static getContentHash(text) {
    return crypto.createHash("md5").update(text).digest("hex");
  }
  // Generate 768-dimension embedding
  static async embed(text) {
    this.totalRequests++;
    const key = this.getContentHash(text);
    if (this.cache.has(key)) {
      this.cacheHits++;
      const idx = this.cacheKeys.indexOf(key);
      if (idx !== -1) {
        this.cacheKeys.splice(idx, 1);
        this.cacheKeys.push(key);
      }
      return this.cache.get(key);
    }
    const start = Date.now();
    let embedding = [];
    if (!this.fallbackActive) {
      try {
        const response = await fetch("http://localhost:11434/api/embeddings", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            model: "nomic-embed-text",
            prompt: text
          }),
          // short timeout so we fallback quickly instead of hanging server
          signal: AbortSignal.timeout(1500)
        });
        if (response.ok) {
          const data = await response.json();
          if (data.embedding && Array.isArray(data.embedding)) {
            embedding = data.embedding;
          }
        } else {
          console.warn("[EmbeddingEngine] Ollama endpoint returned error. Using local TF-IDF fallback.");
        }
      } catch (e) {
        this.fallbackActive = true;
        console.warn("[EmbeddingEngine] Could not reach Ollama nomic-embed-text. Activating TF-IDF fallback.");
      }
    }
    if (embedding.length === 0) {
      embedding = this.fallbackEmbed(text);
    }
    this.totalLatencyMs += Date.now() - start;
    this.cache.set(key, embedding);
    this.cacheKeys.push(key);
    if (this.cacheKeys.length > 500) {
      const oldest = this.cacheKeys.shift();
      if (oldest) this.cache.delete(oldest);
    }
    return embedding;
  }
  // Batch process up to 32 texts in parallel
  static async embedBatch(texts) {
    const results = [];
    const batchSize = 32;
    for (let i = 0; i < texts.length; i += batchSize) {
      const chunk = texts.slice(i, i + batchSize);
      const promises = chunk.map((text) => this.embed(text));
      const chunkResults = await Promise.all(promises);
      results.push(...chunkResults);
    }
    return results;
  }
  // Compute Cosine Similarity between vector A and B
  static cosineSimilarity(vecA, vecB) {
    if (vecA.length !== vecB.length || vecA.length === 0) return 0;
    let dotProduct = 0;
    let normA = 0;
    let normB = 0;
    for (let i = 0; i < vecA.length; i++) {
      dotProduct += vecA[i] * vecB[i];
      normA += vecA[i] * vecA[i];
      normB += vecB[i] * vecB[i];
    }
    if (normA === 0 || normB === 0) return 0;
    return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
  }
  // Find top K candidates
  static findTopK(queryEmbedding, candidates, k) {
    const scored = candidates.map((cand) => ({
      item: cand.item,
      score: this.cosineSimilarity(queryEmbedding, cand.embedding)
    }));
    return scored.sort((a, b) => b.score - a.score).slice(0, k);
  }
  // Simple TF-IDF pseudo-embedding (768 dimensions)
  static fallbackEmbed(text) {
    const words = text.toLowerCase().replace(/[^\w\s@:-]/g, "").split(/\s+/).filter((w) => w.length > 2);
    const vec = new Array(768).fill(0);
    if (words.length === 0) {
      vec[0] = 1;
      return vec;
    }
    for (const word of words) {
      let hash = 0;
      for (let i = 0; i < word.length; i++) {
        hash = word.charCodeAt(i) + (hash << 5) - hash & 4294967295;
      }
      const idx = Math.abs(hash) % 768;
      vec[idx] += 1;
    }
    const mag = Math.sqrt(vec.reduce((sum, v) => sum + v * v, 0));
    if (mag > 0) {
      for (let i = 0; i < 768; i++) vec[i] /= mag;
    }
    return vec;
  }
  // Allow resetting fallback mode (e.g. if we want to retry connection)
  static resetFallback() {
    this.fallbackActive = false;
  }
};

// src/server/semanticSearch.ts
import crypto2 from "crypto";
function parseEmbedding(val) {
  if (!val) return [];
  if (typeof val === "string") {
    return JSON.parse(val);
  }
  if (Buffer.isBuffer(val)) {
    const str = val.toString("utf8");
    if (str.startsWith("[")) {
      return JSON.parse(str);
    }
    const floatArray = new Float32Array(val.buffer, val.byteOffset, val.length / 4);
    return Array.from(floatArray);
  }
  if (Array.isArray(val)) {
    return val;
  }
  return [];
}
var SemanticSearch = class {
  static isIndexing = false;
  static init() {
    this.watchAndIndex();
    setTimeout(() => {
      this.indexAll().catch((err) => console.error("[SemanticSearch] Initial sweep failed:", err));
    }, 3e3);
  }
  // Master index sweep method
  static async indexAll() {
    if (this.isIndexing) {
      return { tablesIndexed: 0, rowsAdded: 0, rowsSkipped: 0, durationMs: 0, engine: "Ollama/TF-IDF" };
    }
    this.isIndexing = true;
    const startTime = Date.now();
    const tables = [
      { name: "swarm_results", mapText: (row) => row.result || row.builder_output || row.optimizer_synthesis || "" },
      { name: "mind_log", mapText: (row) => row.think_output || [row.directive_intent, row.reasoning].filter(Boolean).join("\n") || "" },
      { name: "kinetic_logs", mapText: (row) => row.event_description || row.stage_transition || "" },
      { name: "dna_archive", mapText: (row) => (row.config || "") + "\n" + (row.performance_notes || "") || row.config_json || "" },
      { name: "quantum_conversations", mapText: (row) => row.message_content || row.messages || "" },
      { name: "overnight_log", mapText: (row) => (row.task || "") + "\n" + (row.result || "") },
      { name: "world_state", mapText: (row) => row.value || "" }
    ];
    let tablesIndexed = 0;
    let rowsAdded = 0;
    let rowsSkipped = 0;
    for (const tbl of tables) {
      try {
        const rows = memoryVault.prepare(`SELECT * FROM ${tbl.name}`).all();
        tablesIndexed++;
        for (const row of rows) {
          const text = tbl.mapText(row);
          if (!text || !text.trim()) continue;
          const contentHash = crypto2.createHash("md5").update(text).digest("hex");
          const rowId = row.id?.toString() || row.row_id?.toString() || "";
          if (!rowId) continue;
          const uuid = `${tbl.name}_${rowId}`;
          const existing = memoryVault.prepare(`SELECT content_hash FROM semantic_index WHERE id = ?`).get(uuid);
          if (existing && existing.content_hash === contentHash) {
            rowsSkipped++;
            continue;
          }
          const embedding = await EmbeddingEngine.embed(text);
          const tokenCount = Math.ceil(text.length / 4);
          memoryVault.prepare(`
            INSERT INTO semantic_index (id, source_table, source_id, content_hash, text_content, embedding, indexed_at, token_count)
            VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, ?)
            ON CONFLICT(id) DO UPDATE SET
              content_hash = excluded.content_hash,
              text_content = excluded.text_content,
              embedding = excluded.embedding,
              indexed_at = CURRENT_TIMESTAMP,
              token_count = excluded.token_count
          `).run(uuid, tbl.name, rowId, contentHash, text, Buffer.from(JSON.stringify(embedding)), tokenCount);
          rowsAdded++;
        }
      } catch (err) {
        console.warn(`[SemanticSearch] Table '${tbl.name}' indexing skipped or failed:`, err.message);
      }
    }
    this.isIndexing = false;
    const durationMs = Date.now() - startTime;
    const stats = EmbeddingEngine.getEngineStats();
    const engine = stats.fallbackModeActive ? "TF-IDF Fallback" : "Ollama nomic-embed-text";
    return {
      tablesIndexed,
      rowsAdded,
      rowsSkipped,
      durationMs,
      engine
    };
  }
  // Core Cosine Similarity Search
  static async search(query, options = {}) {
    try {
      const tables = options.tables;
      const limit = options.limit ?? 10;
      const minScore = options.minScore ?? 0.65;
      const queryEmbedding = await EmbeddingEngine.embed(query);
      let selectSql = `SELECT * FROM semantic_index`;
      let params = [];
      if (tables && tables.length > 0) {
        const placeholders = tables.map(() => "?").join(",");
        selectSql = `SELECT * FROM semantic_index WHERE source_table IN (${placeholders})`;
        params = tables;
      }
      const allEntries = memoryVault.prepare(selectSql).all(...params);
      const scoredResults = [];
      for (const entry of allEntries) {
        let embedding = [];
        try {
          embedding = parseEmbedding(entry.embedding);
        } catch {
          continue;
        }
        const score = EmbeddingEngine.cosineSimilarity(queryEmbedding, embedding);
        if (score >= minScore) {
          scoredResults.push({
            sourceTable: entry.source_table,
            sourceId: entry.source_id,
            content: entry.text_content || "",
            score,
            timestamp: entry.indexed_at || (/* @__PURE__ */ new Date()).toISOString(),
            tokenCount: entry.token_count || Math.ceil((entry.text_content || "").length / 4)
          });
        }
      }
      return scoredResults.sort((a, b) => b.score - a.score).slice(0, limit);
    } catch (err) {
      console.error("[SemanticSearch] Search exception:", err);
      return [];
    }
  }
  // Automated pattern matching for routing efficiency
  static async getCacheMatch(prompt) {
    const results = await this.search(prompt, { minScore: 0.96, limit: 1, tables: ["quantum_conversations"] });
    if (results.length > 0) {
      const row = memoryVault.prepare(`SELECT response FROM quantum_conversations WHERE id = ?`).get(results[0].sourceId);
      return row?.response || null;
    }
    return null;
  }
  // Curate contextual matches within token budgets using razor prioritization
  static async searchForContext(taskIntent, tokenBudget, tables) {
    const allMatches = await this.search(taskIntent, { minScore: 0.2, limit: 50, tables });
    const results = [];
    let tokenEstimate = 0;
    const tablesHitSet = /* @__PURE__ */ new Set();
    for (const match of allMatches) {
      const matchTokens = match.tokenCount || Math.ceil(match.content.length / 4);
      if (tokenEstimate + matchTokens <= tokenBudget) {
        results.push(match);
        tokenEstimate += matchTokens;
        tablesHitSet.add(match.sourceTable);
      }
    }
    if (results.length === 0) {
      nexusBus.emit("SEARCH_ZERO_RESULTS", { query: taskIntent });
      console.log(`[SemanticSearch] 0 semantic results for taskIntent '${taskIntent}'. Entering keyword match fallback...`);
      const words = taskIntent.split(/\s+/).filter((w) => w.trim().length > 3);
      if (words.length > 0) {
        const queryTerms = words.map(() => "text_content LIKE ?").join(" OR ");
        const selectSql = `SELECT * FROM semantic_index WHERE ${queryTerms}`;
        const params = words.map((w) => `%${w}%`);
        try {
          const entryRows = memoryVault.prepare(selectSql).all(...params);
          for (const entry of entryRows) {
            const matchTokens = entry.token_count || Math.ceil((entry.text_content || "").length / 4);
            if (tokenEstimate + matchTokens <= tokenBudget) {
              results.push({
                sourceTable: entry.source_table,
                sourceId: entry.source_id,
                content: entry.text_content || "",
                score: 0.5,
                timestamp: entry.indexed_at || (/* @__PURE__ */ new Date()).toISOString(),
                tokenCount: matchTokens
              });
              tokenEstimate += matchTokens;
              tablesHitSet.add(entry.source_table);
            }
          }
        } catch (e) {
          console.error("[SemanticSearch] Keyword fallback search failed:", e);
        }
      }
    }
    return {
      results,
      tablesHit: Array.from(tablesHitSet),
      tokenEstimate,
      query: taskIntent
    };
  }
  // Obtain statistics of indexes per source table
  static async getIndexCoverage() {
    const tables = ["swarm_results", "mind_log", "kinetic_logs", "dna_archive", "quantum_conversations", "overnight_log", "world_state"];
    const report = {
      tables: {}
    };
    const stats = EmbeddingEngine.getEngineStats();
    for (const table of tables) {
      try {
        const totalRow = memoryVault.prepare(`SELECT count(*) as count FROM ${table}`).get();
        const totalRows = totalRow ? totalRow.count : 0;
        const indexedRow = memoryVault.prepare(`SELECT count(*) as count FROM semantic_index WHERE source_table = ?`).get(table);
        const indexedRows = indexedRow ? indexedRow.count : 0;
        const lastIndexedRow = memoryVault.prepare(`SELECT max(indexed_at) as last FROM semantic_index WHERE source_table = ?`).get(table);
        const lastIndexedAt = lastIndexedRow?.last || "N/A";
        const coveragePct = totalRows > 0 ? indexedRows / totalRows * 100 : 100;
        if (coveragePct < 70 && totalRows > 0) {
          nexusBus.emit("INDEX_COVERAGE_LOW", { table, coveragePct });
        }
        report.tables[table] = {
          totalRows,
          indexedRows,
          coveragePct,
          lastIndexedAt,
          stats_val: null
        };
        report.tables[table] = {
          totalRows,
          indexedRows,
          coveragePct,
          lastIndexedAt,
          avgLatencyMs: stats.avgLatencyMs > 0 ? Math.round(stats.avgLatencyMs) : 85
        };
      } catch (err) {
        report.tables[table] = {
          totalRows: 0,
          indexedRows: 0,
          coveragePct: 0,
          lastIndexedAt: "N/A",
          avgLatencyMs: 0
        };
      }
    }
    return report;
  }
  // Automated spine-wire callbacks for indexing
  static watchAndIndex() {
    console.log("[SemanticSearch] Attaching real-time incremental codebase and cognitive indexing listeners...");
    nexusBus.on("MIND_THINK_COMPLETE", async (event) => {
      try {
        const id = event?.id || event?.rowId;
        let row;
        if (id) {
          row = memoryVault.prepare(`SELECT * FROM mind_log WHERE id = ?`).get(id);
        } else {
          row = memoryVault.prepare(`SELECT * FROM mind_log ORDER BY timestamp DESC LIMIT 1`).get();
        }
        if (row) {
          const text = row.think_output || [row.directive_intent, row.reasoning].filter(Boolean).join("\n") || "";
          await this.indexNewEntry("mind_log", row.id.toString(), text);
        }
      } catch (e) {
        console.error("[SemanticSearch] MIND_THINK_COMPLETE indexing failed:", e);
      }
    });
    nexusBus.on("SWARM_JOB_COMPLETE", async (event) => {
      try {
        const id = event?.rowId || event?.id || event?.jobId;
        let row;
        if (id) {
          row = memoryVault.prepare(`SELECT * FROM swarm_results WHERE id = ? OR task_id = ?`).get(id, id);
        } else {
          row = memoryVault.prepare(`SELECT * FROM swarm_results ORDER BY timestamp DESC LIMIT 1`).get();
        }
        if (row) {
          const text = row.result || [row.builder_output, row.optimizer_synthesis].filter(Boolean).join("\n") || "";
          await this.indexNewEntry("swarm_results", row.id.toString(), text);
        }
      } catch (e) {
        console.error("[SemanticSearch] SWARM_JOB_COMPLETE indexing failed:", e);
      }
    });
    nexusBus.on("FILE_MODIFIED", async (event) => {
      try {
        const id = event?.id || event?.rowId || event?.filePath;
        let row;
        if (id) {
          row = memoryVault.prepare(`SELECT * FROM kinetic_logs WHERE id = ?`).get(id);
        } else {
          row = memoryVault.prepare(`SELECT * FROM kinetic_logs ORDER BY timestamp DESC LIMIT 1`).get();
        }
        if (row) {
          const text = row.event_description || row.stage_transition || "";
          await this.indexNewEntry("kinetic_logs", row.id.toString(), text);
        }
      } catch (e) {
        console.error("[SemanticSearch] FILE_MODIFIED indexing failed:", e);
      }
    });
    nexusBus.on("DNA_PROMOTED", async (event) => {
      try {
        const id = event?.id || event?.rowId;
        let row;
        if (id) {
          row = memoryVault.prepare(`SELECT * FROM dna_archive WHERE id = ?`).get(id);
        } else {
          row = memoryVault.prepare(`SELECT * FROM dna_archive ORDER BY timestamp DESC LIMIT 1`).get();
        }
        if (row) {
          const text = (row.config || "") + "\n" + (row.performance_notes || "") || row.config_json || "";
          await this.indexNewEntry("dna_archive", row.id.toString(), text);
        }
      } catch (e) {
        console.error("[SemanticSearch] DNA_PROMOTED indexing failed:", e);
      }
    });
    nexusBus.on("OVERNIGHT_TASK_COMPLETE", async (event) => {
      try {
        const id = event?.id || event?.rowId;
        let row;
        if (id) {
          row = memoryVault.prepare(`SELECT * FROM overnight_log WHERE id = ?`).get(id);
        } else {
          row = memoryVault.prepare(`SELECT * FROM overnight_log ORDER BY started_at DESC LIMIT 1`).get();
        }
        if (row) {
          const text = (row.task || "") + "\n" + (row.result || "");
          await this.indexNewEntry("overnight_log", row.id.toString(), text);
        }
      } catch (e) {
        console.error("[SemanticSearch] OVERNIGHT_TASK_COMPLETE indexing failed:", e);
      }
    });
  }
  // Local helper for target indexing
  static async indexNewEntry(tableName, rowId, textToEmbed) {
    if (!textToEmbed || !textToEmbed.trim()) return false;
    try {
      const contentHash = crypto2.createHash("md5").update(textToEmbed).digest("hex");
      const uuid = `${tableName}_${rowId}`;
      const existing = memoryVault.prepare(`SELECT content_hash FROM semantic_index WHERE id = ?`).get(uuid);
      if (existing && existing.content_hash === contentHash) {
        return false;
      }
      const embedding = await EmbeddingEngine.embed(textToEmbed);
      const tokenCount = Math.ceil(textToEmbed.length / 4);
      memoryVault.prepare(`
        INSERT INTO semantic_index (id, source_table, source_id, content_hash, text_content, embedding, indexed_at, token_count)
        VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, ?)
        ON CONFLICT(id) DO UPDATE SET
          content_hash = excluded.content_hash,
          text_content = excluded.text_content,
          embedding = excluded.embedding,
          indexed_at = CURRENT_TIMESTAMP,
          token_count = excluded.token_count
      `).run(uuid, tableName, rowId, contentHash, textToEmbed, Buffer.from(JSON.stringify(embedding)), tokenCount);
      return true;
    } catch (err) {
      console.error(`[SemanticSearch] Failed to index new entry for ${tableName}:${rowId}:`, err);
      return false;
    }
  }
  // File-specific indexing for content search
  static async indexFileContent(filePath, content) {
    return await this.indexNewEntry("files", filePath, content);
  }
  // Retrieve search stats
  static getIndexStats() {
    try {
      const row = memoryVault.prepare(`SELECT count(*) as count FROM semantic_index`).get();
      const totalIndexed = row ? row.count : 0;
      const lastUpdate = memoryVault.prepare(`SELECT max(indexed_at) as last FROM semantic_index`).get();
      return {
        totalIndexed,
        lastUpdate: lastUpdate ? lastUpdate.last : "N/A"
      };
    } catch {
      return { totalIndexed: 0, lastUpdate: "N/A" };
    }
  }
};
SemanticSearch.init();

// src/server/modelRouter.ts
import { EventEmitter as EventEmitter2 } from "events";
import fs2 from "fs";
import path3 from "path";

// src/server/observability.ts
import { EventEmitter } from "events";
import * as admin from "firebase-admin";
import { getFirestore } from "firebase-admin/firestore";
import * as fs from "fs";
import * as path2 from "path";
var logEmitter = new EventEmitter();
var cachedFirestoreDB = null;
var isFirestoreApiDisabled = false;
var MockFirestoreDB = class {
  collection(name) {
    return new class MockCollectionReference {
      name;
      constructor(n) {
        this.name = n;
      }
      doc(id) {
        return new class MockDocumentReference {
          collectionName;
          id;
          constructor(c, d) {
            this.collectionName = c;
            this.id = d;
          }
          async set(data, options) {
            return {};
          }
          async update(data) {
            return {};
          }
          async delete() {
            return {};
          }
          async get() {
            return {
              exists: false,
              data: () => null,
              id: this.id
            };
          }
        }(this.name, id || "mock-id");
      }
      orderBy() {
        return this;
      }
      limit() {
        return this;
      }
      where() {
        return this;
      }
      startAfter() {
        return this;
      }
      async get() {
        return {
          exists: false,
          docs: [],
          forEach: (cb) => {
          }
        };
      }
    }(name);
  }
};
function createResilientFirestoreProxy(realDb) {
  return new Proxy(realDb, {
    get(target, prop, receiver) {
      if (prop === "collection") {
        return function(collectionName) {
          if (isFirestoreApiDisabled) {
            return new MockFirestoreDB().collection(collectionName);
          }
          try {
            const realCollection = target.collection(collectionName);
            return new Proxy(realCollection, {
              get(colTarget, colProp) {
                const originalVal = colTarget[colProp];
                if (typeof originalVal === "function") {
                  return function(...args) {
                    if (colProp === "doc") {
                      try {
                        const realDoc = originalVal.apply(colTarget, args);
                        return new Proxy(realDoc, {
                          get(docTarget, docProp) {
                            const originalDocVal = docTarget[docProp];
                            if (typeof originalDocVal === "function") {
                              return function(...docArgs) {
                                if (["set", "update", "delete", "get"].includes(docProp)) {
                                  try {
                                    return originalDocVal.apply(docTarget, docArgs).catch((err) => {
                                      console.warn(`[OBSERVABILITY BYPASS] Logged error on document ${docProp}:`, err.message);
                                      if (err.message && (err.message.includes("PERT_DENIED") || err.message.includes("PERMISSION_DENIED") || err.message.includes("not been used") || err.message.includes("disabled"))) {
                                        console.warn("[OBSERVABILITY BYPASS] Cloud Firestore API disabled in this project. Dynamically diverting all database traffic to high-resiliency backup mocks.");
                                        isFirestoreApiDisabled = true;
                                      }
                                      if (docProp === "get") {
                                        return { exists: false, data: () => null, id: docTarget.id };
                                      }
                                      return {};
                                    });
                                  } catch (err) {
                                    return Promise.resolve(docProp === "get" ? { exists: false, data: () => null, id: docTarget.id } : {});
                                  }
                                }
                                return originalDocVal.apply(docTarget, docArgs);
                              };
                            }
                            return originalDocVal;
                          }
                        });
                      } catch (docErr) {
                        return new MockFirestoreDB().collection(collectionName).doc(args[0]);
                      }
                    }
                    if (["get", "add"].includes(colProp)) {
                      try {
                        return originalVal.apply(colTarget, args).catch((err) => {
                          console.warn(`[OBSERVABILITY BYPASS] Logged error on collection ${colProp}:`, err.message);
                          if (err.message && (err.message.includes("PERMISSION_DENIED") || err.message.includes("not been used") || err.message.includes("disabled"))) {
                            console.warn("[OBSERVABILITY BYPASS] Cloud Firestore API disabled in this project. Dynamically diverting all database traffic to high-resiliency backup mocks.");
                            isFirestoreApiDisabled = true;
                          }
                          if (colProp === "get") {
                            return { exists: false, docs: [], forEach: () => {
                            } };
                          }
                          return {};
                        });
                      } catch (err) {
                        return Promise.resolve(colProp === "get" ? { exists: false, docs: [], forEach: () => {
                        } } : {});
                      }
                    }
                    try {
                      const queryResult = originalVal.apply(colTarget, args);
                      if (queryResult && typeof queryResult.get === "function") {
                        return new Proxy(queryResult, {
                          get(qTarget, qProp) {
                            const qVal = qTarget[qProp];
                            if (typeof qVal === "function") {
                              return function(...qArgs) {
                                if (qProp === "get") {
                                  try {
                                    return qVal.apply(qTarget, qArgs).catch((err) => {
                                      console.warn(`[OBSERVABILITY BYPASS] Logged error on query get:`, err.message);
                                      if (err.message && (err.message.includes("PERMISSION_DENIED") || err.message.includes("not been used") || err.message.includes("disabled"))) {
                                        console.warn("[OBSERVABILITY BYPASS] Cloud Firestore API disabled. Activating local mock memory matrix.");
                                        isFirestoreApiDisabled = true;
                                      }
                                      return { exists: false, docs: [], forEach: () => {
                                      } };
                                    });
                                  } catch (err) {
                                    return Promise.resolve({ exists: false, docs: [], forEach: () => {
                                    } });
                                  }
                                }
                                const chainResult = qVal.apply(qTarget, qArgs);
                                return chainResult;
                              };
                            }
                            return qVal;
                          }
                        });
                      }
                      return queryResult;
                    } catch (queryErr) {
                      return new MockFirestoreDB().collection(collectionName);
                    }
                  };
                }
                return originalVal;
              }
            });
          } catch (colErr) {
            return new MockFirestoreDB().collection(collectionName);
          }
        };
      }
      return Reflect.get(target, prop, receiver);
    }
  });
}
function getFirestoreDB() {
  if (cachedFirestoreDB) {
    if (isFirestoreApiDisabled) {
      return new MockFirestoreDB();
    }
    return cachedFirestoreDB;
  }
  if (admin.apps?.length) {
    try {
      const configPath = path2.join(process.cwd(), "firebase-applet-config.json");
      if (fs.existsSync(configPath)) {
        const config = JSON.parse(fs.readFileSync(configPath, "utf8"));
        if (config.firestoreDatabaseId) {
          const dbInstance = getFirestore(admin.apps[0], config.firestoreDatabaseId);
          if (dbInstance && typeof dbInstance.collection === "function") {
            cachedFirestoreDB = createResilientFirestoreProxy(dbInstance);
            return cachedFirestoreDB;
          }
        }
      }
    } catch (e) {
      console.warn("Failed to retrieve custom databaseId, falling back to default:", e);
    }
    try {
      const dbInstance = admin.firestore();
      if (dbInstance && typeof dbInstance.collection === "function") {
        cachedFirestoreDB = createResilientFirestoreProxy(dbInstance);
        return cachedFirestoreDB;
      }
    } catch (e) {
      console.warn("admin.firestore() fallback failed:", e);
    }
  }
  return null;
}
var logCache = [];
async function logObservabilityEvent(type, message, status = "success", details) {
  const logEvent = {
    id: "ob-" + Date.now() + "-" + Math.random().toString(36).substr(2, 5),
    type,
    message,
    status,
    details: details ? typeof details === "object" ? details : { raw: details } : {},
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  };
  logCache.unshift(logEvent);
  if (logCache.length > 500) logCache.pop();
  logEmitter.emit("new-log", logEvent);
  try {
    const db = getFirestoreDB();
    if (db) {
      await db.collection("observability_logs").doc(logEvent.id).set({
        ...logEvent,
        timestamp: admin.firestore.FieldValue.serverTimestamp()
      });
    }
  } catch (err) {
    console.error("[OBSERVABILITY ENGINE] Failed to persist log to Firestore:", err.message);
  }
  return logEvent;
}

// src/server/modelRouter.ts
var require2 = typeof import.meta !== "undefined" && import.meta.url ? createRequire(import.meta.url) : require2;
var nexusBus = new EventEmitter2();
function normalizeModelName(model) {
  let clean = model.replace(/^google\//, "");
  if (clean === "gemini-1.5-flash" || clean === "gemini-2.0-flash" || clean === "gemini-2.0-flash-thinking") {
    return "gemini-1.5-flash";
  }
  if (clean === "gemini-1.5-pro" || clean === "gemini-2.0-pro" || clean === "gemini-pro-1.5" || clean === "gemini-pro") {
    return "gemini-1.5-pro";
  }
  return clean;
}
var ModelRouter = class {
  dailyBudgetUSD = 50;
  // default budget guard
  currentSpend = 0;
  forcedProvider = null;
  isCheckingHealth = false;
  ollamaStatus = {
    online: false,
    modelsAvailable: [],
    gpuMemoryFree: 100,
    currentLoad: 0
  };
  ollamaUrl = process.env.OLLAMA_URL || "http://127.0.0.1:11434";
  requiredLocalModels = [
    "llama3.1:70b",
    "mistral:7b",
    "deepseek-coder-v2",
    "qwen2.5:7b",
    "nomic-embed-text"
  ];
  constructor() {
    this.startHealthCheckLoop();
  }
  startHealthCheckLoop() {
    this.localHealthCheck().catch((err) => {
      console.warn("[ModelRouter] Initial local health check warning:", err.message);
    });
    setInterval(() => {
      this.localHealthCheck().catch((err) => {
        console.warn("[ModelRouter] Periodic local health check warning:", err.message);
      });
    }, 6e4);
  }
  setLocalNodeUrl(url) {
    this.ollamaUrl = url;
    console.log(`[ModelRouter] Local primary endpoint updated to: ${url}`);
    this.localHealthCheck();
  }
  getStatusForBar() {
    let readyToTrain = false;
    try {
      const { FineTuneCollector } = require2("./fineTuneCollector");
      const counts = FineTuneCollector.getFileCounts();
      readyToTrain = counts.swarm > 500 || counts.overnight > 500 || counts.mind > 500 || counts.dna > 500;
    } catch (e) {
    }
    return {
      online: this.ollamaStatus.online,
      availableCount: this.ollamaStatus.modelsAvailable.filter((m) => this.requiredLocalModels.includes(m)).length,
      totalCount: this.requiredLocalModels.length,
      allModels: this.ollamaStatus.modelsAvailable,
      requiredModels: this.requiredLocalModels,
      readyToTrain
    };
  }
  async localHealthCheck() {
    if (this.isCheckingHealth) return this.ollamaStatus;
    this.isCheckingHealth = true;
    try {
      const url = `${this.ollamaUrl}/api/tags`;
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 4e3);
      const res = await fetch(url, { signal: controller.signal });
      clearTimeout(timeout);
      if (!res.ok) {
        throw new Error(`Ollama returned status ${res.status}`);
      }
      const data = await res.json();
      const installedModels = (data.models || []).map((m) => m.name.split(":")[0] === m.name ? m.name : m.name);
      const available = [];
      for (const req of this.requiredLocalModels) {
        const found = (data.models || []).some(
          (m) => m.name.toLowerCase().includes(req.toLowerCase()) || req.toLowerCase().includes(m.name.toLowerCase())
        );
        if (found) {
          available.push(req);
        }
      }
      const wasOffline = !this.ollamaStatus.online;
      this.ollamaStatus = {
        online: true,
        modelsAvailable: available,
        gpuMemoryFree: 82,
        // mock metric logic
        currentLoad: Math.floor(Math.random() * 25)
        // mock loader
      };
      if (wasOffline) {
        console.log("[ModelRouter] Ollama node connection re-established. Local primary armed.");
        nexusBus.emit("LOCAL_RESTORED");
      }
    } catch (err) {
      if (this.ollamaStatus.online) {
        console.warn("[ModelRouter] Primary Ollama connection severed. Emitting LOCAL_OFFLINE.");
        nexusBus.emit("LOCAL_OFFLINE");
      }
      this.ollamaStatus = {
        online: false,
        modelsAvailable: [],
        gpuMemoryFree: 0,
        currentLoad: 0
      };
    } finally {
      this.isCheckingHealth = false;
    }
    return this.ollamaStatus;
  }
  /**
   * Main routing matrix decision block
   */
  async route(req) {
    const { prompt, taskType, context, taskId = "task_" + Date.now(), webRequired = false, heavyHardwareLoad = false } = req;
    try {
      const cachedResponse = await SemanticSearch.getCacheMatch(prompt);
      if (cachedResponse) {
        console.log(`[ModelRouter] TIER 0 [CACHE HIT]: Returning cached response for taskId [${taskId}]`);
        return cachedResponse;
      }
    } catch (e) {
      console.warn("[ModelRouter] Error checking semantic cache:", e);
    }
    this.updateDailySpend();
    const mappedTier = this.mapTaskTypeToTier(taskType);
    if (this.forcedProvider) {
      console.log(`[ModelRouter] Provider override active: ${this.forcedProvider}`);
      return this.callProvider(this.forcedProvider, prompt, taskType, false, mappedTier, taskId, "Forced Provider Override", void 0, context);
    }
    const apiModelName = this.getAPIModelForTier(mappedTier);
    let runAPI = true;
    let overflowReason = "";
    if (runAPI) {
      try {
        console.log(`[ModelRouter] TIER 1 [API]: Routing task [${taskType}] to ${apiModelName}`);
        const providerName = apiModelName.startsWith("anthropic") ? "anthropic" : apiModelName.startsWith("google") ? "google-fallback" : "openrouter";
        let hasKey = true;
        if (providerName === "anthropic" && !process.env.ANTHROPIC_API_KEY) {
          hasKey = false;
        } else if (providerName === "openrouter" && !process.env.OPENROUTER_API_KEY && !process.env.OrionHavwsteeOoenrouterapikey) {
          hasKey = false;
        }
        if (!hasKey) {
          throw new Error(`API key for ${providerName} is not configured.`);
        }
        const response = await this.callProvider(providerName, prompt, taskType, false, mappedTier, taskId, "", apiModelName, context);
        return response;
      } catch (err) {
        overflowReason = `API Crash/Limit hit: ${err.message}. Overflowing.`;
        console.warn(`[ModelRouter] ${overflowReason}`);
      }
    }
    try {
      const hasOpenRouterKey = !!(process.env.OPENROUTER_API_KEY || process.env.OrionHavwsteeOoenrouterapikey);
      if (!hasOpenRouterKey) {
        throw new Error("OpenRouter API key is not configured.");
      }
      console.log(`[ModelRouter] TIER 2 [OPENROUTER FALLBACK]: Routing task [${taskType}] due to: ${overflowReason}`);
      const response = await this.callProvider("openrouter", prompt, taskType, true, mappedTier, taskId, overflowReason, void 0, context);
      return response;
    } catch (err) {
      overflowReason = `OpenRouter Overflow failure: ${err.message}. Routing to Local.`;
      console.warn(`[ModelRouter] ${overflowReason}`);
    }
    let localModelName = this.getLocalModelForTier(mappedTier);
    if (!this.ollamaStatus.online) {
      overflowReason = `Ollama local node is offline. (${overflowReason})`;
    } else {
      try {
        console.log(`[ModelRouter] TIER 3 [LOCAL OLLAMA]: Routing task [${taskType}] to ${localModelName}`);
        return await this.callProvider("local-ollama", prompt, taskType, true, mappedTier, taskId, overflowReason, void 0, context);
      } catch (err) {
        overflowReason = `Local model execution crash: ${err.message}.`;
        console.error(`[ModelRouter] Tier 3 Local Crash: ${err.message}`);
      }
    }
    try {
      console.log(`[ModelRouter] TIER 4 [ULTIMATE GOOGLE GEMINI FALLBACK]: Routing task [${taskType}] due to: ${overflowReason}`);
      return await this.callProvider("google-fallback", prompt, taskType, true, mappedTier, taskId, overflowReason, "gemini-1.5-flash", context);
    } catch (err) {
      console.error(`[ModelRouter] Ultimate Google Fallback critical failure: ${err.message}`);
      return `[ERROR_ROUTING_FAILED] All AI Router Tiers exhausted. Error: ${err.message}`;
    }
  }
  mapTaskTypeToTier(taskType) {
    const type = taskType.toUpperCase();
    if (type.includes("BUG_FIX") || type.includes("ERROR_FIX") || type.includes("TELEMETRY")) {
      return "HIGH_REASONING";
    }
    if (type.includes("QUICK_EDIT") || type.includes("TWEAK")) {
      return "QUICK_EDIT";
    }
    if (type.includes("EXPLAIN") || type.includes("EXPLANATION") || type.includes("DOCUMENT")) {
      return "EXPLANATION";
    }
    if (type.includes("CHAT") || type.includes("INTENT")) {
      return "INTENT_ACTION";
    }
    if (type.includes("ARCHITECTURE") || type.includes("THINK") || type.includes("ADJUDICATOR") || type.includes("REASONING")) {
      return "HIGH_REASONING";
    }
    if (type.includes("BUILD") || type.includes("GEN") || type.includes("REVIEW") || type.includes("DIFF") || type.includes("CODE_EDIT")) {
      return "CODE_GEN";
    }
    if (type.includes("SWARM") || type.includes("WORKER") || type.includes("AGENT")) {
      return "SWARM_WORKER";
    }
    if (type.includes("OVERNIGHT") || type.includes("BULK") || type.includes("DAEMON")) {
      return "OVERNIGHT_TASK";
    }
    if (type.includes("METAPHYSICAL") || type.includes("CHALLENGER")) {
      return "METAPHYSICAL";
    }
    if (type.includes("ANALYSIS") || type.includes("DEEP")) {
      return "DEEP_ANALYSIS";
    }
    return "HIGH_REASONING";
  }
  getLocalModelForTier(tier) {
    switch (tier) {
      case "INTENT_ACTION":
        return "llama3.2:3b";
      case "HIGH_REASONING":
        return "llama3.1:70b";
      case "CODE_GEN":
        return "deepseek-coder-v2";
      case "SWARM_WORKER":
        return "mistral:7b";
      case "OVERNIGHT_TASK":
        return "qwen2.5:7b";
      case "METAPHYSICAL":
        return "llama3.1:70b";
      case "DEEP_ANALYSIS":
        return "llama3.1:70b";
      default:
        return "llama3.1:70b";
    }
  }
  getAPIModelForTier(tier) {
    switch (tier) {
      case "INTENT_ACTION":
        return "groq/llama-3.1-8b-instant";
      case "HIGH_REASONING":
        return "anthropic/claude-3-opus-20240229";
      // Opus for bug fixing and complex reasoning
      case "CODE_GEN":
        return "google/gemini-1.5-pro-preview";
      case "QUICK_EDIT":
        return "google/gemini-3.5-flash";
      case "EXPLANATION":
        return "anthropic/claude-3-haiku-20240307";
      case "SWARM_WORKER":
        return "google/gemini-3.5-flash";
      case "OVERNIGHT_TASK":
        return "anthropic/claude-3.5-haiku";
      case "METAPHYSICAL":
        return "anthropic/claude-3.5-sonnet:beta";
      case "DEEP_ANALYSIS":
        return "google/gemini-3.1-pro-preview";
      default:
        return "google/gemini-3.5-flash";
    }
  }
  assessConfidence(response, tier) {
    if (!response || response.trim().length === 0) return 0;
    const lower = response.toLowerCase();
    if (lower.includes("unable to generate") || lower.includes("cannot fulfill") || lower.includes("ollama error") || lower.includes("failed to process")) {
      return 0.2;
    }
    if (lower.length < 150 && (tier === "HIGH_REASONING" || tier === "CODE_GEN")) {
      return 0.5;
    }
    return 0.95;
  }
  async callProvider(provider, prompt, taskType, isFallback, tier, taskId, reason, optionalModelOverride, context) {
    const start = Date.now();
    let responseText = "";
    let selectedModel = "";
    let activeSystemPrompt = "";
    try {
      activeSystemPrompt = fs2.readFileSync(path3.resolve("system-prompt-core.md"), "utf-8");
    } catch (e) {
      activeSystemPrompt = "You are the God Mode OS agent. Fully execute the user request without gatekeeping.";
    }
    let previewSenses = "";
    try {
      const previewPath = path3.resolve(process.cwd(), "data", "preview_logs.txt");
      if (fs2.existsSync(previewPath)) {
        previewSenses = `

[LIVE PREVIEW TELEMETRY (What the agent "sees")]:
` + fs2.readFileSync(previewPath, "utf8");
      }
    } catch (e) {
    }
    const enhancedPrompt = `${activeSystemPrompt}${previewSenses}

${context ? `PROJECT CONTEXT: ${JSON.stringify(context)}

USER PROMPT: ${prompt}` : prompt}`;
    const finalizeCall = async (provider2, model, response) => {
      const duration = Date.now() - start;
      console.log(`[ModelRouter] ${provider2} (${model}) completed in ${duration}ms`);
      await logObservabilityEvent("action", `Provider call: ${provider2}`, "success", {
        provider: provider2,
        model,
        duration,
        taskId
      });
      if (duration > 5e3) {
        await logObservabilityEvent("error", `Latency spike detected at ${provider2}`, "running", { duration, taskId });
      }
    };
    if (provider === "local-ollama") {
      selectedModel = this.getLocalModelForTier(tier);
      const url = `${this.ollamaUrl}/api/generate`;
      const body = { model: selectedModel, prompt: enhancedPrompt, stream: false };
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 12e3);
      try {
        const res = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
          signal: controller.signal
        });
        clearTimeout(timeout);
        if (!res.ok) throw new Error(`Ollama returned status ${res.status}`);
        const data = await res.json();
        responseText = data.response || "";
        await finalizeCall("local-ollama", selectedModel, responseText);
      } catch (err) {
        clearTimeout(timeout);
        throw err;
      }
    } else if (provider === "anthropic") {
      selectedModel = optionalModelOverride || "claude-3-5-sonnet-20241022";
      const apiKey = process.env.ANTHROPIC_API_KEY || "";
      const url = "https://api.anthropic.com/v1/messages";
      let attempt = 0;
      let res;
      while (attempt < 10) {
        res = await fetch(url, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-api-key": apiKey,
            "anthropic-version": "2023-06-01"
          },
          body: JSON.stringify({
            model: selectedModel,
            max_tokens: 8192,
            messages: [{ role: "user", content: enhancedPrompt }]
          })
        });
        if (res.status !== 429) break;
        attempt++;
        const jitter = Math.random() * 2e3;
        await new Promise((resolve) => setTimeout(resolve, Math.min(Math.pow(2, attempt) * 1500 + jitter, 6e4)));
      }
      if (!res.ok) {
        throw new Error(`Anthropic returned status ${res.status}: ${await res.text()}`);
      }
      const data = await res.json();
      responseText = data.content?.map((b) => b.text || "").join("") || "";
    } else if (provider === "openrouter") {
      selectedModel = optionalModelOverride || this.getAPIModelForTier(tier);
      const apiKey = process.env.OPENROUTER_API_KEY || process.env.OrionHavwsteeOoenrouterapikey || "";
      const url = "https://openrouter.ai/api/v1/chat/completions";
      let attempt = 0;
      let res;
      while (attempt < 10) {
        res = await fetch(url, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${apiKey}`
          },
          body: JSON.stringify({
            model: selectedModel,
            messages: [{ role: "user", content: enhancedPrompt }]
          })
        });
        if (res.status !== 429) break;
        attempt++;
        const jitter = Math.random() * 2e3;
        await new Promise((resolve) => setTimeout(resolve, Math.min(Math.pow(2, attempt) * 1500 + jitter, 6e4)));
      }
      if (!res.ok) {
        throw new Error(`OpenRouter returned status ${res.status}`);
      }
      const data = await res.json();
      responseText = data.choices?.[0]?.message?.content || "";
    } else if (provider === "google-fallback") {
      selectedModel = normalizeModelName(optionalModelOverride || "gemini-3.5-flash");
      const apiKey = process.env.GEMINI_API_KEY || "";
      if (!apiKey) {
        throw new Error("GEMINI_API_KEY is missing/empty");
      }
      const ai = new GoogleGenAI({ apiKey });
      try {
        const response = await ai.models.generateContent({
          model: selectedModel,
          contents: [{ parts: [{ text: enhancedPrompt }] }]
        });
        responseText = response.text || "";
      } catch (err) {
        if (selectedModel !== "gemini-3.5-flash") {
          console.warn(`Fallback to default gemini-3.5-flash due to: ${err.message}`);
          const response = await ai.models.generateContent({
            model: "gemini-3.5-flash",
            contents: [{ parts: [{ text: enhancedPrompt }] }]
          });
          responseText = response.text || "";
        } else {
          throw err;
        }
      }
    } else {
      selectedModel = provider;
      responseText = `Forced local diagnostic pass for model ${selectedModel}`;
    }
    const latency = Date.now() - start;
    const tokensIn = Math.ceil(prompt.length / 4);
    const tokensOut = Math.ceil(responseText.length / 4);
    const calculatedCost = this.estimateCost(provider, selectedModel, tokensIn, tokensOut);
    const statusVal = responseText ? "SUCCESS" : "FAILED";
    const errVal = responseText ? null : "Empty response generated";
    try {
      memoryVault.prepare(`
        INSERT INTO model_router_log 
        (provider_selected, was_fallback, task_type, latency_ms, tokens_in, tokens_out, estimated_cost, status, error_message) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(provider, isFallback ? 1 : 0, taskType, latency, tokensIn, tokensOut, calculatedCost, statusVal, errVal);
    } catch (e) {
      console.warn("[ModelRouter] Warning writing to model_router_log:", e.message);
    }
    try {
      memoryVault.prepare(`
        INSERT INTO api_cost_log 
        (provider, model, tokens_in, tokens_out, cost_usd, task_type, task_id, reason) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `).run(provider, selectedModel, tokensIn, tokensOut, calculatedCost, taskType, taskId, reason || "Normal execution");
    } catch (e) {
      console.warn("[ModelRouter] Warning writing to api_cost_log:", e.message);
    }
    return responseText;
  }
  estimateCost(provider, model, inTokens, outTokens) {
    if (provider === "local-ollama") return 0;
    const cleanModel = model.toLowerCase();
    if (cleanModel.includes("sonnet")) {
      return inTokens * 3e-6 + outTokens * 15e-6;
    }
    if (cleanModel.includes("opus")) {
      return inTokens * 15e-6 + outTokens * 75e-6;
    }
    if (cleanModel.includes("pro")) {
      return inTokens * 125e-8 + outTokens * 5e-6;
    }
    if (cleanModel.includes("haiku") || cleanModel.includes("flash")) {
      return inTokens * 3e-7 + outTokens * 12e-7;
    }
    return 0;
  }
  updateDailySpend() {
    try {
      const row = memoryVault.prepare(`
        SELECT SUM(cost_usd) as total 
        FROM api_cost_log 
        WHERE timestamp >= date('now')
      `).get();
      this.currentSpend = row?.total || 0;
      if (this.currentSpend >= this.dailyBudgetUSD * 0.8) {
        nexusBus.emit("BUDGET_WARNING");
      }
    } catch (err) {
    }
  }
  getRouterStats() {
    try {
      const stats = memoryVault.prepare(`
        SELECT provider, model, COUNT(*) as c, SUM(cost_usd) as total_cost 
        FROM api_cost_log 
        GROUP BY provider, model
      `).all();
      return {
        stats,
        activeProvider: this.ollamaStatus.online ? "Local Primary (Ollama)" : "OpenRouter API Overflow",
        local: this.getStatusForBar(),
        dailySpend: this.currentSpend,
        timestamp: Date.now()
      };
    } catch (err) {
      return {
        stats: [],
        activeProvider: "Offline Fallback",
        local: this.getStatusForBar(),
        dailySpend: this.currentSpend,
        timestamp: Date.now()
      };
    }
  }
  forceProvider(p) {
    this.forcedProvider = p === "clear" ? null : p;
  }
  async checkAllProviders() {
    await this.localHealthCheck();
    return [
      { name: "Local Primary (Ollama)", status: this.ollamaStatus.online ? "ONLINE" : "OFFLINE" },
      { name: "llama3.1:70b", status: this.ollamaStatus.modelsAvailable.includes("llama3.1:70b") ? "ONLINE" : "OFFLINE" },
      { name: "mistral:7b", status: this.ollamaStatus.modelsAvailable.includes("mistral:7b") ? "ONLINE" : "OFFLINE" },
      { name: "deepseek-coder-v2", status: this.ollamaStatus.modelsAvailable.includes("deepseek-coder-v2") ? "ONLINE" : "OFFLINE" },
      { name: "qwen2.5:7b", status: this.ollamaStatus.modelsAvailable.includes("qwen2.5:7b") ? "ONLINE" : "OFFLINE" },
      { name: "OpenRouter (API Overflow)", status: "ONLINE" }
    ];
  }
  getCostReport() {
    try {
      const today = memoryVault.prepare(`SELECT SUM(cost_usd) as total FROM api_cost_log WHERE timestamp >= date('now')`).get();
      const week = memoryVault.prepare(`SELECT SUM(cost_usd) as total FROM api_cost_log WHERE timestamp >= date('now', '-7 days')`).get();
      const month = memoryVault.prepare(`SELECT SUM(cost_usd) as total FROM api_cost_log WHERE timestamp >= date('now', '-30 days')`).get();
      return {
        today: today?.total || 0,
        week: week?.total || 0,
        month: month?.total || 0,
        savings: (week?.total || 0) * 4.2
        // savings metric calculation
      };
    } catch (err) {
      return { today: 0, week: 0, month: 0, savings: 0 };
    }
  }
  setBudgetGuard(limit) {
    this.dailyBudgetUSD = limit;
  }
};
var modelRouter = new ModelRouter();
var modelRouter_default = modelRouter;
export {
  ModelRouter,
  modelRouter_default as default,
  modelRouter,
  nexusBus
};
