import express from 'express';
import { exec, ChildProcess } from 'child_process';
import path from 'path';
import fs from 'fs';
import http from 'http';

export const inceptionRoutes = express.Router();

// Memory-based registry of active sandbox processes
interface SandboxServer {
  id: string;
  name: string;
  port: number;
  status: 'IDLE' | 'RUNNING' | 'ERROR';
  command: string;
  cwd: string;
  process?: ChildProcess;
  logs: string[];
  createdAt: string;
  startedAt?: string;
}

const activeServers: Record<number, SandboxServer> = {};

// Default Sandbox directory
const SANDBOX_DIR = path.join(process.cwd(), 'data', 'inception-sandboxes');

// Ensure base dir exists
try {
  if (!fs.existsSync(SANDBOX_DIR)) {
    fs.mkdirSync(SANDBOX_DIR, { recursive: true });
  }
} catch (e) {
  console.error('[Inception] Failed to create sandbox directory:', e);
}

// Preset configurations
const PRESETS = [
  {
    id: 'bannon-game',
    name: 'Bannon Combat Game',
    rootFile: 'public/bannon.html',
    sourceFile: 'public/bannon.html',
    command: 'npx http-server public -p {port} -c-1 --cors'
  },
  {
    id: 'space-shooter',
    name: 'Nebula Force Space Shooter',
    rootFile: 'space-shooter.html',
    sourceFile: 'space-shooter.html',
    command: 'npx http-server . -p {port} -c-1 --cors'
  },
  {
    id: 'custom-physics',
    name: 'Neuro-Spatial Physics Lab',
    rootFile: 'quantum_mobile.html',
    sourceFile: 'public/quantum_mobile.html',
    command: 'npx http-server public -p {port} -c-1 --cors'
  }
];

// Helper to append logs
function appendServerLog(port: number, text: string) {
  if (!activeServers[port]) return;
  const cleanText = text.replace(/\r/g, '');
  activeServers[port].logs.push(cleanText);
  if (activeServers[port].logs.length > 1000) {
    activeServers[port].logs.shift();
  }
}

// Initialize default servers in registry if empty on start
function ensureInitialized(port: number = 8080, presetId: string = 'bannon-game') {
  if (!activeServers[port]) {
    const preset = PRESETS.find(p => p.id === presetId) || PRESETS[0];
    const cwd = process.cwd();
    
    activeServers[port] = {
      id: preset.id,
      name: preset.name,
      port: port,
      status: 'IDLE',
      command: preset.command.replace('{port}', port.toString()),
      cwd,
      logs: [`[SYSTEM] Sandbox interface armed on port ${port}. Awaiting ignition.\n`],
      createdAt: new Date().toISOString()
    };
  }
}

// REST APIs
// 1. Get status of all servers
inceptionRoutes.get('/servers', (req, res) => {
  const list = Object.values(activeServers).map(s => ({
    id: s.id,
    name: s.name,
    port: s.port,
    status: s.status,
    command: s.command,
    createdAt: s.createdAt,
    startedAt: s.startedAt,
    logCount: s.logs.length
  }));
  res.json({ success: true, servers: list, presets: PRESETS });
});

// 2. Get specific logs
inceptionRoutes.get('/logs/:port', (req, res) => {
  const port = parseInt(req.params.port);
  if (!activeServers[port]) {
    return res.status(404).json({ error: 'No sandbox server configured on this port' });
  }
  res.json({ success: true, logs: activeServers[port].logs.join('') });
});

// 3. Register or create custom workspace files
inceptionRoutes.post('/create', (req, res) => {
  try {
    const { id, name, htmlContent, jsContent, cssContent } = req.body;
    if (!id || !name) {
      return res.status(400).json({ error: 'Missing app id or name' });
    }

    const cleanId = id.toLowerCase().trim().replace(/[^a-z0-9_-]/g, '');
    const appDir = path.join(SANDBOX_DIR, cleanId);

    if (!fs.existsSync(appDir)) {
      fs.mkdirSync(appDir, { recursive: true });
    }

    // Write default index.html
    const indexHtml = htmlContent || `<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>${name}</title>
    <style>
        body { background: #0a0a0c; color: #a855f7; font-family: monospace; display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 100vh; margin: 0; }
        .card { background: #111116; border: 1px solid #a855f733; padding: 24px; border-radius: 12px; box-shadow: 0 0 20px rgba(168,85,247,0.2); text-align: center; max-width: 400px; }
        h1 { color: #fff; text-shadow: 0 0 8px #a855f7; margin-top: 0; }
        ${cssContent || ''}
    </style>
</head>
<body>
    <div class="card">
        <h1>${name}</h1>
        <p>[ Inception Server Port: <span id="port-label">...</span> ]</p>
        <p>Operational reality loaded successfully.</p>
        <div id="dynamic-log" style="color: #64748b; font-size: 11px; margin-top: 15px;">Awaiting interaction...</div>
    </div>
    <script>
        document.getElementById('port-label').innerText = window.location.port || 'detected';
        ${jsContent || '// Custom scripts go here'}
    </script>
</body>
</html>`;

    fs.writeFileSync(path.join(appDir, 'index.html'), indexHtml, 'utf8');

    // Register this custom preset dynamically
    const presetId = `custom-${cleanId}`;
    const customPresetIndex = PRESETS.findIndex(p => p.id === presetId);
    
    const cmd = `npx http-server data/inception-sandboxes/${cleanId} -p {port} -c-1 --cors`;
    const newPreset = {
      id: presetId,
      name,
      rootFile: `data/inception-sandboxes/${cleanId}/index.html`,
      sourceFile: `data/inception-sandboxes/${cleanId}/index.html`,
      command: cmd
    };

    if (customPresetIndex >= 0) {
      PRESETS[customPresetIndex] = newPreset;
    } else {
      PRESETS.push(newPreset);
    }

    res.json({ success: true, preset: newPreset });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 4. Start a sandbox server
inceptionRoutes.post('/start', (req, res) => {
  const { port = 8080, presetId = 'bannon-game' } = req.body;
  const targetPort = parseInt(port);

  if (isNaN(targetPort) || targetPort <= 0 || targetPort > 65535) {
    return res.status(400).json({ error: 'Invalid port parameter' });
  }

  ensureInitialized(targetPort, presetId);
  const server = activeServers[targetPort];

  // If already running, reboot instead
  if (server.status === 'RUNNING') {
    return res.json({ success: true, message: 'Server already running on port ' + targetPort, status: 'RUNNING' });
  }

  try {
    server.status = 'IDLE';
    server.logs.push(`[SYSTEM] Initiating server process bootstrap...\nCommand: ${server.command}\nCWD: ${server.cwd}\n`);

    const child = exec(server.command, { cwd: server.cwd });
    server.process = child;
    server.status = 'RUNNING';
    server.startedAt = new Date().toISOString();

    child.stdout?.on('data', (data) => {
      appendServerLog(targetPort, `[STDOUT] ${data}`);
    });

    child.stderr?.on('data', (data) => {
      appendServerLog(targetPort, `[STDERR] ${data}`);
    });

    child.on('close', (code) => {
      appendServerLog(targetPort, `[SYSTEM] Process terminated with exit code ${code}\n`);
      if (server.status === 'RUNNING') {
        server.status = 'IDLE';
      }
    });

    child.on('error', (err) => {
      appendServerLog(targetPort, `[SYSTEM EVENT ERROR] Process error: ${err.message}\n`);
      server.status = 'ERROR';
    });

    res.json({ success: true, message: 'Server process spawned successfully', status: 'RUNNING', port: targetPort });
  } catch (err: any) {
    server.status = 'ERROR';
    server.logs.push(`[BOOT ERROR] Fork failed: ${err.message}\n`);
    res.status(500).json({ error: err.message });
  }
});

// 5. Stop a server
inceptionRoutes.post('/stop', (req, res) => {
  const { port } = req.body;
  const targetPort = parseInt(port);

  if (!activeServers[targetPort]) {
    return res.status(404).json({ error: 'No configured server on port ' + targetPort });
  }

  const server = activeServers[targetPort];
  if (server.process) {
    try {
      server.logs.push('[SYSTEM] Dispatching kill signal (SIGTERM)...\n');
      server.process.kill();
      server.process = undefined;
      server.status = 'IDLE';
      res.json({ success: true, message: 'Process termination signal dispatched' });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  } else {
    server.status = 'IDLE';
    res.json({ success: true, message: 'Process is already inactive' });
  }
});

// 6. Reboot / Restart server
inceptionRoutes.post('/reboot', async (req, res) => {
  const { port = 8080, presetId = 'bannon-game' } = req.body;
  const targetPort = parseInt(port);

  if (!activeServers[targetPort]) {
    ensureInitialized(targetPort, presetId);
  }

  const server = activeServers[targetPort];
  server.logs.push(`\n[REBOOT PROTOCOL] Initiating system hot-swap restart on port ${targetPort}...\n`);

  // Kill old process if active
  if (server.process) {
    try {
      server.process.kill();
      server.process = undefined;
      await new Promise(r => setTimeout(r, 400));
    } catch (e) {}
  }

  // Restart
  try {
    const preset = PRESETS.find(p => p.id === presetId) || PRESETS[0];
    server.command = preset.command.replace('{port}', targetPort.toString());
    server.id = preset.id;
    server.name = preset.name;
    
    server.logs.push(`[REBOOT] Spawning new process sequence...\nCommand: ${server.command}\n`);
    const child = exec(server.command, { cwd: server.cwd });
    server.process = child;
    server.status = 'RUNNING';
    server.startedAt = new Date().toISOString();

    child.stdout?.on('data', (data) => {
      appendServerLog(targetPort, `[STDOUT] ${data}`);
    });

    child.stderr?.on('data', (data) => {
      appendServerLog(targetPort, `[STDERR] ${data}`);
    });

    child.on('close', (code) => {
      appendServerLog(targetPort, `[SYSTEM] Process terminated with exit code ${code}\n`);
      if (server.status === 'RUNNING') {
        server.status = 'IDLE';
      }
    });

    child.on('error', (err) => {
      appendServerLog(targetPort, `[SYSTEM EVENT ERROR] Process error: ${err.message}\n`);
      server.status = 'ERROR';
    });

    res.json({ success: true, message: 'Server rebooted successfully', status: 'RUNNING' });
  } catch (err: any) {
    server.status = 'ERROR';
    server.logs.push(`[REBOOT FAILURE] Fork failed: ${err.message}\n`);
    res.status(500).json({ error: err.message });
  }
});

// 7. Secure Native Proxy Middleware to route calls into internal servers
inceptionRoutes.all('/proxy/:port/*', (req, res) => {
  const portString = req.params.port;
  const targetPort = parseInt(portString);

  if (isNaN(targetPort)) {
    return res.status(400).send('Invalid inception port parameter.');
  }

  // Generate target URL path
  const prefix = `/proxy/${portString}`;
  const rawPath = req.originalUrl;
  const proxyPathIndex = rawPath.indexOf(prefix);
  let finalPath = '/';
  
  if (proxyPathIndex !== -1) {
    finalPath = rawPath.substring(proxyPathIndex + prefix.length);
  }
  if (!finalPath.startsWith('/')) {
    finalPath = '/' + finalPath;
  }

  // Ensure server on that port is registered & running, or lazily boot Bannon as fallback
  if (!activeServers[targetPort] || activeServers[targetPort].status !== 'RUNNING') {
    ensureInitialized(targetPort);
    // Lazily boot
    const preset = PRESETS[0];
    const server = activeServers[targetPort];
    server.command = preset.command.replace('{port}', targetPort.toString());
    
    try {
      const child = exec(server.command, { cwd: server.cwd });
      server.process = child;
      server.status = 'RUNNING';
      server.startedAt = new Date().toISOString();

      child.stdout?.on('data', (data) => appendServerLog(targetPort, `[STDOUT] ${data}`));
      child.stderr?.on('data', (data) => appendServerLog(targetPort, `[STDERR] ${data}`));
      child.on('close', () => { if (server.status === 'RUNNING') server.status = 'IDLE'; });
    } catch (e) {}
  }

  // Create reverse proxy request
  const options = {
    hostname: '127.0.0.1',
    port: targetPort,
    path: finalPath,
    method: req.method,
    headers: {
      ...req.headers,
      // Remove host and referers to avoid circular redirects or hostname conflicts
      host: `127.0.0.1:${targetPort}`,
    }
  };

  // We delete the referer so internal web servers serve assets relative to themselves without getting confused
  delete options.headers['referer'];

  const proxyReq = http.request(options, (proxyRes) => {
    // Intercept client-redirects
    if (proxyRes.headers.location) {
      // Rewrite response redirect to stay inside our portal!
      let loc = proxyRes.headers.location;
      if (loc.startsWith(`http://127.0.0.1:${targetPort}`)) {
        loc = loc.replace(`http://127.0.0.1:${targetPort}`, `/api/armada/inception/proxy/${targetPort}`);
      } else if (loc.startsWith('/')) {
        loc = `/api/armada/inception/proxy/${targetPort}${loc}`;
      }
      proxyRes.headers.location = loc;
    }

    res.writeHead(proxyRes.statusCode || 200, proxyRes.headers);
    proxyRes.pipe(res, { end: true });
  });

  proxyReq.on('error', (err) => {
    console.error(`[Inception Proxy Error] on Port ${targetPort}:`, err.message);
    res.status(502).send(`
      <div style="background-color: #030005; color: #f43f5e; font-family: monospace; height: 100vh; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 20px; box-sizing: border-box; text-align: center;">
        <h2 style="text-shadow: 0 0 10px rgba(244,63,94,0.5);">[ INCEPTION SANBOX NODE NOT RESPONDING ]</h2>
        <p style="color: #94a3b8; font-size: 13px;">Failed to proxy request to internal port <strong>${targetPort}</strong>.</p>
        <p style="color: #64748b; font-size: 11px; max-width: 500px;">Reason: ${err.message}<br>Confirm the sandbox server is actively booted and running in the Server Manager panel.</p>
      </div>
    `);
  });

  // Pipe request body into proxy if present
  req.pipe(proxyReq, { end: true });
});
