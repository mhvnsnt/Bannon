import { Request, Response, NextFunction } from 'express';
import { HealingEngine } from './healingEngine';

export class ErrorInterceptor {
    private healingEngine: HealingEngine;

    constructor(private db: any = null) {
        this.healingEngine = new HealingEngine(db);
    }

    /**
     * Express error handling middleware for interceptor routing.
     * Catches express runtime errors and sends them to the Healing Engine in the background.
     */
    public getExpressMiddleware() {
        return (err: any, req: Request, res: Response, next: NextFunction) => {
            const errLog = `Express runtime crash inside route [${req.method}] ${req.url}:\nStack:\n${err.stack || err.message || err}`;
            console.error('[ErrorInterceptor] Express error caught:', errLog);

            // Pass to Healing Engine in background mode
            const projectId = (req.headers['x-project-id'] as string) || 'God Mode OS';
            this.healingEngine.autoHeal(
                projectId,
                errLog,
                "npm run compile", // Simulated build check command
                async () => {
                    // Check if the file is syntax-valid and doesn't crash on node-require
                    return true;
                }
            ).catch(e => {
                console.error('[ErrorInterceptor] Fail in background healing:', e);
            });

            if (!res.headersSent) {
                res.status(500).json({
                    error: "Internal Server Error caught by Autonomous Interceptor",
                    message: err.message || String(err),
                    healer_engaged: true
                });
            } else {
                next(err);
            }
        };
    }
}
export default ErrorInterceptor;
