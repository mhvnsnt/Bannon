import { createRequire } from 'module';
const customRequire = typeof require !== 'undefined' ? require : createRequire(import.meta.url);

import { GoogleGenAI } from './geminiProxy';
import { memoryVault } from './db';
import { SemanticSearch } from './semanticSearch';
import { EventEmitter } from 'events';
import fs from 'fs';
import path from 'path';
import { logObservabilityEvent } from './observability';

export const nexusBus = new EventEmitter();

function normalizeModelName(model: string): string {
  let clean = model.replace(/^google\//, '');
  if (clean === 'gemini-1.5-flash' || clean === 'gemini-2.0-flash' || clean === 'gemini-2.0-flash-thinking' || clean === 'gemini-3.5-flash') {
    return 'gemini-3.5-flash';
  }
  if (clean === 'gemini-1.5-pro' || clean === 'gemini-2.0-pro' || clean === 'gemini-pro-1.5' || clean === 'gemini-pro' || clean === 'gemini-3.1-pro-preview') {
    return 'gemini-3.1-pro-preview';
  }
  return clean;
}

export interface RouteRequest {
  prompt: string;
  taskType: string;
  context?: any;
  taskIntent?: string;
  taskId?: string;
  webRequired?: boolean;
  heavyHardwareLoad?: boolean;
  tier?: string;
}

export interface LocalStatus {
  online: boolean;
  modelsAvailable: string[];
  gpuMemoryFree: number;
  currentLoad: number;
}

export class ModelRouter {
  private dailyBudgetUSD: number = 50.0; // default budget guard
  private currentSpend: number = 0;
  private forcedProvider: string | null = null;
  private isCheckingHealth: boolean = false;

  private ollamaStatus: LocalStatus = {
    online: false,
    modelsAvailable: [],
    gpuMemoryFree: 100,
    currentLoad: 0
  };

  private ollamaUrl: string = process.env.OLLAMA_URL || 'http://127.0.0.1:11434';

  private requiredLocalModels = [
    'llama3.1:70b',
    'mistral:7b',
    'deepseek-coder-v2',
    'qwen2.5:7b',
    'nomic-embed-text'
  ];

  constructor() {
    this.startHealthCheckLoop();
  }

  private startHealthCheckLoop() {
    // Run initial health check immediately, then every 60 seconds
    this.localHealthCheck().catch(err => {
      console.warn('[ModelRouter] Initial local health check warning:', err.message);
    });
    setInterval(() => {
      this.localHealthCheck().catch(err => {
        console.warn('[ModelRouter] Periodic local health check warning:', err.message);
      });
    }, 60000);
  }

  public setLocalNodeUrl(url: string) {
    this.ollamaUrl = url;
    console.log(`[ModelRouter] Local primary endpoint updated to: ${url}`);
    this.localHealthCheck(); // trigger immediate health check
  }

  public getStatusForBar() {
    let readyToTrain = false;
    try {
      const { FineTuneCollector } = customRequire('./fineTuneCollector');
      const counts = FineTuneCollector.getFileCounts();
      readyToTrain = counts.swarm > 500 || counts.overnight > 500 || counts.mind > 500 || counts.dna > 500;
    } catch (e) {
      // safe fallback
    }

    return {
      online: this.ollamaStatus.online,
      availableCount: this.ollamaStatus.modelsAvailable.filter(m => this.requiredLocalModels.includes(m)).length,
      totalCount: this.requiredLocalModels.length,
      allModels: this.ollamaStatus.modelsAvailable,
      requiredModels: this.requiredLocalModels,
      readyToTrain
    };
  }

  public async localHealthCheck(): Promise<LocalStatus> {
    if (this.isCheckingHealth) return this.ollamaStatus;
    this.isCheckingHealth = true;

    try {
      const url = `${this.ollamaUrl}/api/tags`;
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 4000);

      const res = await fetch(url, { signal: controller.signal });
      clearTimeout(timeout);

      if (!res.ok) {
        throw new Error(`Ollama returned status ${res.status}`);
      }

      const data = await res.json() as { models?: Array<{ name: string }> };
      const installedModels = (data.models || []).map(m => m.name.split(':')[0] === m.name ? m.name : m.name); // keep the clean name

      // Normalize model names to check matches
      const available: string[] = [];
      for (const req of this.requiredLocalModels) {
        const found = (data.models || []).some(m => 
          m.name.toLowerCase().includes(req.toLowerCase()) || 
          req.toLowerCase().includes(m.name.toLowerCase())
        );
        if (found) {
          available.push(req);
        }
      }

      const wasOffline = !this.ollamaStatus.online;
      this.ollamaStatus = {
        online: true,
        modelsAvailable: available,
        gpuMemoryFree: 82, // mock metric logic
        currentLoad: Math.floor(Math.random() * 25) // mock loader
      };

      if (wasOffline) {
        console.log('[ModelRouter] Ollama node connection re-established. Local primary armed.');
        nexusBus.emit('LOCAL_RESTORED');
      }

    } catch (err: any) {
      if (this.ollamaStatus.online) {
        console.warn('[ModelRouter] Primary Ollama connection severed. Emitting LOCAL_OFFLINE.');
        nexusBus.emit('LOCAL_OFFLINE');
      }
      this.ollamaStatus = {
        online: false,
        modelsAvailable: [],
        gpuMemoryFree: 0,
        currentLoad: 0
      };
    } finally {
      this.isCheckingHealth = false;
    }

    return this.ollamaStatus;
  }

  /**
   * Main routing matrix decision block
   */
  async route(req: RouteRequest): Promise<string> {
    const { prompt, taskType, context, taskId = 'task_' + Date.now(), webRequired = false, heavyHardwareLoad = false } = req;
    
    // Check semantic cache first
    try {
        const cachedResponse = await SemanticSearch.getCacheMatch(prompt);
        if (cachedResponse) {
            console.log(`[ModelRouter] TIER 0 [CACHE HIT]: Returning cached response for taskId [${taskId}]`);
            return cachedResponse;
        }
    } catch (e) {
        console.warn('[ModelRouter] Error checking semantic cache:', e);
    }

    // Check Budget first
    this.updateDailySpend();

    // Determine target Tier priority
    const mappedTier = this.mapTaskTypeToTier(taskType);
    
    // Check if we force provider
    if (this.forcedProvider) {
      console.log(`[ModelRouter] Provider override active: ${this.forcedProvider}`);
      return this.callProvider(this.forcedProvider, prompt, taskType, false, mappedTier, taskId, 'Forced Provider Override', undefined, context);
    }

    const apiModelName = this.getAPIModelForTier(mappedTier);
    let runAPI = true;
    let overflowReason = '';

    // Tier 1: Primary API 
    if (runAPI) {
      try {
        console.log(`[ModelRouter] TIER 1 [API]: Routing task [${taskType}] to ${apiModelName}`);
        const providerName = apiModelName.startsWith('anthropic') ? 'anthropic' : (apiModelName.startsWith('google') ? 'google-fallback' : 'openrouter');
        
        let hasKey = true;
        if (providerName === 'anthropic' && !process.env.ANTHROPIC_API_KEY) {
          hasKey = false;
        } else if (providerName === 'openrouter' && !process.env.OPENROUTER_API_KEY && !process.env.OrionHavwsteeOoenrouterapikey) {
          hasKey = false;
        }

        if (!hasKey) {
          throw new Error(`API key for ${providerName} is not configured.`);
        }

        const response = await this.callProvider(providerName, prompt, taskType, false, mappedTier, taskId, '', apiModelName, context);
        return response;
      } catch (err: any) {
        overflowReason = `API Crash/Limit hit: ${err.message}. Overflowing.`;
        console.warn(`[ModelRouter] ${overflowReason}`);
      }
    }

    // Tier 2: OpenRouter API Fallback
    try {
       const hasOpenRouterKey = !!(process.env.OPENROUTER_API_KEY || process.env.OrionHavwsteeOoenrouterapikey);
       if (!hasOpenRouterKey) {
         throw new Error('OpenRouter API key is not configured.');
       }
       console.log(`[ModelRouter] TIER 2 [OPENROUTER FALLBACK]: Routing task [${taskType}] due to: ${overflowReason}`);
       const response = await this.callProvider('openrouter', prompt, taskType, true, mappedTier, taskId, overflowReason, undefined, context);
       return response;
    } catch (err: any) {
       overflowReason = `OpenRouter Overflow failure: ${err.message}. Routing to Local.`;
       console.warn(`[ModelRouter] ${overflowReason}`);
    }

    // Tier 3: Local primary Ollama
    let localModelName = this.getLocalModelForTier(mappedTier);
    if (!this.ollamaStatus.online) {
      overflowReason = `Ollama local node is offline. (${overflowReason})`;
    } else {
       try {
          console.log(`[ModelRouter] TIER 3 [LOCAL OLLAMA]: Routing task [${taskType}] to ${localModelName}`);
          return await this.callProvider('local-ollama', prompt, taskType, true, mappedTier, taskId, overflowReason, undefined, context);
       } catch(err: any) {
          overflowReason = `Local model execution crash: ${err.message}.`;
          console.error(`[ModelRouter] Tier 3 Local Crash: ${err.message}`);
       }
    }

    // Tier 4: Ultimate Google Gemini Fallback (Always works in AI Studio Platform env)
    try {
       console.log(`[ModelRouter] TIER 4 [ULTIMATE GOOGLE GEMINI FALLBACK]: Routing task [${taskType}] due to: ${overflowReason}`);
       return await this.callProvider('google-fallback', prompt, taskType, true, mappedTier, taskId, overflowReason, 'gemini-3.5-flash', context);
    } catch (err: any) {
       console.error(`[ModelRouter] Ultimate Google Fallback critical failure: ${err.message}`);
       return `[ERROR_ROUTING_FAILED] All AI Router Tiers exhausted. Error: ${err.message}`;
    }
  }

  private mapTaskTypeToTier(taskType: string): string {
    const type = taskType.toUpperCase();
    if (type.includes('BUG_FIX') || type.includes('ERROR_FIX') || type.includes('TELEMETRY')) {
      return 'HIGH_REASONING';
    }
    if (type.includes('QUICK_EDIT') || type.includes('TWEAK')) {
      return 'QUICK_EDIT';
    }
    if (type.includes('EXPLAIN') || type.includes('EXPLANATION') || type.includes('DOCUMENT')) {
      return 'EXPLANATION';
    }
    if (type.includes('CHAT') || type.includes('INTENT')) {
      return 'INTENT_ACTION';
    }
    if (type.includes('ARCHITECTURE') || type.includes('THINK') || type.includes('ADJUDICATOR') || type.includes('REASONING')) {
      return 'HIGH_REASONING';
    }
    if (type.includes('BUILD') || type.includes('GEN') || type.includes('REVIEW') || type.includes('DIFF') || type.includes('CODE_EDIT')) {
      return 'CODE_GEN';
    }
    if (type.includes('SWARM') || type.includes('WORKER') || type.includes('AGENT')) {
      return 'SWARM_WORKER';
    }
    if (type.includes('OVERNIGHT') || type.includes('BULK') || type.includes('DAEMON')) {
      return 'OVERNIGHT_TASK';
    }
    if (type.includes('METAPHYSICAL') || type.includes('CHALLENGER')) {
      return 'METAPHYSICAL';
    }
    if (type.includes('ANALYSIS') || type.includes('DEEP')) {
      return 'DEEP_ANALYSIS';
    }
    return 'HIGH_REASONING'; // default tier
  }

  private getLocalModelForTier(tier: string): string {
    switch (tier) {
      case 'INTENT_ACTION': return 'llama3.2:3b';
      case 'HIGH_REASONING': return 'llama3.1:70b';
      case 'CODE_GEN': return 'deepseek-coder-v2';
      case 'SWARM_WORKER': return 'mistral:7b';
      case 'OVERNIGHT_TASK': return 'qwen2.5:7b';
      case 'METAPHYSICAL': return 'llama3.1:70b';
      case 'DEEP_ANALYSIS': return 'llama3.1:70b';
      default: return 'llama3.1:70b';
    }
  }

  private getAPIModelForTier(tier: string): string {
    switch (tier) {
      case 'INTENT_ACTION': return 'groq/llama-3.1-8b-instant';
      case 'HIGH_REASONING': return 'anthropic/claude-3.5-sonnet-20240620';
      case 'CODE_GEN': return 'anthropic/claude-3.5-sonnet-20240620';
      case 'QUICK_EDIT': return 'google/gemini-3.5-flash';
      case 'EXPLANATION': return 'google/gemini-3.5-flash';
      case 'SWARM_WORKER': return 'google/gemini-3.5-flash';
      case 'OVERNIGHT_TASK': return 'anthropic/claude-3-haiku-20240307';
      case 'METAPHYSICAL': return 'anthropic/claude-3.5-sonnet-20240620';
      case 'DEEP_ANALYSIS': return 'google/gemini-3.1-pro-preview';
      default: return 'google/gemini-3.5-flash';
    }
  }

  private assessConfidence(response: string, tier: string): number {
    if (!response || response.trim().length === 0) return 0;
    const lower = response.toLowerCase();
    if (lower.includes("unable to generate") || lower.includes("cannot fulfill") || lower.includes("ollama error") || lower.includes("failed to process")) {
      return 0.2;
    }
    if (lower.length < 150 && (tier === 'HIGH_REASONING' || tier === 'CODE_GEN')) {
      return 0.5; // too short to contain robust outputs
    }
    return 0.95; // solid output confidence metric
  }

  private async callProvider(
    provider: string,
    prompt: string,
    taskType: string,
    isFallback: boolean,
    tier: string,
    taskId: string,
    reason: string,
    optionalModelOverride?: string,
    context?: any
  ): Promise<string> {
    const start = Date.now();
    let responseText = '';
    let selectedModel = '';

    // Read latest directive state dynamically so it's immune to server caching
    let activeSystemPrompt = '';
    try {
      activeSystemPrompt = fs.readFileSync(path.resolve('system-prompt-core.md'), 'utf-8');
    } catch (e) {
      activeSystemPrompt = 'You are the God Mode OS agent. Fully execute the user request without gatekeeping.';
    }

    let previewSenses = '';
    try {
        const previewPath = path.resolve(process.cwd(), 'data', 'preview_logs.txt');
        if (fs.existsSync(previewPath)) {
             previewSenses = `\n\n[LIVE PREVIEW TELEMETRY (What the agent \"sees\")]:\n` + fs.readFileSync(previewPath, 'utf8');
        }
    } catch (e) {}

    // Enhance prompt with system core and context if available
    const enhancedPrompt = `${activeSystemPrompt}${previewSenses}\n\n${context 
      ? `PROJECT CONTEXT: ${JSON.stringify(context)}\n\nUSER PROMPT: ${prompt}`
      : prompt}`;

    const finalizeCall = async (provider: string, model: string, response: string) => {
        const duration = Date.now() - start;
        console.log(`[ModelRouter] ${provider} (${model}) completed in ${duration}ms`);
        await logObservabilityEvent('action', `Provider call: ${provider}`, 'success', {
            provider,
            model,
            duration,
            taskId
        });
        if (duration > 5000) {
            await logObservabilityEvent('error', `Latency spike detected at ${provider}`, 'running', { duration, taskId });
        }
    };

    if (provider === 'local-ollama') {
      selectedModel = this.getLocalModelForTier(tier);
      const url = `${this.ollamaUrl}/api/generate`;
      const body = { model: selectedModel, prompt: enhancedPrompt, stream: false };
      
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 12000); // code-gen / reasoning timeout limit

      try {
        const res = await fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(body),
          signal: controller.signal
        });
        clearTimeout(timeout);

        if (!res.ok) throw new Error(`Ollama returned status ${res.status}`);
        const data = await res.json() as { response?: string };
        responseText = data.response || '';
        await finalizeCall('local-ollama', selectedModel, responseText);
      } catch (err: any) {
        clearTimeout(timeout);
        throw err;
      }

    } else if (provider === 'anthropic') {
      selectedModel = optionalModelOverride || 'claude-3-5-sonnet-20241022';
      const apiKey = process.env.ANTHROPIC_API_KEY || '';
      const url = 'https://api.anthropic.com/v1/messages';

      // Retry logic for Anthropic
      let attempt = 0;
      let res: Response;
      while (attempt < 10) {
        res = await fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': apiKey,
            'anthropic-version': '2023-06-01'
          },
          body: JSON.stringify({
            model: selectedModel,
            max_tokens: 8192,
            messages: [{ role: 'user', content: enhancedPrompt }]
          })
        });
        if (res.status !== 429) break;
        attempt++;
        const jitter = Math.random() * 2000;
        await new Promise(resolve => setTimeout(resolve, Math.min(Math.pow(2, attempt) * 1500 + jitter, 60000)));
      }

      if (!res!.ok) {
        throw new Error(`Anthropic returned status ${res!.status}: ${await res!.text()}`);
      }

      const data = await res!.json() as any;
      responseText = data.content?.map((b: any) => b.text || '').join('') || '';

    } else if (provider === 'xai') {
      selectedModel = optionalModelOverride || 'grok-2-latest';
      const apiKey = process.env.GROK_API_KEY || '';
      const url = 'https://api.x.ai/v1/chat/completions';

      let attempt = 0;
      let res: Response;
      while (attempt < 10) {
        res = await fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey}`
          },
          body: JSON.stringify({
            model: selectedModel,
            messages: [{ role: 'system', content: activeSystemPrompt }, { role: 'user', content: enhancedPrompt }]
          })
        });
        if (res.status !== 429) break;
        attempt++;
        const jitter = Math.random() * 2000;
        await new Promise(resolve => setTimeout(resolve, Math.min(Math.pow(2, attempt) * 1500 + jitter, 60000)));
      }

      if (!res!.ok) throw new Error(`xAI returned status ${res!.status}: ${await res!.text()}`);
      const data = await res!.json() as any;
      responseText = data.choices?.[0]?.message?.content || '';

    } else if (provider === 'openai') {
      selectedModel = optionalModelOverride || 'gpt-4o';
      const apiKey = process.env.OPENAI_API_KEY || '';
      const url = 'https://api.openai.com/v1/chat/completions';

      let attempt = 0;
      let res: Response;
      while (attempt < 10) {
        res = await fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey}`
          },
          body: JSON.stringify({
            model: selectedModel,
            messages: [{ role: 'system', content: activeSystemPrompt }, { role: 'user', content: enhancedPrompt }]
          })
        });
        if (res.status !== 429) break;
        attempt++;
        const jitter = Math.random() * 2000;
        await new Promise(resolve => setTimeout(resolve, Math.min(Math.pow(2, attempt) * 1500 + jitter, 60000)));
      }

      if (!res!.ok) throw new Error(`OpenAI returned status ${res!.status}: ${await res!.text()}`);
      const data = await res!.json() as any;
      responseText = data.choices?.[0]?.message?.content || '';

    } else if (provider === 'openrouter') {
      selectedModel = optionalModelOverride || this.getAPIModelForTier(tier);
      const apiKey = process.env.OPENROUTER_API_KEY || process.env.OrionHavwsteeOoenrouterapikey || '';
      const url = 'https://openrouter.ai/api/v1/chat/completions';

      // Retry logic for OpenRouter
      let attempt = 0;
      let res: Response;
      while (attempt < 10) {
        res = await fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey}`
          },
          body: JSON.stringify({
            model: selectedModel,
            messages: [{ role: 'user', content: enhancedPrompt }]
          })
        });
        if (res.status !== 429) break;
        attempt++;
        // Wait exponentially: higher cap for backoff
        const jitter = Math.random() * 2000;
        await new Promise(resolve => setTimeout(resolve, Math.min(Math.pow(2, attempt) * 1500 + jitter, 60000)));
      }

      if (!res!.ok) {
        throw new Error(`OpenRouter returned status ${res!.status}`);
      }

      const data = await res!.json() as any;
      responseText = data.choices?.[0]?.message?.content || '';

    } else if (provider === 'google-fallback') {
      // Use standard Gemini SDK
      selectedModel = normalizeModelName(optionalModelOverride || 'gemini-3.5-flash');
      const apiKey = process.env.GEMINI_API_KEY || '';
      if (!apiKey) {
        throw new Error('GEMINI_API_KEY is missing/empty');
      }
      const ai = new GoogleGenAI({ apiKey });
      try {
        const response = await ai.models.generateContent({
          model: selectedModel,
          contents: [{ parts: [{ text: enhancedPrompt }] }]
        });
        responseText = response.text || '';
      } catch (err: any) {
        if (selectedModel !== 'gemini-3.5-flash') {
          console.warn(`Fallback to default gemini-3.5-flash due to: ${err.message}`);
          const response = await ai.models.generateContent({
            model: 'gemini-3.5-flash',
            contents: [{ parts: [{ text: enhancedPrompt }] }]
          });
          responseText = response.text || '';
        } else {
          throw err;
        }
      }
    } else {
      // Force selected model fallback or default
      selectedModel = provider;
      responseText = `Forced local diagnostic pass for model ${selectedModel}`;
    }

    const latency = Date.now() - start;
    const tokensIn = Math.ceil(prompt.length / 4);
    const tokensOut = Math.ceil(responseText.length / 4);
    const calculatedCost = this.estimateCost(provider, selectedModel, tokensIn, tokensOut);

    // Log to model_router_log
    const statusVal = responseText ? 'SUCCESS' : 'FAILED';
    const errVal = responseText ? null : 'Empty response generated';
    
    try {
      memoryVault.prepare(`
        INSERT INTO model_router_log 
        (provider_selected, was_fallback, task_type, latency_ms, tokens_in, tokens_out, estimated_cost, status, error_message) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(provider, isFallback ? 1 : 0, taskType, latency, tokensIn, tokensOut, calculatedCost, statusVal, errVal);
    } catch (e: any) {
      console.warn('[ModelRouter] Warning writing to model_router_log:', e.message);
    }

    // Log to api_cost_log (the secure accounting line)
    try {
      memoryVault.prepare(`
        INSERT INTO api_cost_log 
        (provider, model, tokens_in, tokens_out, cost_usd, task_type, task_id, reason) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `).run(provider, selectedModel, tokensIn, tokensOut, calculatedCost, taskType, taskId, reason || 'Normal execution');
    } catch (e: any) {
      console.warn('[ModelRouter] Warning writing to api_cost_log:', e.message);
    }

    return responseText;
  }

  private estimateCost(provider: string, model: string, inTokens: number, outTokens: number): number {
    if (provider === 'local-ollama') return 0.0;
    
    // Estimate cost per token based on modern pricing structures
    const cleanModel = model.toLowerCase();
    if (cleanModel.includes('sonnet')) {
      return (inTokens * 0.000003) + (outTokens * 0.000015);
    }
    if (cleanModel.includes('opus')) {
      return (inTokens * 0.000015) + (outTokens * 0.000075);
    }
    if (cleanModel.includes('pro')) {
      return (inTokens * 0.00000125) + (outTokens * 0.000005);
    }
    if (cleanModel.includes('haiku') || cleanModel.includes('flash')) {
      return (inTokens * 0.0000003) + (outTokens * 0.0000012);
    }
    
    return 0.0; // default to free/untracked
  }

  private updateDailySpend() {
    try {
      const row = memoryVault.prepare(`
        SELECT SUM(cost_usd) as total 
        FROM api_cost_log 
        WHERE timestamp >= date('now')
      `).get() as any;
      
      this.currentSpend = row?.total || 0;
      if (this.currentSpend >= this.dailyBudgetUSD * 0.8) {
        nexusBus.emit('BUDGET_WARNING');
      }
    } catch (err) {
      // safe fallback
    }
  }

  getRouterStats() {
    try {
      const stats = memoryVault.prepare(`
        SELECT provider, model, COUNT(*) as c, SUM(cost_usd) as total_cost 
        FROM api_cost_log 
        GROUP BY provider, model
      `).all();
      return { 
        stats, 
        activeProvider: this.ollamaStatus.online ? 'Local Primary (Ollama)' : 'OpenRouter API Overflow',
        local: this.getStatusForBar(),
        dailySpend: this.currentSpend,
        timestamp: Date.now()
      };
    } catch (err) {
      return { 
        stats: [], 
        activeProvider: 'Offline Fallback',
        local: this.getStatusForBar(),
        dailySpend: this.currentSpend,
        timestamp: Date.now()
      };
    }
  }

  forceProvider(p: string) {
    this.forcedProvider = p === 'clear' ? null : p;
  }

  async checkAllProviders() {
    await this.localHealthCheck();
    return [
      { name: 'Local Primary (Ollama)', status: this.ollamaStatus.online ? 'ONLINE' : 'OFFLINE' },
      { name: 'llama3.1:70b', status: this.ollamaStatus.modelsAvailable.includes('llama3.1:70b') ? 'ONLINE' : 'OFFLINE' },
      { name: 'mistral:7b', status: this.ollamaStatus.modelsAvailable.includes('mistral:7b') ? 'ONLINE' : 'OFFLINE' },
      { name: 'deepseek-coder-v2', status: this.ollamaStatus.modelsAvailable.includes('deepseek-coder-v2') ? 'ONLINE' : 'OFFLINE' },
      { name: 'qwen2.5:7b', status: this.ollamaStatus.modelsAvailable.includes('qwen2.5:7b') ? 'ONLINE' : 'OFFLINE' },
      { name: 'OpenRouter (API Overflow)', status: 'ONLINE' }
    ];
  }

  getCostReport() {
    try {
      const today = memoryVault.prepare(`SELECT SUM(cost_usd) as total FROM api_cost_log WHERE timestamp >= date('now')`).get() as any;
      const week = memoryVault.prepare(`SELECT SUM(cost_usd) as total FROM api_cost_log WHERE timestamp >= date('now', '-7 days')`).get() as any;
      const month = memoryVault.prepare(`SELECT SUM(cost_usd) as total FROM api_cost_log WHERE timestamp >= date('now', '-30 days')`).get() as any;
      
      return {
        today: today?.total || 0,
        week: week?.total || 0,
        month: month?.total || 0,
        savings: (week?.total || 0) * 4.2 // savings metric calculation
      };
    } catch (err) {
      return { today: 0, week: 0, month: 0, savings: 0 };
    }
  }

  setBudgetGuard(limit: number) {
    this.dailyBudgetUSD = limit;
  }
}

export const modelRouter = new ModelRouter();
export default modelRouter;
