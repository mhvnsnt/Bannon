import express from 'express';
import fs from 'fs';
import path from 'path';

import { exec } from 'child_process';
import util from 'util';

const execAsync = util.promisify(exec);

export const workspaceFS = express.Router();

workspaceFS.get('/lint', async (req, res) => {
  try {
    const { stdout, stderr } = await execAsync('npx tsc --noEmit', { cwd: process.cwd() });
    res.json({ success: true, valid: true, output: stdout });
  } catch (err: any) {
    res.json({ success: true, valid: false, output: err.stdout || err.message });
  }
});

workspaceFS.get('/tree', (req, res) => {
  try {
    const rootDir = process.cwd();
    const excludeList = ['node_modules', '.git', 'dist', '.cache', 'coverage'];
    
    function buildTree(dir: string, currentPath: string = ''): any[] {
      const entries = fs.readdirSync(dir, { withFileTypes: true });
      let arr = [];
      for (const entry of entries) {
        if (excludeList.includes(entry.name)) continue;
        
        const fullPath = path.join(dir, entry.name);
        const relativePath = path.join(currentPath, entry.name);
        
        if (entry.isDirectory()) {
          arr.push({
            name: entry.name,
            type: 'directory',
            path: relativePath,
            children: buildTree(fullPath, relativePath)
          });
        } else {
          arr.push({
            name: entry.name,
            type: 'file',
            path: relativePath
          });
        }
      }
      // sort dirs first
      return arr.sort((a,b) => {
        if (a.type === b.type) return a.name.localeCompare(b.name);
        return a.type === 'directory' ? -1 : 1;
      });
    }
    
    const tree = buildTree(rootDir);
    res.json({ success: true, tree });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

workspaceFS.get('/file', (req, res) => {
  try {
    const { p } = req.query;
    if (!p || typeof p !== 'string') return res.status(400).json({ error: 'Missing path' });
    
    // Prevents path traversal
    const safePath = path.normalize(p).replace(/^(\.\.[\/\\])+/, '');
    const absolutePath = path.join(process.cwd(), safePath);
    
    if (!fs.existsSync(absolutePath)) {
      return res.status(404).json({ error: 'File not found' });
    }
    
    const content = fs.readFileSync(absolutePath, 'utf8');
    res.json({ success: true, content });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

workspaceFS.post('/save', (req, res) => {
  try {
    const { p, content } = req.body;
    if (!p || typeof p !== 'string') return res.status(400).json({ error: 'Missing path' });
    
    const safePath = path.normalize(p).replace(/^(\.\.[\/\\])+/, '');
    const absolutePath = path.join(process.cwd(), safePath);
    
    fs.mkdirSync(path.dirname(absolutePath), { recursive: true });
    fs.writeFileSync(absolutePath, content, 'utf8');

    // Backup to persistent data/ folder
    try {
      const relative = path.relative(process.cwd(), absolutePath);
      if (!relative.startsWith('node_modules') && !relative.startsWith('.git') && !relative.startsWith('dist') && !relative.startsWith('.cache') && !relative.startsWith('data')) {
        const backupPath = path.join(process.cwd(), 'data', 'workspace_backups', relative);
        fs.mkdirSync(path.dirname(backupPath), { recursive: true });
        fs.writeFileSync(backupPath, content, 'utf8');
      }
    } catch (e) {
      console.warn("[Backup Engine Warning]:", e);
    }

    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

workspaceFS.post('/create', (req, res) => {
  try {
    const { p, type } = req.body;
    if (!p || typeof p !== 'string') return res.status(400).json({ error: 'Missing path' });
    
    const safePath = path.normalize(p).replace(/^(\.\.[\/\\])+/, '');
    const absolutePath = path.join(process.cwd(), safePath);
    
    if (type === 'directory') {
      fs.mkdirSync(absolutePath, { recursive: true });
    } else {
      fs.mkdirSync(path.dirname(absolutePath), { recursive: true });
      fs.writeFileSync(absolutePath, '', 'utf8');
    }
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

workspaceFS.post('/delete', (req, res) => {
  try {
    const { p } = req.body;
    if (!p || typeof p !== 'string') return res.status(400).json({ error: 'Missing path' });
    
    const safePath = path.normalize(p).replace(/^(\.\.[\/\\])+/, '');
    const absolutePath = path.join(process.cwd(), safePath);
    
    if (fs.existsSync(absolutePath)) {
      const stat = fs.statSync(absolutePath);
      if (stat.isDirectory()) {
        fs.rmSync(absolutePath, { recursive: true });
      } else {
        fs.unlinkSync(absolutePath);
      }
    }
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});
