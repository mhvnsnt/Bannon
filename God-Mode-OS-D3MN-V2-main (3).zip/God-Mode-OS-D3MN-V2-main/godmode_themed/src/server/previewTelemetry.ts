import fs from 'fs';
import path from 'path';

export function appendPreviewLog(logMsg: string) {
    const logPath = path.resolve(process.cwd(), 'data', 'preview_logs.txt');
    try {
        if (!fs.existsSync(path.dirname(logPath))) {
            fs.mkdirSync(path.dirname(logPath), { recursive: true });
        }
        
        // Maintain a maximum of 100 lines
        let existing = '';
        if (fs.existsSync(logPath)) {
            existing = fs.readFileSync(logPath, 'utf8');
        }
        let lines = existing.split('\n').filter(Boolean);
        
        const time = new Date().toISOString();
        lines.push(`[${time}] ${logMsg}`);
        
        if (lines.length > 200) {
            lines = lines.slice(-200);
        }
        fs.writeFileSync(logPath, lines.join('\n') + '\n', 'utf8');
        
    } catch (e) {
        console.error("Failed to write preview log", e);
    }
}
