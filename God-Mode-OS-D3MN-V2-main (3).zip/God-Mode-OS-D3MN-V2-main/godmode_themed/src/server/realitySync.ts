import fs from 'fs';
import path from 'path';

export class RealitySyncService {
  private logPath: string;

  constructor() {
    this.logPath = path.join(process.cwd(), 'data', 'reality_sync_log.json');
    this.ensureLogExists();
  }

  private ensureLogExists() {
    const dir = path.dirname(this.logPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    if (!fs.existsSync(this.logPath)) {
      fs.writeFileSync(this.logPath, JSON.stringify([]));
    }
  }

  public logEvent(eventType: string, data: any) {
    const logData = {
        timestamp: new Date().toISOString(),
        physicalTimeMs: Date.now(),
        event: eventType,
        details: data
    };

    const currentLogs = JSON.parse(fs.readFileSync(this.logPath, 'utf-8'));
    currentLogs.push(logData);
    fs.writeFileSync(this.logPath, JSON.stringify(currentLogs, null, 2));
    console.log(`[REALITY-SYNC] Event logged: ${eventType} at ${logData.timestamp}`);
  }

  public getLogs() {
     return JSON.parse(fs.readFileSync(this.logPath, 'utf-8'));
  }
}

export const realitySync = new RealitySyncService();

export function attachRealitySyncRoutes(router: any) {
    router.get('/sync/logs', (req: any, res: any) => {
        try {
            res.json({ success: true, logs: realitySync.getLogs() });
        } catch(e: any) {
            res.status(500).json({ error: e.message });
        }
    });
}
