import express from 'express';
import { QuantumFileEngine } from './quantumFileEngine';
import { QuantumContextManager } from './quantumContextManager';
import { memoryVault } from './db';
import { ModelRouter } from './modelRouter';
import { AutonomousQueueEngine } from './autonomousQueueEngine';
import { GameIndexer } from './gameIndexer';
import crypto from 'crypto';

import fs from 'fs';
import path from 'path';
import { attachRealitySyncRoutes, realitySync } from './realitySync';
import { SystemTemporalClock } from './temporalClock';

// Async initialization
SystemTemporalClock.establishAtomicBaseline();

export const quantumRoutes = express.Router();
attachRealitySyncRoutes(quantumRoutes);
const modelRouter = new ModelRouter();

// ---- NEXUS DATA INGESTION API ----
quantumRoutes.post('/nexus/ingest', (req, res) => {
    try {
        const { pattern, signature, variables } = req.body;
        const entry = {
            id: Date.now().toString(),
            pattern,
            signature,
            variables,
            timestamp: SystemTemporalClock.nowISO()
        };
        
        const logPath = path.join(process.cwd(), 'data', 'nexus_ingestion_log.json');
        let logs = [];
        if (fs.existsSync(logPath)) {
            logs = JSON.parse(fs.readFileSync(logPath, 'utf-8'));
        }
        logs.push(entry);
        fs.writeFileSync(logPath, JSON.stringify(logs, null, 2));
        
        realitySync.logEvent('NEXUS_INGESTION', { entryId: entry.id });
        res.json({ success: true, entry });
    } catch (e: any) {
        res.status(500).json({ error: e.message });
    }
});

quantumRoutes.get('/nexus/data', (req, res) => {
    try {
        const logPath = path.join(process.cwd(), 'data', 'nexus_ingestion_log.json');
        if (fs.existsSync(logPath)) {
            const logs = JSON.parse(fs.readFileSync(logPath, 'utf-8'));
            res.json({ success: true, logs });
        } else {
            res.json({ success: true, logs: [] });
        }
    } catch (e: any) {
        res.status(500).json({ error: e.message });
    }
});

quantumRoutes.get('/directives/core', (req, res) => {
  try {
    const p = path.resolve('system-prompt-core.md');
    let content = '';
    if (fs.existsSync(p)) {
      content = fs.readFileSync(p, 'utf-8');
    }
    res.json({ success: true, content });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

quantumRoutes.post('/directives/core', (req, res) => {
  try {
    const { content } = req.body;
    fs.writeFileSync(path.resolve('system-prompt-core.md'), content, 'utf-8');
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

quantumRoutes.post('/index/file', (req, res) => {
  try {
    const { filePath } = req.body;
    const count = GameIndexer.indexFile(filePath);
    res.json({ success: true, indexedCount: count });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

quantumRoutes.get('/index/search', (req, res) => {
  try {
    const { q } = req.query;
    const results = GameIndexer.search(q as string || '');
    res.json({ success: true, results });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

quantumRoutes.get('/bugs', (req, res) => {
  try {
    const bugs = memoryVault.prepare(`SELECT * FROM bug_tracker ORDER BY status DESC, created_at DESC`).all();
    res.json({ success: true, bugs });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

quantumRoutes.post('/bugs', (req, res) => {
  try {
    const { title, description, location } = req.body;
    memoryVault.prepare(`INSERT INTO bug_tracker (title, description, location) VALUES (?, ?, ?)`).run(title, description, location);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

quantumRoutes.put('/bugs/:id', (req, res) => {
  try {
    const { status, fixed_in_commit } = req.body;
    memoryVault.prepare(`UPDATE bug_tracker SET status = ?, fixed_in_commit = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`).run(status, fixed_in_commit, req.params.id);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

quantumRoutes.post('/telemetry/error', (req, res) => {
  try {
    const { message, source, lineno, colno, stack } = req.body;
    const desc = `Error: ${message}\nStack: ${stack || ''}\nCol/Line: ${colno}/${lineno}`;
    memoryVault.prepare(`INSERT INTO bug_tracker (title, description, location) VALUES (?, ?, ?)`).run(`Runtime Error: ${String(message).substring(0, 50)}`, desc, source || 'Game Client');
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

quantumRoutes.get('/prompts', (req, res) => {
  try {
    const prompts = memoryVault.prepare(`SELECT * FROM prompt_library ORDER BY use_count DESC`).all();
    res.json({ success: true, prompts });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

quantumRoutes.get('/gpus', (req, res) => {
  try {
    const gpus = memoryVault.prepare(`SELECT * FROM gpu_instances`).all();
    if (gpus.length === 0) {
      // Seed initial data
      memoryVault.prepare(`INSERT INTO gpu_instances (id, provider, gpu, cost_per_hr, status) VALUES (?, ?, ?, ?, ?)`).run('1', 'Vast.ai', 'RTX 3090', '$0.20/hr', 'OFFLINE');
      memoryVault.prepare(`INSERT INTO gpu_instances (id, provider, gpu, cost_per_hr, status) VALUES (?, ?, ?, ?, ?)`).run('2', 'RunPod', 'A100 (80GB)', '$0.34/hr', 'OFFLINE');
      const seedsGpus = memoryVault.prepare(`SELECT * FROM gpu_instances`).all();
      return res.json({ success: true, gpus: seedsGpus });
    }
    res.json({ success: true, gpus });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

quantumRoutes.post('/gpus/toggle', (req, res) => {
  try {
    const { id, status } = req.body;
    let ip = '';
    
    // De-activate all other running instances first to prevent conflicts
    if (status === 'RUNNING') {
      memoryVault.prepare(`UPDATE gpu_instances SET status = 'OFFLINE', ip_address = '', updated_at = CURRENT_TIMESTAMP WHERE id != ?`).run(id);
      ip = `10.0.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}:11434`;
      modelRouter.setLocalNodeUrl(`http://${ip}`);
    } else {
      modelRouter.setLocalNodeUrl(process.env.OLLAMA_URL || 'http://127.0.0.1:11434');
    }
    
    memoryVault.prepare(`UPDATE gpu_instances SET status = ?, ip_address = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`).run(status, ip, id);
    res.json({ success: true, ip });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

quantumRoutes.get('/kinetic/assets', (req, res) => {
  try {
    const assets = memoryVault.prepare(`SELECT * FROM kinetic_assets`).all();
    res.json({ success: true, assets });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

quantumRoutes.post('/kinetic/assets', (req, res) => {
  try {
    const { asset_name, asset_value, cash_flow } = req.body;
    memoryVault.prepare(`INSERT INTO kinetic_assets (asset_name, asset_value, cash_flow) VALUES (?, ?, ?)`).run(asset_name, asset_value, cash_flow);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

quantumRoutes.get('/kinetic/debts', (req, res) => {
  try {
    const debts = memoryVault.prepare(`SELECT * FROM debt_targets WHERE status = 'ACTIVE'`).all();
    res.json({ success: true, debts });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

quantumRoutes.post('/kinetic/debts', (req, res) => {
  try {
    const { creditor, total_amount, remaining_amount, interest_rate } = req.body;
    memoryVault.prepare(`INSERT INTO debt_targets (creditor, total_amount, remaining_amount, interest_rate) VALUES (?, ?, ?, ?)`).run(creditor, total_amount, remaining_amount, interest_rate);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

quantumRoutes.post('/kinetic/insight', async (req, res) => {
  try {
    const { assets, debts, cash_flow, net_worth } = req.body;
    
    // Construct the context state prompt
    const prompt = `Analyze this exact financial snapshot:
Assets: ${assets.map((a:any) => a.asset_name + " ($" + a.asset_value + ")").join(", ")}
Debts: ${debts.map((d:any) => d.creditor + " ($" + d.remaining_amount + " at " + d.interest_rate + "%)").join(", ")}
Monthly Cash Flow: $${cash_flow}
Current estimated net worth/trajectory: $${net_worth}

Provide a ruthless, hyper-optimized Kinetic Momentum strategy to accelerate asset acquisition and debt eradication. Output an immediate 3-step action plan using strict quantitative rules. Do not include fluffy motivational text. Only provide a dense, technical execution protocol.`;

    const strategy = await modelRouter.route({ prompt, taskType: 'HIGH_REASONING', context: {} });
    
    res.json({ success: true, strategy });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

quantumRoutes.post('/prompts', (req, res) => {
  try {
    const { title, content, task_type } = req.body;
    memoryVault.prepare(`INSERT INTO prompt_library (title, content, task_type) VALUES (?, ?, ?)`).run(title, content, task_type);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

quantumRoutes.get('/tasks', (req, res) => {
  try {
    const tasks = memoryVault.prepare(`SELECT * FROM autonomous_tasks ORDER BY created_at DESC LIMIT 50`).all();
    res.json({ success: true, tasks });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

quantumRoutes.post('/consensus', async (req, res) => {
  try {
    const { prompt, taskIntent } = req.body;
    // Launch 3 models in parallel for consensus
    const requests = [
      modelRouter.route({ prompt, taskType: 'HIGH_REASONING', context: {} }),
      modelRouter.route({ prompt, taskType: 'CODE_GEN', context: {} }),
      modelRouter.route({ prompt, taskType: 'DEFAULT', context: {} })
    ];
    
    const results = await Promise.allSettled(requests);
    const answers = results.map((r, i) => r.status === 'fulfilled' ? r.value : `Error Model ${i}`);
    
    // We would parse and check if they agree here. 
    // For now, return all 3 for the user to compare.
    res.json({
      success: true,
      options: answers
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

quantumRoutes.post('/upload', (req, res) => {
  try {
    const { filename, content } = req.body;
    const fileId = QuantumFileEngine.storeFile(filename, content, 'Initial Upload');
    res.json({ success: true, fileId, filename, versionNumber: 1, tokenCount: Math.ceil(content.length / 4) });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

quantumRoutes.get('/file/:fileId', (req, res) => {
  try {
    const current = QuantumFileEngine.getCurrentFile(req.params.fileId);
    if (!current) return res.status(404).json({ error: 'Not found' });
    res.json({ success: true, content: current.content, filename: current.filename, version_number: current.version_number });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

quantumRoutes.get('/versions/:fileId', (req, res) => {
  try {
    const versions = QuantumFileEngine.getVersionHistory(req.params.fileId);
    res.json({ success: true, versions });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

quantumRoutes.get('/session/:sessionId/:fileId', (req, res) => {
  try {
    const session = QuantumContextManager.getSession(req.params.sessionId, req.params.fileId);
    res.json({ success: true, messages: session.messages });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

quantumRoutes.post('/rollback', (req, res) => {
  try {
    const { fileId, versionNumber } = req.body;
    const content = QuantumFileEngine.getVersion(fileId, versionNumber);
    if (!content) return res.status(404).json({ error: 'Version not found' });
    
    const original = QuantumFileEngine.getCurrentFile(fileId);
    const newId = QuantumFileEngine.storeFile(original ? original.filename : 'unknown', content, 'Rollback to v' + versionNumber, fileId);
    
    res.json({ success: true, currentVersionNumber: versionNumber });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

quantumRoutes.get('/pending/:sessionId', (req, res) => {
  res.json({ success: true, pending: [] });
});

quantumRoutes.post('/resolve', (req, res) => {
  res.json({ success: true });
});

quantumRoutes.post('/config', (req, res) => {
  res.json({ success: true });
});

quantumRoutes.post('/message', async (req, res) => {
  try {
    const { sessionId, fileId, message, directiveContext, useRazor } = req.body;
    const sysTime = SystemTemporalClock.nowISO();
    
    realitySync.logEvent('QUANTUM_MESSAGE_RECEPTION', { sessionId, messageLength: message?.length, sysTime });
    
    QuantumContextManager.saveMessage(sessionId, fileId, 'user', message);

    // INTENT DETECTION (Fast Model Tier 1)
    const intentPrompt = `Determine the user's intent. The message is: "${message}". Is this:
1. "CHAT" - A casual question, asking for advice, or conversational.
2. "CODE_EDIT" - A request to build, modify, change, or update exactly one workspace file.
3. "SELF_IMPROVEMENT" - A request for the AI to improve its own source code, update its own files, or add a feature to itself.

Respond with exactly one word: CHAT, CODE_EDIT, or SELF_IMPROVEMENT.`;

    const rawIntent = (await modelRouter.route({ prompt: intentPrompt, taskType: 'CHAT', context: {} })).trim();
    let computedIntent = 'CHAT';
    if (rawIntent.includes('CODE_EDIT')) computedIntent = 'CODE_EDIT';
    if (rawIntent.includes('SELF_IMPROVEMENT')) computedIntent = 'SELF_IMPROVEMENT';

    if (computedIntent === 'SELF_IMPROVEMENT') {
      // Trigger background Autonomous build
      const jobId = crypto.randomUUID();
      memoryVault.prepare('INSERT INTO autonomous_tasks (id, prompt, status) VALUES (?, ?, ?)').run(jobId, message, 'PENDING');
      await AutonomousQueueEngine.enqueue(jobId, message);
      
      const responseText = "I have detected a self-improvement request. I am spawning an autonomous background task to evaluate and modify my own source files. You can track progress in the terminal.";
      QuantumContextManager.saveMessage(sessionId, fileId, 'assistant', responseText);
      
      return res.json({
        success: true,
        fileId,
        reply: responseText,
        fileUpdated: false,
        newVersionNumber: 0,
        diffPayload: '',
        compressionStatus: 'STANDARD',
        jobId
      });
    }

    const { prompt, tokenCount, razorMap } = await QuantumContextManager.buildPrompt(sessionId, fileId, message, computedIntent, useRazor);
    
    // Attempt actual model routing depending on available routes
    const aiResponseText = await modelRouter.route({
      prompt: prompt,
      taskType: computedIntent === 'CODE_EDIT' ? 'CODE_EDIT' : 'CHAT',
      context: { razorMap }
    });

    QuantumContextManager.saveMessage(sessionId, fileId, 'assistant', aiResponseText);

    let fileUpdated = false;
    let newVersionNumber = 0;
    let diffPayload = '';

    // If there is DIFF output
    if (aiResponseText.includes('<<<<<<< SEARCH')) {
      const parts = aiResponseText.split(/<<<<<<< SEARCH|>>>>>>>/);
      diffPayload = aiResponseText; // pass Raw diff
      const newFileId = QuantumFileEngine.applyDiff(fileId, diffPayload, message.slice(0, 50));
      if (newFileId) {
        fileUpdated = true;
        const current = QuantumFileEngine.getCurrentFile(newFileId);
        newVersionNumber = current ? current.version_number : 0;
      }
    } else if (aiResponseText.includes('<!DOCTYPE html>') || aiResponseText.includes('export function')) {
      // Crude full file extraction for small files
      const match = aiResponseText.match(/```[a-z]*([\s\S]*?)```/);
      let content = match ? match[1].trim() : aiResponseText.trim();
      const current = QuantumFileEngine.getCurrentFile(fileId);
      if (current) {
        QuantumFileEngine.storeFile(current.filename, content, 'Full rewrite: ' + message.slice(0, 30), fileId);
        fileUpdated = true;
        newVersionNumber = current.version_number + 1;
      }
    }

    let newFileContent: string | null = null;
    if (fileUpdated) {
      const updatedFile = QuantumFileEngine.getCurrentFile(fileId);
      if (updatedFile) {
        newFileContent = updatedFile.content;
      }
    }

    res.json({ 
      success: true, 
      fileId, 
      reply: aiResponseText, 
      fileUpdated, 
      newVersionNumber, 
      diffPayload,
      compressionStatus: 'STANDARD',
      newFileContent
    });

  } catch (err: any) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// ... (other imports)

quantumRoutes.post('/autonomous/build', async (req, res) => {
  try {
    const jobId = crypto.randomUUID();
    memoryVault.prepare('INSERT INTO autonomous_tasks (id, prompt, status) VALUES (?, ?, ?)').run(jobId, req.body.prompt, 'PENDING');
    
    // Offload to background queue
    await AutonomousQueueEngine.enqueue(jobId, req.body.prompt);
    
    res.json({ jobId });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

quantumRoutes.get('/autonomous/status/:jobId', (req, res) => {
    try {
        const task = memoryVault.prepare('SELECT * FROM autonomous_tasks WHERE id = ?').get(req.params.jobId);
        if (!task) return res.status(404).json({ error: 'Task not found' });
        res.json(task);
    } catch (err: any) {
        res.status(500).json({ error: err.message });
    }
});

quantumRoutes.post('/autonomous/cancel/:jobId', async (req, res) => {
    try {
        const success = await AutonomousQueueEngine.cancelTask(req.params.jobId);
        res.json({ success });
    } catch (err: any) {
        res.status(500).json({ error: err.message });
    }
});
