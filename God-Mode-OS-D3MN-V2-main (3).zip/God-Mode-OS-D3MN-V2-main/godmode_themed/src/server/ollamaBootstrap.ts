import fetch from 'node-fetch';

class OllamaBootstrap {
  private get baseUrl() {
    return process.env.OLLAMA_URL || 'http://localhost:11434';
  }

  async init() {
    console.log(`[Ollama Bootstrap] Checking: ${this.baseUrl}`);
    try {
      const res = await fetch(`${this.baseUrl}/api/tags`);
      const data = await res.json() as any;
      const models = data.models.map((m: any) => m.name);
      
      let missing = false;
      if (!models.includes('qwen2.5-coder:14b') && !models.includes('qwen2.5-coder:14b:latest')) {
        console.log("OLLAMA: Model qwen2.5-coder:14b not found");
        missing = true;
      }
      
      if (!missing) {
         console.log("OLLAMA STATUS: Healthy (qwen2.5-coder:14b)");
      }
    } catch (e) {
      console.log(`[Ollama] OFFLINE at ${this.baseUrl} — all autonomous tasks will use paid API fallback. Start Ollama to enable free local inference.`);
    }
  }

  async getOllamaStatus() {
    try {
      const res = await fetch(`${this.baseUrl}/api/tags`);
      const data = await res.json() as any;
      return {
        running: true,
        modelsAvailable: data.models.map((m: any) => m.name),
        totalLocalCompute: "14B Params"
      };
    } catch (e) {
      return { running: false, modelsAvailable: [], totalLocalCompute: "0" };
    }
  }
}

export const ollamaBootstrap = new OllamaBootstrap();
