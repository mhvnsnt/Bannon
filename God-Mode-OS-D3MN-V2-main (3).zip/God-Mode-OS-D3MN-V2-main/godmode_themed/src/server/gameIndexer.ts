import fs from 'fs';
import { memoryVault } from './db';

export class GameIndexer {
  static indexFile(filePath: string) {
    if (!fs.existsSync(filePath)) return false;
    const content = fs.readFileSync(filePath, 'utf-8');
    const lines = content.split('\n');

    // Basic regex for functions and classes in JS/TS
    // e.g. function test()
    // const test = () =>
    // class Test
    
    const symbols = [];
    let currentClass = null;

    for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        
        let match = line.match(/(?:export\s+)?(?:async\s+)?function\s+([a-zA-Z0-9_]+)\s*\(/);
        if (match) {
            symbols.push({ type: 'function', name: match[1], lineStart: i + 1, code: match[0] });
            continue;
        }

        match = line.match(/(?:export\s+)?const\s+([a-zA-Z0-9_]+)\s*=\s*(?:async\s*)?(?:\([^)]*\)|[a-zA-Z0-9_]+)\s*=>/);
        if (match) {
            symbols.push({ type: 'function', name: match[1], lineStart: i + 1, code: match[0] });
            continue;
        }

        match = line.match(/(?:export\s+)?class\s+([a-zA-Z0-9_]+)/);
        if (match) {
            symbols.push({ type: 'class', name: match[1], lineStart: i + 1, code: match[0] });
            continue;
        }
    }

    const stmt = memoryVault.prepare(`INSERT INTO game_index (file_path, symbol_type, name, line_start, code) VALUES (?, ?, ?, ?, ?)`);

    memoryVault.transaction(() => {
        // Clear previous index for this file
        memoryVault.prepare(`DELETE FROM game_index WHERE file_path = ?`).run(filePath);
        
        for (const sym of symbols) {
            stmt.run(filePath, sym.type, sym.name, sym.lineStart, sym.code);
        }
    })();
    
    return symbols.length;
  }

  static search(query: string) {
    const term = `%${query}%`;
    return memoryVault.prepare(`SELECT * FROM game_index WHERE name LIKE ? OR code LIKE ? LIMIT 20`).all(term, term);
  }

  static getRelevantContext(query: string) {
    const results = this.search(query) as any[];
    if (!results || results.length === 0) return '';
    return results.map(r => `- ${r.symbol_type} ${r.name} at ${r.file_path}:${r.line_start}`).join('\n');
  }
}
