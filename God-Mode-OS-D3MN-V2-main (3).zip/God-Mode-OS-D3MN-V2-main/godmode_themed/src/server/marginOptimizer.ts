import { EconomicLedger } from './economicLedger';

export class MarginOptimizer {
    private ledger: EconomicLedger;
    private minMarginThreshold = 60.0; // 60% minimum requested profitability threshold

    constructor(private db: any = null) {
        this.ledger = new EconomicLedger(db);
    }

    /**
     * Checks if the real-time profit margin is safe.
     * Evaluates the margin health of the current system context.
     */
    public isMarginHealthy(): { healthy: boolean; margin: number; revenue: number; cost: number } {
        const stats = this.ledger.calculateBuildMargin();
        const healthy = stats.margin >= this.minMarginThreshold;
        return {
            healthy,
            margin: stats.margin,
            revenue: stats.revenue,
            cost: stats.cost
        };
    }

    /**
     * Determine the optimal model profile to execute a task based on real-time economic health.
     * If margins are unhealthy (<60% profit margin), we auto-scale all requests to the 'FAST' (cheaper) profile.
     */
    public optimizeProfile(
        taskIntent: string, 
        baseProfileName: string, 
        baseProfile: any
    ): { enforcedProfileName: string; isScaledDown: boolean; reason: string } {
        const health = this.isMarginHealthy();
        
        // If profit margins are unhealthy, enforce the FAST model profile to preserve credits
        if (!health.healthy && baseProfileName !== 'FAST') {
            return {
                enforcedProfileName: 'FAST',
                isScaledDown: true,
                reason: `Margin Optimizer scaling down from ${baseProfileName} to FAST. Current profit margin of ${health.margin}% is below safe operating threshold of ${this.minMarginThreshold}%. (Total Revenue: $${health.revenue}, Model Cost: $${health.cost})`
            };
        }

        return {
            enforcedProfileName: baseProfileName,
            isScaledDown: false,
            reason: `Margin healthy at ${health.margin}%. Utilizing standard routed profile: ${baseProfileName}.`
        };
    }
}
