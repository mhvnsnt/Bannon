import { memoryVault } from './db';
import { AutonomousEngine } from './autonomousEngine';
import { modelRouter } from './modelRouter';
import { EventEmitter } from 'events';

export const queueEvents = new EventEmitter();

export class AutonomousQueueEngine {
  private static activeWorkers = 0;
  private static MAX_CONCURRENCY = 5;

  static async enqueue(jobId: string, prompt: string): Promise<void> {
    console.log(`[AutonomousQueueEngine] Task [${jobId}] explicitly enqueued.`);
    // Defer processQueue so it doesn't block the caller synchronically
    setTimeout(() => {
      this.processQueue().catch(e => {
        console.error(`[AutonomousQueueEngine] Queue processor failure:`, e);
      });
    }, 100);
  }

  static async processQueue(): Promise<void> {
    if (this.activeWorkers >= this.MAX_CONCURRENCY) {
      console.log(`[AutonomousQueueEngine] Max concurrency reached (${this.activeWorkers}/${this.MAX_CONCURRENCY}). Yielding.`);
      return;
    }
    this.activeWorkers++;

    console.log(`[AutonomousQueueEngine] Worker booted. Active workers: ${this.activeWorkers}/${this.MAX_CONCURRENCY}`);

    try {
      while (true) {
        // Query next PENDING task, or RESTARTING task, ordered by created_at
        let task;
        try {
          // Use a fast transaction to acquire a task and mark it tentatively to avoid race conditions
          memoryVault.exec('BEGIN IMMEDIATE');
          task = memoryVault.prepare(`
            SELECT * FROM autonomous_tasks 
            WHERE status IN ('PENDING', 'QUEUED')
            ORDER BY created_at ASC LIMIT 1
          `).get() as any;

          if (task) {
             memoryVault.prepare(`UPDATE autonomous_tasks SET status = 'ACQUIRED' WHERE id = ?`).run(task.id);
          }
          memoryVault.exec('COMMIT');
        } catch (e) {
          memoryVault.exec('ROLLBACK');
          console.error('[AutonomousQueueEngine] Task acquisition failed:', e);
          break;
        }

        if (!task) {
          console.log(`[AutonomousQueueEngine] Queue drained. Worker terminating.`);
          break;
        }

        // Check if task was cancelled before execution
        // It might be cancelled immediately. If so, setting status to 'RUNNING' shouldn't happen.
        // Wait, 'CANCELLED' status might be missed because we just set it to 'ACQUIRED'.
        // But the intent was captured in memoryVault transaction if it was 'CANCELLED' instead of 'PENDING/QUEUED', we wouldn't have picked it.

        console.log(`[AutonomousQueueEngine] Booting Execution Environment for Job: ${task.id}`);
        queueEvents.emit('task_started', { jobId: task.id, timestamp: Date.now() });

        memoryVault.prepare(`
          UPDATE autonomous_tasks 
          SET status = 'RUNNING', started_at = CURRENT_TIMESTAMP 
          WHERE id = ?
        `).run(task.id);

        try {
          const engine = new AutonomousEngine(modelRouter);
          const result = await engine.runAutonomousTask(task.id, task.prompt);
          
          // Re-check status in case it was cancelled mid-flight
          const midFlightCheck = memoryVault.prepare(`SELECT status FROM autonomous_tasks WHERE id = ?`).get(task.id) as any;
          if (midFlightCheck && midFlightCheck.status === 'CANCELLED') {
              console.log(`[AutonomousQueueEngine] Task [${task.id}] was cancelled mid-flight.`);
              queueEvents.emit('task_cancelled', { jobId: task.id });
              continue;
          }

          memoryVault.prepare(`
            UPDATE autonomous_tasks 
            SET status = 'COMPLETED', result = ?, completed_at = CURRENT_TIMESTAMP 
            WHERE id = ?
          `).run(result, task.id);
          
          queueEvents.emit('task_completed', { jobId: task.id, result });
          console.log(`[AutonomousQueueEngine] Task [${task.id}] completed successfully.`);

        } catch (e: any) {
          console.error(`[AutonomousQueueEngine] Critical fail on task [${task.id}]:`, e);
          
          const maxRetries = 3;
          const currentRetries = task.retry_count || 0;

          if (currentRetries < maxRetries) {
              console.log(`[AutonomousQueueEngine] Task Retry. Re-queuing Task [${task.id}] (Attempt ${currentRetries + 1}/${maxRetries})`);
              memoryVault.prepare(`
                UPDATE autonomous_tasks 
                SET status = "PENDING", retry_count = retry_count + 1 
                WHERE id = ?
              `).run(task.id);
          } else {
             console.log(`[AutonomousQueueEngine] Task [${task.id}] exceeded max retries. Fatal Error.`);
             memoryVault.prepare(`
               UPDATE autonomous_tasks 
               SET status = 'FAILED', result = ?, completed_at = CURRENT_TIMESTAMP 
               WHERE id = ?
             `).run(`Max retries exceeded: ${e.message}`, task.id);
             queueEvents.emit('task_failed', { jobId: task.id, error: e.message });
          }
        }

        // Small delay to prevent tight-loop lockups and handle memory management slightly better
        await new Promise(resolve => setTimeout(resolve, 500));
      }
    } finally {
      this.activeWorkers--;
      console.log(`[AutonomousQueueEngine] Worker terminated. Active workers: ${this.activeWorkers}/${this.MAX_CONCURRENCY}`);
    }
  }

  static async cancelTask(jobId: string): Promise<boolean> {
     console.log(`[AutonomousQueueEngine] Attempting to cancel task: ${jobId}`);
     const res = memoryVault.prepare(`
       UPDATE autonomous_tasks 
       SET status = 'CANCELLED', completed_at = CURRENT_TIMESTAMP 
       WHERE id = ? AND status IN ('PENDING', 'QUEUED', 'RUNNING', 'ACQUIRED')
     `).run(jobId);
     
     if (res.changes > 0) {
        queueEvents.emit('task_cancelled', { jobId });
        return true;
     }
     return false;
  }
}


