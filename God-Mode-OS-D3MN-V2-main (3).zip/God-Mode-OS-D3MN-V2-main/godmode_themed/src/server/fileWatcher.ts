import { createRequire } from 'module';
const customRequire = typeof require !== 'undefined' ? require : createRequire(import.meta.url);

import chokidar from 'chokidar';
import path from 'path';
import crypto from 'crypto';
import fs from 'fs';

export const initializeFileSystemWatcher = (db: any) => {
    console.log(`[VAULT WATCHER] Initializing Nexus Source Code Sentinel...`);

    const watcher = chokidar.watch([
        path.join(process.cwd(), 'src'),
        path.join(process.cwd(), 'public'),
        path.join(process.cwd(), 'server.ts')
    ], {
        ignored: /(^|[\/\\])\../, // ignore dotfiles
        persistent: true,
        ignoreInitial: true
    });

    watcher.on('all', (event, filePath) => {
        console.log(`[VAULT WATCHER] Codebase perturbation [${event}]: ${filePath}`);
        
        try {
            const id = crypto.randomUUID();
            const stmt = db.prepare(`INSERT INTO kinetic_logs (id, session_id, stage_transition, bass_sensitivity, turbulence) VALUES (?, ?, ?, ?, ?)`);
            stmt.run(
                id,
                'nexus-watcher',
                `[CODE_MODIFICATION] ${event} on ${path.basename(filePath)}`,
                0.0,
                1.0
            );

        // Index semantically
            try {
                const content = fs.readFileSync(filePath, 'utf8');
                const { SemanticSearch } = require('./semanticSearch');
                SemanticSearch.indexFileContent(filePath, content).catch(e => console.error(`[VAULT WATCHER] Failed indexing:`, e));
            } catch (innerE) {
                console.error(`[VAULT WATCHER] Failed reading file for indexing:`, innerE);
            }
        } catch (e: any) {
            console.error(`[VAULT WATCHER] Entropy detected in DB insertion:`, e.message);
        }
    });
};
