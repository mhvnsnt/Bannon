import Database from 'better-sqlite3';
import path from 'path';

// Central Database Initialization
const dbPath = path.resolve('bannon_physics.db');
export const memoryVault = new Database(dbPath);

// Robust performance and consistency settings
memoryVault.pragma('journal_mode = WAL');
memoryVault.pragma('synchronous = NORMAL');
memoryVault.pragma('foreign_keys = ON');
console.log('✅ SQLite WAL mode enabled and DB initialized');
