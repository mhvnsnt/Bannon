import { useEffect, useRef } from 'react';
import { usePrimeStore } from '../lib/store';
import { AudioStimulusEngine } from '../lib/audioEngine';

export function useKineticHapticEngine() {
  const engineRef = useRef<AudioStimulusEngine | null>(null);

  useEffect(() => {
    // 1. Initialize Audio Engine constraints
    const initAudio = () => {
      if (!engineRef.current) {
        engineRef.current = new AudioStimulusEngine();
        engineRef.current.initializeEngine();
        // Base kinetic drone: 432 Hz carrier, a bit of low-end depth
        engineRef.current.deployFrequencyVector(432, 2.5, 'sine');
        // Initial state: muted until activity triggers it
        engineRef.current.adjustVolume(0);
      }
    };

    // User must interact first before audio context fully unlocks
    document.addEventListener('click', initAudio, { once: true });
    document.addEventListener('keydown', initAudio, { once: true });

    return () => {
      document.removeEventListener('click', initAudio);
      document.removeEventListener('keydown', initAudio);
      if (engineRef.current) {
        engineRef.current.terminateActiveWaves();
      }
    };
  }, []);

  useEffect(() => {
    // 2. Event Listeners for Kinetic Haptics via Device Vibration API
    const handleAutoHeal = (e: any) => {
      const msg = e.detail || '';
      // Distinct physical feeling: deep short pulses for write success
      if (typeof navigator !== 'undefined' && navigator.vibrate) {
        if (msg.includes('SUCCESS')) {
          navigator.vibrate([100, 50, 100]); // physical double tap
        } else {
          navigator.vibrate([200, 100, 300]); // heavy error drag
        }
      }
      
      // Throttle audio drone up briefly on file write, then back down
      if (engineRef.current) {
        engineRef.current.adjustVolume(0.15); // ramp up
        setTimeout(() => {
          if (engineRef.current) engineRef.current.adjustVolume(0);
        }, 800);
      }
    };

    const handleTerminalExec = (e: any) => {
      // Long, low, steady rumble when terminal commands run
      if (typeof navigator !== 'undefined' && navigator.vibrate) {
         navigator.vibrate([250]);
      }
      if (engineRef.current) {
        engineRef.current.adjustVolume(0.08); 
        setTimeout(() => {
          if (engineRef.current) engineRef.current.adjustVolume(0);
        }, 1500);
      }
    };

    window.addEventListener('quantum-auto-heal', handleAutoHeal as any);
    window.addEventListener('terminal-execution', handleTerminalExec as any);

    return () => {
      window.removeEventListener('quantum-auto-heal', handleAutoHeal as any);
      window.removeEventListener('terminal-execution', handleTerminalExec as any);
    };
  }, []);

  return null; // pure headless engine hook
}
