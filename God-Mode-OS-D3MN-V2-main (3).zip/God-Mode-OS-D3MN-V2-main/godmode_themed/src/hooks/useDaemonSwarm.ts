import { useState, useEffect } from 'react';

export interface SwarmThread {
  id: string;
  targetFile: string;
  status: 'scanning' | 'analyzing_fault' | 'proposing_patch' | 'healing' | 'resolved';
  progress: number;
}

export function useDaemonSwarm() {
  const [threads, setThreads] = useState<SwarmThread[]>([]);
  
  useEffect(() => {
     // Daemon Background Worker Loop
     const scanCycle = async () => {
         try {
             const res = await fetch('/api/armada/cli', {
                 method: 'POST',
                 headers: { 'Content-Type': 'application/json' },
                 body: JSON.stringify({ command: 'npx eslint src/ --ext .ts,.tsx' })
             });
             const data = await res.json();
             
             // Very basic simulation of finding faults based on stdout
             // In a real scenario we'd parse eslint output.
             // Here we'll just pick up random files for visualization if the lint fails,
             // or just show a "Scanning..." state if it passes.
             const output = data.output || "";
             
             if (output.includes('error') || output.includes('warning') || Math.random() > 0.5) {
                 // Spawning a new thread to heal
                 const id = `SWARM-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
                 setThreads(prev => [...prev, {
                     id,
                     targetFile: 'src/components/UnstableComponent.tsx',
                     status: 'analyzing_fault',
                     progress: 10
                 }]);
             }
         } catch(e) {
             console.error("Daemon swarm failed to execute CLI scan.");
         }
     };
     
     // Start the loop
     const interval = setInterval(scanCycle, 15000);
     return () => clearInterval(interval);
  }, []);

  // Animate the existing threads
  useEffect(() => {
      const animator = setInterval(() => {
          setThreads(prev => prev.map(t => {
              if (t.status === 'resolved') return t;
              
              let newProgress = t.progress + (Math.random() * 5);
              let newStatus: SwarmThread['status'] = t.status;
              
              if (newProgress > 30 && t.status === 'analyzing_fault') newStatus = 'proposing_patch';
              if (newProgress > 60 && t.status === 'proposing_patch') newStatus = 'healing';
              if (newProgress >= 100) {
                 newProgress = 100;
                 newStatus = 'resolved';
              }
              
              return { ...t, progress: newProgress, status: newStatus };
          }).filter(t => t.progress < 100 || Math.random() > 0.1)); // Slowly remove resolved threads
      }, 1000);
      
      return () => clearInterval(animator);
  }, []);

  return { threads };
}
