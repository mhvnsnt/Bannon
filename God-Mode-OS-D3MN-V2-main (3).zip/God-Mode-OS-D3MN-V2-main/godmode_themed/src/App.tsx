import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { useWorkspaceAutoSave } from "./hooks/useWorkspaceAutoSave";
import { GlobalErrorPanel } from "./components/GlobalErrorPanel";
import { usePrimeStore } from "./lib/store";
import { ErrorBoundary } from "./components/ErrorBoundary";
import { PanelErrorBoundary } from "./components/PanelErrorBoundary";
import { StatusBar } from "./components/StatusBar";
import { CommandPalette } from "./components/CommandPalette";
import { safeStorage } from "./lib/safeStorage";

import { WorkspaceExplorer } from "./components/WorkspaceExplorer";
// Lazy loading panel components to prevent initialization timeouts and optimize bundle size
const Dashboard = React.lazy(() => import("./components/Dashboard"));
const QuantumChat = React.lazy(() => import("./components/QuantumChat"));
const FieldLogs = React.lazy(() => import("./components/FieldLogs"));
const AutonomyForge = React.lazy(() => import("./components/AutonomyForge"));
const SecurityVault = React.lazy(() => import("./components/SecurityVault"));
const AutonomousSandbox = React.lazy(() => import("./components/AutonomousSandbox"));
const AutonomousAgents = React.lazy(() => import("./components/AutonomousAgents"));
const OverseerProtocol = React.lazy(() => import("./components/OverseerProtocol"));
const TemporalMemoryVault = React.lazy(() => import("./components/TemporalMemoryVault"));
const RealitySyncMonitor = React.lazy(() => import("./components/RealitySyncMonitor"));
const ForgeStudio = React.lazy(() => import("./components/ForgeStudio"));
const MediaForge = React.lazy(() => import("./components/MediaForge"));
const DirectiveVault = React.lazy(() => import("./components/DirectiveVault"));
const KineticWealth = React.lazy(() => import("./components/KineticWealth"));
const KineticResistanceEngine = React.lazy(() => import("./components/KineticResistanceEngine"));
const OrbitalResonance = React.lazy(() => import("./components/OrbitalResonance"));
const PrimeDirectivesOS = React.lazy(() => import("./components/PrimeDirectivesOS"));
const BinarySigilManager = React.lazy(() => import("./components/BinarySigilManager"));
const InfluenceArcEngine = React.lazy(() => import("./components/InfluenceArcEngine"));
const SettingsModal = React.lazy(() => import("./components/SettingsModal"));
const EnvironmentalControls = React.lazy(() => import("./components/EnvironmentalControls"));
const EarthObservationGrid = React.lazy(() => import("./components/EarthObservationGrid").then(m => ({ default: m.EarthObservationGrid })));
const CellularRejuvenationMatrix = React.lazy(() => import("./components/CellularRejuvenationMatrix").then(m => ({ default: m.CellularRejuvenationMatrix })));
const MasterBlueprintAtlas = React.lazy(() => import("./components/MasterBlueprintAtlas").then(m => ({ default: m.MasterBlueprintAtlas })));
const EnvironmentalTechGrid = React.lazy(() => import("./components/EnvironmentalTechGrid").then(m => ({ default: m.EnvironmentalTechGrid })));
const EmbodiedRoboticsInterface = React.lazy(() => import("./components/EmbodiedRoboticsInterface").then(m => ({ default: m.EmbodiedRoboticsInterface })));
const OneBitCompressionEngine = React.lazy(() => import("./components/OneBitCompressionEngine").then(m => ({ default: m.OneBitCompressionEngine })));
const AgenticSwarmMatrix = React.lazy(() => import("./components/AgenticSwarmMatrix").then(m => ({ default: m.AgenticSwarmMatrix })));
const TrendlineForecaster = React.lazy(() => import("./components/TrendlineForecaster").then(m => ({ default: m.TrendlineForecaster })));
const KineticHapticEngine = React.lazy(() => import("./components/KineticHapticEngine").then(m => ({ default: m.KineticHapticEngine })));
const AnatomicalPhysicsRig = React.lazy(() => import("./components/AnatomicalPhysicsRig").then(m => ({ default: m.AnatomicalPhysicsRig })));
const PrimeArchitectIDE = React.lazy(() => import("./components/PrimeArchitectIDE").then(m => ({ default: m.PrimeArchitectIDE })));
const QuantumFieldVisualizer = React.lazy(() => import("./components/QuantumFieldVisualizer"));
const SectorMatrixHub = React.lazy(() => import("./components/SectorMatrixHub"));
const ContextCuratorUI = React.lazy(() => import("./components/ContextCuratorUI").then(m => ({ default: m.ContextCuratorUI })));

const BiologicalOverride = React.lazy(() => import("./components/BiologicalOverride").then(m => ({ default: m.BiologicalOverride })));
const CrucibleProtocol = React.lazy(() => import("./components/CrucibleProtocol").then(m => ({ default: m.CrucibleProtocol })));
const NeuroplasticityEngine = React.lazy(() => import("./components/NeuroplasticityEngine").then(m => ({ default: m.NeuroplasticityEngine })));
const OmniSingularityNexus = React.lazy(() => import("./components/OmniSingularityNexus").then(m => ({ default: m.OmniSingularityNexus })));
const MetaconsciousApotheosis = React.lazy(() => import("./components/MetaconsciousApotheosis").then(m => ({ default: m.MetaconsciousApotheosis })));
const OmniverseHyperStructure = React.lazy(() => import("./components/OmniverseHyperStructure").then(m => ({ default: m.OmniverseHyperStructure })));
const AutonomousNavigationMatrix = React.lazy(() => import("./components/AutonomousNavigationMatrix").then(m => ({ default: m.AutonomousNavigationMatrix })));
const ApexCoreOS = React.lazy(() => import("./components/ApexCore").then(m => ({ default: m.ApexCoreOS })));
const AbundanceCompiler = React.lazy(() => import("./components/AbundanceCompiler").then(m => ({ default: m.AbundanceCompiler })));
const KineticVisualizer = React.lazy(() => import("./components/KineticVisualizer").then(m => ({ default: m.KineticVisualizer })));
const KineticCreativeControl = React.lazy(() => import("./components/KineticCreativeControl").then(m => ({ default: m.KineticCreativeControl })));
const MlabStudio = React.lazy(() => import("./components/MlabStudio"));
const TelemetryGrid = React.lazy(() => import("./components/TelemetryGrid").then(m => ({ default: m.TelemetryGrid })));
const CodeSurgeonPanel = React.lazy(() => import("./components/CodeSurgeonPanel"));
const GameIndexerPanel = React.lazy(() => import("./components/GameIndexerPanel"));
const TaskQueuePanel = React.lazy(() => import("./components/TaskQueuePanel"));
const PromptLibraryPanel = React.lazy(() => import("./components/PromptLibraryPanel"));
const DiffEditorPanel = React.lazy(() => import("./components/DiffEditorPanel"));
const GPURentalPanel = React.lazy(() => import("./components/GPURentalPanel"));
const HeadlessGameTesterPanel = React.lazy(() => import("./components/HeadlessGameTesterPanel"));
const ChangeHistoryPanel = React.lazy(() => import("./components/ChangeHistoryPanel"));
const DependencyGraphPanel = React.lazy(() => import("./components/DependencyGraphPanel"));
const CoreDirectivesPanel = React.lazy(() => import("./components/CoreDirectivesPanel"));
const KineticPayloadPanel = React.lazy(() => import("./components/KineticPayloadPanel"));
const BugTrackerPanel = React.lazy(() => import("./components/BugTrackerPanel"));
const SocialProofMonitor = React.lazy(() => import("./components/SocialProofMonitor"));
const GodModeOS = React.lazy(() => import("./components/GodModeOS"));
const CognitiveArchitectureNexus = React.lazy(() => import("./components/CognitiveArchitectureNexus"));
const SpatialCommandArchitecture = React.lazy(() => import("./components/SpatialCommandArchitecture"));
const MotorolaHardwareBridge = React.lazy(() => import("./components/MotorolaHardwareBridge"));
const EvolutionRoadmap = React.lazy(() => import("./components/EvolutionRoadmap"));
const MotorolaDataGrid = React.lazy(() => import("./components/MotorolaDataGrid"));
const RealityCompiler = React.lazy(() => import("./components/RealityCompiler"));
const CognitiveLinguisticsExplorer = React.lazy(() => import("./components/CognitiveLinguisticsExplorer"));
const NeurospatialWormhole = React.lazy(() => import("./components/NeurospatialWormhole"));
const FractalExpansionEngine = React.lazy(() => import("./components/FractalExpansionEngine"));
const MythEngine = React.lazy(() => import("./components/MythEngine").then(m => ({ default: m.MythEngine })));
const AppletLinter = React.lazy(() => import("./components/AppletLinter"));
const InceptionSandboxPanel = React.lazy(() => import("./components/InceptionSandboxPanel"));
// ── v9 NEW COMPONENTS (grafted in, keeping your UI) ──
const BiomechanicalSandbox = React.lazy(() => import("./components/BiomechanicalSandbox"));
const CurationDashboard = React.lazy(() => import("./components/CurationDashboard"));
const EconomicDashboard = React.lazy(() => import("./components/EconomicDashboard"));
const HealingMonitor = React.lazy(() => import("./components/HealingMonitor"));
const ParliamentViewer = React.lazy(() => import("./components/ParliamentViewer"));
const PaywallModal = React.lazy(() => import("./components/PaywallModal"));
const QuantumBuilder = React.lazy(() => import("./components/QuantumBuilder"));
const VoidMonitor = React.lazy(() => import("./components/VoidMonitor"));

import { ARMADA_NODES, PROVIDERS, ArmadaNode, ModelProvider } from "./types";
import {
  Hexagon,
  LayoutDashboard,
  Database,
  Cpu,
  Settings,
  PanelLeftClose,
  PanelLeft,
  PanelRightClose,
  Globe,
  Menu,
  X,
  ShieldAlert,
  Fingerprint,
  Power,
  Volume2,
  VolumeX,
  LogOut,
  Github,
  Eye,
  Code2,
  Music,
  Clock,
  Laptop,
  Camera,
  Terminal,
  Activity,
  ChevronDown,
  ChevronRight,
  Folder,
  Network,
  Check,
  Orbit,
  DollarSign,
  Users,
  Trophy,
  Focus,
  Wind,
  Dumbbell,
  Brain,
  Thermometer,
  Infinity as InfinityIcon,
  Sparkles,
  Smartphone,
  Code,
  Zap,
  Search,
  Bug as BugIcon,
  Server,
  BookOpen,
  Gamepad2,
  History,
  Target,
  Flame
} from "lucide-react";
import { Map as MapIcon } from "lucide-react";
import { useAuthState } from "react-firebase-hooks/auth";
import { auth, db } from "./lib/firebase";
import {
  GoogleAuthProvider,
  GithubAuthProvider,
  signInWithPopup,
  signOut,
  OAuthProvider,
} from "firebase/auth";
import { doc, getDoc, setDoc, addDoc, collection } from "firebase/firestore";
import { useFCM } from "./hooks/useFCM";

import { useKineticHapticEngine } from "./hooks/useKineticHapticEngine";

export function useViewportSensing() {
  useEffect(() => {
    const lockPerimeter = () => {
      const currentWidth = document.documentElement.clientWidth;
      usePrimeStore.getState().setGlassWidth(currentWidth);
      document.documentElement.style.setProperty(
        "--absolute-bound",
        `${currentWidth}px`,
      );
    };

    window.addEventListener("resize", lockPerimeter);
    lockPerimeter();

    return () => window.removeEventListener("resize", lockPerimeter);
  }, []);
}

const NavItem = React.memo(function NavItem({ active, icon, label, onClick, id, isPinned, onTogglePin }: any) {
  return (
    <div className="relative w-full flex items-center group">
      <button
        onClick={onClick}
        draggable={!!id}
        onDragStart={(e) => {
          if (id) {
            e.dataTransfer.setData("text/plain", id);
          }
        }}
        className={`flex items-center gap-3 w-full p-2.5 pr-8 rounded-xl border transition-all cursor-pointer ${active ? "bg-[#1a1a1a] border-fuchsia-500/30 text-white font-semibold shadow-lg shadow-black/50" : "bg-[#0c0c0c] border-[#1a1a1a] text-gray-400 hover:text-gray-200 hover:bg-[#111] hover:border-[#333]"}`}
      >
        <div className="shrink-0">{icon}</div>
        <span className="text-sm font-medium truncate">{label}</span>
      </button>
      {id && onTogglePin && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            onTogglePin(id);
          }}
          title={isPinned ? "Unpin Panel" : "Pin Panel"}
          className={`absolute right-2 opacity-0 group-hover:opacity-100 transition-opacity p-1 ${isPinned ? "opacity-100 text-fuchsia-400" : "text-gray-500 hover:text-gray-300"}`}
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill={isPinned ? "currentColor" : "none"} stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="17" x2="12" y2="22"></line><path d="M5 17h14v-1.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.68V6a3 3 0 0 0-3-3 3 3 0 0 0-3 3v4.68a2 2 0 0 1-1.11 1.87l-1.78.89A2 2 0 0 0 5 15.24Z"></path></svg>
        </button>
      )}
    </div>
  );
});

export const PANELS = [
  { id: 'prime_architect', label: "Prime Architect IDE", icon: <Code className="text-cyan-400" />, isMain: true },
  { id: 'inception', label: "Inception Sandbox", icon: <Flame className="text-rose-500 animate-pulse" />, isMain: true },
  { id: 'code_surgeon', label: "Code Surgeon", icon: <Sparkles className="text-fuchsia-400" />, isMain: true },
  { id: 'social_proof', label: "Social Proof Monitor", icon: <Network className="text-cyan-400" />, isMain: true },
  { id: 'god_mode_os', label: "God Mode OS", icon: <LayoutDashboard className="text-amber-400" />, isMain: true },
  { id: 'cog_nexus', label: "Cognitive Nexus", icon: <Brain className="text-fuchsia-400" />, isMain: true },
  { id: 'spatial_command', label: "Spatial Command Architecture", icon: <Hexagon className="text-teal-400" />, isMain: true },
  { id: 'motorola_bridge', label: "Motorola Hardware Bridge", icon: <Smartphone className="text-emerald-400" />, isMain: true },
  { id: 'motorola_grid', label: "Motorola Data Grid", icon: <Network className="text-emerald-500" />, isMain: true },
  { id: 'fractal_expansion', label: "Fractal Expansion Engine", icon: <Orbit className="text-emerald-400" />, isMain: true },
  { id: 'myth_engine', label: "The Myth Engine", icon: <Database className="text-blue-500" />, isMain: true },
  { id: 'reality_compiler', label: "Reality Compiler", icon: <Code className="text-fuchsia-400" />, isMain: true },
  { id: 'cogni_linguistics', label: "Cognitive Linguistics Explorer", icon: <Brain className="text-fuchsia-400 animate-pulse" />, isMain: true },
  { id: 'neuro_wormhole', label: "Neurospatial Wormhole", icon: <Orbit className="text-purple-500" />, isMain: true },
  { id: 'evolution_roadmap', label: "Evolution Roadmap", icon: <MapIcon className="text-cyan-400" />, isMain: true },
  { id: 'terminal', label: "QUANTUM CHAT", icon: <Terminal className="text-purple-400" />, isMain: true },
  { id: 'omniverse', label: "OMNIVERSE", icon: <Sparkles className="text-fuchsia-400" />, isMain: true },
  { id: 'apex', label: "Apex CoreOS", icon: <Cpu className="text-teal-400" />, isMain: true },
  { id: 'abundance', label: "Abundance Compiler", icon: <LayoutDashboard className="text-yellow-400" />, isMain: true },
  { id: 'quantum_reality', label: "Quantum Reality", icon: <Globe className="text-indigo-400" />, isMain: true },
  { id: 'mlab', label: "MLab DAW Music Studio", icon: <Music className="text-pink-400" />, isMain: true },
  { id: 'applet_linter', label: "Quantum Applet Linter", icon: <Activity className="text-amber-400" />, isMain: true },
  { id: 'file_explorer', label: "Project Files", icon: <Database className="text-cyan-400" />, isMain: true },
  { id: 'core_directives', label: "Core Directives", icon: <ShieldAlert className="text-red-500" />, isMain: true },
  { id: 'kinetic_payload', label: "Kinetic Payload", icon: <Target className="text-emerald-500" />, isMain: true },
  { id: 'game_indexer', label: "Bannon Game Indexer", icon: <Search className="text-emerald-400" />, isMain: true },
  { id: 'bug_tracker', label: "System Bug Tracker", icon: <BugIcon className="text-red-400" />, isMain: true },
  { id: 'task_queue', label: "Autonomous Tasks", icon: <Server className="text-blue-400" />, isMain: true },
  { id: 'diff_editor', label: "Diff Visualizer", icon: <Code className="text-pink-400" />, isMain: true },
  { id: 'gpu_rental', label: "GPU Rentals", icon: <Server className="text-purple-400" />, isMain: true },
  { id: 'prompt_library', label: "Prompt Library", icon: <BookOpen className="text-amber-400" />, isMain: true },
  { id: 'headless_tester', label: "Headless Tester", icon: <Gamepad2 className="text-orange-400" />, isMain: true },
  { id: 'change_history', label: "Change History", icon: <History className="text-pink-400" />, isMain: true },
  { id: 'dependency_graph', label: "Dependency Graph", icon: <Network className="text-indigo-400" />, isMain: true },
  // And the rest which were right panels...
  { id: 'dashboard', label: "Dashboard Overview", icon: <LayoutDashboard /> },
  { id: 'device_sensors', label: "Hardware/Sensor Bridge", icon: <Smartphone className="text-emerald-400" /> },
  { id: 'sector_matrix', label: "Sector Matrix Hub", icon: <Network className="text-indigo-400" /> },
  { id: 'metaconscious', label: "Metaconscious Apotheosis", icon: <Sparkles className="text-cyan-300" /> },
  { id: 'omni_nexus', label: "Omni-Singularity Nexus", icon: <InfinityIcon className="text-fuchsia-500" /> },
  { id: 'neuroplasticity', label: "Neuroplasticity Engine", icon: <Brain className="text-cyan-400" /> },
  { id: 'environmental', label: "Environmental OS (God Mode)", icon: <Thermometer className="text-red-400" /> },
  { id: 'earth_grid', label: "Earth Observation Grid", icon: <Globe className="text-emerald-500" /> },
  { id: 'cellular', label: "Cellular Rejuvenation Matrix", icon: <Thermometer className="text-rose-400" /> },
  { id: 'atlas', label: "Master Blueprint Atlas", icon: <MapIcon className="text-indigo-400" /> },
  { id: 'environmental_tech', label: "Environmental Tech Grid", icon: <Globe className="text-emerald-400" /> },
  { id: 'robotics', label: "Embodied Physical Robotics", icon: <Cpu className="text-cyan-400" /> },
  { id: 'compression', label: "One-Bit Compression Engine", icon: <Zap className="text-amber-400" /> },
  { id: 'swarms', label: "Agentic Swarm Matrix", icon: <Network className="text-indigo-400" /> },
  { id: 'forecaster', label: "Predictive Reality Forecaster", icon: <Activity className="text-cyan-400" /> },
  { id: 'haptics', label: "Kinetic Haptic Engine", icon: <Smartphone className="text-rose-400" /> },
  { id: 'physics', label: "Tomodachi Simulation Sandbox", icon: <Database className="text-fuchsia-400" /> },
  { id: 'crucible', label: "The Crucible Protocol", icon: <Dumbbell className="text-amber-500" /> },
  { id: 'override', label: "Biological Override", icon: <Activity className="text-emerald-500" /> },
  { id: 'arc_engine', label: "Influence Arc Engine", icon: <Orbit className="text-fuchsia-400" /> },
  { id: 'wealth', label: "Kinetic Wealth", icon: <DollarSign /> },
  { id: 'resistance', label: "Kinetic Resistance", icon: <Activity className="text-emerald-500" /> },
  { id: 'resonance', label: "Orbital Resonance", icon: <Users /> },
  { id: 'directives_architect', label: "Prime Architect", icon: <Trophy /> },
  { id: 'logs', label: "Activity Logs", icon: <Database className="text-blue-400" /> },
  { id: 'memory', label: "Temporal Memory Vault", icon: <Activity className="text-purple-400" /> },
  { id: 'reality_sync_monitor', label: "Reality Sync Monitor", icon: <Globe className="text-emerald-400" /> },
  { id: 'sandbox', label: "Autonomous Sandbox", icon: <Terminal className="text-emerald-400" /> },
  { id: 'forge_studio', label: "Forge Studio (IDE)", icon: <Laptop className="text-cyan-400" /> },
  { id: 'media_forge', label: "Media Forge (Tensor)", icon: <Camera className="text-indigo-400" /> },
  { id: 'directives', label: "Directive Vault", icon: <Terminal className="text-white" /> },
  { id: 'vault', label: "Security Vault", icon: <ShieldAlert className="text-red-500/80" /> },
  { id: 'curator', label: "Quantum Context Curator", icon: <Globe className="text-cyan-400" /> },
  { id: 'overseer', label: "Overseer Protocol", icon: <Eye className="w-5 h-5 text-indigo-400" />, adminOnly: true },
  // ── v9 NEW PANELS ──
  { id: 'biomechanical_sandbox', label: "Biomechanical Sandbox", icon: <Activity className="text-rose-400" />, isMain: true },
  { id: 'curation_dashboard', label: "Curation Engine", icon: <Sparkles className="text-amber-400" />, isMain: true },
  { id: 'economic_ledger', label: "Economic Ledger", icon: <DollarSign className="text-emerald-400" />, isMain: true },
  { id: 'healing_monitor', label: "Healing Monitor", icon: <Flame className="text-rose-500" />, isMain: true },
  { id: 'parliament_viewer', label: "Model Parliament", icon: <Users className="text-fuchsia-400" />, isMain: true },
  { id: 'quantum_builder', label: "Quantum Builder", icon: <Code2 className="text-cyan-400" />, isMain: true },
  { id: 'void_monitor', label: "Void Monitor", icon: <InfinityIcon className="text-purple-500" />, isMain: true },
];

const SidebarNavList = React.memo(function SidebarNavList({
  mainView,
  rightPanel,
  isPrimeNode,
  user,
  setMainView,
  setRightPanel,
  toggleRightPanel,
  onSignOut,
  onLogin,
}: {
  mainView: string;
  rightPanel: string | null;
  isPrimeNode: boolean;
  user: any;
  setMainView: (v: any) => void;
  setRightPanel: (v: string | null) => void;
  toggleRightPanel: (v: string) => void;
  onSignOut?: () => void;
  onLogin?: () => void;
}) {
  const [pinned, setPinned] = useState<string[]>(() => {
    try {
      const saved = safeStorage.getItem("workspace-pinned-panels");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [explorerExpanded, setExplorerExpanded] = useState(false);

  const togglePin = React.useCallback((id: string) => {
    setPinned(prev => {
      const next = prev.includes(id) ? prev.filter(p => p !== id) : [...prev, id];
      safeStorage.setItem("workspace-pinned-panels", JSON.stringify(next));
      return next;
    });
  }, []);

  const pinnedPanels = PANELS.filter(p => pinned.includes(p.id) && (!p.adminOnly || isPrimeNode));
  const unpinnedPanels = PANELS.filter(p => !pinned.includes(p.id) && (!p.adminOnly || isPrimeNode));

  return (
    <div className="flex flex-col gap-1 p-3 flex-1 overflow-y-auto no-scrollbar pb-24">
      {/* Persistent Core Links */}
      <NavItem
        key="terminal-core-top"
        id="terminal"
        active={mainView === "terminal"}
        icon={<Terminal className="text-purple-400 w-5 h-5" />}
        label="QUANTUM CHAT"
        isPinned={false}
        onTogglePin={undefined}
        onClick={() => {
          setMainView("terminal");
          setRightPanel(null);
        }}
      />
      <NavItem
        key="omniverse-core-top"
        id="omniverse"
        active={mainView === "omniverse"}
        icon={<Sparkles className="text-fuchsia-400 w-5 h-5" />}
        label="OMNIVERSE"
        isPinned={false}
        onTogglePin={undefined}
        onClick={() => {
          setMainView("omniverse");
          setRightPanel(null);
        }}
      />

      {/* Project Files Explorer */}
      <div className="my-1 px-3">
        <button
          onClick={() => setExplorerExpanded(!explorerExpanded)}
          className="flex items-center justify-between w-full text-left text-[11px] font-semibold text-cyan-400 tracking-wider py-1.5 hover:text-cyan-300 transition-colors uppercase outline-none focus:outline-none"
        >
          <span className="flex items-center gap-1.5 font-mono">
            <Folder className="w-3.5 h-3.5" />
            Project Files
          </span>
          {explorerExpanded ? (
            <ChevronDown className="w-3.5 h-3.5" />
          ) : (
            <ChevronRight className="w-3.5 h-3.5" />
          )}
        </button>
        {explorerExpanded && (
          <div className="mt-1 border border-zinc-800 bg-[#07070a]/90 rounded-lg p-2 max-h-[250px] overflow-y-auto custom-scrollbar text-xs shadow-[inset_0_0_10px_rgba(6,182,212,0.1)]">
            <WorkspaceExplorer 
              onFileSelect={(path, content) => {
                const event = new CustomEvent('open-workspace-file', { detail: { path, content } });
                window.dispatchEvent(event);
                setMainView("prime_architect");
                setRightPanel(null);
              }}
            />
          </div>
        )}
      </div>

      <div className="my-2 px-3">
        <div className="h-px w-full bg-[#222]" />
      </div>

      {pinnedPanels.length > 0 && (
        <>
          <div className="text-[10px] font-semibold text-fuchsia-500 px-3 py-2 mb-1 uppercase tracking-widest flex items-center gap-1.5 opacity-80">
            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="17" x2="12" y2="22"></line><path d="M5 17h14v-1.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.68V6a3 3 0 0 0-3-3 3 3 0 0 0-3 3v4.68a2 2 0 0 1-1.11 1.87l-1.78.89A2 2 0 0 0 5 15.24Z"></path></svg>
            Pinned Panels
          </div>
          {pinnedPanels.map((p) => (
            <NavItem
              key={p.id}
              id={p.id}
              active={p.isMain ? mainView === p.id : rightPanel === p.id}
              icon={p.icon}
              label={p.label}
              isPinned={true}
              onTogglePin={togglePin}
              onClick={() => {
                if (p.isMain) {
                  setMainView(p.id);
                  setRightPanel(null);
                } else {
                  toggleRightPanel(p.id);
                }
              }}
            />
          ))}
          <div className="my-2 px-3">
            <div className="h-px w-full bg-[#222]" />
          </div>
        </>
      )}

      <div className="text-[10px] font-semibold text-gray-500 px-3 py-2 mb-1 uppercase tracking-widest opacity-80">
        Interface Panels
      </div>
      
      {unpinnedPanels.map((p) => (
        <NavItem
          key={p.id}
          id={p.id}
          active={p.isMain ? mainView === p.id : rightPanel === p.id}
          icon={p.icon}
          label={p.label}
          isPinned={false}
          onTogglePin={togglePin}
          onClick={() => {
            if (p.isMain) {
              setMainView(p.id);
              setRightPanel(null);
            } else {
              toggleRightPanel(p.id);
            }
          }}
        />
      ))}

      <div className="mt-8 mb-2 px-3">
        <div className="h-px w-full bg-[#222]" />
      </div>
      <NavItem
        active={rightPanel === "vault"}
        icon={<ShieldAlert className="w-5 h-5 text-red-500/80" />}
        label="Security Vault"
        onClick={() => toggleRightPanel("vault")}
        id="vault"
      />
      <div className="mt-auto pt-4 border-t border-[#222222]/60 px-3">
        {user ? (
          <div className="flex flex-col gap-2">
            <div className="flex items-center gap-2 mb-2 px-2">
              <div className="w-8 h-8 rounded-full bg-purple-500/20 text-purple-400 flex items-center justify-center text-xs border border-purple-500/50">
                {user.email?.[0]?.toUpperCase() || "A"}
              </div>
              <div className="flex flex-col overflow-hidden">
                <span className="text-xs text-gray-300 truncate">{user.displayName || "Architect"}</span>
                <span className="text-[10px] text-gray-500 truncate">{user.email}</span>
              </div>
            </div>
            <NavItem
              active={false}
              icon={<LogOut className="w-5 h-5 text-red-400/80 hover:text-red-400 transition-colors" />}
              label="Disconnect Session"
              onClick={async () => {
                if (auth) {
                  try {
                    await signOut(auth);
                  } catch (e) {
                    console.warn("[AUTH] SignOut failed:", e);
                  }
                  console.log("[AUTH LOG] Clean session sign-out executed.");
                }
                if (onSignOut) onSignOut();
              }}
            />
          </div>
        ) : (
          <div className="flex flex-col gap-2 px-2">
            <button
              onClick={() => onLogin && onLogin()}
              className="flex items-center gap-2 bg-white text-black px-4 py-2 rounded-lg font-semibold w-full hover:bg-gray-200 transition-colors"
            >
              <div className="w-4 h-4 bg-black rounded-full" />
              <span>Google Connect</span>
            </button>
            <div className="text-[10px] text-gray-500 text-center mt-1">Authenticate to access Prime Network</div>
          </div>
        )}
      </div>
    </div>
  );
});

export default function App() {
  useViewportSensing();
  useFCM();
  useKineticHapticEngine();

  const [booting, setBooting] = useState(true);
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [firebaseConnected, setFirebaseConnected] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setBooting(false);
    }, 2500);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    // Safety check: if Firebase doesn't respond/load within 4.5 seconds,
    // override block and force safety-boot to offline fallback user.
    const safetyTimer = setTimeout(() => {
      if (loading) {
        console.warn("[SYSTEM HANDSHAKE] Auth handshake timed out on sandboxed/restricted network. Forcing safety-boot...");
        setUser({
          uid: "offline-identity-key",
          email: "MarquisWhitacre@gmail.com",
          displayName: "Marquis Whitacre (Offline)",
          photoURL: null,
        });
        setFirebaseConnected(false);
        setLoading(false);
      }
    }, 4500);
    return () => clearTimeout(safetyTimer);
  }, [loading]);

  useEffect(() => {
    if (!auth) {
      setUser(null);
      setFirebaseConnected(false);
      setLoading(false);
      return;
    }
    const unsub = auth.onAuthStateChanged((currentUser: any) => {
      if (currentUser) {
        setUser(currentUser);
        if (
          currentUser.uid !== "offline-identity-key" &&
          currentUser.uid !== "offline-architect"
        ) {
          setFirebaseConnected(true);
        } else {
          setFirebaseConnected(false);
        }
      } else {
        setUser(null);
        setFirebaseConnected(false);
      }
      setLoading(false);
    });
    return () => {
      if (unsub) unsub();
    };
  }, []);

  // ── THEME SYSTEM ──────────────────────────────────────────────────────────────
  const [isDark, setIsDark] = useState<boolean>(() => {
    try { return safeStorage.getItem("godmode-theme") !== "light"; } catch { return true; }
  });

  useEffect(() => {
    const root = document.documentElement;
    if (isDark) {
      root.classList.remove("light-mode");
    } else {
      root.classList.add("light-mode");
    }
    try { safeStorage.setItem("godmode-theme", isDark ? "dark" : "light"); } catch {}
  }, [isDark]);

  const toggleTheme = () => setIsDark(prev => !prev);
  // ─────────────────────────────────────────────────────────────────────────────

  const [mainView, setMainView] = useState<string>("prime_architect");
  const [isSplitWorkspace, setIsSplitWorkspace] = useState(false);
  const [splitViewRight, setSplitViewRight] = useState<string>("omniverse");
  const [isCmdPaletteOpen, setIsCmdPaletteOpen] = useState(false);
  const [isHoveringLeft, setIsHoveringLeft] = useState(false);
  const [isHoveringRight, setIsHoveringRight] = useState(false);

  const [presets, setPresets] = useState<{id: string, name: string, main: string, right: string, split: boolean}[]>(() => {
    try {
      const saved = safeStorage.getItem("workspace-layout-presets");
      if (saved) return JSON.parse(saved);
      return [
        { id: 'dev-preset', name: "Development Layout", main: "terminal", right: "forge_studio", split: true },
        { id: 'analytics-preset', name: "Analytics Layout", main: "abundance", right: "wealth", split: true }
      ];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    // Machine Learning heuristic: Track user interaction patterns and auto-suggest layout presets based on time and hardware bridge load
    const interval = setInterval(() => {
      const hour = new Date().getHours();
      
      // Simulate detecting a high load on the hardware bridge
      const simulateBridgeLoad = () => Math.random() > 0.85;
      const isHighLoad = simulateBridgeLoad();

      setPresets((prev) => {
        let next = [...prev];
        if (isHighLoad && !next.some(p => p.id === 'bridge-ops-auto')) {
          next.push({ id: 'bridge-ops-auto', name: 'Bridge Max Load (Heuristic)', main: 'motorola_bridge', right: 'motorola_grid', split: true });
        }
        if ((hour >= 22 || hour <= 4) && !next.some(p => p.id === 'night-ops-auto')) {
          next.push({ id: 'night-ops-auto', name: 'Night Ops (Heuristic)', main: 'terminal', right: 'vault', split: true });
        } else if ((hour >= 9 && hour <= 17) && !next.some(p => p.id === 'day-ops-auto')) {
          next.push({ id: 'day-ops-auto', name: 'Day Ops (Heuristic)', main: 'god_mode_os', right: 'abundance', split: true });
        }
        return next;
      });
    }, 10000); // Check every 10 seconds

    return () => clearInterval(interval);
  }, []);

  const onSavePreset = () => {
    const name = `Preset: ${mainView} ${isSplitWorkspace ? `+ ${splitViewRight}` : ''}`;
    const next = [...presets, { id: Date.now().toString(), name, main: mainView, right: splitViewRight, split: isSplitWorkspace }];
    setPresets(next);
    safeStorage.setItem("workspace-layout-presets", JSON.stringify(next));
  };

  const onLoadPreset = (preset: any) => {
    setMainView(preset.main);
    setSplitViewRight(preset.right);
    setIsSplitWorkspace(preset.split);
  };

  useEffect(() => {
    const handleGlobalKeys = (e: KeyboardEvent) => {
      // Cmd/Ctrl + K (Command Palette)
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setIsCmdPaletteOpen((prev) => !prev);
      }
      // Cmd/Ctrl + B (Toggle Left Sidebar)
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "b") {
        e.preventDefault();
        setLeftSidebarOpen((prev) => !prev);
      }
      // Cmd/Ctrl + S (Toggle Split View)
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "s") {
        e.preventDefault();
        setIsSplitWorkspace((prev) => !prev);
      }
    };
    window.addEventListener("keydown", handleGlobalKeys);
    return () => window.removeEventListener("keydown", handleGlobalKeys);
  }, []);

  const renderWorkspacePanel = (name: string) => {
    const getPanelElement = () => {
      switch (name) {
        case "prime_architect":
          return <PrimeArchitectIDE />;
        case "inception":
          return <InceptionSandboxPanel />;
        case "code_surgeon":
          return <CodeSurgeonPanel />;
        case "social_proof":
          return <SocialProofMonitor />;
        case "god_mode_os":
          return (
            <GodModeOS onNavigate={(id, isRight) => {
              if (isRight) {
                setIsSplitWorkspace(true);
                setSplitViewRight(id);
              } else {
                setMainView(id);
              }
            }} />
          );
        case "cog_nexus":
          return <CognitiveArchitectureNexus />;
        case "spatial_command":
          return <SpatialCommandArchitecture />;
        case "motorola_bridge":
          return <MotorolaHardwareBridge />;
        case "motorola_grid":
          return <MotorolaDataGrid />;
        case "fractal_expansion":
          return <FractalExpansionEngine />;
        case "myth_engine":
          return <MythEngine />;
        case "reality_compiler":
          return <RealityCompiler />;
        case "cogni_linguistics":
          return <CognitiveLinguisticsExplorer />;
        case "neuro_wormhole":
          return <NeurospatialWormhole />;
        case "evolution_roadmap":
          return <EvolutionRoadmap />;
        case "mlab":
          return <MlabStudio />;
        case "terminal":
          return <QuantumChat />;
        case "omniverse":
          return <OmniverseHyperStructure />;
        case "apex":
          return <ApexCoreOS />;
        case "abundance":
          return <AbundanceCompiler />;
        case "quantum_reality":
          return <QuantumFieldVisualizer />;
        case "dashboard":
          return <Dashboard />;
        case "logs":
          return <FieldLogs />;
        case "vault":
          return <SecurityVault />;
        case "curator":
          return <ContextCuratorUI />;
        case "sandbox":
          return <AutonomousSandbox />;
        case "agents":
          return <AutonomousAgents />;
        case "overseer":
          return <OverseerProtocol />;
        case "memory":
          return <TemporalMemoryVault />;
        case "reality_sync_monitor":
          return <RealitySyncMonitor />;
        case "forge_studio":
          return <ForgeStudio />;
        case "media_forge":
          return <MediaForge />;
        case "directives":
          return <DirectiveVault />;
        case "wealth":
          return <KineticWealth />;
        case "resistance":
          return <KineticResistanceEngine />;
        case "resonance":
          return <OrbitalResonance />;
        case "directives_architect":
          return <PrimeDirectivesOS />;
        case "sigils":
          return <BinarySigilManager />;
        case "arc_engine":
          return <InfluenceArcEngine />;
        case "environmental":
          return <EnvironmentalControls />;
        case "earth_grid":
          return <EarthObservationGrid />;
        case "cellular":
          return <CellularRejuvenationMatrix />;
        case "robotics":
          return <EmbodiedRoboticsInterface />;
        case "compression":
          return <OneBitCompressionEngine />;
        case "swarms":
          return <AgenticSwarmMatrix />;
        case "forecaster":
          return <TrendlineForecaster />;
        case "haptics":
          return <KineticHapticEngine />;
        case "physics":
          return <AnatomicalPhysicsRig />;
        case "atlas":
          return <MasterBlueprintAtlas />;
        case "environmental_tech":
          return <EnvironmentalTechGrid />;
        case "override":
          return <BiologicalOverride />;
        case "applet_linter":
          return <AppletLinter />;
        case "file_explorer":
          return <WorkspaceExplorer onFileSelect={(path, content) => {
            setMainView("prime_architect");
            console.log(`Opening file: ${path}`);
          }} />;
        case "game_indexer":
          return <GameIndexerPanel />;
        case "bug_tracker":
          return <BugTrackerPanel />;
        case "task_queue":
          return <TaskQueuePanel />;
        case "prompt_library":
          return <PromptLibraryPanel />;
        case "diff_editor":
          return <DiffEditorPanel />;
        case "gpu_rental":
          return <GPURentalPanel />;
        case "headless_tester":
          return <HeadlessGameTesterPanel />;
        case "change_history":
          return <ChangeHistoryPanel />;
        case "dependency_graph":
          return <DependencyGraphPanel />;
        case "core_directives":
          return <CoreDirectivesPanel />;
        case "kinetic_payload":
          return <KineticPayloadPanel />;
        case "crucible":
          return <CrucibleProtocol />;
        case "neuroplasticity":
          return <NeuroplasticityEngine />;
        case "omni_nexus":
          return <OmniSingularityNexus />;
        case "metaconscious":
          return <MetaconsciousApotheosis />;
        case "sector_matrix":
          return <SectorMatrixHub />;
        case "device_sensors":
          return (
            <TelemetryGrid 
              flickerRate={60} 
              colorTemperature={5000} 
              intensity={80} 
              activeAcoustic="Stereo Monitor" 
              activePhotonic="Photonic Matrix" 
              activeAtmospheric="Standard" 
            />
          );
        // ── v9 NEW PANELS (grafted in) ──
        case "biomechanical_sandbox":
          return <BiomechanicalSandbox />;
        case "curation_dashboard":
          return <CurationDashboard />;
        case "economic_ledger":
          return <EconomicDashboard />;
        case "healing_monitor":
          return <HealingMonitor />;
        case "parliament_viewer":
          return <ParliamentViewer />;
        case "paywall_modal":
          return <PaywallModal />;
        case "quantum_builder":
          return <QuantumBuilder />;
        case "void_monitor":
          return <VoidMonitor />;
        default:
          return <QuantumChat />;
      }
    };

    const label = name.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase());
    return (
      <PanelErrorBoundary panelName={label}>
        {getPanelElement()}
      </PanelErrorBoundary>
    );
  };

  const [leftSidebarOpen, setLeftSidebarOpen] = useState(() => typeof window !== 'undefined' ? window.innerWidth >= 768 : true);
  
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 768) {
        setLeftSidebarOpen(false);
      }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);
  const [rightPanel, setRightPanel] = useState<string | null>(null);
  const [isFingerprintPrompt, setIsFingerprintPrompt] = useState(false);
  const [showPrimeSync, setShowPrimeSync] = useState(false);
  const [showOmniPortal, setShowOmniPortal] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [bridgeLoad, setBridgeLoad] = useState(0);

  useEffect(() => {
     // Cognitive Field Depth of Field heuristic simulate bridge load
     const loadInterval = setInterval(() => {
        setBridgeLoad(prev => Math.max(0, Math.min(1, prev + (Math.random() - 0.4) * 0.3)));
     }, 2000);
     return () => clearInterval(loadInterval);
  }, []);

  // Centralized state-to-Firestore auto-save sync debounced at 5 seconds
  useWorkspaceAutoSave(
    user?.uid,
    { mainView, splitViewRight, rightPanel, isSplitWorkspace, leftSidebarOpen },
    { setMainView, setSplitViewRight, setRightPanel, setIsSplitWorkspace, setLeftSidebarOpen }
  );

  const handlePortalNavigation = (type: "main" | "panel", id: any) => {
    if (type === "main") {
      setMainView(id);
    } else {
      setRightPanel(id);
    }
    setShowOmniPortal(false);
  };
  const [isAdmin, setIsAdmin] = useState(false);
  const activeNode = usePrimeStore((state) => state.activeNode);
  const setActiveNode = usePrimeStore((state) => state.setActiveNode);
  const activeProvider = usePrimeStore((state) => state.activeProvider);
  const setActiveProvider = usePrimeStore((state) => state.setActiveProvider);
  const daemonInsight = usePrimeStore((state) => state.daemonInsight);

  const [providerDropdownOpen, setProviderDropdownOpen] = useState(false);
  const [nodeDropdownOpen, setNodeDropdownOpen] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [tier, setTier] = useState<"free" | "Apex">("free");

  const userEmail = user?.email;
  const userUid = user?.uid;

  useEffect(() => {
    async function initializeUserNode() {
      if (userUid) {
        const isPrime = userEmail === "MarquisWhitacre@gmail.com";
        setTier(isPrime ? "Apex" : "free");
        if (isPrime) setIsAdmin(true);
      }
    }
    initializeUserNode();
  }, [userEmail, userUid, firebaseConnected]);

  const toggleRightPanel = (panel: string) => {
    if (rightPanel === panel) {
      setRightPanel(null);
    } else {
      setRightPanel(panel);
    }
  };

  const handleLogin = async (providerName: "google" | "github" | "discord") => {
    setLoading(true);
    try {
      const isOfflineMode = !auth || typeof auth.signInWithPopup !== "function";
      if (isOfflineMode) {
        setUser({
          uid: "offline-identity-key",
          email: "MarquisWhitacre@gmail.com",
          displayName: "Marquis Whitacre (Offline)",
          photoURL: null,
        });
        setFirebaseConnected(false);
      } else {
        const provider = new GoogleAuthProvider();
        provider.setCustomParameters({ prompt: "select_account" });
        const result = await signInWithPopup(auth, provider);
        const loggedUser = result.user;
        setUser(loggedUser);
        setFirebaseConnected(true);
        console.log("[AUTH LOG] Real Google Account handshake complete:", loggedUser.email);
      }
    } catch (err) {
      console.warn("[AUTH WARNING] Real Google auth canceled or restricted. Activating offline fallback:", err);
      setUser({
        uid: "offline-identity-key",
        email: "MarquisWhitacre@gmail.com",
        displayName: "Marquis Whitacre (Offline)",
        photoURL: null,
      });
      setFirebaseConnected(false);
    } finally {
      setLoading(false);
    }
  };

  if (booting || loading) {
    return (
      <div className="flex h-[100dvh] bg-[#0a0a0a] text-white items-center justify-center font-mono">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-2 border-dashed border-fuchsia-500 border-t-transparent animate-[spin_3s_linear_infinite] rounded-full flex items-center justify-center">
            <div className="w-6 h-6 border-2 border-purple-400 border-b-transparent animate-[spin_1.5s_linear_infinite_reverse] rounded-full" />
          </div>
          <div className="text-sm tracking-widest text-fuchsia-400 font-bold uppercase mt-4">Nexus OS Daemon IS WAKING...</div>
          <div className="text-[10px] text-gray-500 font-mono">Calibrating Sector Matrix Hubs...</div>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="flex flex-col h-[100dvh] bg-[#0a0a0a] text-white items-center justify-center font-sans px-4 relative overflow-hidden">
        <div className="bg-grid-pulse" />
        <h1 className="text-3xl font-bold tracking-tight mb-2 z-10 text-center flex items-center gap-3">
          <span className="text-fuchsia-500 font-mono">❖</span> Identity Access Matrix
        </h1>
        <p className="text-gray-400 text-sm mb-6 z-10 font-mono tracking-widest uppercase">Awaiting Quantum Biometric Sync</p>
        <div className="flex flex-col gap-3 w-full max-w-[280px] z-10">
          <button
            onClick={() => handleLogin("google")}
            className="flex items-center justify-center gap-3 bg-white hover:bg-gray-200 text-black px-6 py-3 rounded-lg font-semibold w-full transition-all hover:scale-[1.02] shadow-[0_0_20px_rgba(255,255,255,0.1)] hover:shadow-[0_0_30px_rgba(255,255,255,0.2)]"
          >
            <svg viewBox="0 0 24 24" className="w-5 h-5">
               <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
               <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
               <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
               <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
             </svg>
            Connect via Google
          </button>
        </div>
      </div>
    );
  }

  const isPrimeNode = isAdmin;

  const handleKillswitch = async () => {
    setIsFingerprintPrompt(true);
    setTimeout(() => {
      setIsFingerprintPrompt(false);
      alert(
        "✅ BIOMETRIC SIGNATURE VERIFIED.\n\nOBSIDIAN DEAD MAN SWITCH ACTIVATED.",
      );
    }, 1500);
  };

  return (
    <div 
      className="flex h-[100dvh] bg-[#0a0a0a] text-gray-200 font-sans overflow-hidden relative w-full"
      style={{
        paddingTop: "env(safe-area-inset-top, 0px)",
        paddingBottom: "env(safe-area-inset-bottom, 0px)"
      }}
    >
      <div className="bg-grid-pulse" />
      {leftSidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-20 md:hidden backdrop-blur-sm"
          onClick={() => setLeftSidebarOpen(false)}
        />
      )}

      <AnimatePresence initial={false}>
        {leftSidebarOpen && (
          <motion.div
            className="absolute md:relative inset-y-0 left-0 flex flex-col bg-[#111111] border-r border-[#222222] z-30 shrink-0 overflow-hidden shadow-2xl md:shadow-none sidebar-glass-panel w-full md:w-64"
            initial={{ x: -300 }}
            animate={{ x: 0 }}
            exit={{ x: -300 }}
            transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
          >
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3, delay: 0.1, ease: "easeOut" }}
              className="w-full h-full flex flex-col"
            >
              <div className="p-4 flex items-center justify-between border-b border-[#222222] h-14 shrink-0">
                <h1 className="font-semibold text-fuchsia-400 text-xs tracking-widest uppercase flex items-center gap-2">
                  <Orbit className="w-4 h-4 flex-shrink-0" />
                  God Mode OS
                </h1>
                <button
                  className="md:hidden p-1 text-gray-400 hover:text-white"
                  onClick={() => setLeftSidebarOpen(false)}
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <SidebarNavList
                mainView={mainView}
                rightPanel={rightPanel}
                isPrimeNode={isPrimeNode}
                user={user}
                onLogin={() => handleLogin("google")}
                setMainView={setMainView}
                setRightPanel={setRightPanel}
                toggleRightPanel={toggleRightPanel}
                onSignOut={() => {
                  setUser(null);
                  setFirebaseConnected(false);
                }}
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex-1 flex flex-col min-w-0 bg-[#0a0a0a] w-full relative h-[100dvh] overflow-hidden">
        <header className="h-14 flex items-center justify-between px-3 md:px-4 border-b border-[#222222] shrink-0 bg-[#070707] z-10 w-full relative gap-3 shadow-md">
          {/* Left Navigation: OS Sidebar Toggle */}
          <div className="flex items-center shrink-0">
            <button
              onClick={() => setLeftSidebarOpen(!leftSidebarOpen)}
              className="px-3 py-2 flex items-center gap-2 border border-[#444] tracking-widest text-[11px] uppercase font-bold text-gray-200 hover:text-white bg-[#1a1a1a] hover:bg-[#2a2a2a] rounded-lg transition-all shadow-md focus:ring-2 focus:ring-fuchsia-500/50"
              title="Open God Mode OS Sidebar"
              id="sidebar-toggle-btn"
            >
              <Menu className="w-4 h-4 text-fuchsia-500" />
              <span className="hidden xs:inline">GOD MODE OS</span>
            </button>
          </div>

          {/* Centered Segmented Control for Core Views: QUANTUM CHAT vs OMNIVERSE */}
          <div className="flex items-center gap-1 sm:gap-2 bg-[#121212] p-1 rounded-lg border border-[#2d2d2d] shadow-inner shrink-0" id="header-segmented-tabs">
            <button
              onClick={() => setMainView("terminal")}
              className={`flex items-center gap-1.5 px-3 py-1.5 border rounded-md transition-all font-bold text-[10px] tracking-widest uppercase focus:ring-1 focus:ring-cyan-500/50 ${mainView === "terminal" ? "bg-cyan-950/80 border-cyan-500/50 text-cyan-300 shadow-sm" : "bg-transparent border-transparent text-gray-400 hover:text-white"}`}
              title="Open Quantum Chat"
              id="quantum-chat-nav-btn"
            >
              <Orbit className={`w-3.5 h-3.5 ${mainView === "terminal" ? "text-cyan-300" : "text-fuchsia-400"}`} />
              <span className="hidden sm:inline">QUANTUM CHAT</span>
            </button>

            <button
              onClick={() => setMainView("omniverse")}
              className={`flex items-center gap-1.5 px-3 py-1.5 border rounded-md transition-all font-bold text-[10px] tracking-widest uppercase focus:ring-1 focus:ring-amber-500/50 ${mainView === "omniverse" ? "bg-fuchsia-950/80 border-fuchsia-500/50 text-fuchsia-300 shadow-sm" : "bg-transparent border-transparent text-gray-400 hover:text-white"}`}
              title="Open Omniverse Dashboard"
              id="omniverse-nav-btn"
            >
              <Sparkles className={`w-3.5 h-3.5 ${mainView === "omniverse" ? "text-fuchsia-300" : "text-amber-500"}`} />
              <span className="hidden sm:inline">OMNIVERSE</span>
            </button>
          </div>
          
          <div className="flex items-center gap-3">
            {daemonInsight ? (
              <div className="hidden lg:flex items-center gap-2 px-3 py-1.5 rounded-lg border border-purple-500/50 bg-[#110522] text-[10px] font-mono shadow-[0_0_10px_rgba(168,85,247,0.3)]">
                <span className="w-2 h-2 rounded-full bg-purple-500 animate-pulse shadow-[0_0_8px_#a855f7] inline-block" />
                <span className="text-purple-300 tracking-widest leading-none drop-shadow-[0_0_3px_rgba(168,85,247,0.5)]">
                  {daemonInsight}
                </span>
              </div>
            ) : null}

            {/* Real-time Device Sync Heartbeat */}
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg border border-[#333] bg-[#0a0a0a] text-xs font-mono font-medium">
              <div className="relative flex items-center justify-center w-3 h-3">
                <span className="absolute inline-flex w-full h-full rounded-full bg-emerald-400 opacity-75 animate-ping" />
                <span className="relative inline-flex w-2 h-2 rounded-full bg-emerald-500" />
              </div>
              <span className="text-gray-400">EDGE_NODE:</span>
              <span className="text-emerald-400">SYNCED</span>
            </div>

            <button
              onClick={() => setIsSplitWorkspace((prev) => !prev)}
              className={`px-3 py-1.5 rounded-lg border text-xs font-mono font-medium transition-all flex items-center gap-1.5 ${
                isSplitWorkspace
                  ? "bg-purple-900/40 border-purple-500/50 text-purple-300 shadow-md shadow-purple-500/10"
                  : "bg-[#111] border-[#333] text-gray-400 hover:text-white"
              }`}
              title="Toggle Parallel Split-View Workspace"
            >
              <LayoutDashboard className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{isSplitWorkspace ? "SPLIT ACTIVE" : "SPLIT VIEW"}</span>
            </button>
            <button
              onClick={toggleTheme}
              className={`px-3 py-1.5 rounded-lg border text-xs font-mono font-medium transition-all flex items-center gap-1.5 ${
                isDark
                  ? "bg-[#111] border-[#333] text-gray-400 hover:text-amber-300 hover:border-amber-500/40"
                  : "bg-amber-50 border-amber-300 text-amber-700 hover:bg-amber-100"
              }`}
              title={isDark ? "Switch to Light Mode" : "Switch to Dark Mode"}
            >
              <span className="text-sm">{isDark ? "☀️" : "🌙"}</span>
              <span className="hidden sm:inline">{isDark ? "LIGHT" : "DARK"}</span>
            </button>
            <StatusBar />
          </div>
        </header>

        <div className="flex-1 overflow-hidden relative flex">
          <ErrorBoundary>
            <React.Suspense fallback={
              <div className="flex h-full w-full flex-col items-center justify-center font-mono text-purple-400 gap-3 bg-[#0a0a0a]">
                <div className="w-5 h-5 border-2 border-purple-500 border-t-transparent animate-spin rounded-full"></div>
                <div className="h-0.5 w-32 bg-gray-800 rounded-full overflow-hidden">
                   <div className="h-full bg-purple-500 animate-[pulse_1s_ease-in-out_infinite]" style={{ width: '100%' }}></div>
                </div>
                <span className="text-xs">Loading panel module...</span>
              </div>
            }>
              <div className={`w-full h-full flex flex-col md:flex-row overflow-hidden ${isSplitWorkspace ? 'divide-y md:divide-y-0 md:divide-x divide-[#222]' : ''}`}>
                <motion.div
                  layout
                  transition={{ type: "spring", stiffness: 300, damping: 30 }}
                  className={`relative overflow-hidden transition-all ${
                    isSplitWorkspace ? "flex-1" : "w-full"
                  } ${isHoveringLeft ? "bg-purple-950/25 ring-2 ring-purple-500 ring-dashed" : ""}`}
                  onDragOver={(e) => e.preventDefault()}
                  onDragEnter={() => setIsHoveringLeft(true)}
                  onDragLeave={() => setIsHoveringLeft(false)}
                  onDrop={(e) => {
                    e.preventDefault();
                    setIsHoveringLeft(false);
                    const draggedId = e.dataTransfer.getData("text/plain");
                    if (draggedId) setMainView(draggedId as any);
                  }}
                >
                  {isSplitWorkspace && (
                    <div className="absolute top-2 right-2 z-10 px-2 py-0.5 rounded bg-black/60 border border-[#222]/80 text-[10px] text-gray-400 font-mono select-none uppercase tracking-wider shadow-lg">
                      Panel A • {mainView}
                    </div>
                  )}
                  <div className={`w-full h-full overflow-y-auto ${isSplitWorkspace ? "pt-8" : ""}`}>
                    <AnimatePresence mode="wait">
                      <motion.div
                        key={mainView}
                        initial={{ opacity: 0, scale: isSplitWorkspace ? 0.95 : 0.7, filter: isSplitWorkspace ? 'blur(10px)' : 'blur(30px)' }}
                        animate={{ opacity: 1, scale: 1, filter: `blur(0px)` }}
                        exit={{ opacity: 0, scale: isSplitWorkspace ? 1.05 : 1.3, filter: isSplitWorkspace ? 'blur(10px)' : 'blur(30px)' }}
                        transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                        className="w-full h-full origin-center"
                      >
                        <PanelErrorBoundary panelName={`Workspace Main: ${mainView.replace(/_/g, ' ').toUpperCase()}`}>
                          <React.Suspense fallback={
                            <div className="flex h-full w-full flex-col items-center justify-center text-[#a855f7] font-mono tracking-widest text-xs gap-3 uppercase py-10 animate-pulse">
                              <div className="w-5 h-5 border border-[#a855f7] border-t-transparent animate-spin rounded-full"></div>
                              <span>Initializing Interface Node: {mainView}</span>
                            </div>
                          }>
                            {renderWorkspacePanel(mainView)}
                          </React.Suspense>
                        </PanelErrorBoundary>
                      </motion.div>
                    </AnimatePresence>
                  </div>
                </motion.div>

                <AnimatePresence>
                  {isSplitWorkspace && (
                    <motion.div
                      layout
                      initial={{ opacity: 0, flex: 0 }}
                      animate={{ opacity: 1, flex: 1 }}
                      exit={{ opacity: 0, flex: 0 }}
                      transition={{ type: "spring", stiffness: 300, damping: 30 }}
                      className={`relative overflow-hidden transition-all ${
                        isHoveringRight ? "bg-indigo-950/25 ring-2 ring-indigo-500 ring-dashed" : ""
                      }`}
                      onDragOver={(e) => e.preventDefault()}
                      onDragEnter={() => setIsHoveringRight(true)}
                      onDragLeave={() => setIsHoveringRight(false)}
                      onDrop={(e) => {
                        e.preventDefault();
                        setIsHoveringRight(false);
                        const draggedId = e.dataTransfer.getData("text/plain");
                        if (draggedId) setSplitViewRight(draggedId);
                      }}
                    >
                      <div className="absolute top-2 right-2 z-10 px-2 py-0.5 rounded bg-black/60 border border-[#222]/80 text-[10px] text-gray-400 font-mono select-none uppercase tracking-wider shadow-lg">
                        Panel B • {splitViewRight}
                      </div>
                      <div className="w-full h-full overflow-y-auto pt-8">
                        <AnimatePresence mode="wait">
                          <motion.div
                            key={splitViewRight}
                            initial={{ opacity: 0, scale: 0.95, filter: 'blur(10px)' }}
                            animate={{ opacity: 1, scale: 1, filter: `blur(0px)` }}
                            exit={{ opacity: 0, scale: 1.05, filter: 'blur(10px)' }}
                            transition={{ duration: 0.3, ease: 'circOut' }}
                            className="w-full h-full origin-center"
                          >
                            <PanelErrorBoundary panelName={`Workspace Split: ${splitViewRight.replace(/_/g, ' ').toUpperCase()}`}>
                              <React.Suspense fallback={
                                <div className="flex h-full w-full flex-col items-center justify-center text-[#818cf8] font-mono tracking-widest text-xs gap-3 uppercase py-10 animate-pulse">
                                  <div className="w-5 h-5 border border-[#818cf8] border-t-transparent animate-spin rounded-full"></div>
                                  <span>Initializing Component Node: {splitViewRight}</span>
                                </div>
                              }>
                                {renderWorkspacePanel(splitViewRight)}
                              </React.Suspense>
                            </PanelErrorBoundary>
                          </motion.div>
                        </AnimatePresence>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </React.Suspense>
          </ErrorBoundary>
        </div>
      </div>

      {rightPanel && (
        <>
          <div
            className="fixed inset-0 bg-black/50 z-[50] md:hidden backdrop-blur-sm"
            onClick={() => setRightPanel(null)}
          />
          <div className="fixed inset-0 md:static md:w-[450px] border-l border-[#222] bg-[#111] overflow-y-auto shrink-0 z-[60]">
            <div className="flex justify-between p-4 border-b border-[#222]">
              <h2 className="font-semibold text-gray-300 uppercase tracking-widest text-xs font-mono">
                {rightPanel === "device_sensors" ? "Hardware & Sensor Bridge" : String(rightPanel).replace("_", " ")}
              </h2>
              <button onClick={() => setRightPanel(null)}>
                <PanelRightClose className="w-5 h-5 text-gray-400 hover:text-white" />
              </button>
            </div>
            <div className="flex-1 w-full h-[calc(100vh-60px)] overflow-y-auto">
              <ErrorBoundary>
                <React.Suspense fallback={
                  <div className="flex h-40 w-full flex-col items-center justify-center font-mono text-xs text-[#a855f7] gap-2.5">
                    <div className="w-3 h-3 border border-purple-500 border-t-transparent animate-spin rounded-full"></div>
                    <span>Reconstructing Vector Node...</span>
                  </div>
                }>
                  {rightPanel === "dashboard" && <Dashboard />}
                  {rightPanel === "logs" && <FieldLogs />}
                  {rightPanel === "vault" && <SecurityVault />}
                  {rightPanel === "sandbox" && <AutonomousSandbox />}
                  {rightPanel === "agents" && <AutonomousAgents />}
                  {rightPanel === "overseer" && <OverseerProtocol />}
                  {rightPanel === "memory" && <TemporalMemoryVault />}
                  {rightPanel === "forge_studio" && <ForgeStudio />}
                  {rightPanel === "media_forge" && <MediaForge />}
                  {rightPanel === "directives" && <DirectiveVault />}
                  {rightPanel === "wealth" && <KineticWealth />}
                  {rightPanel === "resistance" && <KineticResistanceEngine />}
                  {rightPanel === "resonance" && <OrbitalResonance />}
                  {rightPanel === "directives_architect" && <PrimeDirectivesOS />}
                  {rightPanel === "sigils" && <BinarySigilManager />}
                  {rightPanel === "arc_engine" && <InfluenceArcEngine />}
                  {rightPanel === "settings_modal" && <SettingsModal onClose={() => setRightPanel(null)} />}
                  {rightPanel === "environmental" && <EnvironmentalControls />}
                  {rightPanel === "override" && <BiologicalOverride />}
                  {rightPanel === "crucible" && <CrucibleProtocol />}
                  {rightPanel === "neuroplasticity" && <NeuroplasticityEngine />}
                  {rightPanel === "omni_nexus" && <OmniSingularityNexus />}
                  {rightPanel === "metaconscious" && <MetaconsciousApotheosis />}
                  {rightPanel === "sector_matrix" && <SectorMatrixHub />}
                  {rightPanel === "device_sensors" && (
                    <TelemetryGrid 
                      flickerRate={60} 
                      colorTemperature={5000} 
                      intensity={80} 
                      activeAcoustic="Stereo Monitor" 
                      activePhotonic="Photonic Matrix" 
                      activeAtmospheric="Standard" 
                    />
                  )}
                </React.Suspense>
              </ErrorBoundary>
            </div>
          </div>
        </>
      )}

      {showOmniPortal && (
        <AutonomousNavigationMatrix
          onClose={() => setShowOmniPortal(false)}
          onNavigate={handlePortalNavigation}
          activeMain={mainView}
          activePanel={rightPanel}
        />
      )}

      <CommandPalette
        isOpen={isCmdPaletteOpen}
        onClose={() => setIsCmdPaletteOpen(false)}
        onNavigate={(viewId, isRight) => {
          if (isRight) {
            setRightPanel(viewId);
          } else {
            setMainView(viewId as any);
          }
        }}
        onToggleLeftSidebar={() => setLeftSidebarOpen(!leftSidebarOpen)}
        onToggleSplitView={() => setIsSplitWorkspace(!isSplitWorkspace)}
        onTriggerKillSwitch={() => handleKillswitch()}
        presets={presets}
        onLoadPreset={onLoadPreset}
        onSavePreset={onSavePreset}
      />

      <GlobalErrorPanel />
    </div>
  );
}
