import React, { useState, useEffect } from 'react';
import { BookOpen, Plus, Copy } from 'lucide-react';

export default function PromptLibraryPanel() {
  const [prompts, setPrompts] = useState<any[]>([]);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [taskType, setTaskType] = useState('CODE_GEN');

  const loadPrompts = async () => {
    try {
      const res = await fetch('/api/quantum/prompts');
      const data = await res.json();
      if (data.success) {
        setPrompts(data.prompts);
      }
    } catch (e: any) {
      console.error(e);
    }
  };

  useEffect(() => {
    loadPrompts();
  }, []);

  const handleSave = async () => {
    if (!title || !content) return;
    try {
      await fetch('/api/quantum/prompts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, content, task_type: taskType })
      });
      setTitle('');
      setContent('');
      loadPrompts();
    } catch (e: any) {
      console.error(e);
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#0a0a0a] text-gray-200 font-mono p-6">
      <div className="flex items-center gap-3 mb-6 border-b border-[#222] pb-4">
        <BookOpen className="text-amber-400 w-6 h-6" />
        <h2 className="text-xl font-bold tracking-widest uppercase">Prompt Library</h2>
      </div>

      <div className="flex flex-col gap-3 mb-8 bg-[#111] border border-[#333] p-4 rounded">
        <div className="text-xs text-amber-400 uppercase tracking-widest font-bold">New Proven Prompt</div>
        <div className="flex gap-4">
          <input 
            type="text" 
            value={title} 
            onChange={e => setTitle(e.target.value)}
            className="flex-1 bg-[#0a0a0a] border border-[#222] p-2 text-sm focus:outline-none focus:border-amber-500 rounded"
            placeholder="Template Title (e.g. Refactor Physics Module)"
          />
          <select 
            value={taskType}
            onChange={e => setTaskType(e.target.value)}
            className="w-1/4 bg-[#0a0a0a] border border-[#222] p-2 text-sm focus:outline-none focus:border-amber-500 rounded"
          >
            <option value="CODE_GEN">CODE_GEN</option>
            <option value="BUG_FIX">BUG_FIX</option>
            <option value="ARCHITECTURE">ARCHITECTURE</option>
          </select>
        </div>
        <textarea 
          value={content} 
          onChange={e => setContent(e.target.value)}
          className="w-full bg-[#0a0a0a] border border-[#222] p-2 text-sm focus:outline-none focus:border-amber-500 rounded h-20 resize-none"
          placeholder="Prompt content... (It will automatically wrap with contextual data when used)"
        />
        <div className="flex justify-end">
          <button 
            onClick={handleSave}
            disabled={!title || !content}
            className="bg-amber-900/50 hover:bg-amber-800 text-amber-300 px-6 py-2 rounded uppercase font-bold text-xs tracking-widest border border-amber-500/30 flex items-center gap-2 transition-colors disabled:opacity-50"
          >
            <Plus className="w-4 h-4" /> Save Template
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto pr-2 flex flex-col gap-3">
        {prompts.map(p => (
          <div key={p.id} className="flex flex-col border border-[#222] p-4 rounded bg-[#111] relative group">
            <div className="flex items-start justify-between">
              <h3 className="font-bold text-sm text-amber-300">{p.title}</h3>
              <div className="flex items-center gap-2">
                <span className="text-[10px] bg-black px-2 py-0.5 rounded text-gray-400 border border-[#222]">{p.task_type}</span>
                <button 
                  onClick={() => navigator.clipboard.writeText(p.content)}
                  className="text-gray-500 hover:text-amber-400 transition-colors"
                >
                  <Copy className="w-4 h-4" />
                </button>
              </div>
            </div>
            
            <div className="mt-3 text-sm text-gray-300 whitespace-pre-wrap bg-black/40 p-3 rounded">
              {p.content}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
