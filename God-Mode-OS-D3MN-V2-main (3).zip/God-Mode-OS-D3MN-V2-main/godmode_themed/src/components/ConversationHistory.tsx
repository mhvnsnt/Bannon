import React, { useState, useEffect } from "react";
import { MessageSquare, Search, Loader2, Calendar, Database, Trash2 } from "lucide-react";

interface ConversationMessage {
  id: string;
  session_id: string;
  timestamp: string;
  role: "user" | "assistant";
  content: string;
  token_estimate: number;
  model_used: string;
}

interface ConversationHistoryProps {
  currentSessionId: string;
  onSelectSession: (sessionId: string) => void;
}

export default function ConversationHistory({
  currentSessionId,
  onSelectSession,
}: ConversationHistoryProps) {
  const [conversations, setConversations] = useState<ConversationMessage[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchConversations = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/conversations");
      if (res.ok) {
        const data = await res.json();
        setConversations(data || []);
      } else {
        setError(`Failed with status: ${res.status}`);
      }
    } catch (e: any) {
      console.error("Error loading past quantum sessions:", e);
      setError(e.message || "Unknown error");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchConversations();
  }, [currentSessionId]);

  const handleClearHistory = async () => {
    if (!window.confirm("Delete all saved past SQLite conversation logs? This is irreversible.")) return;
    try {
      const res = await fetch("/api/conversations", { method: "DELETE" });
      if (res.ok) {
        setConversations([]);
      }
    } catch (e) {
      console.error("Failed to clear logs:", e);
    }
  };

  // Group messages by session_id to show distinct threads
  const groupedSessions = React.useMemo(() => {
    const groups: Record<string, {
      sessionId: string;
      lastTimestamp: string;
      messagesCount: number;
      sampleSnippet: string;
      modelString: string;
    }> = {};

    conversations.forEach((msg) => {
      const sid = msg.session_id || "default-session";
      if (!groups[sid]) {
        groups[sid] = {
          sessionId: sid,
          lastTimestamp: msg.timestamp,
          messagesCount: 0,
          sampleSnippet: "",
          modelString: msg.model_used || "Apex-Core",
        };
      }
      
      groups[sid].messagesCount += 1;
      // Prefer using the first user message or any message as a snippet descriptor
      if (!groups[sid].sampleSnippet && msg.role === "user" && msg.content) {
        groups[sid].sampleSnippet = msg.content.substring(0, 80);
      }
      if (new Date(msg.timestamp) > new Date(groups[sid].lastTimestamp)) {
        groups[sid].lastTimestamp = msg.timestamp;
      }
    });

    // If a snippet hasn't been set for a group, fill it with a generic fallback
    conversations.forEach((msg) => {
      const sid = msg.session_id || "default-session";
      if (!groups[sid].sampleSnippet && msg.content) {
        groups[sid].sampleSnippet = msg.content.substring(0, 80);
      }
    });

    return Object.values(groups).sort(
      (a, b) => new Date(b.lastTimestamp).getTime() - new Date(a.lastTimestamp).getTime()
    );
  }, [conversations]);

  const filteredSessions = groupedSessions.filter((s) => {
    const term = searchTerm.toLowerCase();
    return (
      s.sessionId.toLowerCase().includes(term) ||
      s.sampleSnippet.toLowerCase().includes(term) ||
      s.modelString.toLowerCase().includes(term)
    );
  });

  return (
    <div className="flex-1 flex flex-col overflow-hidden p-3 gap-3">
      <div className="flex justify-between items-center px-1 shrink-0">
        <div className="text-[10px] uppercase tracking-widest text-[#10b981] font-bold font-mono flex items-center gap-1.5">
          <Database className="w-3 h-3" />
          <span>Past Quantum Loops</span>
        </div>
        
        {conversations.length > 0 && (
          <button
            onClick={handleClearHistory}
            className="text-[9px] font-mono text-red-500 hover:text-red-400 transition-colors uppercase font-bold flex items-center gap-1 cursor-pointer"
            title="Wipe database memory"
          >
            <Trash2 className="w-2.5 h-2.5" />
            <span>Wipe Logs</span>
          </button>
        )}
      </div>

      {/* Search Bar */}
      <div className="relative shrink-0">
        <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-gray-500" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Filter SQLite threads..."
          className="w-full pl-8 pr-3 py-1.5 text-xs text-gray-300 bg-[#111] hover:bg-[#151515] focus:bg-[#1a1a1a] border border-[#222] focus:border-[#10b981]/50 rounded-lg outline-none font-mono transition-colors"
        />
        {searchTerm && (
          <button
            onClick={() => setSearchTerm("")}
            className="absolute right-2.5 top-2 text-gray-500 hover:text-gray-300 font-mono text-xs"
          >
            ✕
          </button>
        )}
      </div>

      {/* Sessions scrolling box */}
      <div className="flex-1 overflow-y-auto space-y-2 pr-1 custom-scrollbar">
        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-10 text-gray-500 gap-2 font-mono text-[10px]">
            <Loader2 className="w-4 h-4 text-[#10b981] animate-spin" />
            <span>QUERYING RECOVERY SLICES...</span>
          </div>
        ) : error ? (
          <div className="p-3 bg-red-950/20 border border-red-500/30 text-red-400 rounded-lg text-center font-mono text-[9px] leading-relaxed">
            {error}
          </div>
        ) : filteredSessions.length === 0 ? (
          <div className="text-center py-12 text-gray-600 font-mono text-[10px] uppercase">
            No SQLite records detected
          </div>
        ) : (
          filteredSessions.map((item) => {
            const isCurrent = item.sessionId === currentSessionId;
            return (
              <button
                key={item.sessionId}
                onClick={() => onSelectSession(item.sessionId)}
                className={`w-full text-left p-2.5 rounded-lg border transition-all flex flex-col gap-1 cursor-pointer ${
                  isCurrent
                    ? "bg-[#10b981]/10 border-[#10b981]/40 shadow-[0_0_12px_rgba(16,185,129,0.05)]"
                    : "bg-[#0b0b0b] border-[#1f1f1f] hover:border-[#10b981]/25 hover:bg-[#101010]"
                }`}
              >
                <div className="flex justify-between items-center text-[8px] font-mono w-full">
                  <span className={`font-bold flex items-center gap-1 uppercase ${isCurrent ? 'text-[#10b981]' : 'text-gray-500'}`}>
                    <MessageSquare className="w-2.5 h-2.5" />
                    {isCurrent ? "Active Thread" : "Recoverable"}
                  </span>
                  <span className="text-gray-600 flex items-center gap-0.5">
                    <Calendar className="w-2.5 h-2.5" />
                    {new Date(item.lastTimestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>

                <p className="text-[11px] font-sans text-gray-300 line-clamp-2 leading-snug break-words">
                  {item.sampleSnippet || "Unlabeled interaction trace"}
                </p>

                <div className="flex justify-between items-center text-[8px] font-mono text-gray-600 mt-1 pt-1 border-t border-[#1a1a1a] w-full">
                  <span>{item.messagesCount} EXCHANGE{item.messagesCount !== 1 ? "S" : ""}</span>
                  <span className="uppercase text-[7px] bg-[#141414] px-1 py-0.5 rounded border border-[#222]">
                    {item.modelString}
                  </span>
                </div>
              </button>
            );
          })
        )}
      </div>

      <div className="p-2 bg-[#090909] border border-[#1a1a1a] rounded-lg text-[8px] font-mono text-gray-500 leading-normal">
        <span className="text-[#10b981] font-bold">SQLITE CONTINUITY ACTIVE</span>
        <p className="mt-0.5">Interaction state slices are committed safely into regional sqlite memory blocks.</p>
      </div>
    </div>
  );
}
