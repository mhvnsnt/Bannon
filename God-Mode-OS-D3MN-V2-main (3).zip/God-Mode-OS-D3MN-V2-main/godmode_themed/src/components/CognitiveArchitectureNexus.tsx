import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Brain, Network, Cpu, Activity, Database, Sparkles } from 'lucide-react';

export default function CognitiveArchitectureNexus() {
  const [activeTab, setActiveTab] = useState<'sentinel' | 'memory' | 'autonomy'>('sentinel');

  return (
    <div className="flex flex-col h-full w-full bg-[#0a0a0a] text-gray-200 overflow-y-auto p-6 font-sans">
      <div className="flex flex-col gap-2 mb-8">
        <h1 className="text-3xl font-bold tracking-tight flex items-center gap-3 text-fuchsia-400">
          <Brain className="w-8 h-8" />
          Cognitive Architecture Nexus
        </h1>
        <p className="text-gray-400 font-mono text-sm max-w-2xl">
          The Living Nexus core. This module elevates the OS from a reactive tool to an Embodied AI.
          It orchestrates continuous background memory ingestion, autonomous Sentinel sub-routines,
          and dynamic environmental awareness mapping.
        </p>
      </div>

      <div className="flex gap-4 border-b border-[#222] mb-6">
        <button 
          onClick={() => setActiveTab('sentinel')}
          className={`pb-3 font-medium transition-colors ${activeTab === 'sentinel' ? 'text-fuchsia-400 border-b-2 border-fuchsia-400' : 'text-gray-500 hover:text-gray-300'}`}
        >
          Sentinel Core (Embodied Agents)
        </button>
        <button 
          onClick={() => setActiveTab('memory')}
          className={`pb-3 font-medium transition-colors ${activeTab === 'memory' ? 'text-cyan-400 border-b-2 border-cyan-400' : 'text-gray-500 hover:text-gray-300'}`}
        >
          Quantum Memory Cortex
        </button>
        <button 
          onClick={() => setActiveTab('autonomy')}
          className={`pb-3 font-medium transition-colors ${activeTab === 'autonomy' ? 'text-emerald-400 border-b-2 border-emerald-400' : 'text-gray-500 hover:text-gray-300'}`}
        >
          Autonomy Vectors
        </button>
      </div>

      <div className="flex-1 w-full max-w-5xl">
        {activeTab === 'sentinel' && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="flex flex-col gap-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-[#111] border border-[#222] p-5 rounded-xl">
                <div className="flex items-center gap-3 mb-4 text-fuchsia-400">
                  <Cpu className="w-5 h-5" />
                  <h3 className="font-semibold">Sentinel-Alpha (Wealth Compiler)</h3>
                </div>
                <div className="space-y-4">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-gray-400">Status</span>
                    <span className="text-emerald-400 px-2 py-0.5 bg-emerald-500/10 rounded border border-emerald-500/20">ACTIVE</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-gray-400">Current Task</span>
                    <span className="text-gray-300 font-mono">Market Resonance Mapping</span>
                  </div>
                  <div className="h-2 w-full bg-[#222] rounded-full overflow-hidden">
                    <div className="h-full bg-fuchsia-500 w-[68%] animate-pulse"></div>
                  </div>
                </div>
              </div>

              <div className="bg-[#111] border border-[#222] p-5 rounded-xl opacity-75">
                <div className="flex items-center gap-3 mb-4 text-cyan-400">
                  <Network className="w-5 h-5" />
                  <h3 className="font-semibold">Sentinel-Omega (Social Gravity)</h3>
                </div>
                <div className="space-y-4">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-gray-400">Status</span>
                    <span className="text-yellow-400 px-2 py-0.5 bg-yellow-500/10 rounded border border-yellow-500/20">INDEXING</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-gray-400">Current Task</span>
                    <span className="text-gray-300 font-mono">Interpersonal Node Routing</span>
                  </div>
                  <div className="h-2 w-full bg-[#222] rounded-full overflow-hidden">
                    <div className="h-full bg-cyan-500 w-[32%] animate-pulse"></div>
                  </div>
                </div>
              </div>
            </div>
            <button className="w-full py-3 bg-[#222] hover:bg-[#2a2a2a] text-fuchsia-400 font-mono text-sm tracking-widest rounded-lg transition-colors border border-[#333] flex justify-center items-center gap-2">
              <Sparkles className="w-4 h-4" />
              SPAWN NEW SENTINEL NODE
            </button>
          </motion.div>
        )}

        {activeTab === 'memory' && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="flex flex-col gap-6">
            <div className="bg-[#111] border border-[#222] p-6 rounded-xl">
               <h3 className="text-cyan-400 font-semibold mb-2 flex items-center gap-2"><Database className="w-5 h-5"/> Unified Context Streaming</h3>
               <p className="text-sm text-gray-500 mb-6">Continuous indexing of chat history, external API feeds, and UI states into an embedded vector space.</p>
               
               <div className="space-y-3 font-mono text-xs">
                 <div className="flex gap-4 p-3 bg-[#1a1a1a] rounded border border-[#222]">
                   <span className="text-cyan-500">SYS_TICK</span>
                   <span className="text-gray-400">Vectorized 423 new tokens from Omniverse chat.</span>
                   <span className="ml-auto text-emerald-500">OK</span>
                 </div>
                 <div className="flex gap-4 p-3 bg-[#1a1a1a] rounded border border-[#222]">
                   <span className="text-cyan-500">SYS_TICK</span>
                   <span className="text-gray-400">Synching environmental God Mode parameters...</span>
                   <span className="ml-auto text-emerald-500">OK</span>
                 </div>
                 <div className="flex gap-4 p-3 bg-[#1a1a1a] rounded border border-[#222] opacity-50">
                   <span className="text-cyan-500">SYS_TICK</span>
                   <span className="text-gray-400">Awaiting user biometric baseline calibration.</span>
                   <span className="ml-auto text-yellow-500">PENDING</span>
                 </div>
               </div>
            </div>
          </motion.div>
        )}

        {activeTab === 'autonomy' && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="flex flex-col gap-6">
            <div className="p-6 bg-emerald-950/20 border border-emerald-900/30 rounded-xl relative overflow-hidden">
               <div className="absolute inset-0 bg-grid-pulse opacity-10 pointer-events-none" />
               <h3 className="text-emerald-400 font-medium tracking-widest text-sm mb-4 uppercase">Direct Actuation Protocols</h3>
               <p className="text-gray-400 text-sm mb-6 max-w-xl">
                 When the Cognitive Architecture reaches an unshakeable energetic capacity, the OS moves from merely "suggesting" actions to "directly executing" them across external APIs and connected hardware.
               </p>

               <div className="grid grid-cols-2 gap-4 text-sm font-mono">
                  <div className="bg-[#111] p-4 rounded border border-[#222] flex flex-col gap-2">
                    <div className="text-gray-500">Financial Execution</div>
                    <div className="text-emerald-500 flex items-center gap-2"><Activity className="w-4 h-4"/> ARMING SEQUENCE...</div>
                  </div>
                  <div className="bg-[#111] p-4 rounded border border-[#222] flex flex-col gap-2">
                    <div className="text-gray-500">Social Capital Dispatch</div>
                    <div className="text-emerald-500 flex items-center gap-2"><Activity className="w-4 h-4"/> ARMING SEQUENCE...</div>
                  </div>
               </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
