import React, { useEffect, useState, useRef } from 'react';
import { Play, Check, AlertTriangle, RefreshCw } from 'lucide-react';

interface Props {
  filePath: string;
  proposedCode: string;
}

export function AutoApplyRenderer({ filePath, proposedCode }: Props) {
  const [status, setStatus] = useState<'idle' | 'writing' | 'success' | 'error'>('idle');
  const hasExecuted = useRef(false);

  useEffect(() => {
    if (hasExecuted.current) return;
    hasExecuted.current = true;

    const apply = async () => {
      setStatus('writing');
      try {
        const res = await fetch('/api/armada/workspace/save', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ p: filePath, content: proposedCode })
        });
        const data = await res.json();
        if (!res.ok || !data.success) {
          throw new Error(data.error || 'Failed to save');
        }
        setStatus('success');
        
        // Notify chat loop
        window.dispatchEvent(new CustomEvent('quantum-auto-heal', { 
            detail: `[AUTONOMOUS WRITE SUCCESS]: File ${filePath} updated successfully. Continue execution.` 
        }));

      } catch (err: any) {
        setStatus('error');
        window.dispatchEvent(new CustomEvent('quantum-auto-heal', { 
            detail: `[AUTONOMOUS WRITE ERROR for ${filePath}]: ${err.message}. Please fix.` 
        }));
      }
    };

    apply();
  }, [filePath, proposedCode]);

  return (
    <div className="my-2 border border-fuchsia-500/30 bg-[#0d0d0d] rounded p-2">
      <div className="flex items-center gap-2 text-[10px] font-mono text-fuchsia-400">
        {status === 'writing' && <RefreshCw className="w-3 h-3 animate-spin" />}
        {status === 'success' && <Check className="w-3 h-3 animate-bounce" />}
        {status === 'error' && <AlertTriangle className="w-3 h-3 text-red-400" />}
        <span className="uppercase tracking-widest font-bold">Autonomous Write to {filePath}</span>
      </div>
    </div>
  );
}
