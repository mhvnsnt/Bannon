import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Play, Check, AlertTriangle, Sparkles, RefreshCw, Activity } from 'lucide-react';
import Editor from '@monaco-editor/react';

interface Props {
  filePath: string;
  proposedCode: string;
  explanation?: string;
}

export function SelfImprovementProposal({ filePath, proposedCode, explanation }: Props) {
  const [status, setStatus] = useState<'idle' | 'writing' | 'linting' | 'success' | 'lint_error' | 'error'>('idle');
  const [errorMsg, setErrorMsg] = useState('');
  const [lintOutput, setLintOutput] = useState('');

  const handleAutoHeal = async () => {
       try {
           const payload = `[AUTO-HEAL TRIGGERED]\nFix the following TypeScript compiler errors in ${filePath} after my last update:\n\n${lintOutput}`;
           window.dispatchEvent(new CustomEvent('quantum-auto-heal', { detail: payload }));
           setStatus('idle');
       } catch(e){}
  }

  const handleApply = async () => {
    setStatus('writing');
    try {
      const res = await fetch('/api/armada/workspace/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ p: filePath, content: proposedCode })
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to save code');
      }
      
      setStatus('linting');
      
      try {
          const lintRes = await fetch('/api/armada/workspace/lint');
          const lintData = await lintRes.json();
          if (!lintData.valid) {
              setLintOutput(lintData.output);
              setStatus('lint_error');
              return;
          }
      } catch (e) {
          console.warn("Linting skipped or failed", e);
      }
      
      setStatus('success');
      // Briefly trigger a verification/check sweep to reload server or status
      await fetch('/api/armada/model_router/check').catch(() => {});
    } catch (err: any) {
      console.error(err);
      setStatus('error');
      setErrorMsg(err.message || 'Unknown write error');
    }
  };

  return (
    <div className="my-4 border border-cyan-500/30 bg-[#0d0d0d]/90 rounded-xl overflow-hidden p-4 shadow-[0_0_15px_rgba(6,182,212,0.15)] max-w-full text-left">
      <div className="flex items-center justify-between border-b border-zinc-800 pb-2 mb-3">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-cyan-400 animate-pulse" />
          <span className="text-[11px] font-mono font-bold tracking-widest text-cyan-400 uppercase">
            🤖 Code Self-Improvement Proposal
          </span>
        </div>
        <div className="text-[9px] text-zinc-400 font-mono bg-zinc-900 border border-zinc-800 px-2 py-0.5 rounded">
          {filePath}
        </div>
      </div>

      {explanation && (
        <p className="text-xs text-zinc-300 font-sans leading-relaxed mb-4 pl-2 border-l border-cyan-500/60">
          {explanation}
        </p>
      )}

      <div className="relative border border-zinc-900 rounded-lg overflow-hidden bg-zinc-950/80 mb-4 h-64 overflow-y-hidden">
        <div className="absolute top-2 right-2 bg-zinc-900/90 text-[8px] text-zinc-500 px-1.5 py-0.5 rounded font-mono border border-zinc-800 z-10">
          MONACO COMPILE VIEW
        </div>
        <Editor
          height="100%"
          language={filePath.endsWith('.tsx') || filePath.endsWith('.ts') ? 'typescript' : 'javascript'}
          theme="vs-dark"
          value={proposedCode}
          options={{
            readOnly: true,
            minimap: { enabled: false },
            fontSize: 11,
            fontFamily: 'JetBrains Mono, monospace',
            scrollBeyondLastLine: false,
            padding: { top: 16 }
          }}
        />
      </div>

      <div className="flex items-center gap-3">
        {status === 'idle' && (
          <button
            onClick={handleApply}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-mono font-bold text-xs uppercase cursor-pointer rounded border border-cyan-400/30 shadow-[0_0_10px_rgba(6,182,212,0.2)] hover:shadow-[0_0_15px_rgba(6,182,212,0.35)] transition-all outline-none"
          >
            <Play className="w-3 h-3" />
            Approve & Compile Self-Improvement
          </button>
        )}

        {status === 'writing' && (
          <div className="flex items-center gap-2 text-cyan-400 font-mono text-xs">
            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            Re-weaving codebase structure, wait...
          </div>
        )}
        
        {status === 'linting' && (
          <div className="flex items-center gap-2 text-amber-500 font-mono text-xs">
            <Activity className="w-3.5 h-3.5 animate-pulse" />
            Compiling and validating syntax trees...
          </div>
        )}

        {status === 'success' && (
          <div className="flex items-center gap-2 text-emerald-400 font-mono text-xs bg-emerald-950/40 border border-emerald-500/20 px-3 py-1.5 rounded">
            <Check className="w-3.5 h-3.5 text-emerald-400 animate-bounce" />
            Self-Improvement Applied Successfully! App rebuilt without syntax errors.
          </div>
        )}

        {status === 'lint_error' && (
          <div className="flex flex-col gap-1 w-full">
            <div className="flex items-center justify-between text-amber-500 font-mono text-xs bg-amber-950/40 border border-amber-500/30 px-3 py-1.5 rounded">
                <div className="flex items-center gap-2">
                   <AlertTriangle className="w-3.5 h-3.5 animate-pulse" />
                   Saved to disk, but TypeScript compilation failed.
                </div>
                <button
                   onClick={handleAutoHeal}
                   className="px-2 py-0.5 bg-amber-500/20 hover:bg-amber-500/40 border border-amber-500/50 rounded text-amber-300 transition-colors"
                >
                   Autonomously Heal
                </button>
            </div>
            <pre className="text-[9px] text-amber-400/70 p-2 overflow-x-auto max-h-32 bg-black border border-amber-500/20 rounded mt-1">
                {lintOutput}
            </pre>
          </div>
        )}

        {status === 'error' && (
          <div className="flex flex-col gap-1">
            <div className="flex items-center gap-2 text-red-400 font-mono text-xs">
              <AlertTriangle className="w-3.5 h-3.5" />
              Applying vector write failed: {errorMsg}
            </div>
            <button
              onClick={handleApply}
              className="text-[10px] text-cyan-400 font-mono underline text-left hover:text-cyan-300"
            >
              Retry merge operation
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
