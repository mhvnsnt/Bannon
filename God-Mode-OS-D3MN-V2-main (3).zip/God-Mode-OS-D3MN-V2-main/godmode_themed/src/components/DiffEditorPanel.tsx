import React, { useState } from 'react';
import { GitBranch, AlertCircle, ArrowLeftRight, Check, X } from 'lucide-react';

export default function DiffEditorPanel() {
  const [mockDiffs] = useState([
    { id: 1, file: 'src/game/physics.js', status: 'PENDING',
      added: [`+ function applyForce(entity, force) {`, `+   entity.velocity.x += force.x;`, `+   entity.velocity.y += force.y;`, `+ }`],
      removed: [`- function applyImpulse(entity, x, y) {`, `-   entity.vx += x;`, `-   entity.vy += y;`, `- }`]
    }
  ]);

  return (
    <div className="flex flex-col h-full bg-[#0a0a0a] text-gray-200 font-mono p-6">
      <div className="flex items-center gap-3 mb-6 border-b border-[#222] pb-4">
        <GitBranch className="text-cyan-400 w-6 h-6" />
        <h2 className="text-xl font-bold tracking-widest uppercase">Diff Editor Visualizer</h2>
      </div>
      
      <div className="text-xs text-gray-400 mb-6 flex items-center gap-2">
        <AlertCircle className="w-4 h-4" />
        Visually review code additions and subtractions before committing changes directly into the build environment. 
      </div>

      <div className="flex-1 overflow-y-auto pr-2 flex flex-col gap-4">
        {mockDiffs.map(diff => (
          <div key={diff.id} className="flex flex-col border border-[#333] rounded bg-[#111] overflow-hidden">
            <div className="bg-[#1a1a1a] p-3 border-b border-[#333] flex justify-between items-center">
              <span className="text-xs font-bold text-gray-300">{diff.file}</span>
              <div className="flex gap-2">
                <button className="bg-red-900/50 text-red-400 hover:text-red-300 border border-red-500/30 px-3 py-1 rounded text-xs flex items-center gap-1 transition-colors">
                  <X className="w-3 h-3" /> Reject
                </button>
                <button className="bg-emerald-900/50 text-emerald-400 hover:text-emerald-300 border border-emerald-500/30 px-3 py-1 rounded text-xs flex items-center gap-1 transition-colors">
                  <Check className="w-3 h-3" /> Accept
                </button>
              </div>
            </div>
            
            <div className="flex w-full divide-x divide-[#333]">
              <div className="w-1/2 p-2 bg-[#221010] text-[#ff8888] text-xs whitespace-pre font-mono overflow-x-auto">
                {diff.removed.map((line, i) => <div key={i}>{line}</div>)}
              </div>
              <div className="w-1/2 p-2 bg-[#102210] text-[#88ff88] text-xs whitespace-pre font-mono overflow-x-auto">
                {diff.added.map((line, i) => <div key={i}>{line}</div>)}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
