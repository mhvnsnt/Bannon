import React, { useEffect, useState } from 'react';
import { Network, ZoomIn, Search } from 'lucide-react';

export default function DependencyGraphPanel() {
  const [nodes] = useState(['applyForce', 'updatePhysics', 'gameLoop', 'handleInput', 'checkCollisions', 'grappleState']);
  const [edges] = useState([
    { from: 'gameLoop', to: 'handleInput' },
    { from: 'gameLoop', to: 'updatePhysics' },
    { from: 'updatePhysics', to: 'applyForce' },
    { from: 'updatePhysics', to: 'checkCollisions' },
    { from: 'handleInput', to: 'grappleState' },
    { from: 'grappleState', to: 'applyForce' }
  ]);

  return (
    <div className="flex flex-col h-full bg-[#0a0a0a] text-gray-200 font-mono p-6">
      <div className="flex items-center gap-3 mb-6 border-b border-[#222] pb-4">
        <Network className="text-indigo-400 w-6 h-6" />
        <h2 className="text-xl font-bold tracking-widest uppercase">Dependency Graph</h2>
      </div>

      <div className="text-xs text-gray-400 mb-6 flex gap-2 items-center">
        Map all function call relationships to prevent breaking dependent code.
      </div>

      <div className="flex-1 bg-[#111] border border-[#222] rounded relative overflow-hidden flex items-center justify-center">
        <div className="absolute top-4 right-4 flex gap-2">
           <div className="bg-black/50 p-2 rounded backdrop-blur border border-[#333] text-gray-400 hover:text-indigo-400 transition-colors cursor-pointer">
             <Search className="w-4 h-4" />
           </div>
           <div className="bg-black/50 p-2 rounded backdrop-blur border border-[#333] text-gray-400 hover:text-indigo-400 transition-colors cursor-pointer">
             <ZoomIn className="w-4 h-4" />
           </div>
        </div>
        
        {/* Simplified mock rendering of a graph */}
        <div className="relative w-full h-full p-10">
          <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-30">
             {edges.map((edge, i) => (
                <line key={i} x1="50%" y1="20%" x2="50%" y2="50%" stroke="#818cf8" strokeWidth="2" />
             ))}
          </svg>
          
          <div className="flex flex-wrap gap-4 items-center justify-center mt-20 relative z-10 w-full max-w-lg mx-auto">
             {nodes.map(node => (
                <div key={node} className="bg-[#1a1a2e] border border-indigo-500/50 px-4 py-2 rounded-full text-indigo-200 text-xs shadow-[0_0_15px_rgba(99,102,241,0.2)]">
                  {node}()
                </div>
             ))}
          </div>
        </div>
      </div>
    </div>
  );
}
