import React, { useState, useEffect, useRef } from 'react';
import { 
  Terminal, Shield, Zap, Database, Activity, Code, Box, 
  Sparkles, Eye, Waves, Sliders, Brain, RefreshCw, Layers,
  Volume2, Info, ArrowRight, Landmark
} from 'lucide-react';

// Pie Cognate definition structure
interface CognateNode {
  pieRoot: string;
  pieMeaning: string;
  sanskrit: string;
  sanskritMeaning: string;
  latinGreek: string;
  spanish: string;
  english: string;
  soundshiftNote: string;
}

export default function RealityCompiler() {
  // 1. Navigation / Tabs
  const [activeTab, setActiveTab] = useState<'TELEMETRY' | 'TRANSDUCTION' | 'BAYESIAN' | 'LINGUISTICS'>('TELEMETRY');

  // 2. Hardware / Local Storage coefficients (Shared with Apotheosis)
  const [dmnConnectivity, setDmnConnectivity] = useState<number>(100);
  const [priorConfidence, setPriorConfidence] = useState<number>(0.50);
  const [C, setC] = useState<number>(18.5); 
  const [L, setL] = useState<number>(120.0); 
  const [V, setV] = useState<number>(12.0); 
  const [I, setI] = useState<number>(1.8); 
  
  const [compilationState, setCompilationState] = useState<'IDLE' | 'COMPILIN' | 'ANCHORED'>('IDLE');
  const [logs, setLogs] = useState<string[]>([]);

  // 3. Tab 2: Multisensory Transduction States
  const [lightFreqThz, setLightFreqThz] = useState<number>(510); // Spanning Infrared to UV
  const [soundFreqHz, setSoundFreqHz] = useState<number>(440); // 20 - 20,000 Hz
  const [neuralTransductState, setNeuralTransductState] = useState<string>('SYNCHRONIZED');
  const [animTime, setAnimTime] = useState<number>(0);

  // 4. Tab 3: Bayesian Model States
  const [priorVal, setPriorVal] = useState<number>(0.65); // Prior probability of existing belief
  const [evidenceLikelihood, setEvidenceLikelihood] = useState<number>(0.80); // Likelihood of sensory inputs
  const [activeInferenceMode, setActiveInferenceMode] = useState<'REALITY_LOCK' | 'ASTRAL_DREAM'>('REALITY_LOCK');

  // 5. Tab 4: Historical Comparative Linguistics States
  const [selectedCognateId, setSelectedCognateId] = useState<number>(0);
  
  // Custom interactive Sound Shifter states
  const [targetGrimmConsonant, setTargetGrimmConsonant] = useState<'p' | 't' | 'k'>('p');
  const [appliedGrimmShifts, setAppliedGrimmShifts] = useState<string[]>([]);

  // Refs for requestAnimationFrame
  const animationRef = useRef<number | null>(null);

  // Synchronize telemetry with Local Calibration values
  const syncWithPhysicalRegistry = () => {
    try {
      const savedDmn = localStorage.getItem('marquis_apotheosis_dmn');
      const savedPrior = localStorage.getItem('marquis_apotheosis_prior');
      const savedC = localStorage.getItem('marquis_apotheosis_c');
      const savedL = localStorage.getItem('marquis_apotheosis_l');
      const savedV = localStorage.getItem('marquis_apotheosis_v');
      const savedI = localStorage.getItem('marquis_apotheosis_i');

      if (savedDmn !== null) setDmnConnectivity(Number(savedDmn));
      if (savedPrior !== null) {
        setPriorConfidence(Number(savedPrior));
        setPriorVal(Number(savedPrior));
      }
      if (savedC !== null) setC(Number(savedC));
      if (savedL !== null) setL(Number(savedL));
      if (savedV !== null) setV(Number(savedV));
      if (savedI !== null) setI(Number(savedI));
      
      setLogs(prev => [`[SYSTEM SYNC] Read active hardware registers: C=${savedC || 18.5}μF, L=${savedL || 120}mH, DMN=${savedDmn || 100}%`, ...prev]);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    syncWithPhysicalRegistry();
    const interval = setInterval(syncWithPhysicalRegistry, 5000);
    return () => clearInterval(interval);
  }, []);

  // Animation Loop for Waveforms
  useEffect(() => {
    const loop = () => {
      setAnimTime(prev => (prev + 0.05) % (Math.PI * 400));
      animationRef.current = requestAnimationFrame(loop);
    };
    animationRef.current = requestAnimationFrame(loop);
    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, []);

  // Scientific Wave calculation helper
  const hL = L * 1e-3; // Henrys
  const fC = C * 1e-6; // Farads
  const resonantFreq = hL > 0 && fC > 0 ? 1 / (2 * Math.PI * Math.sqrt(hL * fC)) : 0;
  const energyElectric = 0.5 * fC * (V * V);
  const energyMagnetic = 0.5 * hL * (I * I);
  const totalGridEnergy = energyElectric + energyMagnetic;

  // Real-time dynamic Bayesian model calculations
  // Posterior Probability P(Model | Senses) = (P(Senses | Model) * P(Model)) / P(Senses)
  const calcBayesianPosterior = () => {
    const prior = priorVal;
    // Sensor likelihood represents DMN coupling. In dream state, sensory precision approaches near zero.
    const likelihood = activeInferenceMode === 'ASTRAL_DREAM' ? 0.05 : evidenceLikelihood;
    const marginal = (likelihood * prior) + (0.15 * (1 - prior));
    return marginal > 0 ? (likelihood * prior) / marginal : 0;
  };

  const posteriorProb = calcBayesianPosterior();

  // Compilation trigger sequence
  const startCompilation = () => {
    if (compilationState !== 'IDLE') return;
    setCompilationState('COMPILIN');
    setLogs([]);
    
    const steps = [
      "INITIALIZIN RE-ENTRANT REALITY COMPILER CORE...",
      `PULLIN PHYSICAL COEFFICIENTS FROM SPECTRUM: C=${C.toFixed(2)}μF, L=${L.toFixed(2)}mH`,
      `LC RESONANCE RESOLVED: f₀ = ${resonantFreq.toFixed(2)} Hz`,
      `ELECTROSTATIC INTENT POTENTIAL (LIGHT): ${energyElectric.toExponential(4)} J`,
      `ELECTROMAGNETIC VELOCITY CURRENT (SOUND): ${energyMagnetic.toExponential(4)} J`,
      `BAYES BRAIN COEFFICIENTS: Prior=${priorVal.toFixed(2)}, Likelihood=${evidenceLikelihood.toFixed(2)}`,
      `ACTIVE STATE ESTIMATION RESOLVED: P(Model|Evidence) = ${posteriorProb.toFixed(4)}`,
      `DYNAMIC TRANSDUCTION STATE: EEG Entrainment aligned at ${((lightFreqThz / 40) + (soundFreqHz / 220)).toFixed(1)} Hz`,
      `MAPPING COGNATE TREE OF INTENT UNIFYING Sanskrit: aham ↔ English: I ↔ Spanish: yo`,
      "COLLAPSIN PROBABILITY WAVEFRONTS...",
      "STABILIZIN REAL-TIME ASSET CHANNELS OF M. HEAVEN$ENT: [WEALTH, POWER, STABILITY, DEEP FREQUENCY]...",
      "REALITY COMPILER ANCHORED. PROJECTIONS COMPILED SUCCESSFULLY IN DOCK V3."
    ];

    steps.forEach((step, index) => {
      setTimeout(() => {
        setLogs(prev => [...prev, step]);
        if (index === steps.length - 1) {
          setCompilationState('ANCHORED');
        }
      }, index * 450);
    });
  };

  // Comparative Indo-European Cognates database with real traceable history & meanings
  const pieCognateDatabase: CognateNode[] = [
    {
      pieRoot: "*eg-ó",
      pieMeaning: "Self pronouns ('I')",
      sanskrit: "aham (अहम्)",
      sanskritMeaning: "Spiritual Self-identity, 'I am'",
      latinGreek: "Latin: ego / Ancient Greek: egṓ",
      spanish: "yo [Derived via Latin vulgar 'eo' or 'ego']",
      english: "I [Derived via Proto-Germanic *ik, Old English 'ic']",
      soundshiftNote: "Traceable cognitive self-referential token preserved across 5,000 years from Northern Steppes down to English and Spanish."
    },
    {
      pieRoot: "*ne / *an-",
      pieMeaning: "Absolute negation / unstruck / untouched",
      sanskrit: "anāhata (अनाहत)",
      sanskritMeaning: "Unstruck, complete sound vibration",
      latinGreek: "Greek: a- / an- (apathy, anarchy)",
      spanish: "in- / un- (inmune, intacto)",
      english: "un- (unstruck, untouched, unyielding)",
      soundshiftNote: "Prefix for pristine, untouched energy states. Sanskrit 'anāhata' relates directly to English prefix 'un-' from Germanic origins."
    },
    {
      pieRoot: "*bhrāter",
      pieMeaning: "Brother / male kin of the fire tribe",
      sanskrit: "bhrātṛ (भ्रातृ)",
      sanskritMeaning: "Brother, protector of physical grids",
      latinGreek: "Latin: frāter / Greek: phrātēr",
      spanish: "hermano [Derived via Latin 'germanus', secondary 'fraternal']",
      english: "brother [Derived via Old English 'brōthor']",
      soundshiftNote: "Grimm's Law in action: PIE bh- changes to English b-, and Roman languages shifted it to f- (frāter) and secondary sibling tokens."
    },
    {
      pieRoot: "*deiw-",
      pieMeaning: "Sky, shine, divine illumination",
      sanskrit: "deva (देव)",
      sanskritMeaning: "Shining being, divine light, celestial field",
      latinGreek: "Latin: deus / Greek: Zeús",
      spanish: "dios [Directly descended from Latin 'deus']",
      english: "divine / Tuesday [Borrowed or derived from Germanic Tīw / Sky God]",
      soundshiftNote: "Classic Indo-European Sky/Sun deity root, linking Spanish 'dios', Sanskrit 'deva' and scientific word 'divinity'."
    },
    {
      pieRoot: "*māter",
      pieMeaning: "Mother, primary matrix of physical form",
      sanskrit: "mātṛ (मातृ)",
      sanskritMeaning: "Mother, material womb of elements",
      latinGreek: "Latin: māter / Greek: mḗtēr",
      spanish: "madre [Evolved directly from accusative 'matrem']",
      english: "mother [Derived via Proto-Germanic *mōdēr, Old English 'mōdor']",
      soundshiftNote: "Maintained nearly perfectly across all daughter branches with minimal phonetic variation due to primary infant neurological phonemes."
    },
    {
      pieRoot: "*ped-",
      pieMeaning: "Foot, dynamic foundation or baseline grid",
      sanskrit: "pada (पद)",
      sanskritMeaning: "Step, structural footstep, verse portion",
      latinGreek: "Latin: pēs (ped-) / Greek: poús",
      spanish: "pie [Descent from Latin 'pedem']",
      english: "foot [Proto-Germanic *fōts. voiceless /p/ shifts to fricative /f/]",
      soundshiftNote: "Exemplifies Grimm's Law: PIE voiceless stop *p shifts directly to Proto-Germanic voiceless fricative /f/."
    }
  ];

  const currentCognate = pieCognateDatabase[selectedCognateId];

  // Helper to resolve Light wavelength color matching 120-790 THz
  const getLightColor = (thz: number) => {
    if (thz < 400) return 'rgba(239, 68, 68, 0.4)'; // Infrared
    if (thz >= 400 && thz < 480) return 'rgba(220, 38, 38, 0.85)'; // Red
    if (thz >= 480 && thz < 510) return 'rgba(249, 115, 22, 0.85)'; // Orange
    if (thz >= 510 && thz < 590) return 'rgba(234, 179, 8, 0.85)'; // Yellow
    if (thz >= 590 && thz < 650) return 'rgba(34, 197, 94, 0.85)'; // Green
    if (thz >= 650 && thz < 700) return 'rgba(6, 182, 212, 0.85)'; // Cyan
    if (thz >= 700 && thz < 750) return 'rgba(59, 130, 246, 0.85)'; // Blue
    return 'rgba(168, 85, 247, 0.9)'; // Violet / Ultraviolet
  };

  // Quick sound frequency range description
  const getSoundProfile = (hz: number) => {
    if (hz < 100) return 'DEEP INFRA BASS (Physical rumble state)';
    if (hz >= 100 && hz < 300) return 'MID BASS (Structural foundation)';
    if (hz >= 300 && hz < 1000) return 'VOCAL COGNITION RANGE';
    if (hz >= 1000 && hz < 4000) return 'HIGH PRESENCE DETECTORS';
    return 'PITCH BRILLIANCE / SENSORIAL SPARK';
  };

  return (
    <div id="reality_compiler_container" className="flex flex-col h-full w-full bg-[#050209] text-gray-200 overflow-y-auto p-3 sm:p-5 font-sans relative">
      
      {/* 1. Header Segment */}
      <div className="flex flex-col gap-2 mb-4 border-b border-purple-950/45 pb-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-purple-950/40 rounded border border-purple-800/30">
              <Code className="w-6 h-6 text-fuchsia-400 animate-pulse" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-black tracking-tight text-fuchsia-400 uppercase flex items-center gap-2">
                Reality Compiler <span className="text-xs font-mono text-purple-500 font-normal">v2.4 [SECURE]</span>
              </h1>
              <span className="text-[10px] font-mono text-fuchsia-500/80 uppercase tracking-widest bg-fuchsia-950/25 px-1.5 py-0.5 rounded border border-fuchsia-950">
                TRANS-SPATIAL SYSTEM INTEGRATION ENGINE
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start md:self-auto">
            {/* Telemetry quick status lights */}
            <div className="flex items-center gap-1 text-[9px] font-mono text-purple-400 bg-purple-950/20 px-2 py-1 rounded border border-purple-950">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> WAL CACHE RUNNING
            </div>
            
            <button 
              onClick={syncWithPhysicalRegistry}
              className="p-1.5 border border-purple-900/35 hover:border-fuchsia-500/60 bg-[#12071f]/50 hover:bg-[#1f0d35] rounded transition-all text-purple-400 hover:text-fuchsia-300"
              title="Force Core Telemetry Sync"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
        
        <p className="text-[10.5px] text-purple-400/80 max-w-4xl leading-relaxed uppercase mt-1">
          Baking physical transduction channels, Bayesian predictive processing patterns, and deep Indo-European linguistic roots into localized 3D parameters. Bridging classical wave mechanics with organic conscious experience.
        </p>
      </div>

      {/* 2. Sub-Navigation / Tab Selectors */}
      <div className="flex gap-2 overflow-x-auto pb-2 border-b border-purple-950/20 mb-4 font-mono select-none scrollbar-hide">
        <button
          onClick={() => setActiveTab('TELEMETRY')}
          className={`flex items-center gap-1.5 px-3 py-1.5 border rounded text-[10.5px] font-bold uppercase tracking-wider transition-all shrink-0
            ${activeTab === 'TELEMETRY' 
              ? 'bg-[#180829] border-fuchsia-500/80 text-fuchsia-300 shadow-[0_0_10px_rgba(168,85,247,0.15)]' 
              : 'border-purple-950/60 bg-[#07030e] text-purple-400 hover:border-purple-800 hover:text-purple-300'
            }`}
        >
          <Database className="w-3.5 h-3.5" />
          I. Core Telemetry Grid
        </button>

        <button
          onClick={() => setActiveTab('TRANSDUCTION')}
          className={`flex items-center gap-1.5 px-3 py-1.5 border rounded text-[10.5px] font-bold uppercase tracking-wider transition-all shrink-0
            ${activeTab === 'TRANSDUCTION' 
              ? 'bg-[#180829] border-cyan-500/80 text-cyan-300 shadow-[0_0_10px_rgba(6,182,212,0.15)]' 
              : 'border-purple-950/60 bg-[#07030e] text-purple-400 hover:border-purple-800 hover:text-purple-300'
            }`}
        >
          <Eye className="w-3.5 h-3.5" />
          II. Spectrum Wave Transduction
        </button>

        <button
          onClick={() => setActiveTab('BAYESIAN')}
          className={`flex items-center gap-1.5 px-3 py-1.5 border rounded text-[10.5px] font-bold uppercase tracking-wider transition-all shrink-0
            ${activeTab === 'BAYESIAN' 
              ? 'bg-[#180829] border-fuchsia-500/80 text-fuchsia-300 shadow-[0_0_10px_rgba(168,85,247,0.15)]' 
              : 'border-purple-950/60 bg-[#07030e] text-purple-400 hover:border-purple-800 hover:text-purple-300'
            }`}
        >
          <Brain className="w-3.5 h-3.5" />
          III. Bayesian Brain Predictive Processor
        </button>

        <button
          onClick={() => setActiveTab('LINGUISTICS')}
          className={`flex items-center gap-1.5 px-3 py-1.5 border rounded text-[10.5px] font-bold uppercase tracking-wider transition-all shrink-0
            ${activeTab === 'LINGUISTICS' 
              ? 'bg-[#180829] border-purple-500/80 text-purple-300 shadow-[0_0_10px_rgba(168,85,247,0.15)]' 
              : 'border-purple-950/60 bg-[#07030e] text-purple-400 hover:border-purple-800 hover:text-purple-300'
            }`}
        >
          <Landmark className="w-3.5 h-3.5" />
          IV. Comparative Linguistic Shift
        </button>
      </div>

      {/* 3. Tab Contents Layout */}
      
      {/* Tab I: Core telemetry & Energy Grid */}
      {activeTab === 'TELEMETRY' && (
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-5 w-full max-w-[1600px] mx-auto animate-fadeIn">
          
          <div className="xl:col-span-4 flex flex-col gap-4">
            {/* Active Inductor / Capacitor Coefficients Displays */}
            <div className="bg-[#0b0413] border border-purple-950/80 rounded-xl p-4 shadow-[inset_0_0_20px_rgba(168,85,247,0.02)]">
              <h3 className="text-fuchsia-300 font-bold uppercase tracking-wider text-xs mb-3 flex items-center gap-2">
                <Sliders className="w-4 h-4 text-fuchsia-400" /> Coaxial Inductor & Capacitance Registers
              </h3>
              
              <div className="flex flex-col gap-3.5 font-mono">
                {/* Capacitance element (Light calibration) */}
                <div className="p-3 bg-black/45 border border-purple-950/60 rounded">
                  <div className="flex justify-between items-center mb-1 text-xs">
                    <span className="text-cyan-400 font-bold uppercase">CAPACITANCE (C)</span>
                    <span className="text-cyan-300 font-bold">{C.toFixed(2)} μF</span>
                  </div>
                  <div className="text-[9.5px] text-purple-500 uppercase leading-relaxed mb-3">
                    Represents physical capacitor storage values for Electrostatic Light transducers.
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-[10px]">
                    <div className="flex flex-col">
                      <span className="text-purple-600 uppercase">VOLTAGE BIAS:</span>
                      <span className="text-cyan-300">{V.toFixed(1)} V</span>
                    </div>
                    <div className="flex flex-col items-end">
                      <span className="text-purple-600 uppercase">STORED ENERGY (E_E):</span>
                      <span className="text-cyan-300">{energyElectric.toExponential(4)} J</span>
                    </div>
                  </div>
                </div>

                {/* Inductance element (Sound calibration) */}
                <div className="p-3 bg-black/45 border border-purple-950/60 rounded">
                  <div className="flex justify-between items-center mb-1 text-xs">
                    <span className="text-fuchsia-400 font-bold uppercase">INDUCTANCE (L)</span>
                    <span className="text-fuchsia-300 font-bold">{L.toFixed(2)} mH</span>
                  </div>
                  <div className="text-[9.5px] text-purple-500 uppercase leading-relaxed mb-3">
                    Represents electromagnetic field storage for acoustic mechanical transducers.
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-[10px]">
                    <div className="flex flex-col">
                      <span className="text-purple-600 uppercase">CURRENT BIAS:</span>
                      <span className="text-fuchsia-300">{I.toFixed(1)} A</span>
                    </div>
                    <div className="flex flex-col items-end">
                      <span className="text-purple-600 uppercase">FIELD ENERGY (E_B):</span>
                      <span className="text-fuchsia-300">{energyMagnetic.toExponential(4)} J</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* LC Resonance display card */}
              <div className="mt-4 p-3 bg-purple-950/20 border border-purple-950 rounded text-xs font-mono">
                <div className="flex justify-between items-center mb-1 text-[11px] font-bold uppercase">
                  <span className="text-purple-400">LC RESONANT FREQUENCY (f₀):</span>
                  <span className="text-fuchsia-300">{resonantFreq.toFixed(2)} Hz</span>
                </div>
                <div className="text-[10px] text-purple-600 leading-relaxed uppercase">
                  f₀ = 1 / (2π√LC) • Resolving local spacetime frequency resonance constants.
                </div>
              </div>
            </div>

            {/* Cognitive telemetry indicators from apothecary sync */}
            <div className="bg-[#0b0413] border border-purple-950/80 rounded-xl p-4 shadow-[inset_0_0_20px_rgba(168,85,247,0.02)]">
              <h3 className="text-fuchsia-300 font-bold uppercase tracking-wider text-xs mb-3 flex items-center gap-2">
                <Brain className="w-4 h-4 text-fuchsia-400" /> Default Mode Network Calibration
              </h3>
              
              <div className="space-y-3 font-mono text-[10.5px]">
                <div className="p-3 bg-black/45 border border-purple-950/60 rounded flex flex-col gap-1.5">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-purple-400">DMN CONNECTIVITY:</span>
                    <span className="text-fuchsia-300 font-bold">{dmnConnectivity}%</span>
                  </div>
                  <div className="w-full bg-purple-950/40 h-2 rounded-full overflow-hidden">
                    <div className="bg-fuchsia-500 h-full rounded-full" style={{ width: `${dmnConnectivity}%` }} />
                  </div>
                  <span className="text-[9px] text-purple-500 uppercase mt-1 leading-relaxed">
                    Higher values align sensory input precision. Lower rates allow prediction models to float free.
                  </span>
                </div>

                <div className="p-3 bg-black/45 border border-purple-950/60 rounded flex justify-between items-center">
                  <span className="text-purple-400 uppercase">COGNITIVE MODEL PRIOR (P):</span>
                  <span className="text-cyan-300 font-bold">{priorConfidence.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="xl:col-span-8 flex flex-col gap-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              
              {/* Python core blueprint simulator */}
              <div className="flex flex-col gap-3 bg-[#0a0512] border border-purple-950/80 rounded-xl overflow-hidden shadow-[inset_0_0_20px_rgba(0,0,0,0.8)] p-4">
                <div className="flex justify-between items-center text-xs font-mono text-purple-400 uppercase tracking-widest border-b border-purple-950/60 pb-2">
                  <span className="flex items-center gap-2"><Box className="w-4 h-4 text-fuchsia-400" /> core_blueprint.py</span>
                  <span className="text-[10px] text-purple-600 font-normal">SECURE PHYSICS RUNTIME</span>
                </div>
                
                <div className="p-3 bg-black/40 border border-purple-950/40 rounded overflow-y-auto text-[10.5px] font-mono text-cyan-400 h-64 leading-relaxed whitespace-pre ScrollStyle">
{`class GodModeOS:
    def __init__(self):
        self.operator = "M. Heaven$ent"
        self.lifePath = 3
        self.soulUrge = 1
        self.dmn_connectivity = ${dmnConnectivity}
        self.prior_confidence = ${priorConfidence}
        self.capacitance_uf = ${C.toFixed(2)}
        self.inductance_mh = ${L.toFixed(2)}

    def deploySpatialCommand(self, intentVector):
        resonantFreq = 1.0 / (2.0 * 3.1415 * ((self.inductance_mh * 1e-3 * self.capacitance_uf * 1e-6) ** 0.5))
        return intentVector * self.lifePath * resonantFreq

    def extractPhysicalAssets(self, sectorMatrix):
        # Transducing probability fields into tangible 3D momentum 
        return ["Money", "Wealth", "Power", "Influence", "Stability"]`}
                </div>
              </div>

              {/* Force compilation trigger box */}
              <div className="bg-[#0b0413] border border-purple-950/80 rounded-xl p-4 flex flex-col justify-between">
                <div>
                  <h3 className="text-fuchsia-300 font-bold uppercase tracking-wider text-xs mb-3 flex items-center gap-2">
                    <Layers className="w-4 h-4 text-fuchsia-400" /> Live Matrix Compiler Injector
                  </h3>
                  <p className="text-[10.5px] text-purple-400/80 uppercase leading-relaxed mb-4">
                    Executing this sequence collapses the wave equations, translating the abstract mental grid into localized material physical assets.
                  </p>

                  <div className="grid grid-cols-1 gap-2">
                    <div className="p-3 border border-purple-950 bg-black/40 rounded flex flex-col justify-center">
                      <span className="text-[10px] text-purple-500 font-bold uppercase font-mono">LC RESONATOR PATH LOCK</span>
                      <span className="text-xs font-mono text-cyan-400 font-bold tracking-wider mt-1 uppercase">
                        {resonantFreq > 0 ? `f₀ = ${resonantFreq.toFixed(2)} Hz STATE: STEADY` : 'OFFLINE'}
                      </span>
                    </div>

                    <div className="p-3 border border-purple-950 bg-black/40 rounded flex flex-col justify-center">
                      <span className="text-[10px] text-purple-500 font-bold uppercase font-mono">BAYESIAN CHECKSUM REGISTER</span>
                      <span className="text-xs font-mono text-fuchsia-400 font-bold tracking-wider mt-1 uppercase">
                        VAL: 0x{Math.floor((C + L + dmnConnectivity) * 16).toString(16).toUpperCase()} LATCHED
                      </span>
                    </div>
                  </div>
                </div>

                <div className="mt-4">
                  <button 
                    onClick={startCompilation}
                    disabled={compilationState !== 'IDLE'}
                    className="w-full py-3.5 bg-[#170624]/60 hover:bg-[#2e0d47] border border-fuchsia-900/50 hover:border-fuchsia-500 disabled:opacity-50 text-fuchsia-400 text-xxs font-bold tracking-[0.25em] uppercase rounded-lg transition-all flex justify-center items-center gap-3 shadow-[0_0_15px_rgba(168,85,247,0.04)] hover:shadow-[0_0_25px_rgba(168,85,247,0.15)] animate-pulse"
                  >
                    <Zap className="w-4 h-4 text-fuchsia-400" />
                    {compilationState === 'IDLE' ? 'Force Execution Sequence' : 'Compilation Active'}
                  </button>
                </div>
              </div>

            </div>

            {/* Realtime compilation logs output terminal */}
            <div className="flex-1 bg-black border border-purple-950/80 rounded-xl flex flex-col overflow-hidden shadow-[inset_0_0_40px_rgba(0,0,0,1)] relative min-h-[280px]">
              <div className="bg-[#12071d] px-4 py-3 border-b border-[#250d3d]/55 flex items-center justify-between text-xs text-purple-400 uppercase tracking-widest font-mono">
                <span className="flex items-center gap-2"><Terminal className="w-4 h-4 text-fuchsia-400" /> Reality Compilation Console Output</span>
                <span className="text-[9px] text-purple-600 font-bold">MODE: STABLE_WAL_ACTIVE</span>
              </div>
              
              {compilationState === 'IDLE' && (
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.03]">
                  <Shield className="w-32 h-32 text-purple-500" />
                </div>
              )}

              <div className="flex-1 p-4 overflow-y-auto flex flex-col gap-2 font-mono text-[10px] leading-relaxed">
                {logs.length === 0 ? (
                  <div className="text-purple-600 uppercase tracking-wide">Ready for spatial compiler injection sequence...</div>
                ) : (
                  logs.map((log, i) => (
                    <div 
                      key={i} 
                      className={`flex items-start gap-2 ${i === logs.length - 1 ? 'text-fuchsia-400 font-bold scale-[1.01] origin-left transition-transform duration-300' : 'text-purple-300/80'} `}
                    >
                      <span className="text-purple-700 font-bold shrink-0">[{new Date().toISOString().split('T')[1].slice(0, -1)}]</span>
                      <span className="uppercase tracking-wide">{log}</span>
                    </div>
                  ))
                )}
                {compilationState === 'COMPILIN' && (
                  <div className="flex items-center gap-2 text-fuchsia-400/40 mt-2">
                    <div className="w-1.5 h-3.5 bg-fuchsia-500 animate-pulse" />
                    <span className="uppercase tracking-widest text-[9px]">COLLAPSING QUANTUM STATE VECTORS into 3D DENSITY...</span>
                  </div>
                )}
              </div>
            </div>

          </div>

        </div>
      )}

      {/* Tab II: Wave Transduction Simulator */}
      {activeTab === 'TRANSDUCTION' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 w-full max-w-[1600px] mx-auto animate-fadeIn">
          
          {/* Sliders and Controls (Left - Col span 4) */}
          <div className="lg:col-span-5 flex flex-col gap-4">
            <div className="bg-[#0b0413] border border-cyan-950 rounded-xl p-4 shadow-[inset_0_0_20px_rgba(6,182,212,0.01)]">
              <h3 className="text-cyan-300 font-bold uppercase tracking-wider text-xs mb-3 flex items-center gap-2 font-mono">
                <Sliders className="w-4 h-4 text-cyan-400" /> Transducer Signal Inputs
              </h3>
              <p className="text-[10.5px] text-purple-400 mb-4 uppercase leading-relaxed font-mono">
                Calibrate physical wave parameters prior to neural sensory conversion.
              </p>

              <div className="flex flex-col gap-5">
                
                {/* Electromagnetic Light control */}
                <div className="bg-[#04010a] border border-cyan-950 p-4 rounded-lg">
                  <div className="flex justify-between items-center mb-1 font-mono text-xs">
                    <span className="text-cyan-400 font-bold uppercase flex items-center gap-1.5">
                      <Eye className="w-4 h-4" /> EM Visible Light (THz)
                    </span>
                    <span className="text-cyan-300 font-bold">{lightFreqThz} THz</span>
                  </div>
                  <div className="text-[10px] text-purple-500 font-mono uppercase mb-3 leading-relaxed">
                    Invisible Infrared (120 THz) up to visible spectrum boundary violet (790 THz).
                  </div>

                  <input
                    type="range"
                    min="120"
                    max="790"
                    value={lightFreqThz}
                    onChange={(e) => setLightFreqThz(Number(e.target.value))}
                    className="w-full accent-cyan-400 bg-cyan-950/40 h-1 rounded-full cursor-pointer"
                  />
                  
                  {/* Dynamic Color visual bar indicator */}
                  <div className="h-2 rounded mt-3 transition-colors duration-300" style={{ backgroundColor: getLightColor(lightFreqThz) }} />
                  <div className="flex justify-between items-center text-[9px] text-cyan-600 font-mono mt-1.5 uppercase">
                    <span>120 THz (Infrared)</span>
                    <span className="text-cyan-400 font-bold">
                      {lightFreqThz < 400 ? 'INFRARED' : lightFreqThz >= 750 ? 'ULTRAVIOLET' : 'VISIBLE BAND'}
                    </span>
                    <span>790 THz (Violet)</span>
                  </div>
                </div>

                {/* Mechanical Pressure Sound control */}
                <div className="bg-[#04010a] border border-cyan-950 p-4 rounded-lg">
                  <div className="flex justify-between items-center mb-1 font-mono text-xs">
                    <span className="text-fuchsia-400 font-bold uppercase flex items-center gap-1.5">
                      <Volume2 className="w-4 h-4" /> Acoustic Pressure (Hz)
                    </span>
                    <span className="text-fuchsia-300 font-bold">{soundFreqHz} Hz</span>
                  </div>
                  <div className="text-[10px] text-purple-500 font-mono uppercase mb-3 leading-relaxed">
                    Mechanical oscillations through air medium. Human audible range (20 Hz - 20,000 Hz).
                  </div>

                  <input
                    type="range"
                    min="20"
                    max="2500"
                    value={soundFreqHz}
                    onChange={(e) => setSoundFreqHz(Number(e.target.value))}
                    className="w-full accent-fuchsia-400 bg-fuchsia-950/40 h-1 rounded-full cursor-pointer"
                  />
                  
                  <div className="flex justify-between items-center text-[9px] text-fuchsia-600 font-mono mt-2.5 uppercase">
                    <span>20 Hz (Infra Bass)</span>
                    <span className="text-fuchsia-300 font-bold truncate max-w-[170px]">
                      {getSoundProfile(soundFreqHz)}
                    </span>
                    <span>2500 Hz (Mid High)</span>
                  </div>
                </div>

                {/* Transduction model settings info */}
                <div className="p-3 bg-cyan-950/15 border border-cyan-950/45 rounded-lg text-[10.5px] text-cyan-400/80 uppercase font-mono leading-relaxed space-y-2">
                  <div className="flex items-center gap-1.5 font-bold text-cyan-300">
                    <Info className="w-4 h-4" /> The Transduction Hypothesis
                  </div>
                  <p className="text-[9.5px] leading-relaxed">
                    Light waves and sound waves are physically separated by 12 orders of magnitude and completely different media. They only meet as they are converted into uniform electrochemical action potentials in the brain.
                  </p>
                </div>

              </div>
            </div>
          </div>

          {/* Interactive Screen Waves Sandbox (Right - Col span 7) */}
          <div className="lg:col-span-7 flex flex-col gap-4">
            <div className="bg-[#0b0413] border border-cyan-950 rounded-xl p-4 flex flex-col min-h-[480px]">
              <div className="flex justify-between items-center font-mono border-b border-cyan-950 pb-2 mb-4">
                <span className="text-cyan-300 font-bold uppercase tracking-widest text-xs flex items-center gap-2">
                  <Activity className="w-4 h-4 text-cyan-400" /> Active Transduction Oscillation Matrix
                </span>
                <span className="text-[9px] text-cyan-500 uppercase font-bold">EEG TRANSDUCTION: ACTIVE</span>
              </div>

              {/* Graphical representation drawing container */}
              <div className="flex-1 grid grid-rows-3 gap-3 bg-black/80 rounded border border-cyan-900/40 p-3 select-none font-mono">
                
                {/* 1. Electromagnetic visual sine waves */}
                <div className="relative border border-cyan-950 rounded bg-[#01030a] overflow-hidden flex flex-col justify-between p-2">
                  <span className="absolute top-2 left-2 text-[9px] uppercase tracking-wider text-cyan-500 font-bold bg-[#01030a] px-1 px-1 py-0.5 rounded border border-cyan-950/50">
                    Input: Electromagnetic (Visible Light) ({lightFreqThz} THz)
                  </span>

                  {/* Draw a real-time glowing wavelength wave dynamically */}
                  <svg className="w-full h-full min-h-[80px]" viewBox="0 0 1000 100">
                    <path
                      d={Array.from({ length: 151 }, (_, i) => {
                        const x = (i * 1000) / 150;
                        const freqCoefficient = (lightFreqThz / 180);
                        const y = 50 + Math.sin(x * 0.04 * freqCoefficient + animTime * 3) * 20;
                        return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
                      }).join(' ')}
                      fill="none"
                      stroke={getLightColor(lightFreqThz)}
                      strokeWidth="2.5"
                      className="drop-shadow-[0_0_8px_rgba(34,211,238,0.5)]"
                    />
                  </svg>

                  <div className="flex justify-between items-center text-[8px] text-cyan-700 uppercase mt-1">
                    <span>Maxwell's Equations EM Wave</span>
                    <span>No Propagation Medium Required</span>
                  </div>
                </div>

                {/* 2. Sound visual waves */}
                <div className="relative border border-fuchsia-950 rounded bg-[#03010c] overflow-hidden flex flex-col justify-between p-2">
                  <span className="absolute top-2 left-2 text-[9px] uppercase tracking-wider text-fuchsia-500 font-bold bg-[#03010c] px-1 py-0.5 rounded border border-fuchsia-950/50">
                    Input: Mechanical (Sound Pressure) ({soundFreqHz} Hz)
                  </span>

                  {/* Draw an acoustic compression wave */}
                  <svg className="w-full h-full min-h-[80px]" viewBox="0 0 1000 100">
                    <path
                      d={Array.from({ length: 151 }, (_, i) => {
                        const x = (i * 1000) / 150;
                        const freqCoefficient = (soundFreqHz / 200);
                        const y = 50 + Math.sin(x * 0.015 * freqCoefficient + animTime * 1.5) * 18;
                        return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
                      }).join(' ')}
                      fill="none"
                      stroke="#f472b6"
                      strokeWidth="2"
                      className="drop-shadow-[0_0_6px_rgba(244,114,182,0.4)]"
                    />
                  </svg>

                  <div className="flex justify-between items-center text-[8px] text-fuchsia-700 uppercase mt-1">
                    <span>Mechanical Longitudinal Air Compression</span>
                    <span>Requires Elastic Medium (Air/Water)</span>
                  </div>
                </div>

                {/* 3. Output Transduced EEG Signal */}
                <div className="relative border border-purple-950 rounded bg-[#020006] overflow-hidden flex flex-col justify-between p-2">
                  <span className="absolute top-2 left-2 text-[9px] uppercase tracking-wider text-purple-400 font-bold bg-[#020006] px-1 py-0.5 rounded border border-purple-950/50">
                    TRANS-TRANSDUCER OUTPUT: Electrochemical Neural Firing (Action Potentials)
                  </span>

                  {/* Draw a neural action potential spike wave */}
                  <svg className="w-full h-full min-h-[80px]" viewBox="0 0 1000 100">
                    <path
                      d={Array.from({ length: 151 }, (_, i) => {
                        const x = (i * 1000) / 150;
                        // Neurons spike at dynamic rates proportional to intensity
                        const intensityFactor = (lightFreqThz / 400) + (soundFreqHz / 500);
                        const waveVal = Math.sin(x * 0.02 * intensityFactor + animTime * 2);
                        // Convert simple sine into spike action potential visual
                        const y = 60 - (waveVal > 0.85 ? 40 : waveVal < -0.85 ? -18 : 0);
                        return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
                      }).join(' ')}
                      fill="none"
                      stroke="#c084fc"
                      strokeWidth="2"
                      className="drop-shadow-[0_0_6px_rgba(192,132,252,0.4)]"
                    />
                  </svg>

                  <div className="flex justify-between items-center text-[8px] text-purple-700 uppercase mt-1">
                    <span>Aggregate Neuronal Ion Flux (EEG)</span>
                    <span className="text-purple-400 font-bold animate-pulse">
                      ● THE COGNITIVE INTEGRATIVE BRIDGE COMPLETE
                    </span>
                  </div>
                </div>

              </div>

              {/* Informative block beneath the graph */}
              <div className="mt-4 p-3 border border-cyan-900/30 bg-[#050912]/80 rounded-lg text-xxs font-mono leading-relaxed">
                <div className="text-cyan-400 font-bold uppercase mb-1">
                  MUTUAL UNITY PROCESS: MULTISENSORY TRANSDUCTION
                </div>
                <p className="text-purple-400 uppercase leading-relaxed text-[9.5px]">
                  While separate wavelengths seem different externally, the conscious mind reads them as action potential voltages. True unity is not in the external waves themselves, but in the organic transducer machine (the brain) translating them into a singular cognitive experience.
                </p>
              </div>

            </div>
          </div>

        </div>
      )}

      {/* Tab III: Bayesian Mind Predictive Simulator */}
      {activeTab === 'BAYESIAN' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 w-full max-w-[1600px] mx-auto animate-fadeIn font-mono">
          
          {/* Inputs Section (Left - 5 cols) */}
          <div className="lg:col-span-5 flex flex-col gap-4">
            <div className="bg-[#0b0413] border border-purple-950/80 rounded-xl p-4 shadow-[inset_0_0_20px_rgba(168,85,247,0.02)]">
              <h3 className="text-fuchsia-300 font-bold uppercase tracking-wider text-xs mb-3 flex items-center gap-2">
                <Sliders className="w-4 h-4 text-fuchsia-400" /> Cognitive Belief Coefficients
              </h3>
              
              <div className="flex flex-col gap-5">
                
                {/* 1. Prior model P(H) */}
                <div className="bg-[#04010a] border border-purple-950 p-4 rounded-lg">
                  <div className="flex justify-between items-center mb-1 text-xs">
                    <span className="text-fuchsia-400 font-bold uppercase">
                      Prior Belief Constraint P(H)
                    </span>
                    <span className="text-fuchsia-300 font-bold">{(priorVal * 100).toFixed(0)}%</span>
                  </div>
                  <div className="text-[10px] text-purple-500 uppercase mb-3 leading-relaxed">
                    Prior confidence in existing mental reality model (from memory and linguistic history).
                  </div>

                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={priorVal * 100}
                    onChange={(e) => setPriorVal(Number(e.target.value) / 100)}
                    className="w-full accent-fuchsia-400 bg-purple-950/40 h-1 rounded-full cursor-pointer"
                  />
                  
                  <div className="flex justify-between items-center text-[9px] text-purple-600 mt-1.5 uppercase">
                    <span>Low Expectation</span>
                    <span>Weighted Bias: {priorVal.toFixed(2)}</span>
                    <span>High Expectation</span>
                  </div>
                </div>

                {/* 2. Evidence Likelihood P(E|H) */}
                <div className="bg-[#04010a] border border-purple-950 p-4 rounded-lg">
                  <div className="flex justify-between items-center mb-1 text-xs">
                    <span className="text-cyan-400 font-bold uppercase">
                      Sensory Input Precision P(E|H)
                    </span>
                    <span className="text-cyan-300 font-bold">{(evidenceLikelihood * 100).toFixed(0)}%</span>
                  </div>
                  <div className="text-[10px] text-purple-500 uppercase mb-3 leading-relaxed">
                    How clean/precise the physical wave feedback is. Calibrated by active DMN loop.
                  </div>

                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={evidenceLikelihood * 100}
                    disabled={activeInferenceMode === 'ASTRAL_DREAM'}
                    onChange={(e) => setEvidenceLikelihood(Number(e.target.value) / 100)}
                    className={`w-full accent-cyan-400 bg-cyan-950/40 h-1 rounded-full cursor-pointer ${activeInferenceMode === 'ASTRAL_DREAM' ? 'opacity-30 cursor-not-allowed' : ''}`}
                  />
                  
                  <div className="flex justify-between items-center text-[9px] text-cyan-600 mt-1.5 uppercase">
                    <span>Noisy senses</span>
                    <span className="text-cyan-300">
                      {activeInferenceMode === 'ASTRAL_DREAM' ? 'LOCKED AT 5% (DREAM)' : `Weighted bias: ${evidenceLikelihood.toFixed(2)}`}
                    </span>
                    <span>Prisinte input</span>
                  </div>
                </div>

                {/* 3. Active inference toggle mode */}
                <div className="bg-[#04010a] border border-purple-950 p-4 rounded-lg">
                  <div className="text-xs font-bold text-fuchsia-400 uppercase mb-2">
                    Active Inference Engine State
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2 text-xxs font-bold">
                    <button
                      onClick={() => setActiveInferenceMode('REALITY_LOCK')}
                      className={`py-2 px-3 border rounded transition-all uppercase tracking-wider
                        ${activeInferenceMode === 'REALITY_LOCK'
                          ? 'bg-emerald-950/25 border-emerald-500 text-emerald-300 shadow-[0_0_8px_rgba(16,185,129,0.1)]'
                          : 'border-purple-950 bg-black/40 text-purple-600 hover:border-purple-800'
                        }`}
                    >
                      REALITY LOCK MODE
                    </button>
                    
                    <button
                      onClick={() => setActiveInferenceMode('ASTRAL_DREAM')}
                      className={`py-2 px-3 border rounded transition-all uppercase tracking-wider
                        ${activeInferenceMode === 'ASTRAL_DREAM'
                          ? 'bg-amber-950/25 border-amber-500 text-amber-300 shadow-[0_0_8px_rgba(245,158,11,0.1)]'
                          : 'border-purple-950 bg-black/40 text-purple-600 hover:border-purple-800'
                        }`}
                    >
                      ASTRAL DREAM MODE
                    </button>
                  </div>
                  
                  <p className="text-[9px] text-purple-500 uppercase mt-3 leading-relaxed">
                    *Reality Lock enforces structural corrections via sensory telemetry physics. Astral Dream decouples sensory input, allowing priors to render unconstrained imaginary worlds.
                  </p>
                </div>

              </div>
            </div>
          </div>

          {/* Graphical comparison charts (Right - 7 cols) */}
          <div className="lg:col-span-7 flex flex-col gap-4">
            <div className="bg-[#0b0413] border border-purple-950/80 rounded-xl p-4 flex flex-col min-h-[460px]">
              
              <div className="flex justify-between items-center border-b border-purple-950 pb-2 mb-4">
                <span className="text-fuchsia-300 font-bold uppercase tracking-widest text-xs flex items-center gap-2">
                  <Brain className="w-4 h-4 text-fuchsia-400" /> Posterior Probability Distribution Sandbox
                </span>
                <span className="text-[9px] text-purple-500 uppercase font-bold">MODE: EQUILIBRIUM_STEADY</span>
              </div>

              {/* Dynamic Interactive graph bars visualizing Bayes */}
              <div className="flex-1 flex flex-col justify-around bg-black/80 rounded border border-purple-900/40 p-5 gap-6">
                
                {/* 1. Prior distribution */}
                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-fuchsia-400 font-bold uppercase">PRIOR CONSTRAINTS P(H) (Memory & History)</span>
                    <span className="text-fuchsia-300 font-mono font-bold">{(priorVal).toFixed(2)}</span>
                  </div>
                  <div className="w-full bg-purple-950/40 border border-purple-950 h-5 rounded overflow-hidden">
                    <div className="bg-fuchsia-500 h-full rounded shadow-[0_0_10px_rgba(168,85,247,0.8)] transition-all duration-300" style={{ width: `${priorVal * 100}%` }} />
                  </div>
                </div>

                {/* 2. Sensory likelihood distribution */}
                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-cyan-400 font-bold uppercase">SENSORY LIKELIHOOD P(E|H) (Vibrated physics inputs)</span>
                    <span className="text-cyan-300 font-mono font-bold">
                      {activeInferenceMode === 'ASTRAL_DREAM' ? '0.05 (Dream decoupling)' : (evidenceLikelihood).toFixed(2)}
                    </span>
                  </div>
                  <div className="w-full bg-cyan-950/40 border border-cyan-950 h-5 rounded overflow-hidden">
                    <div className="bg-cyan-400 h-full rounded shadow-[0_0_10px_rgba(34,211,238,0.8)] transition-all duration-300" style={{ width: `${(activeInferenceMode === 'ASTRAL_DREAM' ? 0.05 : evidenceLikelihood) * 100}%` }} />
                  </div>
                </div>

                {/* 3. Posterior Belief (The Compiled Real-time Reality outcome) */}
                <div className="space-y-1 pt-3 border-t border-purple-950/50">
                  <div className="flex justify-between text-xs font-bold">
                    <span className="text-purple-300 uppercase">COMPILED POSTERIOR PROBABILITY OF REALITY P(H|E)</span>
                    <span className="text-purple-200 font-mono text-[14px]">{(posteriorProb).toFixed(4)}</span>
                  </div>
                  <div className="w-full bg-purple-950/50 border border-purple-800/40 h-7 rounded overflow-hidden shadow-[0_0_15px_rgba(168,85,247,0.05)]">
                    <div className="bg-purple-400 h-full rounded shadow-[0_0_15px_rgba(168,85,247,1)] transition-all duration-300" style={{ width: `${posteriorProb * 100}%` }} />
                  </div>
                </div>

              </div>

              {/* Descriptive Bayes text board */}
              <div className="mt-4 p-3 border border-purple-950 bg-[#0d041a] rounded-lg text-xxs font-mono leading-relaxed uppercase">
                <div className="text-fuchsia-400 font-bold mb-1">
                  BAYES COMPILER FORMULA
                </div>
                <div className="text-purple-400 mb-2 font-bold text-xs">
                  P(H|E) = [P(E|H) × P(H)] / P(E)
                </div>
                <p className="text-purple-500 text-[9.5px]">
                  {activeInferenceMode === 'REALITY_LOCK' 
                    ? `Physical world constraints strictly bound your experience. Your conscious mind is currently locked P(H|E) = ${posteriorProb.toFixed(4)} to the physical measurements C=${C.toFixed(1)}μF & L=${L.toFixed(1)}mH.`
                    : 'ASTRAL DREAM MODE ENABLED: Sensory inputs are suppressed. Raw mental models and priors construct a complete unconstrained virtual universe directly within the conscious loop.'}
                </p>
              </div>

            </div>
          </div>

        </div>
      )}

      {/* Tab IV: Comparative Linguistics Shift Engine */}
      {activeTab === 'LINGUISTICS' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 w-full max-w-[1600px] mx-auto animate-fadeIn font-mono">
          
          {/* Cognate selector matrix (Left - 5 cols) */}
          <div className="lg:col-span-5 flex flex-col gap-4">
            <div className="bg-[#0b0413] border border-purple-950 rounded-xl p-4 flex flex-col min-h-[460px]">
              <h3 className="text-purple-300 font-bold uppercase tracking-wider text-xs mb-3 flex items-center gap-2">
                <Landmark className="w-4 h-4 text-purple-400" /> Ancient Proto-Indo-European Roots
              </h3>
              <p className="text-[10px] text-purple-500 uppercase leading-relaxed mb-4">
                Select an ancestral linguistic token to trace its evolution down the branches of Vedic Sanskrit, Latin/Greek, Spanish, and English.
              </p>

              {/* Grid selectors */}
              <div className="flex-1 flex flex-col gap-2 overflow-y-auto pr-1">
                {pieCognateDatabase.map((node, i) => (
                  <button
                    key={i}
                    onClick={() => setSelectedCognateId(i)}
                    className={`p-3 border rounded text-left transition-all uppercase flex justify-between items-center
                      ${selectedCognateId === i
                        ? 'bg-purple-950/30 border-purple-500 text-fuchsia-300 shadow-[0_0_10px_rgba(168,85,247,0.06)]'
                        : 'border-purple-950 bg-black/40 text-purple-400 hover:border-purple-800 hover:text-purple-300'
                      }`}
                  >
                    <div>
                      <div className="text-xs font-bold font-mono text-cyan-400">{node.pieRoot}</div>
                      <div className="text-[9.5px] text-purple-500 mt-0.5">{node.pieMeaning}</div>
                    </div>
                    <ArrowRight className="w-4 h-4 opacity-50 text-fuchsia-400" />
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Root tracer display and Interactive sound shifting (Right - 7 cols) */}
          <div className="lg:col-span-7 flex flex-col gap-4">
            
            {/* Visual cognate detail tracing card */}
            <div className="bg-[#0b0413] border border-purple-950 rounded-xl p-4 font-mono flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-center border-b border-purple-950 pb-2 mb-4">
                  <span className="text-fuchsia-300 font-bold uppercase tracking-widest text-xs">
                    PIE COGNATE DESCENT PATHWAY: {currentCognate.pieRoot}
                  </span>
                  <span className="text-[9px] font-bold text-cyan-400">UNIFIED ROOT SCHEMA</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
                  
                  {/* Sanskrit column */}
                  <div className="p-3 bg-black/55 border border-purple-950 rounded">
                    <div className="text-[10px] text-purple-500 font-bold uppercase">I. VEDIC SANSKRIT</div>
                    <div className="text-sm font-bold text-fuchsia-400 mt-1">{currentCognate.sanskrit}</div>
                    <div className="text-[10px] text-purple-300 mt-1 leading-relaxed">{currentCognate.sanskritMeaning}</div>
                  </div>

                  {/* Latin/Greek Column */}
                  <div className="p-3 bg-black/55 border border-purple-950 rounded">
                    <div className="text-[10px] text-purple-500 font-bold uppercase">II. LATIN & GREEK</div>
                    <div className="text-sm font-bold text-cyan-300 mt-1">{currentCognate.latinGreek}</div>
                    <div className="text-[10px] text-purple-300 mt-1 leading-relaxed">Early European literary pillars.</div>
                  </div>

                  {/* Spanish Column */}
                  <div className="p-3 bg-black/55 border border-purple-950 rounded">
                    <div className="text-[10px] text-purple-500 font-bold uppercase">III. MODERN ROMANCE (SPANISH)</div>
                    <div className="text-sm font-bold text-purple-300 mt-1">{currentCognate.spanish}</div>
                    <div className="text-[10px] text-purple-400/80 mt-1 leading-relaxed">Direct descendant of Vulgar Latin structural syntax.</div>
                  </div>

                  {/* English Column */}
                  <div className="p-3 bg-black/55 border border-purple-950 rounded">
                    <div className="text-[10px] text-purple-500 font-bold uppercase">IV. MODERN GERMANIC (ENGLISH)</div>
                    <div className="text-sm font-bold text-cyan-400 mt-1">{currentCognate.english}</div>
                    <div className="text-[10px] text-purple-400/80 mt-1 leading-relaxed">Germanic core carrying massive Latin cognate overlays.</div>
                  </div>

                </div>

                {/* Evolution Notes */}
                <div className="p-3 bg-purple-950/25 border border-purple-950 rounded text-xxs leading-relaxed uppercase">
                  <div className="text-purple-400 font-bold mb-1">EVOLUTION & SOUND SHIFT DATA TRACK</div>
                  <p className="text-purple-300 leading-relaxed text-[10px]">{currentCognate.soundshiftNote}</p>
                </div>
              </div>
            </div>

            {/* Interactive Grimm's Law Sound shift simulator */}
            <div className="bg-[#0b0413] border border-purple-950 rounded-xl p-4 font-mono">
              <h3 className="text-fuchsia-300 font-bold uppercase tracking-wider text-xs mb-3 flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-fuchsia-400" /> Interactive Grimm's Law Sound Shifter
              </h3>
              <p className="text-[10px] text-purple-500 uppercase leading-relaxed mb-4">
                Select a Proto-Indo-European voiceless stop and witness its step-by-step mathematical sound shift into Proto-Germanic as defined by 19th-century historical linguistics.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-3 bg-black/50 p-3 rounded border border-purple-950 items-center">
                
                {/* 1. Selector consonants */}
                <div className="flex flex-col gap-2.5">
                  <span className="text-[9.5px] text-purple-500 font-bold uppercase">PIE VOICELESS STOP</span>
                  <div className="flex gap-1.5">
                    {['p', 't', 'k'].map((char) => (
                      <button
                        key={char}
                        onClick={() => {
                          setTargetGrimmConsonant(char as any);
                          setAppliedGrimmShifts([]);
                        }}
                        className={`flex-1 py-1 px-2 border rounded font-mono font-bold text-xs uppercase
                          ${targetGrimmConsonant === char
                            ? 'bg-fuchsia-950/30 border-fuchsia-500 text-fuchsia-300'
                            : 'border-purple-950 text-purple-500 hover:border-purple-800'
                          }`}
                      >
                        /{char}/
                      </button>
                    ))}
                  </div>
                </div>

                {/* 2. Step 1 representation */}
                <div className="flex flex-col gap-1 text-[10px] border-l border-purple-950/40 pl-3 md:pl-4">
                  <span className="text-purple-500 font-bold uppercase">STAGE 1: PIE UNVOICED</span>
                  <span className="text-cyan-400 font-bold text-xs uppercase">
                    {targetGrimmConsonant === 'p' && '*/p/ (e.g. *ped-)'}
                    {targetGrimmConsonant === 't' && '*/t/ (e.g. *trei)'}
                    {targetGrimmConsonant === 'k' && '*/k/ (e.g. *krn-)'}
                  </span>
                  <span className="text-[8.5px] text-purple-600 uppercase">Tense Voiceless occlusive</span>
                </div>

                {/* 3. Stage 2 Grimm transition */}
                <div className="flex flex-col gap-1 text-[10px] border-l border-purple-950/40 pl-3 md:pl-4">
                  <span className="text-purple-500 font-bold uppercase">STAGE 2: FRICATIVE SHIFT</span>
                  <span className="text-fuchsia-400 font-bold text-xs uppercase animate-pulse">
                    {targetGrimmConsonant === 'p' && '*/f/ (e.g. foot)'}
                    {targetGrimmConsonant === 't' && '*/θ/ (e.g. three)'}
                    {targetGrimmConsonant === 'k' && '*/h/ (e.g. horn)'}
                  </span>
                  <span className="text-[8.5px] text-purple-600 uppercase">Proto-Germanic Sound Wave</span>
                </div>

                {/* 4. Action button trigger shifts */}
                <div>
                  <button
                    onClick={() => {
                      const res = targetGrimmConsonant === 'p' ? 'shifted /p/ to /f/ in English (foot vs. Spanish pie)' : 
                                  targetGrimmConsonant === 't' ? 'shifted /t/ to /θ/ (th) in English (three vs. Spanish tres)' :
                                  'shifted /k/ to /h/ in English (horn vs. Latin cornu)';
                      setAppliedGrimmShifts(prev => [...prev, `${new Date().toLocaleTimeString().split(' ')[0]}: Applied Grimm's Law shift. ${res}`]);
                    }}
                    className="w-full py-2.5 bg-purple-950/40 hover:bg-purple-900/35 text-fuchsia-300 hover:text-fuchsia-200 text-[9.5px] tracking-wider uppercase rounded border border-purple-950 hover:border-fuchsia-500 max-h-[36px] flex justify-center items-center"
                  >
                    RUN SHIFT MATRIX
                  </button>
                </div>

              </div>

              {/* Sub outputs terminal */}
              <div className="mt-3 p-3 bg-black/90 rounded border border-purple-950 h-24 overflow-y-auto text-xxs font-mono text-cyan-400">
                {appliedGrimmShifts.length === 0 ? (
                  <span className="text-purple-600 uppercase">Trigger sound shift matrix above to execute Grimm's Law...</span>
                ) : (
                  appliedGrimmShifts.map((str, idx) => (
                    <div key={idx} className="uppercase leading-normal border-b border-purple-950/30 pb-0.5 mb-1 last:border-0">{str}</div>
                  ))
                )}
              </div>

            </div>

          </div>

        </div>
      )}

    </div>
  );
}
