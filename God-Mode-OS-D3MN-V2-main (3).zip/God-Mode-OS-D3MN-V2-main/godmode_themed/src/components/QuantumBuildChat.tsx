import React, { useState, useEffect, useRef } from 'react';
import { 
  FileCode, Upload, Layers, Play, ExternalLink, Download, 
  Send, ChevronRight, Activity, ShieldAlert, Cpu, Check, X,
  FileCheck, RotateCcw, AlertTriangle, CpuIcon, AlertCircle, Eye,
  Terminal, MessageSquare, Plus, Trash2, Edit, Save, PlusCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { safeStorage } from '../lib/safeStorage';

import { WorkspaceExplorer } from './WorkspaceExplorer';
import { PromptQueuePanel } from './PromptQueuePanel';
import { TerminalConsole } from './TerminalConsole';

export function QuantumBuildChat() {
  const [file, setFile] = useState<{ id: string; filename: string; content: string; version_number: number; token_count?: number } | null>(null);
  const [isWorkspaceOpen, setIsWorkspaceOpen] = useState(true);
  const [isQueueMode, setIsQueueMode] = useState(false);
  const [showTerminal, setShowTerminal] = useState(false);
  const [terminalExpanded, setTerminalExpanded] = useState(true);
  const [isDragging, setIsDragging] = useState(false);
  const [versionHistory, setVersionHistory] = useState<any[]>([]);
  const [buildHistory, setBuildHistory] = useState<any[]>([]);
  const [historyTab, setHistoryTab] = useState<'versions' | 'builds'>('versions');
  const [showHistory, setShowHistory] = useState(false);
  const [activePreview, setActivePreview] = useState<'preview' | 'code'>('preview');

  const [sessionId, setSessionId] = useState<string>(() => {
    const cached = safeStorage.getItem('quantum_session_id');
    if (cached) return cached;
    const fresh = 'sess_' + Math.random().toString(36).substr(2, 9);
    safeStorage.setItem('quantum_session_id', fresh);
    return fresh;
  });
  const [sessions, setSessions] = useState<any[]>([]);
  const [editingSessionId, setEditingSessionId] = useState<string | null>(null);
  const [editingSessionTitle, setEditingSessionTitle] = useState<string>('');
  const [availableFiles, setAvailableFiles] = useState<any[]>([]);

  const [messages, setMessages] = useState<any[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isSending, setIsSending] = useState(false);

  const [modelPreference, setModelPreference] = useState<'standard' | 'creative'>('standard');
  const [providers, setProviders] = useState<any[]>([]);
  
  // Autonomous & Permission gate state
  const [autonomousMode, setAutonomousMode] = useState(false);
  const [trustMind, setTrustMind] = useState(false);
  const [useRazor, setUseRazor] = useState(true);
  const [pendingDirectives, setPendingDirectives] = useState<any[]>([]);
  const [countdown, setCountdown] = useState<Record<string, number>>({});
  const [activeJobId, setActiveJobId] = useState<string | null>(null);
  const [activeJobLogs, setActiveJobLogs] = useState<string>('');
  const [activeJobStatus, setActiveJobStatus] = useState<string>('');

  // Applet Linter Diagnostics State
  const [linterScore, setLinterScore] = useState<number | null>(null);
  const [linterLogs, setLinterLogs] = useState<string[]>([]);
  const [linterWarnings, setLinterWarnings] = useState<string[]>([]);
  const [isLinting, setIsLinting] = useState(false);
  const [showLinterPanel, setShowLinterPanel] = useState(true);

  const runLinterDiagnostics = async () => {
    if (!file) return;
    setIsLinting(true);
    setLinterLogs([
      `[COMPILER] Initiating reality-compiler matrix...`,
      `[AST PARSER] Reading stream source: ${file.filename}...`,
      `[COMPILER] Loading AST evaluation tree...`
    ]);
    setLinterWarnings([]);
    setLinterScore(null);

    setTimeout(async () => {
      try {
        const res = await fetch(`/api/armada/quantum/file/${file.id}`);
        if (res.ok) {
          const fileData = await res.json();
          const code = fileData.content || '';
          const logs: string[] = [];
          let score = 100;
          const warnings: string[] = [];

          logs.push(`[AST PARSER] Starting AST analysis on ${file.filename}...`);
          const openTags = (code.match(/<[a-zA-Z1-6]+(Anim|Btn|Card|Grid|Wrap|Sel|Header|Footer|Section|Div|Span)?(?:\s[^>]*)?>/g) || []);
          const closeTags = (code.match(/<\/[a-zA-Z1-6]+(Anim|Btn|Card|Grid|Wrap|Sel|Header|Footer|Section|Div|Span)?>/g) || []);
          logs.push(`[AST PARSER] Found ${openTags.length} opening html/jsx layout tags.`);

          logs.push(`[REACT HOOK ANALYZER] Evaluating hook dependencies...`);
          if (code.includes('setMetrics(prev => {') && code.includes('setHistory(')) {
            warnings.push(`Potential recursive update loop detected: setHistory called inside setMetrics state updater!`);
            score -= 15;
          }

          logs.push(`[LUCIDE RESOLVER] Validating SVG icon namespaces...`);
          const lucideMatch = code.match(/import\s*\{([^}]+)\}\s*from\s*['"]lucide-react['"]/);
          if (lucideMatch) {
            logs.push(`[LUCIDE RESOLVER] Bound icon modules successfully.`);
          }

          logs.push(`[ID INTEGRITY] Exposing interactive elements ID hashes...`);
          const interactiveCount = (code.match(/<(button|input|select|card|div\s+className=['"][^'"]*interactive[^'"]*['"])/g) || []).length;
          const idCount = (code.match(/id=['"][^'"]+['"]/g) || []).length;
          if (interactiveCount > 0 && idCount < interactiveCount / 2) {
            warnings.push(`Warning: Only ${idCount} out of ${interactiveCount} interactive components have an 'id' attribute. Add unique IDs for precise targeting.`);
            score -= 10;
          } else {
            logs.push(`[ID INTEGRITY] Target IDs checked and verified compliant.`);
          }

          logs.push(`[COMPILER] Build analysis complete. Structural integrity score: ${score}%.`);

          setLinterScore(score);
          setLinterLogs(logs);
          setLinterWarnings(warnings);
        }
      } catch (e) {
        console.error(e);
      } finally {
        setIsLinting(false);
      }
    }, 1500);
  };

  const fileInputRef = useRef<HTMLInputElement>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const fetchProviders = async () => {
    try {
      const res = await fetch('/api/armada/model_router/check');
      if (res.ok) {
        setProviders(await res.json());
      }
    } catch (e) {
      console.error(e);
    }
  };

  const fetchSessions = async () => {
    try {
      const res = await fetch('/api/armada/quantum/sessions');
      if (res.ok) {
        const data = await res.json();
        const list = data.sessions || [];
        setSessions(list);

        // Auto-refresh or auto-load active session on mount
        const activeSessId = safeStorage.getItem('quantum_session_id');
        if (activeSessId) {
          const match = list.find((s: any) => s.id === activeSessId);
          if (match && !file) {
            handleSessionChange(match.id, match.file_id);
          }
        } else if (list.length > 0 && !file) {
          handleSessionChange(list[0].id, list[0].file_id);
        }
      }
    } catch (e) {
      console.error("fetchSessions failed:", e);
    }
  };

  const fetchQuantumFiles = async () => {
    try {
      const res = await fetch('/api/armada/quantum/files');
      if (res.ok) {
        const data = await res.json();
        setAvailableFiles(data.files || []);
      }
    } catch (e) {
      console.error("fetchQuantumFiles failed:", e);
    }
  };

  const handleSessionChange = async (targetSessionId: string, targetFileId: string) => {
    setIsSending(true);
    try {
      setSessionId(targetSessionId);
      safeStorage.setItem('quantum_session_id', targetSessionId);

      // Load file context
      const fileRes = await fetch(`/api/armada/quantum/file/${targetFileId}`);
      if (fileRes.ok) {
        const fileData = await fileRes.json();
        if (fileData && fileData.content) {
          setFile({
            id: targetFileId,
            filename: fileData.filename,
            content: fileData.content,
            version_number: fileData.version_number,
            token_count: Math.ceil(fileData.content.length / 4)
          });
        }
      }

      // Load messages
      const msgsRes = await fetch(`/api/armada/quantum/session/${targetSessionId}/${targetFileId}`);
      if (msgsRes.ok) {
        const msgsData = await msgsRes.json();
        setMessages(msgsData.messages || []);
      }
    } catch (e) {
      console.error("handleSessionChange failed:", e);
    } finally {
      setIsSending(false);
    }
  };

  const handleNewSession = async (customFile?: { id: string; filename: string; content: string }) => {
    const targetFile = customFile || file;
    if (!targetFile) {
      alert("Please upload or select a workspace file first before starting a session.");
      return;
    }
    const freshSessionId = 'sess_' + Math.random().toString(36).substr(2, 9);
    setSessionId(freshSessionId);
    safeStorage.setItem('quantum_session_id', freshSessionId);
    setMessages([]);

    try {
      // Register session on backend
      await fetch('/api/armada/quantum/session/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId: freshSessionId,
          title: `Conversation via ${targetFile.filename}`,
          fileId: targetFile.id
        })
      });
      fetchSessions();
    } catch (e) {
      console.error("Failed to create new session:", e);
    }
  };

  const handleRenameSession = async (targetSessionId: string, titleName: string) => {
    if (!titleName.trim()) return;
    try {
      const res = await fetch('/api/armada/quantum/session/rename', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId: targetSessionId, title: titleName })
      });
      if (res.ok) {
        setEditingSessionId(null);
        fetchSessions();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleDeleteSession = async (targetSessionId: string) => {
    if (!confirm("Are you sure you want to permanently delete this conversation and its entire history?")) return;
    try {
      const res = await fetch(`/api/armada/quantum/session/${targetSessionId}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        // If we deleted the active session, pick another one or build a new one
        if (sessionId === targetSessionId) {
          const remaining = sessions.filter(s => s.id !== targetSessionId);
          if (remaining.length > 0) {
            handleSessionChange(remaining[0].id, remaining[0].file_id);
          } else {
            // No sessions left, reset session ID
            const fresh = 'sess_' + Math.random().toString(36).substr(2, 9);
            setSessionId(fresh);
            safeStorage.setItem('quantum_session_id', fresh);
            setMessages([]);
          }
        }
        fetchSessions();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const fetchHistory = async () => {
    if (!file) return;
    try {
      const res = await fetch(`/api/armada/quantum/versions/${file.id}`);
      if (res.ok) {
        const data = await res.json();
        setVersionHistory(data.versions);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const fetchBuilds = async () => {
    try {
      const res = await fetch('/api/armada/quantum/builds');
      if (res.ok) {
        const data = await res.json();
        setBuildHistory(data.builds || []);
      }
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    fetchSessions();
    fetchQuantumFiles();
  }, []);

  useEffect(() => {
    if (showHistory) {
      fetchBuilds();
    }
  }, [showHistory]);

  const fetchPending = async () => {
    try {
      const res = await fetch(`/api/armada/quantum/pending/${sessionId}`);
      if (res.ok) {
        const data = await res.json();
        setPendingDirectives(data.pending || []);
      }
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    fetchProviders();
    const interval = setInterval(() => {
      fetchProviders();
      if (file) {
        fetchPending();
      }
    }, 5000);
    return () => clearInterval(interval);
  }, [file]);

  useEffect(() => {
    if (file) {
      fetchHistory();
      runLinterDiagnostics();
      // Load current session messages
      fetch(`/api/armada/quantum/session/${sessionId}/${file.id}`)
        .then(r => r.json())
        .then(data => {
          if (data.success && data.messages) {
            setMessages(data.messages);
          }
        })
        .catch(e => console.error("Session load failed:", e));
    }
  }, [file?.id]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isSending]);

  // Autonomously handle pending countdowns
  useEffect(() => {
    if (pendingDirectives.length === 0) return;

    const timer = setInterval(() => {
      setCountdown(prev => {
        const next = { ...prev };
        let changed = false;

        for (const dir of pendingDirectives) {
          if (next[dir.id] === undefined) {
            next[dir.id] = 30;
            changed = true;
          } else if (next[dir.id] > 0) {
            next[dir.id] -= 1;
            changed = true;
          } else if (next[dir.id] === 0) {
            // Trigger Auto-Approve!
            handleResolveDirective(dir.id, true);
            delete next[dir.id];
            changed = true;
          }
        }
        return changed ? next : prev;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [pendingDirectives]);

  const handleFileUpload = async (filename: string, content: string) => {
    try {
      const res = await fetch('/api/armada/quantum/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename, content })
      });
      if (res.ok) {
        const data = await res.json();
        const uploadedFile = {
          id: data.fileId,
          filename,
          content,
          version_number: 1,
          token_count: data.tokenCount
        };
        setFile(uploadedFile);
        // Start persistent session for this new upload
        await handleNewSession(uploadedFile);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const onDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const onDragLeave = () => {
    setIsDragging(false);
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      const reader = new FileReader();
      const f = files[0];
      reader.onload = (evt) => {
        if (evt.target?.result) {
          handleFileUpload(f.name, evt.target.result as string);
        }
      };
      reader.readAsText(f);
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const reader = new FileReader();
      const f = files[0];
      reader.onload = (evt) => {
        if (evt.target?.result) {
          handleFileUpload(f.name, evt.target.result as string);
        }
      };
      reader.readAsText(f);
    }
  };

  const handleRollback = async (verNum: number) => {
    if (!file) return;
    try {
      const res = await fetch('/api/armada/quantum/rollback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fileId: file.id, versionNumber: verNum })
      });
      if (res.ok) {
        const data = await res.json();
        // Reload current state
        const fileRes = await fetch(`/api/armada/quantum/file/${data.fileId}`);
        if (fileRes.ok) {
          const fileData = await fileRes.json();
          setFile({
            id: data.fileId,
            filename: fileData.filename,
            content: fileData.content,
            version_number: fileData.version_number,
            token_count: Math.ceil(fileData.content.length / 4)
          });
          setShowHistory(false);
        }
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleResolveDirective = async (dirId: string, approve: boolean) => {
    try {
      await fetch('/api/armada/quantum/resolve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ directiveId: dirId, approve })
      });
      setPendingDirectives(prev => prev.filter(p => p.id !== dirId));
      if (approve && file) {
        // Reload active file details
        setTimeout(async () => {
          const fileRes = await fetch(`/api/armada/quantum/file/${file.id}`);
          if (fileRes.ok) {
            const fileData = await fileRes.json();
            setFile(prev => prev ? {
              ...prev,
              content: fileData.content,
              version_number: fileData.version_number,
              token_count: Math.ceil(fileData.content.length / 4)
            } : null);
          }
        }, 1200);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim() || !file || isSending) return;
    setIsSending(true);
    const textToSend = inputMessage;
    setInputMessage('');

    if (textToSend.startsWith('/build ')) {
      try {
        const res = await fetch('/api/armada/quantum/autonomous/build', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prompt: textToSend.substring(7) })
        });
        
        if (!res.ok) throw new Error('Failed to start build');
        const { jobId } = await res.json();
        
        setActiveJobId(jobId);
        setActiveJobStatus('QUEUED');
        setActiveJobLogs('Job enqueued in background processor...');

        const poll = setInterval(async () => {
            const statusRes = await fetch(`/api/armada/quantum/autonomous/status/${jobId}`);
            if (!statusRes.ok) return;
            const task = await statusRes.json();
            
            setActiveJobStatus(task.status);
            setActiveJobLogs(task.logs || '');

            if (task.status === 'COMPLETED' || task.status === 'FAILED' || task.status === 'CANCELLED') {
                clearInterval(poll);
                setTimeout(() => setActiveJobId(null), 10000); // clear after 10s
                
                // Refresh file
                const fileRes = await fetch(`/api/armada/quantum/file/${file.id}`);
                if (fileRes.ok) {
                    const fileData = await fileRes.json();
                    setFile(prev => prev ? { ...prev, content: fileData.content, version_number: fileData.version_number } : null);
                }
            }
        }, 1500);
      } catch (e) {
        console.error(e);
      } finally {
        setIsSending(false);
      }
      return;
    }

    try {
      const res = await fetch('/api/armada/quantum/message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          fileId: file.id,
          message: textToSend,
          modelPreference,
          useRazor
        })
      });

      if (res.ok) {
        const data = await res.json();
        const nextVer = (file ? file.version_number : 0) + 1;
        
        if (data.linterScore !== undefined) {
          setLinterScore(data.linterScore);
          setLinterLogs(data.linterLogs || []);
          setLinterWarnings(data.linterWarnings || []);
        }

        setFile(prev => prev ? {
          ...prev,
          id: data.fileId,
          version_number: nextVer,
          content: data.newFileContent || prev.content,
          token_count: Math.ceil((data.newFileContent || prev.content).length / 4)
        } : null);

        // Fetch refreshed chat messages
        const chatRes = await fetch(`/api/armada/quantum/session/${sessionId}/${data.fileId}`);
        if (chatRes.ok) {
          const chatData = await chatRes.json();
          setMessages(chatData.messages);
          fetchSessions();
        }

        // PHYSICAL ARTIFACT AUTO-DOWNLOAD VECTOR
        if (!autonomousMode && data.newFileContent) {
          try {
            const blob = new Blob([data.newFileContent], { type: 'text/html' });
            const link = document.createElement('a');
            
            // Format filename to include active version identifier (e.g., bannon v3.html)
            const currentFilename = file ? file.filename : 'bannon.html';
            const dotIndex = currentFilename.lastIndexOf('.');
            const downloadFilename = dotIndex !== -1
              ? `${currentFilename.slice(0, dotIndex)} v${nextVer}${currentFilename.slice(dotIndex)}`
              : `${currentFilename} v${nextVer}`;

            link.href = URL.createObjectURL(blob);
            link.download = downloadFilename;
            link.click();
            URL.revokeObjectURL(link.href);
            console.log(`[QuantumBuildChat] Successfully downloaded auto-artifact: ${downloadFilename}`);
          } catch (err) {
            console.error("Auto-download trigger failed:", err);
          }
        }
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsSending(false);
    }
  };

  const downloadFile = () => {
    if (!file) return;
    const blob = new Blob([file.content], { type: 'text/html' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = file.filename;
    link.click();
  };

  // Compute metrics
  const maxTokens = 120000;
  const currentTokens = file?.token_count || 0;
  const tokenPercent = Math.min(100, Math.round((currentTokens / maxTokens) * 100));

  const isHtml = file?.filename.endsWith('.html');

  const handleWorkspaceFileSelect = async (path: string, content: string) => {
    try {
      const parts = path.split('/');
      const name = parts[parts.length - 1];
      const res = await fetch('/api/armada/quantum/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename: name, content })
      });
      if (res.ok) {
        const data = await res.json();
        const selectedFile = { 
          id: data.fileId, 
          filename: data.filename || name, 
          content, 
          version_number: 1, 
          token_count: Math.ceil(content.length / 4) 
        };
        setFile(selectedFile);
        await handleNewSession(selectedFile);
      }
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="flex flex-col lg:flex-row h-full w-full bg-black text-white font-mono rounded-xl border border-white/10 overflow-hidden relative" style={{ height: 'calc(100vh - 100px)' }}>

      {isWorkspaceOpen && (
        <div className="w-[260px] flex-shrink-0 border-r border-white/10 overflow-hidden flex flex-col h-full bg-[#050505]">
          {/* File explorer - takes upper portion */}
          <div className="flex-1 overflow-y-auto border-b border-white/10">
            <WorkspaceExplorer onFileSelect={handleWorkspaceFileSelect} />
          </div>

          {/* Saved conversations - takes lower portion */}
          <div className="h-[45%] flex flex-col bg-black overflow-hidden border-t border-white/5">
            <div className="px-4 py-3 border-b border-white/10 bg-[#070707] flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-[10px] tracking-wider text-amber-500 font-bold uppercase">
                <MessageSquare className="w-3.5 h-3.5 text-amber-500" />
                <span>Saved Chats</span>
              </div>
              <button 
                onClick={() => handleNewSession()}
                className="p-1 hover:bg-white/5 rounded text-amber-400 hover:text-amber-300 transition-all"
                title="Create a new clean message context segment"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-2 space-y-1 no-scrollbar">
              {sessions.length === 0 ? (
                <div className="text-[10px] text-zinc-650 text-center py-6 px-4 italic leading-relaxed">
                  No permanently logged chats found. Messages will self-persist here automatically.
                </div>
              ) : (
                sessions.map((s) => {
                  const isActive = s.id === sessionId;
                  const isEditing = s.id === editingSessionId;

                  return (
                    <div 
                      key={s.id}
                      className={`group relative p-2 rounded flex flex-col gap-1 transition-all text-left text-[11px] cursor-pointer ${
                        isActive 
                          ? 'bg-amber-500/10 border border-amber-500/30' 
                          : 'hover:bg-white/5 border border-transparent'
                      }`}
                      onClick={() => !isEditing && handleSessionChange(s.id, s.file_id)}
                    >
                      <div className="flex items-center gap-2 justify-between w-full">
                        <div className="flex items-center gap-1.5 flex-1 min-w-0">
                          <MessageSquare className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-amber-400' : 'text-zinc-600'}`} />
                          
                          {isEditing ? (
                            <input 
                              type="text"
                              value={editingSessionTitle}
                              onChange={(e) => setEditingSessionTitle(e.target.value)}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') handleRenameSession(s.id, editingSessionTitle);
                                if (e.key === 'Escape') setEditingSessionId(null);
                              }}
                              className="bg-black text-amber-400 border border-amber-500/45 rounded px-1 text-[10px] w-full focus:outline-none"
                              autoFocus
                              onClick={(e) => e.stopPropagation()}
                            />
                          ) : (
                            <span className={`truncate font-semibold tracking-tight ${isActive ? 'text-amber-400' : 'text-zinc-350'}`}>
                              {s.title}
                            </span>
                          )}
                        </div>

                        {/* Actions */}
                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity shrink-0">
                          {isEditing ? (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleRenameSession(s.id, editingSessionTitle);
                              }}
                              className="p-0.5 text-emerald-400 hover:text-emerald-300"
                            >
                              <Save className="w-3.5 h-3.5" />
                            </button>
                          ) : (
                            <>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setEditingSessionId(s.id);
                                  setEditingSessionTitle(s.title);
                                }}
                                className="p-0.5 text-zinc-500 hover:text-amber-400 transition-colors"
                                title="Rename Chat"
                              >
                                <Edit className="w-3 h-3" />
                              </button>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDeleteSession(s.id);
                                }}
                                className="p-0.5 text-zinc-500 hover:text-red-400 transition-colors"
                                title="Delete Permanently"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            </>
                          )}
                        </div>
                      </div>
                      
                      <div className="flex justify-between items-center text-[8px] text-zinc-600">
                        <span className="font-mono">ID: {s.id.substring(0, 10)}</span>
                        <span>{new Date(s.created_at).toLocaleDateString()}</span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}

      {/* File & Workspace Pane */}
      <div className="flex-1 flex flex-col border-r border-white/10 h-full overflow-hidden relative">
        {/* Top workspace toolbar */}
        <div className="px-4 py-3 bg-[#0a0a0a] border-b border-white/10 flex items-center justify-between z-10">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setIsWorkspaceOpen(!isWorkspaceOpen)}
              className="p-1 hover:bg-white/5 rounded text-gray-400 transition-colors"
            >
              <FileCode className="w-5 h-5 text-amber-500" />
            </button>
            {file ? (
              <div>
                <div className="font-bold text-xs text-white max-w-[180px] sm:max-w-xs truncate">{file.filename}</div>
                <div className="text-[9px] text-gray-500">VERSION {file.version_number} • {file.token_count || 0} TOKENS</div>
              </div>
            ) : (
              <span className="text-gray-400 text-xs">No Workspace File Uploaded</span>
            )}
          </div>

          {file && (
            <div className="flex items-center gap-2">
              <button 
                onClick={() => setIsQueueMode(!isQueueMode)}
                className={`text-xs px-2.5 py-1 rounded transition-colors font-bold ${isQueueMode ? 'bg-amber-500 text-black' : 'bg-zinc-900 border border-white/10 text-gray-400 hover:border-white/30'}`}
              >
                PROMPT QUEUE ENGINE
              </button>

              <button 
                onClick={() => setShowHistory(!showHistory)}
                className="bg-zinc-900 border border-white/10 hover:border-white/30 text-xs px-2.5 py-1 rounded transition-colors text-gray-400"
              >
                Version History
              </button>

              <button 
                onClick={downloadFile}
                className="p-1 px-2.5 text-xs text-amber-500 bg-amber-500/10 hover:bg-amber-500/25 rounded flex items-center gap-1.5 transition-all"
                title="Download HTML Output"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export</span>
              </button>

              <div className="flex border border-white/10 rounded overflow-hidden">
                <button 
                  onClick={() => setActivePreview('preview')}
                  className={`px-2.5 py-1 text-[10px] uppercase font-bold transition-all ${activePreview === 'preview' ? 'bg-amber-500 text-black' : 'bg-transparent text-gray-400'}`}
                >
                  <Eye className="w-3.5 h-3.5" />
                </button>
                <button 
                  onClick={() => setActivePreview('code')}
                  className={`px-2.5 py-1 text-[10px] uppercase font-bold transition-all ${activePreview === 'code' ? 'bg-amber-500 text-black' : 'bg-transparent text-gray-400'}`}
                >
                  Code
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Workspace Display Slot */}
        <div className="flex-1 bg-[#111] relative overflow-hidden flex flex-col">
          {!file ? (
            <div 
              onDragOver={onDragOver}
              onDragLeave={onDragLeave}
              onDrop={onDrop}
              className={`flex-1 flex flex-col items-center justify-center border-2 border-dashed mx-6 my-6 rounded-xl transition-all ${
                isDragging ? 'border-amber-500 bg-amber-500/5' : 'border-white/10 bg-black/40'
              }`}
            >
              <Upload className="w-12 h-12 text-gray-600 mb-4 animate-bounce" />
              <h3 className="font-bold text-sm text-gray-300 mb-1">Drag and drop your bannon.html game file</h3>
              <p className="text-[10px] text-gray-500 mb-4 max-w-xs text-center leading-relaxed">
                Unlock instant physical rendering, progressive code chunking, and unlimited AI iterations.
              </p>
              <button 
                onClick={triggerFileInput}
                className="bg-amber-600 hover:bg-amber-500 text-black px-4 py-2 rounded text-xs font-bold transition-all"
              >
                Select File Manually
              </button>
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={onFileChange} 
                className="hidden" 
                accept=".html,.js,.jsx,.ts,.tsx"
              />
            </div>
          ) : (
            <div className="w-full h-full flex flex-col dynamic-window flex-1 relative overflow-hidden">
              {/* Version history overlay */}
              <AnimatePresence>
                {showHistory && (
                  <motion.div 
                    initial={{ opacity: 0, x: -100 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -100 }}
                    className="absolute inset-y-0 left-0 w-80 bg-black/95 border-r border-white/10 z-20 p-4 flex flex-col"
                  >
                    <div className="flex items-center justify-between mb-4 border-b border-white/10 pb-2">
                       <h3 className="text-xs font-bold text-amber-500 uppercase tracking-widest">Version Archives</h3>
                       <button onClick={() => setShowHistory(false)}><X className="w-4 h-4 text-gray-400 hover:text-white" /></button>
                    </div>

                    {/* Segmented Tab Control */}
                    <div className="grid grid-cols-2 bg-white/5 p-1 rounded-md mb-4 text-[10px]">
                      <button
                        onClick={() => setHistoryTab('versions')}
                        className={`py-1 rounded font-bold uppercase transition-all ${historyTab === 'versions' ? 'bg-amber-500 text-black' : 'text-gray-400 hover:text-white'}`}
                      >
                        Code Versions
                      </button>
                      <button
                        onClick={() => setHistoryTab('builds')}
                        className={`py-1 rounded font-bold uppercase transition-all ${historyTab === 'builds' ? 'bg-amber-500 text-black' : 'text-gray-400 hover:text-white'}`}
                      >
                        Commit Logs
                      </button>
                    </div>

                    <div className="flex-1 overflow-y-auto space-y-2 no-scrollbar">
                       {historyTab === 'versions' ? (
                         versionHistory.map((ver, idx) => (
                           <div key={idx} className="p-3 bg-white/5 hover:bg-white/10 rounded-lg border border-white/5 flex flex-col gap-1 text-[11px]">
                             <div className="flex items-center justify-between">
                               <span className="font-bold text-amber-400">v{ver.version_number}</span>
                               <span className="text-[9px] text-gray-500">{new Date(ver.timestamp).toLocaleTimeString()}</span>
                             </div>
                             <p className="text-gray-300 italic">"{ver.change_summary || 'Auto transformation'}"</p>
                             <button 
                               onClick={() => handleRollback(ver.version_number)}
                               className="mt-2 text-[9px] bg-amber-500/20 hover:bg-amber-500 text-amber-400 hover:text-black py-1 px-2 rounded font-bold transition-all flex items-center justify-center gap-1"
                             >
                               <RotateCcw className="w-3 h-3" />
                               Restore Version
                             </button>
                           </div>
                         ))
                       ) : (
                         buildHistory.length === 0 ? (
                           <p className="text-[10px] text-zinc-500 text-center py-6">No build deployments committed yet.</p>
                         ) : (
                           buildHistory.map((run, idx) => (
                             <div key={idx} className="p-3 bg-white/5 rounded-lg border border-white/5 flex flex-col gap-1.5 text-[10.5px]">
                               <div className="flex items-center justify-between">
                                 <span className={`text-[9px] px-1.5 py-0.5 rounded font-bold ${
                                   run.deploy_status === 'COMPLETED' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                                 }`}>
                                   {run.deploy_status}
                                 </span>
                                 <span className="text-[9px] text-gray-450">{new Date(run.timestamp).toLocaleTimeString()}</span>
                               </div>
                               <div className="font-mono text-[9.5px] text-amber-400 font-bold bg-white/5 p-1 rounded break-all">
                                 SHA: {run.commit_hash?.substring(0, 8)}...
                               </div>
                               <div className="text-gray-355 font-semibold truncate">File: {run.files_changed}</div>
                               <p className="text-gray-455 italic text-[10px] leading-relaxed">Prompt: "{run.chat_message}"</p>
                             </div>
                           ))
                         )
                       )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {activePreview === 'preview' && isHtml ? (
                <iframe 
                  srcDoc={file.content}
                  className="w-full h-full bg-white flex-1"
                  title="Canvas Sandbox Rendering"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <pre className="w-full h-full overflow-auto p-4 text-[11px] text-gray-300 bg-black/50 select-text flex-1 whitespace-pre">
                  <code>{file.content}</code>
                </pre>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Persistent Build Controller Panel */}
      <div className="lg:w-96 flex flex-col bg-[#050505] h-full overflow-hidden">
        
        {/* Token Status bar */}
        {file && (
          <div className="px-4 py-2 border-b border-white/5 bg-[#0a0a0a] text-[10px]">
            <div className="flex items-center justify-between text-gray-400 mb-1">
              <span>CONTEXT COMPRESSION ENVELOPE</span>
              <span className={tokenPercent > 80 ? 'text-red-400 font-bold' : 'text-gray-400'}>
                 {tokenPercent}% USED ({currentTokens} / {maxTokens})
              </span>
            </div>
            <div className="w-full bg-zinc-900 rounded-full h-1 overflow-hidden">
              <div 
                className={`h-full transition-all duration-300 ${tokenPercent > 80 ? 'bg-red-500' : tokenPercent > 60 ? 'bg-amber-500' : 'bg-emerald-500'}`}
                style={{ width: `${tokenPercent}%` }}
              />
            </div>
            {tokenPercent > 60 && (
              <div className="text-[9px] text-amber-400 bg-amber-500/5 border border-amber-500/10 p-1 px-2 rounded mt-1.5 flex items-center gap-1">
                <AlertTriangle className="w-3 h-3 text-amber-500 shrink-0" />
                <span>History condensing triggers under active compression to safe-keep space.</span>
              </div>
            )}
          </div>
        )}

        {/* Model Route Controls */}
        <div className="px-4 py-3 border-b border-white/5 bg-[#0a0a0a] flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-gray-400 uppercase font-semibold">Active Compute Route</span>
            <div className="flex border border-white/10 rounded overflow-hidden">
               <button 
                 onClick={() => setModelPreference('standard')}
                 className={`px-2 py-0.5 text-[9px] font-bold ${modelPreference === 'standard' ? 'bg-amber-500 text-black' : 'text-gray-400 hover:text-white'}`}
               >
                 Standard
               </button>
               <button 
                 onClick={() => setModelPreference('creative')}
                 className={`px-2 py-0.5 text-[9px] font-bold ${modelPreference === 'creative' ? 'bg-amber-500 text-black' : 'text-gray-400 hover:text-white'}`}
               >
                 Creative
               </button>
            </div>
          </div>

          <div className="grid grid-cols-5 gap-1">
             {providers.map((p, i) => (
                <div key={i} className="text-[8px] p-1 rounded bg-white/5 border border-white/5 flex flex-col items-center gap-0.5 justify-center">
                   <span className="text-gray-400 text-[7px] truncate w-full text-center">{p.name.replace('Local ', 'L_')}</span>
                   <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                </div>
             ))}
          </div>

          {/* Let Nexus Drive Toggle & Trust Toggle */}
          <div className="flex flex-col gap-2 mt-1 border-t border-white/5 pt-2">
            <div className="flex items-center justify-between">
               <label className="text-[10px] text-gray-400 flex items-center gap-1.5 cursor-pointer">
                  <input 
                    type="checkbox" 
                    checked={autonomousMode} 
                    onChange={async (e) => {
                      setAutonomousMode(e.target.checked);
                      if (file) {
                        await fetch('/api/armada/quantum/config', {
                          method: 'POST',
                          headers: { 'Content-Type': 'application/json' },
                          body: JSON.stringify({ sessionId, fileId: file.id, autonomous: e.target.checked, trust: trustMind })
                        });
                      }
                    }} 
                    className="accent-amber-500 rounded" 
                  />
                  <span>Let Nexus Drive</span>
               </label>

               {autonomousMode && (
                 <label className="text-[10px] text-gray-400 flex items-center gap-1.5 cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={trustMind} 
                      onChange={async (e) => {
                        setTrustMind(e.target.checked);
                        if (file) {
                          await fetch('/api/armada/quantum/config', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ sessionId, fileId: file.id, autonomous: autonomousMode, trust: e.target.checked })
                          });
                        }
                      }}
                      className="accent-amber-500 rounded" 
                    />
                    <span className="text-amber-500 font-bold">Trust Mind (Un-gated)</span>
                 </label>
               )}
            </div>

            <div className="flex items-center justify-between mt-1 border-t border-white/5 pt-1.5 pb-1">
               <label className="text-[10px] text-gray-400 flex items-center gap-1.5 cursor-pointer">
                  <input 
                    type="checkbox" 
                    checked={useRazor} 
                    onChange={(e) => setUseRazor(e.target.checked)} 
                    className="accent-amber-500 rounded" 
                  />
                  <span>Context Slicing (Razor Engine)</span>
               </label>
            </div>
            {file && (
              <button
                onClick={downloadFile}
                className="w-full mt-2 py-2 px-3 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-black rounded text-[10px] font-bold tracking-widest uppercase transition-all flex items-center justify-center gap-1.5 shadow-md shadow-amber-500/10 active:scale-[0.98]"
                title="Force raw download of the latest game build state from quantum vault"
              >
                <Download className="w-3.5 h-3.5 shrink-0" />
                <span>Download Latest Artifact</span>
              </button>
            )}
          </div>
        </div>

        {/* ==================== APPLET INTEGRITY COMPILER & LINTER ==================== */}
        {file && (
          <div className="px-4 py-3 border-b border-white/5 bg-black/40 flex flex-col gap-2.5">
            <div className="flex items-center justify-between cursor-pointer" onClick={() => setShowLinterPanel(!showLinterPanel)}>
              <div className="flex items-center gap-2">
                <div className={`w-2 h-2 rounded-full ${isLinting ? 'bg-amber-500 animate-ping' : linterScore !== null && linterScore >= 90 ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                <span className="text-[10px] text-gray-400 uppercase font-bold tracking-wider">Applet Linter Diagnostics</span>
              </div>
              {linterScore !== null && (
                <div className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${linterScore >= 90 ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'}`}>
                  {linterScore}% COMPLIANT
                </div>
              )}
            </div>

            {showLinterPanel && (
              <div className="space-y-2">
                {/* Compiler Step Log Deck */}
                <div className="bg-black/90 rounded border border-white/5 p-2 font-mono text-[9px] leading-relaxed max-h-32 overflow-y-auto space-y-1 select-text">
                  {linterLogs.length === 0 ? (
                    <span className="text-gray-600 italic">[LINTER] Diagnostics standby. Ready to audit sandbox structure.</span>
                  ) : (
                    linterLogs.map((log, idx) => (
                      <div key={idx} className={log.includes('WARNING') || log.includes('Potential') ? 'text-amber-400 font-bold' : log.includes('complete') || log.includes('complete') ? 'text-emerald-400 font-bold' : 'text-gray-400'}>
                        {log}
                      </div>
                    ))
                  )}
                  {isLinting && (
                    <div className="flex items-center gap-1.5 text-amber-500 font-bold animate-pulse">
                      <span>⚡ Compiling & Analysing AST nodes...</span>
                    </div>
                  )}
                </div>

                {/* Show warnings if they exist */}
                {linterWarnings.length > 0 && (
                  <div className="bg-amber-500/10 border border-amber-500/20 rounded p-2 text-[9px] text-amber-400 space-y-1">
                    <div className="font-bold uppercase tracking-wider flex items-center gap-1 mb-1">
                      <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                      <span>Surgical Warnings Detected</span>
                    </div>
                    {linterWarnings.map((warn, idx) => (
                      <p key={idx} className="leading-normal">• {warn}</p>
                    ))}
                  </div>
                )}

                {/* Run Linter button */}
                <button
                  type="button"
                  onClick={runLinterDiagnostics}
                  disabled={isLinting}
                  className="w-full py-1.5 px-2.5 bg-zinc-900 hover:bg-zinc-800 border border-white/10 active:border-white/30 text-gray-300 rounded text-[9.5px] font-bold tracking-widest uppercase transition-all flex items-center justify-center gap-1.5"
                >
                  <Activity className={`w-3.5 h-3.5 text-amber-500 ${isLinting ? 'animate-spin' : ''}`} />
                  <span>{isLinting ? 'Auditing Codebase...' : 'Execute AST Compiler check'}</span>
                </button>
              </div>
            )}
          </div>
        )}
        {/* ========================================================================= */}

        {/* Pending approvals notifications */}
        {pendingDirectives.length > 0 && (
          <div className="p-3 bg-amber-500/10 border-b border-amber-500/20 text-[10px] space-y-2">
             <div className="flex items-center gap-2 text-amber-400 font-bold">
                <ShieldAlert className="w-4 h-4 animate-pulse text-amber-500" />
                <span>PENDING NEXUS AUTONOMOUS PROPOSAL</span>
             </div>
             {pendingDirectives.map((dir, i) => (
                <div key={i} className="bg-black/40 border border-white/5 p-2 rounded relative">
                   <p className="text-gray-300 italic mb-2">"Mind wants to: {dir.intent}"</p>
                   <div className="flex items-center justify-between">
                      <span className="text-gray-500">Auto-Approve in: {countdown[dir.id] ?? 30}s</span>
                      <div className="flex items-center gap-1">
                         <button 
                           onClick={() => handleResolveDirective(dir.id, false)}
                           className="bg-red-500/20 hover:bg-red-500 text-red-400 hover:text-white border border-red-500/30 p-1 px-2.5 rounded text-[9px] font-bold transition-all"
                         >
                           Block
                         </button>
                         <button 
                           onClick={() => handleResolveDirective(dir.id, true)}
                           className="bg-emerald-500/20 hover:bg-emerald-500 text-emerald-400 hover:text-white border border-emerald-500/30 p-1 px-2.5 rounded text-[9px] font-bold transition-all"
                         >
                           Approve
                         </button>
                      </div>
                   </div>
                </div>
             ))}
          </div>
        )}

        {isQueueMode ? (
          <div className="flex-1 overflow-y-auto no-scrollbar relative w-full h-full flex flex-col bg-black">
            <PromptQueuePanel />
          </div>
        ) : (
          <>
            {/* Chat Feed */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
               {messages.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center text-gray-600 px-6">
                     <Cpu className="w-8 h-8 text-white/5 mb-3" />
                     <p className="text-xs">No active conversation.</p>
                     <p className="text-[10px] text-gray-500 mt-1 leading-relaxed">
                        Upload an HTML/JS template, and chat here to apply robust surgical modifications with precise diff patches.
                     </p>
                  </div>
               ) : (
                  messages.map((m, idx) => (
                    <div 
                      key={idx} 
                      className={`flex flex-col max-w-[90%] gap-1.5 p-3 rounded-lg border text-[11px] leading-relaxed ${
                        m.role === 'user' 
                        ? 'self-end ml-auto bg-amber-500/5 border-amber-500/20 text-amber-400' 
                        : 'self-start mr-auto bg-white/5 border-white/10 text-gray-100'
                      }`}
                    >
                      <div className="text-[8px] text-gray-500 uppercase tracking-wider font-bold">
                        {m.role === 'user' ? 'USER DIRECTIVE' : 'NEXUS INTELLECT'}
                      </div>
                      <div>
                        {m.content}
                      </div>
                    </div>
                  ))
               )}
               {isSending && (
                  <div className="bg-white/5 border border-white/10 p-3 rounded-lg self-start mr-auto max-w-[60%] flex items-center gap-3 text-[11px] text-gray-400">
                     <div className="w-2.5 h-2.5 bg-amber-500 rounded-full animate-ping" />
                     <span>Thinking & applying diff code modifications...</span>
                  </div>
               )}
               <div ref={chatEndRef} />
            </div>

            {/* Autonomous Job Status View */}
            {activeJobId && (
              <div className="mx-3 mt-0 mb-3 p-3 border border-amber-500/20 bg-amber-500/5 rounded-lg flex flex-col gap-2 relative">
                 <div className="flex justify-between items-center text-[10px] font-bold tracking-widest uppercase text-amber-500">
                    <span className="flex items-center gap-2">
                       {['PENDING', 'QUEUED', 'RUNNING'].includes(activeJobStatus) && (
                          <div className="w-1.5 h-1.5 bg-amber-500 rounded-full animate-ping" />
                       )}
                       ⚙ AUTONOMOUS ORCHESTRATOR ({activeJobStatus})
                    </span>
                    {['PENDING', 'QUEUED', 'RUNNING'].includes(activeJobStatus) && (
                       <button 
                         onClick={async () => {
                           await fetch(`/api/armada/quantum/autonomous/cancel/${activeJobId}`, { method: 'POST' });
                           setActiveJobStatus('CANCELLING...');
                         }}
                         className="px-2 py-0.5 border border-red-500/50 text-red-500 hover:bg-red-500/10 rounded transition"
                       >
                          CANCEL
                       </button>
                    )}
                 </div>
                 <div className="text-[10px] font-mono text-gray-300 w-full overflow-hidden text-ellipsis whitespace-pre-wrap max-h-[80px] overflow-y-auto no-scrollbar">
                    {activeJobLogs || 'Awaiting agent telemetry stream...'}
                 </div>
              </div>
            )}

            {/* Input Interface */}
            <div className="p-3 bg-[#0a0a0a] border-t border-white/10 flex items-center gap-2">
               <input 
                 type="text" 
                 className="flex-1 bg-black/60 border border-white/10 rounded px-3 py-2 text-[11px] text-gray-200 placeholder-gray-600 focus:outline-none focus:border-amber-500"
                 placeholder={file ? "Request surgical improvements..." : "Upload files first to initiate session"}
                 value={inputMessage}
                 onChange={(e) => setInputMessage(e.target.value)}
                 disabled={!file || isSending}
                 onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
               />
               <button 
                 onClick={handleSendMessage}
                 disabled={!file || isSending || !inputMessage.trim()}
                 className="p-2 text-amber-500 bg-amber-500/10 border border-amber-500/20 hover:bg-amber-500 hover:text-black rounded transition-all disabled:opacity-40 shrink-0"
               >
                 <Send className="w-4 h-4" />
               </button>
               <button 
                 onClick={() => setShowTerminal(!showTerminal)}
                 className={`p-2 rounded border transition-colors shrink-0 flex items-center justify-center ${showTerminal ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400' : 'bg-zinc-900 border-white/10 text-gray-500 hover:text-gray-300'}`}
                 title="Toggle Bare Metal Actuator"
               >
                 <Terminal className="w-4 h-4" />
               </button>
            </div>
          </>
        )}

        {showTerminal && (
          <TerminalConsole 
            isExpanded={terminalExpanded} 
            onToggleExpand={() => setTerminalExpanded(!terminalExpanded)} 
            onClose={() => setShowTerminal(false)} 
          />
        )}
      </div>
    </div>
  );
}
