import React, { useState, useEffect } from 'react';
import { Bot, Play, CheckCircle, XCircle, Clock } from 'lucide-react';

export default function TaskQueuePanel() {
  const [tasks, setTasks] = useState<any[]>([]);

  const loadTasks = async () => {
    try {
      const res = await fetch('/api/armada/quantum/tasks');
      const data = await res.json();
      if (data.success) {
        setTasks(data.tasks);
      }
    } catch (e: any) {
      console.error(e);
    }
  };

  useEffect(() => {
    loadTasks();
    const int = setInterval(loadTasks, 5000);
    return () => clearInterval(int);
  }, []);

  return (
    <div className="flex flex-col h-full bg-[#0a0a0a] text-gray-200 font-mono p-6">
      <div className="flex items-center gap-3 mb-6 border-b border-[#222] pb-4">
        <Bot className="text-blue-400 w-6 h-6" />
        <h2 className="text-xl font-bold tracking-widest uppercase">Autonomous Task Queue</h2>
      </div>

      <div className="flex-1 overflow-y-auto pr-2 flex flex-col gap-3">
        {tasks.length === 0 && (
          <div className="text-gray-600 text-xs tracking-widest text-center mt-10">QUEUE IS EMPTY</div>
        )}
        {tasks.map(task => (
          <div key={task.id} className={`flex flex-col border p-4 rounded ${task.status === 'RUNNING' || task.status === 'ACQUIRED' ? 'bg-[#0a1520] border-blue-900/50' : 'bg-[#111] border-[#222]'}`}>
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                {task.status === 'COMPLETED' ? <CheckCircle className="text-emerald-500 w-4 h-4" /> : 
                 task.status === 'FAILED' ? <XCircle className="text-red-500 w-4 h-4" /> : 
                 task.status === 'PENDING' ? <Clock className="text-gray-500 w-4 h-4" /> : 
                 <Play className="text-blue-500 w-4 h-4 animate-pulse" />}
                <h3 className="font-bold text-sm text-gray-300">{task.id.split('-')[0]}</h3>
                <span className={`text-[10px] px-2 py-0.5 rounded tracking-widest ${
                  task.status === 'COMPLETED' ? 'bg-emerald-900/50 text-emerald-400' :
                  task.status === 'FAILED' ? 'bg-red-900/50 text-red-400' :
                  'bg-blue-900/50 text-blue-400'
                }`}>{task.status}</span>
              </div>
              <span className="text-xs text-gray-600">{new Date(task.created_at).toLocaleString()}</span>
            </div>
            <div className="mt-2 text-xs text-gray-400 bg-black/40 p-2 rounded">
              {task.prompt.substring(0, 160)}{task.prompt.length > 160 ? '...' : ''}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
