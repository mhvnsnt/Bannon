import React, { useState, useEffect } from 'react';
import { Server, Play, Square, Activity, ExternalLink } from 'lucide-react';

export default function GPURentalPanel() {
  const [instances, setInstances] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const loadInstances = async () => {
    try {
      const res = await fetch('/api/quantum/gpus');
      const data = await res.json();
      if (data.success) {
        setInstances(data.gpus);
      }
    } catch (e: any) {
      console.error(e);
    }
  };

  useEffect(() => {
    loadInstances();
  }, []);

  const handleToggle = async (id: string, currentStatus: string) => {
    setLoading(true);
    try {
      const newStatus = currentStatus === 'OFFLINE' ? 'RUNNING' : 'OFFLINE';
      await fetch('/api/quantum/gpus/toggle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, status: newStatus })
      });
      await loadInstances();
    } catch (e: any) {
      console.error(e);
    }
    setLoading(false);
  };

  return (
    <div className="flex flex-col h-full bg-[#0a0a0a] text-gray-200 font-mono p-6">
      <div className="flex items-center gap-3 mb-6 border-b border-[#222] pb-4">
        <Server className="text-purple-400 w-6 h-6" />
        <h2 className="text-xl font-bold tracking-widest uppercase">GPU Rental Management</h2>
      </div>

      <div className="text-xs text-gray-400 mb-6 max-w-2xl">
        Manage ephemeral GPU instances for deep reasoning, no-filter local model execution, and massive parallel testing. Auto-connects Ollama/OpenRouter APIs linearly into the God Mode Smart Router when active. Pay only while active.
      </div>

      <div className="flex flex-col gap-4">
        {instances.map(inst => (
          <div key={inst.id} className={`flex items-center justify-between border border-[#222] p-4 rounded bg-[#111] transition-colors ${inst.status === 'RUNNING' ? 'border-purple-500/50' : ''}`}>
            <div className="flex items-center gap-4">
              <div className={`w-3 h-3 rounded-full ${inst.status === 'RUNNING' ? 'bg-purple-500 shadow-[0_0_10px_rgba(168,85,247,0.8)]' : 'bg-gray-600'}`}></div>
              <div className="flex flex-col">
                <div className="font-bold text-gray-200">{inst.provider} - {inst.gpu}</div>
                <div className="text-xs text-gray-500 flex gap-4 mt-1">
                  <span>{inst.cost_per_hr}</span>
                  {inst.status === 'RUNNING' && <span className="text-purple-400 flex items-center gap-1"><ExternalLink className="w-3 h-3" /> {inst.ip_address} (God Mode Connected)</span>}
                </div>
              </div>
            </div>

            <button 
              onClick={() => handleToggle(inst.id, inst.status)}
              disabled={loading}
              className={`px-6 py-2 rounded text-xs font-bold uppercase tracking-widest border transition-colors flex items-center gap-2 ${
                inst.status === 'OFFLINE' 
                ? 'bg-purple-900/40 hover:bg-purple-800 text-purple-300 border-purple-500/50' 
                : 'bg-red-900/40 hover:bg-red-800 text-red-300 border-red-500/50'
              } disabled:opacity-50`}
            >
              {inst.status === 'OFFLINE' ? <><Play className="w-4 h-4" /> Spin Up</> : <><Square className="w-4 h-4" /> Terminate</>}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
