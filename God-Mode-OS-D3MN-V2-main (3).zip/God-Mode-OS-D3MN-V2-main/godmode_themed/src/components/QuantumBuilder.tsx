import React, { useState, useEffect } from 'react';
import { Code2, Play, Activity, Folder, Database, Network, Server, FileText, CheckCircle, Clock } from 'lucide-react';

export default function QuantumBuilder() {
  const [prompt, setPrompt] = useState('');
  const [files, setFiles] = useState<string[]>([]);
  const [selectedFiles, setSelectedFiles] = useState<Set<string>>(new Set());
  const [jobs, setJobs] = useState<any[]>([]);
  const [isBuilding, setIsBuilding] = useState(false);

  useEffect(() => {
    fetch('/api/files')
       .then(r => r.json())
       .then(data => {
           if(Array.isArray(data)) setFiles(data);
       })
       .catch(err => console.error('Failed to load files:', err));
    
    fetchJobs();
    const interval = setInterval(fetchJobs, 3000);
    return () => clearInterval(interval);
  }, []);

  const fetchJobs = () => {
    fetch('/api/jobs')
       .then(r => r.json())
       .then(data => {
           if(Array.isArray(data)) setJobs(data);
       })
       .catch(err => console.error('Failed to load jobs:', err));
  };

  const handleToggleFile = (file: string) => {
      const newSet = new Set(selectedFiles);
      if (newSet.has(file)) newSet.delete(file);
      else newSet.add(file);
      setSelectedFiles(newSet);
  };

  const handleBuild = async () => {
      if (!prompt.trim()) return;
      setIsBuilding(true);
      
      try {
          await fetch('/api/ai/build', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ 
                  prompt, 
                  contextFiles: Array.from(selectedFiles) 
              })
          });
          setPrompt('');
          setSelectedFiles(new Set());
          fetchJobs();
      } catch(e) {
          console.error(e);
      } finally {
          setIsBuilding(false);
      }
  };

  return (
    <div className="flex flex-col w-full h-full bg-[#0a0512] text-fuchsia-100 font-mono relative">
       <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-fuchsia-900/10 via-transparent to-transparent pointer-events-none" />
       
       <div className="p-5 border-b border-fuchsia-900/40 bg-[#0f0a1c]/80 flex items-center justify-between z-10 backdrop-blur-sm">
           <div className="flex items-center gap-4">
             <Code2 className="text-fuchsia-400 w-5 h-5" />
             <h2 className="tracking-[0.2em] font-bold text-sm uppercase">Quantum Builder</h2>
           </div>
           <div className="flex items-center gap-4 text-xs font-bold tracking-widest uppercase">
               <span className="flex items-center gap-2 text-emerald-400"><Server className="w-3.5 h-3.5" /> Node Cluster Active</span>
               <span className="flex items-center gap-2 text-cyan-400"><Network className="w-3.5 h-3.5" /> Multi-LLM Router</span>
           </div>
       </div>
       
       <div className="flex flex-col md:flex-row flex-1 overflow-hidden z-10">
           {/* Left Column: Build Configuration */}
           <div className="flex-[2] flex flex-col border-r border-fuchsia-900/30 p-6 overflow-y-auto custom-scrollbar">
               <h3 className="text-xs uppercase tracking-widest text-[#cbd5e1] mb-4 flex items-center gap-2 font-bold">
                  <Play className="w-4 h-4 text-fuchsia-500" /> Structural Objective
               </h3>
               
               <textarea 
                   value={prompt}
                   onChange={e => setPrompt(e.target.value)}
                   placeholder="Enter high-altitude architectural schematic. The Reality Compiler will format it into localized 3D mechanics."
                   className="w-full bg-[#0b0314]/80 border border-fuchsia-900/50 rounded-lg p-4 text-sm focus:outline-none focus:border-fuchsia-400 focus:ring-1 focus:ring-fuchsia-400 transition-all font-mono min-h-[150px] mb-6 shadow-inner text-fuchsia-50"
               />

               <h3 className="text-xs uppercase tracking-widest text-[#cbd5e1] mb-4 flex items-center gap-2 font-bold">
                  <Folder className="w-4 h-4 text-fuchsia-500" /> Context Ingestion Nodes (Local Files)
               </h3>
               
               <div className="bg-[#11051c] border border-fuchsia-900/40 rounded-lg p-3 flex flex-col gap-1 max-h-[250px] overflow-y-auto mb-6 custom-scrollbar shadow-inner">
                   {files.map(file => (
                       <label key={file} className="flex items-center gap-3 py-1.5 px-2 hover:bg-fuchsia-900/20 rounded cursor-pointer transition-colors">
                           <input 
                              type="checkbox" 
                              checked={selectedFiles.has(file)}
                              onChange={() => handleToggleFile(file)}
                              className="accent-fuchsia-500 rounded-sm"
                           />
                           <FileText className="w-3.5 h-3.5 text-gray-500" />
                           <span className="text-xs truncate tracking-wider text-gray-300">{file}</span>
                       </label>
                   ))}
               </div>

               <button 
                  onClick={handleBuild}
                  disabled={isBuilding || !prompt.trim()}
                  className="bg-fuchsia-600 hover:bg-fuchsia-500 disabled:opacity-50 text-white p-4 rounded-lg shadow-[0_0_15px_rgba(217,70,239,0.3)] transition-all flex items-center justify-center gap-3 uppercase tracking-[0.2em] font-bold mt-auto"
               >
                   <Activity className="w-5 h-5" />
                   {isBuilding ? 'Initializing Node Swarm...' : 'Compile Structure'}
               </button>
           </div>
           
           {/* Right Column: Execution Queue */}
           <div className="flex-1 flex flex-col p-6 bg-[#0c0617] overflow-y-auto custom-scrollbar">
               <h3 className="text-xs uppercase tracking-widest text-[#cbd5e1] mb-4 flex items-center gap-2 font-bold">
                  <Database className="w-4 h-4 text-cyan-500" /> Distributed Job Queue
               </h3>
               
               <div className="flex flex-col gap-4">
                   {jobs.length === 0 && (
                       <div className="text-center font-mono opacity-50 mt-10 text-xs tracking-wider">
                           No localized execution jobs active.
                       </div>
                   )}
                   {jobs.map(job => (
                       <div key={job.id} className="bg-[#150a24] border border-fuchsia-900/40 rounded-lg p-4 flex flex-col gap-2 shadow-lg relative overflow-hidden">
                           {(job.status === 'processing' || job.status === 'queued') && (
                               <div className="absolute top-0 left-0 h-0.5 bg-fuchsia-500 animate-pulse w-full" />
                           )}
                           <div className="flex items-center justify-between">
                               <span className="text-[10px] tracking-widest opacity-60 uppercase">JOB {job.id.substring(0, 8)}</span>
                               {job.status === 'completed' ? (
                                   <span className="text-[9px] text-emerald-400 bg-emerald-950/40 px-2 py-1 rounded border border-emerald-900/50 flex items-center gap-1 uppercase">
                                       <CheckCircle className="w-3 h-3" /> SUCCESS
                                   </span>
                               ) : job.status === 'error' ? (
                                   <span className="text-[9px] text-red-400 bg-red-950/40 px-2 py-1 rounded border border-red-900/50 uppercase">
                                       FAILED
                                   </span>
                               ) : (
                                   <span className="text-[9px] text-cyan-400 bg-cyan-950/40 px-2 py-1 rounded border border-cyan-900/50 flex items-center gap-1 animate-pulse uppercase">
                                       <Clock className="w-3 h-3" /> {job.status}
                                   </span>
                               )}
                           </div>
                           <p className="text-xs text-gray-300 line-clamp-2 mt-1 hidden sm:block">{job.prompt}</p>
                           {job.details && <div className="text-[10px] text-fuchsia-400/80 mt-1 uppercase tracking-widest">{job.details}</div>}
                           {job.result && job.status === 'completed' && (
                               <div className="mt-2 text-[10px] font-mono text-gray-400 whitespace-pre-wrap max-h-[100px] overflow-y-auto bg-black/40 p-2 rounded shadow-inner">
                                   Operations executed locally by orchestrator swarm.
                               </div>
                           )}
                           {job.result && job.status === 'error' && (
                               <div className="mt-2 text-[10px] font-mono text-red-400/80 p-2 bg-red-950/20 rounded">
                                   {job.result}
                               </div>
                           )}
                       </div>
                   ))}
               </div>
           </div>
       </div>
    </div>
  );
}
