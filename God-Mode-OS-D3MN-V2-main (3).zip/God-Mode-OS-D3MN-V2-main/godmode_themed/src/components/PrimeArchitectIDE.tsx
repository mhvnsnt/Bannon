import React, { useState, useEffect, useRef } from 'react';
import { Terminal, Code, Cpu, Network, Zap, Play, Box, Database, HardDrive, Shield, Activity, GitMerge, FileCode, Layers } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { EngineAnalyzer } from './EngineAnalyzer';
import { WorkspaceExplorer } from './WorkspaceExplorer';
import CodeSurgeonPanel from './CodeSurgeonPanel';
import SessionBridgePanel from './SessionBridgePanel';

export function PrimeArchitectIDE() {
  const [activeTab, setActiveTab] = useState<'SOURCE' | 'PHYSICS_OS' | 'SWARM_LOG' | 'ENGINE_ANALYZER' | 'EDITOR' | 'BRIDGE'>('SOURCE');
  const [compilerStatus, setCompilerStatus] = useState<'IDLE' | 'COMPILING' | 'SYNCED'>('IDLE');
  const [activeFile, setActiveFile] = useState<{ path: string; content: string } | null>(null);
  const [terminalLogs, setTerminalLogs] = useState<string[]>([
    "[SYSTEM] NexusMind Core loaded.",
    "[SYSTEM] Absolute Autonomy Grid initialized.",
    "[NETWORK] Localhost:9999 Bare Metal connection secured."
  ]);
  const [astNodes, setAstNodes] = useState(14092);
  const bottomRef = useRef<HTMLDivElement>(null);

  const writeLog = (msg: string) => {
    setTerminalLogs(prev => [...prev, msg].slice(-50));
  };

  useEffect(() => {
    if (bottomRef.current) {
      bottomRef.current.scrollTop = bottomRef.current.scrollHeight;
    }
  }, [terminalLogs]);
  
  useEffect(() => {
     const swarmBg = setInterval(() => {
        if (Math.random() > 0.8) {
           setAstNodes(prev => prev + Math.floor(Math.random() * 10 - 2));
        }
     }, 800);
     return () => clearInterval(swarmBg);
  }, []);

  useEffect(() => {
    const handleOpenFile = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (customEvent.detail && customEvent.detail.path) {
        setActiveFile({ path: customEvent.detail.path, content: customEvent.detail.content || "" });
        setActiveTab('EDITOR');
      }
    };
    
    const handleIframeMessage = (e: MessageEvent) => {
        if (e.data && e.data.type === 'bannon-log') {
            console.log("[PREVIEW EVENT]", e.data.message);
            writeLog(`[PREVIEW] ${e.data.message}`);
            // Send to backend so the LLM has contextual 'sight'
            fetch('/api/armada/preview_telemetry', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ message: e.data.message })
            }).catch(() => {});
        }
    };
    
    window.addEventListener('open-workspace-file', handleOpenFile);
    window.addEventListener('message', handleIframeMessage);
    
    return () => {
        window.removeEventListener('open-workspace-file', handleOpenFile);
        window.removeEventListener('message', handleIframeMessage);
    };
  }, []);

  const executeBareMetal = () => {
    if (compilerStatus === 'COMPILING') return;
    setCompilerStatus('COMPILING');
    writeLog(`[INIT] Collapsing 5D high-altitude concept into 3D density...`);
    writeLog(`[AUTH] Enforcing Prime Architectural Command.`);
    
    setTimeout(() => {
       writeLog(`\`\`\`bash\ncurl -X POST http://localhost:9999/execute -d '{"command": "force_compile", "target": "reality_matrix", "density": "ultra"}'\n\`\`\``);
    }, 800);

    setTimeout(() => {
       writeLog(`[AGENTIC SWARM] Self-healing codebase deployed. Source logic rewritten continuously.`);
       writeLog(`[COMPILER] Zero friction detected. Structural container locked.`);
    }, 1800);

    setTimeout(() => {
       writeLog(`[SUCCESS] 3D Vector grid generated. Absolute command maintained.`);
       setCompilerStatus('SYNCED');
       setTimeout(() => setCompilerStatus('IDLE'), 3000);
    }, 3000);
  };

  return (
    <div className="w-full h-full bg-[#030305] text-cyan-500 font-mono flex flex-col overflow-hidden border-l border-cyan-900/30">
      {/* Top Header */}
      <div className="border-b border-cyan-900/50 bg-[#050508] p-2 flex justify-between items-center shrink-0 shadow-lg">
        <div className="flex items-center gap-3">
           <div className="w-3 h-3 bg-cyan-500 rounded-sm shadow-[0_0_10px_cyan] animate-pulse" />
           <h2 className="text-xs font-bold uppercase tracking-widest text-cyan-400 flex items-center gap-2">
             Prime Architect IDE <span className="text-cyan-800">|</span> Absolute Autonomy Grid
           </h2>
        </div>
        <div className="flex items-center gap-4 text-[10px] font-bold">
           <span className="flex items-center gap-1 text-emerald-400 border border-emerald-900/50 bg-emerald-950/30 px-2 py-1 rounded">
             <Activity className="w-3 h-3" /> LATENCY: 0.001ms
           </span>
           <span className="flex items-center gap-1 text-fuchsia-400 border border-fuchsia-900/50 bg-fuchsia-950/30 px-2 py-1 rounded">
             <Zap className="w-3 h-3" /> 1-BIT EFFICIENCY
           </span>
           <button 
             onClick={executeBareMetal}
             disabled={compilerStatus === 'COMPILING'}
             className="flex items-center gap-2 px-4 py-1 ml-2 bg-cyan-500/20 hover:bg-cyan-500/40 text-cyan-300 border border-cyan-500/50 transition-colors uppercase disabled:opacity-50"
           >
             <Play className="w-3 h-3" /> {compilerStatus === 'COMPILING' ? 'COLLAPSING REALITY...' : 'EXECUTE BARE METAL'}
           </button>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
         {/* Left Sidebar - File Tree & Swarms */}
         <div className="w-64 border-r border-cyan-900/30 bg-[#020203] flex flex-col shrink-0">
            <WorkspaceExplorer onFileSelect={(path, content) => {
               setActiveFile({ path, content });
               setActiveTab('EDITOR');
             }} />
         </div>

         {/* Main Editor / Sandbox Area */}
         <div className="flex-1 flex flex-col bg-[#050508] relative">
            <div className="flex border-b border-cyan-900/30 text-[10px] uppercase font-bold shrink-0 bg-[#030304]">
               {[
                 { id: 'SOURCE', icon: <FileCode className="w-3 h-3"/>, label: 'Raw Source Logic' },
                 { id: 'PHYSICS_OS', icon: <Layers className="w-3 h-3"/>, label: '3D Spatial Sandbox' },
                 { id: 'SWARM_LOG', icon: <Activity className="w-3 h-3"/>, label: 'Agent Reasoning Trace' },
                 { id: 'ENGINE_ANALYZER', icon: <Cpu className="w-3 h-3"/>, label: 'Engine Analyzer' },
                 { id: 'BRIDGE', icon: <Layers className="w-3 h-3 text-[#00e5ff]"/>, label: 'Session Bridge' },
                 { id: 'EDITOR', icon: <Code className="w-3 h-3"/>, label: 'File Editor' }
               ].map(t => (
                  <button 
                     key={t.id}
                     onClick={() => setActiveTab(t.id as any)}
                     className={`flex items-center gap-2 px-4 py-2 border-r border-cyan-900/30 ${activeTab === t.id ? 'bg-cyan-900/20 text-cyan-300 border-b-2 border-b-cyan-400' : 'text-cyan-700 hover:bg-cyan-950/30'}`}
                  >
                     {t.icon} {t.label}
                  </button>
               ))}
            </div>
            
            <div className="flex-1 relative overflow-auto custom-scrollbar p-4">
                {activeTab === 'SOURCE' && (
                   <div className="font-mono text-xs leading-relaxed text-cyan-200">
<pre className="text-cyan-600 select-none">1  </pre><span className="text-fuchsia-400">import</span> {'{'} AbsoluteAutonomy, GravityWell {'}'} <span className="text-fuchsia-400">from</span> <span className="text-amber-300">'@nexus/core'</span>;<br/>
<pre className="text-cyan-600 select-none">2  </pre><span className="text-fuchsia-400">import</span> {'{'} BaseEditor {'}'} <span className="text-fuchsia-400">from</span> <span className="text-amber-300">'@nexus/biology'</span>;<br/>
<pre className="text-cyan-600 select-none">3  </pre><br/>
<pre className="text-cyan-600 select-none">4  </pre><span className="text-emerald-400">@SpatialCommand</span>()<br/>
<pre className="text-cyan-600 select-none">5  </pre><span className="text-fuchsia-400">export default class</span> <span className="text-amber-400">RealityCompiler</span> {'{'}<br/>
<pre className="text-cyan-600 select-none">6  </pre>  <span className="text-cyan-500">private</span> densityMetric: <span className="text-fuchsia-400">number</span> = <span className="text-amber-300">100.0</span>;<br/>
<pre className="text-cyan-600 select-none">7  </pre><br/>
<pre className="text-cyan-600 select-none">8  </pre>  <span className="text-emerald-400">@AutonomousEngine</span><br/>
<pre className="text-cyan-600 select-none">9  </pre>  <span className="text-cyan-500">async</span> collapseField(intentVector: <span className="text-fuchsia-400">VectorGrid</span>): <span className="text-fuchsia-400">Promise</span>&lt;PhysicalWin&gt; {'{'}<br/>
<pre className="text-cyan-600 select-none">10 </pre>    <span className="text-cyan-700">/* Translating high-altitude 5D concepts to 3D. */</span><br/>
<pre className="text-cyan-600 select-none">11 </pre>    <span className="text-cyan-500">const</span> rawIntent = <span className="text-fuchsia-400">new</span> <span className="text-amber-400">ComputationalLogic</span>(intentVector);<br/>
<pre className="text-cyan-600 select-none">12 </pre>    <br/>
<pre className="text-cyan-600 select-none">13 </pre>    <span className="text-cyan-500">while</span> (!rawIntent.locked) {'{'}<br/>
<pre className="text-cyan-600 select-none">14 </pre>       <span className="text-amber-400">AgenticSwarm</span>.deploySelfHealing(rawIntent);<br/>
<pre className="text-cyan-600 select-none">15 </pre>       <span className="text-cyan-500">await</span> rawIntent.compress(<span className="text-amber-300">OneBitModel</span>);<br/>
<pre className="text-cyan-600 select-none">16 </pre>    {'}'}<br/>
<pre className="text-cyan-600 select-none">17 </pre>    <br/>
<pre className="text-cyan-600 select-none">18 </pre>    <span className="text-fuchsia-400">return</span> <span className="text-amber-400">GravityWell</span>.manifest(rawIntent, <span className="text-amber-300">ZeroFriction</span>);<br/>
<pre className="text-cyan-600 select-none">19 </pre>  {'}'}<br/>
<pre className="text-cyan-600 select-none">20 </pre>{'}'}
                   </div>
                )}
                
                {activeTab === 'PHYSICS_OS' && (
                    <div className="absolute inset-0 flex flex-col bg-[#020202]">
                        {/* Interactive Viewer Iframe wrapper */}
                         <div className="flex-1 w-full h-full relative z-10 border border-cyan-900/50 rounded overflow-hidden shadow-[0_0_20px_rgba(6,182,212,0.15)]">
                             <div className="absolute top-2 left-2 px-3 py-1 bg-black/60 border border-emerald-500/50 text-emerald-400 text-[10px] font-bold tracking-widest z-20 flex items-center gap-2 rounded backdrop-blur-md">
                               <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" /> LIVE SPATIAL RENDER
                             </div>
                              <iframe 
                               src={`/${activeFile?.path.replace('public/', '').replace('src/client/', '') || 'bannon.html'}`} 
                                 className="w-full h-full border-none"
                               sandbox="allow-scripts allow-same-origin allow-popups"
                               title="Live Physical Sandbox"
                             />
                         </div>
                        
                         {/* Stats Overlay Bar */}
                        <div className="h-10 bg-black/90 px-4 border-t border-cyan-900/50 flex items-center justify-between text-xs font-mono tracking-widest relative z-20 shrink-0">
                           <div className="flex items-center gap-2">
                             <Layers className="w-4 h-4 text-cyan-500" />
                             <span className="text-cyan-500 font-bold">SPATIAL RENDER PIPELINE</span>
                           </div>
                           <div className="flex gap-6">
                              <span className="text-cyan-700">FPS: <span className="text-cyan-300">144.0</span></span>
                              <span className="text-cyan-700">POLY: <span className="text-cyan-300">LIVE</span></span>
                              <span className="text-cyan-700">PHYSICS ENGINE: <span className="text-amber-300 animate-pulse">SYNCHRONIZED BANNON CORE</span></span>
                           </div>
                        </div>
                    </div>
                )}
                
                {activeTab === 'SWARM_LOG' && (
                    <div className="font-mono text-xs text-indigo-400 space-y-2">
                       <div className="text-indigo-300 opacity-50">&gt;&gt; TRACING AGENTIC REWRITES IN RAW MEMORY...</div>
                       <motion.div initial={{opacity:0}} animate={{opacity:1}} transition={{delay: 0.2}} className="pl-4 border-l-2 border-indigo-900/50">
                          [SWARM-1] Investigating AST Node 0x9A4F... No corruption. Load: 12%<br/>
                          [SWARM-4] Re-compiling Core_Blueprint.rs to Rust bare-metal target.<br/>
                          [SWARM-7] &lt;WARNING&gt; Discrepancy in 5D projection mapping. Healing coordinates.<br/>
                          [SWARM-9] Injecting One-Bit model inference engine at Line 14.<br/>
                          [SWARM-1] Applying Radical Efficiency limits. 45MB -&gt; 1.2MB ram footprint achieved.
                       </motion.div>
                    </div>
                )}
                {activeTab === 'ENGINE_ANALYZER' && (
                    <EngineAnalyzer />
                )}
                {activeTab === 'BRIDGE' && (
                    <SessionBridgePanel />
                )}
                {activeTab === 'EDITOR' && activeFile && (
                    <CodeSurgeonPanel />
                )}
            </div>
         </div>
      </div>

      {/* Bare Metal Output Terminal */}
      <div className="h-48 border-t border-cyan-900/40 bg-[#020202] flex flex-col shrink-0">
          <div className="bg-[#050508] px-3 py-1 text-[10px] uppercase font-bold text-cyan-600 flex items-center gap-2 border-b border-cyan-900/30">
             <Terminal className="w-3 h-3" /> Bare Metal Actuation (Localhost:9999)
          </div>
          <div 
             ref={bottomRef}
             className="flex-1 p-3 overflow-y-auto custom-scrollbar font-mono text-[10px] space-y-1"
          >
             {terminalLogs.map((log, i) => {
                if (log.startsWith('```bash')) {
                   const cmd = log.replace('```bash\n', '').replace('\n```', '');
                   return (
                      <div key={i} className="my-2 bg-black border border-cyan-900/50 p-2 rounded text-amber-400">
                         {cmd}
                      </div>
                   )
                }
                return (
                  <div key={i} className={`${log.includes('[SUCCESS]') || log.includes('locked') ? 'text-emerald-400' : log.includes('[INIT]') || log.includes('[AUTH]') ? 'text-fuchsia-400' : 'text-cyan-500/80'}`}>
                     {log}
                  </div>
                )
             })}
          </div>
      </div>
    </div>
  );
}
