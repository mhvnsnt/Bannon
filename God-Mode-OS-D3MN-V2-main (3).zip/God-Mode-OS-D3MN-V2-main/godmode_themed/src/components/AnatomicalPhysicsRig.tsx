import React, { useState, useRef, useMemo } from 'react';
import { Activity, Play, Square, Settings, Database, Eye, ActivitySquare } from 'lucide-react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Line, Sphere } from '@react-three/drei';
import * as THREE from 'three';

// -----------------------------------------------------
// 1. Procedural 1000+ Bone DAZ Genesis Hierarchy Mapping
// -----------------------------------------------------
const AnatomyMesh = ({ facs, physics, fluidSim }: any) => {
  const meshRef = useRef<THREE.Group>(null);
  const fluidRef = useRef<THREE.Points>(null);

  // Generate procedural bone coordinates resembling an complex anatomical volume
  const { bones, links, fluidParticles } = useMemo(() => {
    const rawBones = [];
    const boneLinks = [];
    // Simulating 1000+ granular bone indices in a geometric layout
    for (let i = 0; i < 1000; i++) {
       const theta = Math.random() * Math.PI * 2;
       const phi = Math.acos((Math.random() * 2) - 1);
       // Distribute bones in a loose torso/head structure
       const r = 2 + Math.sin(phi * 4) * 0.5;
       rawBones.push(new THREE.Vector3(
         r * Math.sin(phi) * Math.cos(theta),
         r * Math.cos(phi) * 1.5,
         r * Math.sin(phi) * Math.sin(theta)
       ));
    }
    
    // Connect adjacent nodes to form a structural lattice (simulating tissue/ligaments)
    for(let i=0; i<1000; i+=2) {
       boneLinks.push([rawBones[i], rawBones[(i+1)%1000], rawBones[(i+2)%1000]]);
    }

    // Fluid mesh particles
    const fParticles = [];
    for(let i=0; i<2000; i++) {
       fParticles.push(new THREE.Vector3(
          (Math.random() - 0.5) * 3,
          (Math.random() - 0.5) * 5,
          (Math.random() - 0.5) * 3
       ));
    }

    return { bones: rawBones, links: boneLinks, fluidParticles: fParticles };
  }, []);

  const fluidGeometry = useMemo(() => {
     const geo = new THREE.BufferGeometry();
     geo.setFromPoints(fluidParticles);
     return geo;
  }, [fluidParticles]);

  useFrame((state, delta) => {
    if (meshRef.current) {
       // Apply FACS and physical tension continuously
       const time = state.clock.getElapsedTime();
       
       // Complex stretching dynamics based on physics tension
       const stretchFactor = 1 + (physics.tension / 100) * Math.sin(time * 2);
       const tearingFactor = physics.tension > 80 ? (Math.random() * 0.05) : 0; // micro-jitter tearing
       
       meshRef.current.rotation.y = time * 0.1;
       meshRef.current.scale.y = stretchFactor;
       meshRef.current.position.y = Math.sin(time) * 0.2 + tearingFactor;
    }

    if (fluidRef.current && fluidSim) {
       const positions = fluidRef.current.geometry.attributes.position.array as Float32Array;
       for (let i = 0; i < positions.length; i += 3) {
          // Fluid dynamics influenced by gravity and tension
          positions[i + 1] -= (physics.gravity * 0.05 + 0.01) * delta * 10;
          
          // Add organic sway (simulating scientific fluid interactions)
          positions[i] += Math.sin(state.clock.elapsedTime * 3 + positions[i+1]) * 0.02;
          
          // Reset particles that fall too low
          if (positions[i + 1] < -3) {
             positions[i + 1] = 3;
          }
       }
       fluidRef.current.geometry.attributes.position.needsUpdate = true;
    }
  });

  return (
    <group ref={meshRef}>
       {/* Ligament Structural Lattice */}
       {links.map((link, idx) => (
          <Line 
            key={idx} 
            points={link} 
            color={physics.tension > 85 ? "#ef4444" : "#d946ef"} 
            opacity={0.1} 
            transparent 
            lineWidth={0.5} 
          />
       ))}
       
       {/* FACS influence indicator (Abstract glowing core representing biological strain) */}
       <Sphere args={[0.5, 32, 32]} position={[0, 1.5 + facs.AU1, 0]}>
         <meshBasicMaterial color="#e879f9" wireframe transparent opacity={0.6 + facs.AU4} />
       </Sphere>

       {/* Scientific Fluid Nodes */}
       {fluidSim && (
          <points ref={fluidRef} geometry={fluidGeometry}>
             <pointsMaterial size={0.03} color="#ec4899" transparent opacity={0.4} blending={THREE.AdditiveBlending} />
          </points>
       )}
    </group>
  );
};

export function AnatomicalPhysicsRig() {
  const [activeRig, setActiveRig] = useState('DAZ_GENESIS_1000_BONE');
  const [facs, setFacs] = useState({ AU1: 0, AU2: 0, AU4: 0, AU12: 0 });
  const [physics, setPhysics] = useState({ gravity: 9.8, tension: 50, dampening: 20 });
  const [fluidSim, setFluidSim] = useState(true);
  const [tearingLog, setTearingLog] = useState<string[]>([]);
  
  // Track structural damage limits based on tension constraint
  const updatePhysics = (prop: string, val: number) => {
      setPhysics(p => ({...p, [prop]: val}));
      if (prop === 'tension' && val > 85) {
          if (Math.random() > 0.8) {
              setTearingLog(prev => [`[${new Date().toISOString().split('T')[1].slice(0,-1)}] WARNING: Micro-structural tearing detected at ligament vector L-${Math.floor(Math.random()*1000)}`, ...prev].slice(0, 5));
          }
      }
  };

  return (
    <div className="w-full h-full bg-[#050005] text-fuchsia-500 font-mono p-4 flex flex-col border-l border-fuchsia-900/40 overflow-hidden">
        <div className="border-b border-fuchsia-900/50 pb-3 mb-4 shrink-0 flex justify-between items-end">
           <div>
               <h2 className="text-sm font-bold uppercase tracking-widest text-fuchsia-400 flex items-center gap-2">
                 <Database className="w-4 h-4" /> Procedural Biomechanical Rig
               </h2>
               <p className="text-[10px] text-fuchsia-700 mt-1">DAZ GENESIS 1000+ Bone Kinematics, WebGL FACS Routing & Fluid Sandbox.</p>
           </div>
           <div className="text-[10px] bg-fuchsia-950/40 border border-fuchsia-900/40 px-2 py-1 text-fuchsia-400 animate-pulse">
               ENGINED: {activeRig}
           </div>
        </div>

        <div className="flex-1 grid grid-cols-3 gap-4 pb-4 overflow-y-auto custom-scrollbar">
            {/* Control Panels */}
            <div className="col-span-1 flex flex-col gap-4">
                <div className="bg-[#0a000a] border border-fuchsia-900/30 rounded p-4 flex flex-col gap-4 shadow-[0_0_15px_rgba(217,70,239,0.05)]">
                    <h3 className="text-xs uppercase font-bold text-fuchsia-500 flex items-center gap-2">
                      <Eye className="w-3 h-3" /> FACS Routing Matrix
                    </h3>
                    <div className="space-y-4">
                       {Object.entries(facs).map(([au, val]) => (
                          <div key={au}>
                             <div className="flex justify-between text-[10px] uppercase text-fuchsia-600 mb-1">
                                <span>{au} {au === 'AU1' ? '(Inner Brow)' : au === 'AU2' ? '(Outer Brow)' : au === 'AU4' ? '(Brow Lowerer)' : '(Lip Corner Puller)'}</span>
                                <span className={val > 0.8 ? "text-fuchsia-300 font-bold" : ""}>{(val * 100).toFixed(0)}%</span>
                             </div>
                             <input 
                                type="range" min="0" max="1" step="0.01" value={val}
                                onChange={e => setFacs({...facs, [au as keyof typeof facs]: parseFloat(e.target.value)})}
                                className="w-full accent-fuchsia-500"
                             />
                          </div>
                       ))}
                    </div>
                </div>

                <div className="bg-[#0a000a] border border-fuchsia-900/30 rounded p-4 flex flex-col gap-4 shadow-[0_0_15px_rgba(217,70,239,0.05)]">
                    <h3 className="text-xs uppercase font-bold text-fuchsia-500 flex items-center gap-2">
                      <Settings className="w-3 h-3" /> Soft Body Dynamics
                    </h3>
                    <div className="space-y-4">
                       {Object.entries(physics).map(([prop, val]) => (
                          <div key={prop}>
                             <div className="flex justify-between text-[10px] uppercase text-fuchsia-600 mb-1">
                                <span>{prop} {prop === 'tension' && val > 85 && <span className="text-red-500 animate-pulse ml-1">CRITICAL</span>}</span>
                                <span>{val.toFixed(1)}</span>
                             </div>
                             <input 
                                type="range" min="0" max={prop === 'gravity' ? 20 : 100} value={val}
                                onChange={e => updatePhysics(prop, parseFloat(e.target.value))}
                                className="w-full accent-fuchsia-500"
                             />
                          </div>
                       ))}
                       
                       <label className="flex items-center gap-2 text-[10px] text-fuchsia-400 uppercase mt-2 bg-fuchsia-950/20 p-2 border border-fuchsia-900/30 rounded cursor-pointer hover:bg-fuchsia-900/20 transition-colors">
                          <input type="checkbox" checked={fluidSim} onChange={e => setFluidSim(e.target.checked)} className="accent-fuchsia-500" />
                          Scientific Fluid Mesh Generation
                       </label>
                    </div>
                </div>

                {/* Tearing Log output */}
                <div className="flex-1 bg-[#050005] border border-red-900/20 p-2 text-[9px] text-red-500/70 overflow-hidden font-mono flex flex-col">
                    <div className="uppercase font-bold mb-1 border-b border-red-900/30 pb-1 flex justify-between">
                        <span>Anatomical Threshold Logs</span>
                        <ActivitySquare className="w-3 h-3" />
                    </div>
                    {tearingLog.length === 0 ? (
                        <div className="text-fuchsia-900">Stability Nominal. Stretching within parameters.</div>
                    ) : (
                        tearingLog.map((log, i) => <div key={i} className="mb-1 leading-tight">{log}</div>)
                    )}
                </div>
            </div>
            
            {/* WebGL Biomechanical Canvas */}
            <div className="col-span-2 bg-[#000000] border border-fuchsia-900/50 rounded h-full relative flex items-center justify-center overflow-hidden shadow-[inset_0_0_50px_rgba(217,70,239,0.05)]">
                {/* HUD Overlay */}
                <div className="absolute top-4 left-4 z-10 pointer-events-none">
                    <div className="text-[10px] text-fuchsia-500/50 uppercase font-mono">
                        Vector Origin: [0.00, 0.00, 0.00]<br/>
                        Sub-divide Level: 4<br/>
                        Bones: 1,024 Active<br/>
                        Fluid Nodes: 2,000<br/>
                        Physiology: {physics.tension > 85 ? 'EXTREME LOAD' : 'NOMINAL'}
                    </div>
                </div>

                <Canvas camera={{ position: [0, 0, 8], fov: 45 }}>
                   <ambientLight intensity={0.5} />
                   <pointLight position={[10, 10, 10]} intensity={1} color="#f0abfc" />
                   <pointLight position={[-10, -10, -10]} intensity={0.5} color="#c026d3" />
                   
                   <AnatomyMesh facs={facs} physics={physics} fluidSim={fluidSim} />
                   
                   <OrbitControls 
                      enablePan={false}
                      autoRotate={!fluidSim}
                      autoRotateSpeed={0.5}
                      minDistance={3}
                      maxDistance={15}
                   />
                </Canvas>
                
                <div className="absolute bottom-2 right-2 text-[9px] text-fuchsia-700/50 font-mono tracking-widest font-bold">
                   REALITY COMPILER | WEBGL BINDING | FPS: 60
                </div>
            </div>
        </div>
    </div>
  );
}
