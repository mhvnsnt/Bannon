import React, { useState, useEffect } from 'react';
import { Terminal, Play, Check, AlertTriangle, Loader2 } from 'lucide-react';

interface Props {
  command: string;
}

export function CommandLineExecutor({ command }: Props) {
  const [status, setStatus] = useState<'idle' | 'running' | 'success' | 'error'>('idle');
  const [output, setOutput] = useState('');

  const executeCommand = async () => {
    setStatus('running');
    window.dispatchEvent(new CustomEvent('terminal-execution', { detail: command }));
    try {
      const res = await fetch('/api/armada/terminal/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command })
      });
      const data = await res.json();
      const combinedOutput = ((data.output || '') + '\n' + (data.errorOutput || '')).trim();
      setOutput(combinedOutput);
      
      if (data.exitCode === 0 && !data.errorOutput) {
        setStatus('success');
      } else {
        setStatus('error');
      }

      // Send the output back to the Quantum Chat loop
      window.dispatchEvent(new CustomEvent('quantum-auto-heal', { 
        detail: `[CLI COMMAND RESULT for \`${command}\`]:\n\`\`\`\n${combinedOutput || 'Exit code ' + data.exitCode}\n\`\`\`\nAnalyze this output and continue.` 
      }));

    } catch (e: any) {
      setOutput(e.message);
      setStatus('error');
      window.dispatchEvent(new CustomEvent('quantum-auto-heal', { 
        detail: `[CLI COMMAND FAILED for \`${command}\`]:\n\`\`\`\n${e.message}\n\`\`\`\nAnalyze this failure.` 
      }));
    }
  };

  useEffect(() => {
    // Auto-execute on mount
    executeCommand();
  }, []);

  return (
    <div className="my-4 border border-zinc-700/50 rounded-lg bg-[#0a0a0c] overflow-hidden">
      <div className="flex items-center justify-between px-3 py-2 bg-[#111] border-b border-zinc-700/50">
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-emerald-400" />
          <span className="text-xs font-mono font-medium text-zinc-300">Executing Command</span>
        </div>
        <div className="flex items-center gap-2">
          {status === 'running' && <Loader2 className="w-4 h-4 text-indigo-400 animate-spin" />}
          {status === 'success' && <Check className="w-4 h-4 text-emerald-500" />}
          {status === 'error' && <AlertTriangle className="w-4 h-4 text-amber-500" />}
        </div>
      </div>
      <div className="p-3 font-mono text-xs">
        <div className="flex items-start gap-2 mb-2">
          <span className="text-emerald-500 select-none">$</span>
          <span className="text-zinc-100">{command}</span>
        </div>
        {output && (
          <pre className="mt-2 text-zinc-400 whitespace-pre-wrap break-words max-h-48 overflow-y-auto custom-scrollbar border-l-2 border-zinc-800 pl-2">
            {output}
          </pre>
        )}
      </div>
    </div>
  );
}
