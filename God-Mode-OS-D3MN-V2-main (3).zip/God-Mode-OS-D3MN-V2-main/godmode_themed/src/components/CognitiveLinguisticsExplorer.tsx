import React, { useState, useEffect, useRef } from 'react';
import { 
  Terminal, Shield, Zap, Search, Brain, HelpCircle, 
  Layers, Volume2, Info, ArrowRight, Landmark, RefreshCw, 
  GitBranch, Sparkles, BookOpen, Sliders, Play, Database, Languages, ScrollText
} from 'lucide-react';
import * as d3 from 'd3';

// 1. Interfaces
interface CognateNode extends d3.SimulationNodeDatum {
  id: string;
  label: string;
  type: 'ROOT' | 'BRANCH' | 'LANGUAGE' | 'COGNATE';
  meaning?: string;
  branch?: string;
  timePeriod?: string;
  valency?: number;
}

interface CognateLink extends d3.SimulationLinkDatum<CognateNode> {
  source: string;
  target: string;
  law?: string;
}

interface EtymologyTreeRef {
  nodes: CognateNode[];
  links: CognateLink[];
  rootName: string;
  rootMeaning: string;
}

interface PIERootRecord {
  root: string;
  meaning: string;
  divergence: {
    english: { form: string; shift: string; example: string };
    sanskrit: { form: string; shift: string; example: string };
    latin: { form: string; shift: string; example: string };
  };
  cognates: Array<{ lang: string; form: string; meaning: string }>;
}

const PIE_ROOT_DATABASE: PIERootRecord[] = [
  {
    root: "*ne / *n̥-",
    meaning: "Prefix marker of absolute negation (not, un-, non-)",
    divergence: {
      english: {
        form: "un- / no / not",
        shift: "Grimm's loss of terminators, West Germanic preservation of *un-",
        example: "unclean, nonconformist (borrowed via Latin)"
      },
      sanskrit: {
        form: "a- / an- / na",
        shift: "Sonorant *n̥ vocalizes to 'a-', preservation of 'na' as standalone negative verb",
        example: "a-jñāna (ignorance / un-knowing), a-hiṃsā (non-injury)"
      },
      latin: {
        form: "in- / ne-",
        shift: "Vocalic spelling change of *n̥ to 'in-', preservation of 'ne' in conjunctions",
        example: "in-justus (unjust), ne-fas (not divine / unspeakable crime)"
      }
    },
    cognates: [
      { lang: "Ancient Greek", form: "a- / an- (alpha privative)", meaning: "an-hydrous (waterless), a-theist (without god)" },
      { lang: "Old Irish", form: "an- / am- / ing-", meaning: "an-fola (un-blood, bad feeling)" },
      { lang: "Old Norse", form: "ū- / ō-", meaning: "ū-gagn (useless, un-gain)" },
      { lang: "Gothic", form: "un-", meaning: "un-mahts (weakness, un-might)" }
    ]
  },
  {
    root: "*ner- / *nert-",
    meaning: "Underworld vital power, active force, manly strength, human courage",
    divergence: {
      english: {
        form: "north / narrow",
        shift: "Germanic shifts *nert -> *nertha (leftward/northern direction of telluric force used in navigation)",
        example: "North, Norse (pertaining to ancestral power orientation)"
      },
      sanskrit: {
        form: "nṛ / nara",
        shift: "Highly conservative vocalic r sound conservation, masculine semantic focus",
        example: "nara-simha (man-lion incarnate), nṛpatis (lord of men)"
      },
      latin: {
        form: "Nero / neriosus",
        shift: "Sabine-Etruscan patrician import mapping strength/bravery to patrician names",
        example: "Nero (Emperor name literally meaning 'the strong one'), neriosus (tough/sinewy)"
      }
    },
    cognates: [
      { lang: "Ancient Greek", form: "anēr / andros", meaning: "phil-anthropy (love of human-kind), andr-ogen (male factor)" },
      { lang: "Old Irish", form: "nert", meaning: "nertmar (mighty, possessing telluric strength)" },
      { lang: "Welsh", form: "nerth", meaning: "nerthog (powerful, armed with clan strength)" },
      { lang: "Avestan", form: "nar-", meaning: "narō (brave men of the dual sky lineage)" }
    ]
  },
  {
    root: "*gnō-",
    meaning: "Cognitive grasp, active recognition, mastery of direct knowledge",
    divergence: {
      english: {
        form: "know / ken / uncouth",
        shift: "Grimm's Law *g -> *k (unvoiced stop). Root vowel lengthened, terminal shifts",
        example: "know (understand), uncouth (originally meaning 'unknown / unfamiliar')"
      },
      sanskrit: {
        form: "jñā",
        shift: "Palatalization transition where velar stop *g shifts under vowel contact to soft affricate 'j-'",
        example: "jñāna (transcendental direct gnosis), jñāti (kinsman, one who is closely known)"
      },
      latin: {
        form: "gno- / co-gno-scere / ignōrāre",
        shift: "Preserved original velar *g, but prepended co- (together) for compound verbs",
        example: "co-gno-scent (knowing together), ig-norant (not knowing)"
      }
    },
    cognates: [
      { lang: "Ancient Greek", form: "gi-gnō-skō / gnōsis", meaning: "dia-gnosis (distinguishing knowledge), gnōstikos (pertaining to knowing)" },
      { lang: "Russian", form: "znat' / znaniye", meaning: "znaniye (mastery of data, knowledge)" },
      { lang: "Old Persian", form: "xšnāsatiy", meaning: "to know, recognize under the sky dome" },
      { lang: "Old Irish", form: "gnáth", meaning: "customary, familiar, known to the tribe" }
    ]
  },
  {
    root: "*ped-",
    meaning: "Physical foot, stepping foundation, structural base, solar cadence",
    divergence: {
      english: {
        form: "foot / fetter",
        shift: "Grimm's Law voiceless stop shifts: *p -> fricative 'f', and voiced dental *d -> unvoiced 't'",
        example: "foot, fetlock, speed (originally meaning 'prosperity / foot-forward')"
      },
      sanskrit: {
        form: "pad / pāda",
        shift: "Vocalic preservation of stop p-, shift of ending to short or long thematic vowels",
        example: "pāda (verse-foot, quarter quadrant of a cosmic stanza), padma (lotus - 'foot-grounded')"
      },
      latin: {
        form: "pēs / pedis / impedire",
        shift: "Pristine consonant preservation of both classical stops: *p and *d",
        example: "ped-al (relating to foot), im-pede (literally 'to tangle the feet of')"
      }
    },
    cognates: [
      { lang: "Ancient Greek", form: "pous / podos", meaning: "podium (foot-stand), pod-iatrist (physician of feet)" },
      { lang: "Gothic", form: "fōtus", meaning: "fōtu-bandi (fetter, ankle lock of iron)" },
      { lang: "Armenian", form: "otn", meaning: "loss of initial p- as is characteristic of Armenian phonetic drift" },
      { lang: "Tocharian B", form: "paiyye", meaning: "foot / step of the desert caravan" }
    ]
  },
  {
    root: "*bher-",
    meaning: "To carry, bear forward, actively bring, give birth to material weight",
    divergence: {
      english: {
        form: "bear / birth / burden",
        shift: "Grimm's shift of voice aspirated stop *bʰ to voice plain stop 'b'",
        example: "bear (carry weight), child-birth (bringing forward)"
      },
      sanskrit: {
        form: "bhṛ / bharati",
        shift: "Flawless conservation of the rare aspirated voiced labial stop *bh",
        example: "bharati (he carries / supports the ritual sacrifice), bhartṛ (husband / carrier)"
      },
      latin: {
        form: "ferre / ferāx",
        shift: "Roman de-aspiration mapping *bʰ to unvoiced labiodental fricative 'f'",
        example: "fer-tile (capable of bearing / carrying crops), transfer (carry across)"
      }
    },
    cognates: [
      { lang: "Ancient Greek", form: "pherein / phoros", meaning: "metaphor (carrying across meanings), phoresis (physical motion)" },
      { lang: "Old Irish", form: "berid", meaning: "he bears / produces progeny of the soil" },
      { lang: "Russian", form: "brat' / beremy", meaning: "brat' (to seize / take / carry), beremennost' (pregnancy)" },
      { lang: "Avestan", form: "baraitiy", meaning: "he carries, offers to the pure fire" }
    ]
  },
  {
    root: "*dʰē-",
    meaning: "To set, do, put down, place or construct a structural boundary",
    divergence: {
      english: {
        form: "do / deed / doom",
        shift: "Germanic shift of aspirated dental stop *dʰ to plain voiced stop 'd'",
        example: "do (perform setting or placing acts), doom (literally 'that which is set or established')"
      },
      sanskrit: {
        form: "dhā / dadhāti",
        shift: "Aspirated voiced dental stop *dʰ fully conserved, typical Reduplicated Present morphology",
        example: "dharma (cosmic set law / what is placed structurally), sam-ā-dhi (placing together in perfect focus)"
      },
      latin: {
        form: "facere / fēci / fās",
        shift: "Italic sound law mapping initial aspirated *dʰ to unvoiced fricative 'f-'",
        example: "fac-tory (place of making / setting), con-fec-tion (things put / placed together)"
      }
    },
    cognates: [
      { lang: "Ancient Greek", form: "tithēmi / thēkē", meaning: "hypo-thesis (placing underneath), apo-thecary (placing / storing box)" },
      { lang: "Old Church Slavonic", form: "děti", meaning: "to place, build, construct, do" },
      { lang: "Lithuanian", form: "dėti", meaning: "to put, lay eggs, establish a clan" },
      { lang: "Tocharian A", form: "tā-", meaning: "to set, place on the central platform" }
    ]
  },
  {
    root: "*dem- / *dom-",
    meaning: "House, household social enclosure, domestic domain of absolute safety",
    divergence: {
      english: {
        form: "timber / dome",
        shift: "Germanic drift mapping *d -> *t (Grimm's shift), semantic focus on the wood used to build houses",
        example: "timber (constructive wood for a house), domain (borrowed from Latin *domus)"
      },
      sanskrit: {
        form: "damas / dampatis",
        shift: "Conservative dental voiced stop conservation, matching ritual house master status",
        example: "dampatis (master / lord of the household, husband-wife combined polarity)"
      },
      latin: {
        form: "domus / dominus",
        shift: "Pristine vowel maintenance, semantic lock as the legal and structural family house",
        example: "dom-estic (relating to house), dom-inate (ruling the house as absolute master)"
      }
    },
    cognates: [
      { lang: "Ancient Greek", form: "domos / despotes", meaning: "despot (master of the house), dōma (roof / house structural top)" },
      { lang: "Russian", form: "dom", meaning: "domashniy (domestic, sweet shelter of the hearth)" },
      { lang: "Old Irish", form: "daim", meaning: "clan group living under one roof" },
      { lang: "Armenian", form: "tun", meaning: "house, structural chamber" }
    ]
  },
  {
    root: "*weid- / *wid-",
    meaning: "To see, to know via direct optical/cognitive perception",
    divergence: {
      english: {
        form: "wit / wise / vision",
        shift: "Germanic conservation of *w, standard stop mutation of *d to t in 'wit'",
        example: "wit (understanding), witness (one who saw)"
      },
      sanskrit: {
        form: "vid / veda",
        shift: "Pristine voiced dental preservation, highly elevated semantic meaning",
        example: "veda (the highest cognitive knowledge), vidyā (science/clarity)"
      },
      latin: {
        form: "vidēre / vīsus",
        shift: "Perfect conservation of *v (w) and *d",
        example: "video (I see), vision (that which is seen)"
      }
    },
    cognates: [
      { lang: "Ancient Greek", form: "eîdon / oîda", meaning: "Loss of initial digamma (w-); oîda = 'I have seen -> I know'" },
      { lang: "Old Church Slavonic", form: "viděti", meaning: "viděti (to see, perceive shape)" },
      { lang: "Old Irish", form: "finn", meaning: "finn (white, bright, visibly clear)" },
      { lang: "Gothic", form: "witan", meaning: "witi (knowledge, intellect)" }
    ]
  },
  {
    root: "*men-",
    meaning: "To think, project the mind, spiritual activity, mathematical mania",
    divergence: {
      english: {
        form: "mind / mean / man",
        shift: "Standard Germanic lengthening and suffix attachments, stable core",
        example: "mind (cognitive faculty), man (the thinking entity)"
      },
      sanskrit: {
        form: "man / mantra",
        shift: "Vocalic shift to 'a', massive explosion of philosophical derivative terms",
        example: "mantra (instrument of the mind), manu (the first thinking man)"
      },
      latin: {
        form: "mēns / mentis / monēre",
        shift: "Vocalic preservation and suffix derivation",
        example: "mental (of the mind), monitor (to warn / make to think)"
      }
    },
    cognates: [
      { lang: "Ancient Greek", form: "ménos / manía", meaning: "menos (spiritual force), mania (ecstatic mind-state)" },
      { lang: "Old Church Slavonic", form: "mьněti", meaning: "mnyeti (to think, to opine)" },
      { lang: "Lithuanian", form: "minti", meaning: "to remember, to hold in cognitive focus" },
      { lang: "Avestan", form: "mainyu", meaning: "spiritual mental force (e.g., Angra Mainyu)" }
    ]
  }
];

// 2. Pre-defined dynamic roots for explorer
const ETYMO_PRESETS: Record<string, EtymologyTreeRef> = {
  "aham / ego": {
    rootName: "*eg-ó",
    rootMeaning: "Primary personal pronoun (Self, 'I am')",
    nodes: [
      { id: 'root', label: '*eg-ó', type: 'ROOT', meaning: "Self pronoun ('I')" },
      // Branches
      { id: 'indo_iranian', label: 'Indo-Iranian', type: 'BRANCH', branch: 'Aryan' },
      { id: 'italic', label: 'Italic', type: 'BRANCH', branch: 'Romance' },
      { id: 'hellenic', label: 'Hellenic', type: 'BRANCH', branch: 'Greek' },
      { id: 'germanic', label: 'Germanic', type: 'BRANCH', branch: 'Teutonic' },
      // Sub-stages / Languages
      { id: 'sanskrit', label: 'Sanskrit (aham)', type: 'LANGUAGE', branch: 'Indo-Aryan', timePeriod: '1500 BCE' },
      { id: 'latin', label: 'Latin (ego)', type: 'LANGUAGE', branch: 'Italic', timePeriod: '100 BCE' },
      { id: 'greek', label: 'Ancient Greek (egō)', type: 'LANGUAGE', branch: 'Hellenic', timePeriod: '500 BCE' },
      { id: 'proto_germanic', label: 'Proto-Germanic (*ik)', type: 'LANGUAGE', branch: 'Germanic', timePeriod: '500 BCE' },
      // Modern cognate leaves
      { id: 'english', label: 'English (I / ego)', type: 'COGNATE', branch: 'West Germanic', meaning: 'Modern 1st Person self' },
      { id: 'spanish', label: 'Spanish (yo)', type: 'COGNATE', branch: 'Romance', meaning: 'Descended via Latin vulgar eo/ego' },
      { id: 'german', label: 'German (ich)', type: 'COGNATE', branch: 'Germanic', meaning: 'High German shift *ik -> ich' }
    ],
    links: [
      { source: 'root', target: 'indo_iranian', law: 'Primary Branching' },
      { source: 'root', target: 'italic', law: 'Primary Branching' },
      { source: 'root', target: 'hellenic', law: 'Primary Branching' },
      { source: 'root', target: 'germanic', law: 'Primary Branching' },
      
      { source: 'indo_iranian', target: 'sanskrit', law: 'Sanskritization' },
      { source: 'italic', target: 'latin', law: 'Phonetic Conservation' },
      { source: 'hellenic', target: 'greek', law: 'Vocalic Shift' },
      { source: 'germanic', target: 'proto_germanic', law: "Grimm's Law Segment Shift (*eg -> *ik)" },

      { source: 'sanskrit', target: 'english', law: 'Indo-Aryan modern loan contact (ego psychological borrow)' },
      { source: 'latin', target: 'spanish', law: 'Vulgar loss of terminal consonants' },
      { source: 'proto_germanic', target: 'english', law: 'Anglo-Saxon standard drift to single phoneme I' },
      { source: 'proto_germanic', target: 'german', law: 'High German Consonant Shift' }
    ]
  },
  "du bist / thou art": {
    rootName: "*tu",
    rootMeaning: "Singly addressed pronouns ('thou / you')",
    nodes: [
      { id: 'root', label: '*tu / *te', type: 'ROOT', meaning: "Second-Person singular address" },
      { id: 'indo_iranian', label: 'Indo-Iranian', type: 'BRANCH', branch: 'Aryan' },
      { id: 'italic', label: 'Italic', type: 'BRANCH', branch: 'Romance' },
      { id: 'germanic', label: 'Germanic', type: 'BRANCH', branch: 'Teutonic' },
      
      { id: 'sanskrit', label: 'Sanskrit (tvam)', type: 'LANGUAGE', branch: 'Indo-Aryan', timePeriod: '1500 BCE' },
      { id: 'latin', label: 'Latin (tu)', type: 'LANGUAGE', branch: 'Italic', timePeriod: '100 BCE' },
      { id: 'proto_germanic', label: 'Proto-Germanic (*þū)', type: 'LANGUAGE', branch: 'Germanic', timePeriod: '500 BCE' },
      
      { id: 'old_english', label: 'Old English (þū)', type: 'LANGUAGE', branch: 'Germanic', timePeriod: '800 CE' },
      { id: 'english_thou', label: 'English (thou / you)', type: 'COGNATE', branch: 'West Germanic', meaning: 'Formally shifted to you plural address' },
      { id: 'spanish', label: 'Spanish (tú)', type: 'COGNATE', branch: 'Romance', meaning: 'Kept direct nominative case' },
      { id: 'german', label: 'German (du)', type: 'COGNATE', branch: 'Germanic', meaning: 'High German d- Voicing' }
    ],
    links: [
      { source: 'root', target: 'indo_iranian' },
      { source: 'root', target: 'italic' },
      { source: 'root', target: 'germanic' },
      
      { source: 'indo_iranian', target: 'sanskrit' },
      { source: 'italic', target: 'latin' },
      { source: 'germanic', target: 'proto_germanic', law: "Grimm's Law: *t -> voiceless fricative /th/" },
      
      { source: 'proto_germanic', target: 'old_english' },
      { source: 'old_english', target: 'english_thou' },
      { source: 'latin', target: 'spanish' },
      { source: 'proto_germanic', target: 'german', law: "High German Shift: th -> d (du)" }
    ]
  },
  "mother / mātṛ": {
    rootName: "*méh₂tēr",
    rootMeaning: "Primary matrix of material form / mother",
    nodes: [
      { id: 'root', label: '*méh₂ter', type: 'ROOT', meaning: "Mother figure, natural node of life" },
      { id: 'indo_iranian', label: 'Indo-Iranian', type: 'BRANCH' },
      { id: 'italic', label: 'Italic', type: 'BRANCH' },
      { id: 'germanic', label: 'Germanic', type: 'BRANCH' },
      
      { id: 'sanskrit', label: 'Sanskrit (mātṛ)', type: 'LANGUAGE', branch: 'Indo-Aryan', timePeriod: '1500 BCE' },
      { id: 'latin', label: 'Latin (māter)', type: 'LANGUAGE', branch: 'Italic', timePeriod: '100 BCE' },
      { id: 'proto_germanic', label: 'Proto-Germanic (*mōdēr)', type: 'LANGUAGE', branch: 'Germanic', timePeriod: '500 BCE' },
      
      { id: 'english', label: 'English (mother)', type: 'COGNATE', branch: 'West Germanic' },
      { id: 'spanish', label: 'Spanish (madre)', type: 'COGNATE', branch: 'Romance' },
      { id: 'german', label: 'German (Mutter)', type: 'COGNATE', branch: 'Germanic' }
    ],
    links: [
      { source: 'root', target: 'indo_iranian' },
      { source: 'root', target: 'italic' },
      { source: 'root', target: 'germanic' },
      { source: 'indo_iranian', target: 'sanskrit' },
      { source: 'italic', target: 'latin' },
      { source: 'germanic', target: 'proto_germanic' },
      { source: 'proto_germanic', target: 'english' },
      { source: 'latin', target: 'spanish' },
      { source: 'proto_germanic', target: 'german' }
    ]
  },
  "brother / bhrātṛ": {
    rootName: "*bʰréh₂tēr",
    rootMeaning: "Male clan companion / brother",
    nodes: [
      { id: 'root', label: '*bʰréh₂tēr', type: 'ROOT', meaning: "Brother, protector of the hearth" },
      { id: 'indo_iranian', label: 'Indo-Iranian', type: 'BRANCH' },
      { id: 'italic', label: 'Italic', type: 'BRANCH' },
      { id: 'germanic', label: 'Germanic', type: 'BRANCH' },
      
      { id: 'sanskrit', label: 'Sanskrit (bhrātṛ)', type: 'LANGUAGE', branch: 'Indo-Aryan', timePeriod: '1500 BCE' },
      { id: 'latin', label: 'Latin (frāter)', type: 'LANGUAGE', branch: 'Italic', timePeriod: '100 BCE' },
      { id: 'proto_germanic', label: 'Proto-Germanic (*brōþēr)', type: 'LANGUAGE', branch: 'Germanic', timePeriod: '500 BCE' },
      
      { id: 'english', label: 'English (brother)', type: 'COGNATE', branch: 'West Germanic' },
      { id: 'spanish', label: 'Spanish (fraternal)', type: 'COGNATE', branch: 'Romance', meaning: 'Learned borrowing (hermano replaces direct parent)' },
      { id: 'german', label: 'German (Bruder)', type: 'COGNATE', branch: 'Germanic' }
    ],
    links: [
      { source: 'root', target: 'indo_iranian' },
      { source: 'root', target: 'italic' },
      { source: 'root', target: 'germanic' },
      { source: 'indo_iranian', target: 'sanskrit' },
      { source: 'italic', target: 'latin', law: 'Aspirated bʰ -> Italic f (frāter)' },
      { source: 'germanic', target: 'proto_germanic', law: 'Aspirated bʰ -> Unvoiced/Voiced stop b' },
      { source: 'proto_germanic', target: 'english' },
      { source: 'latin', target: 'spanish' },
      { source: 'proto_germanic', target: 'german' }
    ]
  }
};

// Auto-generate Graph Nodes for the remaining PIE roots
PIE_ROOT_DATABASE.forEach(item => {
  const presetKey = item.root.split('/')[0].trim() + " (" + item.divergence.english.form.split('/')[0].trim() + ")";
  
  // If it already exists, skip
  if (ETYMO_PRESETS[presetKey]) return;

  const nodes: CognateNode[] = [
    { id: 'root', label: item.root, type: 'ROOT', meaning: item.meaning },
    { id: 'indo_iranian', label: 'Indo-Iranian', type: 'BRANCH' },
    { id: 'italic', label: 'Italic', type: 'BRANCH' },
    { id: 'germanic', label: 'Germanic', type: 'BRANCH' },
    
    { id: 'sanskrit', label: 'Sanskrit (' + item.divergence.sanskrit.form.split('/')[0].trim() + ')', type: 'LANGUAGE', branch: 'Indo-Aryan', timePeriod: '1500 BCE' },
    { id: 'latin', label: 'Latin (' + item.divergence.latin.form.split('/')[0].trim() + ')', type: 'LANGUAGE', branch: 'Italic', timePeriod: '100 BCE' },
    { id: 'proto_germanic', label: 'Proto-Germanic', type: 'LANGUAGE', branch: 'Germanic', timePeriod: '500 BCE' },
    
    { id: 'english', label: 'English (' + item.divergence.english.form.split('/')[0].trim() + ')', type: 'COGNATE', branch: 'West Germanic', meaning: item.divergence.english.shift },
  ];

  const links: CognateLink[] = [
    { source: 'root', target: 'indo_iranian' },
    { source: 'root', target: 'italic' },
    { source: 'root', target: 'germanic' },
    
    { source: 'indo_iranian', target: 'sanskrit', law: item.divergence.sanskrit.shift },
    { source: 'italic', target: 'latin', law: item.divergence.latin.shift },
    { source: 'germanic', target: 'proto_germanic' },
    { source: 'proto_germanic', target: 'english', law: item.divergence.english.shift }
  ];

  // Add broad cognates
  item.cognates.forEach((cog, i) => {
    const branchId = 'cognate_branch_' + i;
    const langId = 'cognate_lang_' + i;
    nodes.push({ id: branchId, label: 'Secondary / ' + cog.lang, type: 'BRANCH' });
    nodes.push({ id: langId, label: cog.lang + ' (' + cog.form.split('/')[0].trim() + ')', type: 'COGNATE', meaning: cog.meaning });
    
    links.push({ source: 'root', target: branchId });
    links.push({ source: branchId, target: langId });
  });

  ETYMO_PRESETS[presetKey] = {
    rootName: item.root,
    rootMeaning: item.meaning,
    nodes,
    links
  };
});

interface ProtocolRecord {
  term: string;
  devanagari: string;
  literalTranslation: string;
  etymology: string;
  historicalContext: string;
  textualLineage: string;
}

const ANCIENT_PROTOCOLS_DATA: ProtocolRecord[] = [
  {
    term: "Anahata",
    devanagari: "अनाहत",
    literalTranslation: "Unstruck / Unbeaten",
    etymology: "From 'an' (not/un) + 'āhata' (struck, from the verbal root *han*, to strike / kill).",
    historicalContext: "In Indian sound philosophy, distinguishes between 'āhata nāda' (struck sound, physical vibration created by contact) and 'anāhata nāda' (unstruck sound, subtle internal vibration resonating without physical contact).",
    textualLineage: "Codified in texts like the 'Shri Tattva Cintamani' (16th century) and widely introduced to Western audiences via Arthur Avalon's (John Woodroffe) translation 'The Serpent Power'. Associated with the heart chakra, the air element, and the bija mantra 'Yam'."
  },
  {
    term: "Soham",
    devanagari: "सोऽहम्",
    literalTranslation: "I am That / I am He",
    etymology: "A sandhi (phonetic fusion) of 'saḥ' (he / that / the Absolute) + 'aham' (I).",
    historicalContext: "A core declaration of Advaita Vedanta (non-dualism). It asserts that the individual self (Jiva/Atman) and the ultimate reality (Brahman) are structurally identical. Functionally used as a natural breath mantra: 'so' upon inhalation, 'ham' upon exhalation.",
    textualLineage: "Central to the analytical framework of Adi Shankara (~8th c. CE) and deeply rooted in Upanishadic thought (conceptually parallel to the Mahavakya 'Tat Tvam Asi' structurally found in the Chandogya Upanishad)."
  },
  {
    term: "Swaha",
    devanagari: "स्वाहा",
    literalTranslation: "So be it / Hail / This offering is made",
    etymology: "Academically debated, but classically parsed as 'su' (well) + 'aha' (spoken) or structurally related to offering one's own.",
    historicalContext: "Used at the precise conclusion of mantras during Vedic fire rituals (homa/yajna). It acts as a ritual performative—sealing an utterance while making a physical or mental offering into the sacred fire.",
    textualLineage: "A cornerstone of Vedic liturgical practice, documented extensively in the oldest layers of the Vedas (Rigveda, Yajurveda) as the essential vocative to invoke Agni, the fire deity, to convey oblations to the structural divinities."
  }
];

export default function CognitiveLinguisticsExplorer() {
  const [selectedPreset, setSelectedPreset] = useState<string>('aham / ego');
  const [customWord, setCustomWord] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'GRAPH' | 'SOUND_MORPH' | 'RULES' | 'ROOT_DATABASE' | 'ECSTATIC_VS_LEXICAL' | 'ANCIENT_PROTOCOLS'>('GRAPH');
  const [selectedNode, setSelectedNode] = useState<CognateNode | null>(null);

  // Sound Morph State
  const [inputWord, setInputWord] = useState<string>('pater');
  const [grimmShiftPercent, setGrimmShiftPercent] = useState<number>(0);
  const [audioFeedback, setAudioFeedback] = useState<boolean>(true);

  // Search state for PIE Root Database
  const [pieSearch, setPieSearch] = useState<string>('');
  const [showCognatesMap, setShowCognatesMap] = useState<Record<string, boolean>>({});

  // Ecstatic & Scientific Linguistics State
  const [selectedEcstaticPreset, setSelectedEcstaticPreset] = useState<string>('LIGHT_LANGUAGE');
  const [customEcstaticText, setCustomEcstaticText] = useState<string>('');
  const [acousticScanActive, setAcousticScanActive] = useState<boolean>(false);
  const [harmonicFeedbackHz, setHarmonicFeedbackHz] = useState<number>(180);

  const svgRef = useRef<SVGSVGElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animationRef = useRef<number | null>(null);

  // Helper to map out consonant phonetic shifts (Grimm's Law simulator)
  const getGrimmShiftValue = (word: string, percentage: number): string => {
    let output = word.toLowerCase();
    
    // Voiceless stops: p -> f, t -> th, k -> h (at 100% completion)
    if (percentage > 50) {
      output = output
        .replace(/p/g, 'f')
        .replace(/t/g, 'th')
        .replace(/c/g, 'h')
        .replace(/k/g, 'h');
    }
    // High German Consonant Shift (beyond 80% Germanic maturation)
    if (percentage > 85) {
      output = output
        .replace(/d/g, 't')
        .replace(/th/g, 'd')
        .replace(/f/g, 'b');
    }
    return output;
  };

  // Synthesize sound using WebAudio based on phonetic structure (Frequency Resonance)
  const synthesizePhoneticFrequencies = () => {
    if (!audioFeedback) return;
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      // Map word vowels/lengths to synthetic harmonic frequencies
      const wordLen = inputWord.length;
      const baseFreq = 180 + (wordLen * 25) + (grimmShiftPercent * 2);
      
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(baseFreq, ctx.currentTime);
      
      // Simulate vowel resonance with secondary filter sweep
      const filter = ctx.createBiquadFilter();
      filter.type = 'peaking';
      filter.frequency.exponentialRampToValueAtTime(1200 - (grimmShiftPercent * 5), ctx.currentTime + 0.4);
      filter.Q.setValueAtTime(8, ctx.currentTime);
      
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.5);
      
      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
      
      osc.start();
      osc.stop(ctx.currentTime + 0.55);
    } catch (e) {
      console.error('Audio engine initialized context block:', e);
    }
  };

  // Canvas Sound Wave Animation for Tab V
  useEffect(() => {
    if (activeTab !== 'ECSTATIC_VS_LEXICAL' || !canvasRef.current) {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
      return;
    }

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let offset = 0;

    const renderWave = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      const width = canvas.width;
      const height = canvas.height;
      const midY = height / 2;

      // Draw grid lines
      ctx.strokeStyle = 'rgba(147, 51, 234, 0.08)';
      ctx.lineWidth = 1;
      for (let i = 0; i < width; i += 40) {
        ctx.beginPath();
        ctx.moveTo(i, 0);
        ctx.lineTo(i, height);
        ctx.stroke();
      }
      for (let j = 0; j < height; j += 40) {
        ctx.beginPath();
        ctx.moveTo(0, j);
        ctx.lineTo(width, j);
        ctx.stroke();
      }

      // We compose dynamic sine waves based on state frequencies
      const freqMultiplier = selectedEcstaticPreset === 'LIGHT_LANGUAGE' ? 0.05 : selectedEcstaticPreset === 'ESPERANTO_BRIDGE' ? 0.025 : 0.015;
      const speed = selectedEcstaticPreset === 'LIGHT_LANGUAGE' ? 0.15 : selectedEcstaticPreset === 'ESPERANTO_BRIDGE' ? 0.08 : 0.04;
      const amplitude = acousticScanActive ? 35 : 12;

      ctx.beginPath();
      ctx.strokeStyle = selectedEcstaticPreset === 'LIGHT_LANGUAGE' 
        ? '#db2777' // Pink
        : selectedEcstaticPreset === 'ESPERANTO_BRIDGE'
        ? '#0891b2' // Cyan
        : '#9333ea'; // Purple
      ctx.lineWidth = 2.5;

      for (let x = 0; x < width; x++) {
        const sin1 = Math.sin(x * freqMultiplier + offset);
        const cos1 = Math.cos(x * 0.035 - offset * 0.5);
        const sin2 = selectedEcstaticPreset === 'LIGHT_LANGUAGE' 
          ? Math.sin(x * 0.12 + offset * 1.4) * 0.3
          : 0;
        
        const y = midY + (sin1 + cos1 + sin2) * amplitude;
        
        if (x === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      }
      ctx.stroke();

      // Draw central stable line
      ctx.strokeStyle = 'rgba(168, 85, 247, 0.12)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, midY);
      ctx.lineTo(width, midY);
      ctx.stroke();

      offset += speed;
      animationRef.current = requestAnimationFrame(renderWave);
    };

    renderWave();

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [activeTab, selectedEcstaticPreset, acousticScanActive]);

  const triggerEcstaticSynth = () => {
    if (!audioFeedback) return;
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      
      const ctx = new AudioCtx();
      setAcousticScanActive(true);

      let baseHz = 180;
      let waveType: OscillatorType = 'sine';
      let duration = 1.2;

      if (selectedEcstaticPreset === 'LIGHT_LANGUAGE') {
        baseHz = 110 + Math.random() * 220;
        waveType = 'sawtooth';
        duration = 1.0;
      } else if (selectedEcstaticPreset === 'ESPERANTO_BRIDGE') {
        baseHz = 220;
        waveType = 'triangle';
        duration = 1.4;
      } else {
        baseHz = 432;
        waveType = 'sine';
        duration = 2.0;
      }

      setHarmonicFeedbackHz(baseHz);

      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gainNode = ctx.createGain();

      osc1.type = waveType;
      osc1.frequency.setValueAtTime(baseHz, ctx.currentTime);

      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(baseHz * 2.0, ctx.currentTime);

      gainNode.gain.setValueAtTime(selectedEcstaticPreset === 'LIGHT_LANGUAGE' ? 0.04 : 0.07, ctx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);

      osc1.connect(gainNode);
      if (selectedEcstaticPreset === 'SANSKRIT_PROTOCOL') {
        osc2.connect(gainNode);
      }
      gainNode.connect(ctx.destination);

      osc1.start();
      if (selectedEcstaticPreset === 'SANSKRIT_PROTOCOL') {
        osc2.start();
      }

      setTimeout(() => {
        osc1.stop();
        if (selectedEcstaticPreset === 'SANSKRIT_PROTOCOL') {
          osc2.stop();
        }
        setAcousticScanActive(false);
      }, duration * 1000);

    } catch (e) {
      console.error('Audio engine ecstatic trigger error:', e);
      setAcousticScanActive(false);
    }
  };

  // 3. Render D3 Force-Directed Network Graph
  useEffect(() => {
    if (!svgRef.current) return;

    // Fetch active root tree data
    let data = ETYMO_PRESETS[selectedPreset];
    if (!data) return;

    // Handle custom word logic dynamically
    if (customWord.trim() !== '') {
      const customRoot = `*${customWord.toLowerCase()}`;
      data = {
        rootName: customRoot,
        rootMeaning: `Indo-European dynamic construct for '${customWord}'`,
        nodes: [
          { id: 'root', label: customRoot, type: 'ROOT', meaning: `Conscious construct tracking root of ${customWord}` },
          { id: 'sanskrit', label: `Sanskrit (*${customWord}a)`, type: 'LANGUAGE', branch: 'Aryan' },
          { id: 'latin', label: `Latin (*${customWord}us)`, type: 'LANGUAGE', branch: 'Italic' },
          { id: 'english', label: `English (*${customWord})`, type: 'COGNATE', branch: 'Germanic' },
          { id: 'spanish', label: `Spanish (*${customWord}o)`, type: 'COGNATE', branch: 'Romance' }
        ],
        links: [
          { source: 'root', target: 'sanskrit' },
          { source: 'root', target: 'latin' },
          { source: 'root', target: 'english' },
          { source: 'latin', target: 'spanish' }
        ]
      };
    }

    // Set SVG size parameters safely matching sandbox space
    const width = 600;
    const height = 400;

    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();

    // Map source and target references to copy safe versions
    const nodesCopy: CognateNode[] = data.nodes.map(n => ({ ...n }));
    const linksCopy: CognateLink[] = data.links.map(l => ({ ...l }));

    // Create D3 Force simulation
    const simulation = d3.forceSimulation<CognateNode>(nodesCopy)
      .force('link', d3.forceLink<CognateNode, CognateLink>(linksCopy)
        .id(d => d.id)
        .distance((d: any) => d.type === 'ROOT' ? 90 : 70)
      )
      .force('charge', d3.forceManyBody().strength(-200))
      .force('center', d3.forceCenter(width / 2, height / 2))
      .force('collision', d3.forceCollide().radius(35));

    // Dynamic color coding matching the absolute cosmic theme
    const getNodeColor = (type: string) => {
      switch (type) {
        case 'ROOT': return '#e879f9'; // Fuchsia
        case 'BRANCH': return '#a855f7'; // Purple
        case 'LANGUAGE': return '#06b6d4'; // Cyan
        case 'COGNATE': return '#10b981'; // Emerald
        default: return '#94a3b8';
      }
    };

    // Render links
    const link = svg.append('g')
      .attr('stroke', '#3b0764')
      .attr('stroke-width', 2)
      .attr('stroke-opacity', 0.6)
      .selectAll('line')
      .data(linksCopy)
      .join('line');

    // Create container for nodes
    const node = svg.append('g')
      .selectAll('g')
      .data(nodesCopy)
      .join('g')
      .attr('class', 'node')
      .on('click', (event, d) => {
        setSelectedNode(d);
      })
      .call(d3.drag<any, any>()
        .on('start', (event, d) => {
          if (!event.active) simulation.alphaTarget(0.3).restart();
          d.fx = d.x;
          d.fy = d.y;
        })
        .on('drag', (event, d) => {
          d.fx = event.x;
          d.fy = event.y;
        })
        .on('end', (event, d) => {
          if (!event.active) simulation.alphaTarget(0);
          d.fx = null;
          d.fy = null;
        })
      );

    // Node circles with glowing filters
    node.append('circle')
      .attr('r', d => d.type === 'ROOT' ? 18 : d.type === 'BRANCH' ? 14 : d.type === 'LANGUAGE' ? 12 : 10)
      .attr('fill', d => getNodeColor(d.type))
      .attr('stroke', '#1e1b4b')
      .attr('stroke-width', 2.5);

    // Labels paired elegantly in JetBrains Mono
    node.append('text')
      .attr('dx', 18)
      .attr('dy', 4)
      .text(d => d.label)
      .attr('fill', '#f1f5f9')
      .attr('font-size', '10px')
      .attr('font-family', 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace')
      .attr('text-shadow', '0 1px 4px rgba(0,0,0,0.9)');

    // Ticks mapping updates
    simulation.on('tick', () => {
      link
        .attr('x1', (d: any) => d.source.x)
        .attr('y1', (d: any) => d.source.y)
        .attr('x2', (d: any) => d.target.x)
        .attr('y2', (d: any) => d.target.y);

      node
        .attr('transform', (d: any) => `translate(${d.x}, ${d.y})`);
    });

    return () => {
      simulation.stop();
    };

  }, [selectedPreset, customWord]);

  return (
    <div id="cognitive_linguistics_container" className="flex flex-col h-full w-full bg-[#030107] text-gray-200 p-4 sm:p-5 overflow-y-auto relative font-sans">
      
      {/* Header Panel */}
      <div className="flex flex-col gap-1 border-b border-purple-950 pb-4 mb-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-purple-950/40 rounded border border-purple-800/20 shadow-[inset_0_0_10px_rgba(168,85,247,0.1)]">
            <Landmark className="w-5 h-5 text-fuchsia-400" />
          </div>
          <div>
            <h2 className="text-lg font-black tracking-tight text-fuchsia-400 uppercase flex items-center gap-2">
              Cognitive Linguistics Explorer <span className="text-xxs font-mono text-purple-500 font-normal">v1.1 [SECURE]</span>
            </h2>
            <span className="text-[10px] font-mono text-purple-500 uppercase tracking-widest leading-none">
              Comparative Indo-European Phonology & Cognitive Etymology Sandbox
            </span>
          </div>
        </div>
      </div>

      {/* Explorer Tabs Selector */}
      <div className="flex flex-wrap gap-2 border-b border-purple-950/45 pb-2 mb-4 font-mono select-none overflow-x-auto">
        <button
          onClick={() => setActiveTab('GRAPH')}
          className={`flex items-center gap-1.5 px-3 py-1.5 border rounded text-[10.5px] font-bold uppercase tracking-wider transition-all shrink-0
            ${activeTab === 'GRAPH' 
              ? 'bg-[#140624] border-fuchsia-500/80 text-fuchsia-300 shadow-[0_0_10px_rgba(168,85,247,0.15)]' 
              : 'border-purple-950 bg-black/40 text-purple-400 hover:border-purple-800 hover:text-purple-300'
            }`}
        >
          <GitBranch className="w-3.5 h-3.5" />
          I. D3 PIE Root Graph
        </button>

        <button
          onClick={() => setActiveTab('SOUND_MORPH')}
          className={`flex items-center gap-1.5 px-3 py-1.5 border rounded text-[10.5px] font-bold uppercase tracking-wider transition-all shrink-0
            ${activeTab === 'SOUND_MORPH' 
              ? 'bg-[#140624] border-cyan-500/80 text-cyan-300 shadow-[0_0_10px_rgba(6,182,212,0.15)]' 
              : 'border-purple-950 bg-black/40 text-purple-400 hover:border-purple-800 hover:text-purple-300'
            }`}
        >
          <Volume2 className="w-3.5 h-3.5" />
          II. Consonant Morphing Lab
        </button>

        <button
          onClick={() => setActiveTab('RULES')}
          className={`flex items-center gap-1.5 px-3 py-1.5 border rounded text-[10.5px] font-bold uppercase tracking-wider transition-all shrink-0
            ${activeTab === 'RULES' 
              ? 'bg-[#140624] border-purple-500/80 text-purple-300 shadow-[0_0_10px_rgba(168,85,247,0.15)]' 
              : 'border-purple-950 bg-black/40 text-purple-400 hover:border-purple-800 hover:text-purple-300'
            }`}
        >
          <Sliders className="w-3.5 h-3.5" />
          III. Grimm's Sound Shift Laws
        </button>

        <button
          onClick={() => setActiveTab('ROOT_DATABASE')}
          className={`flex items-center gap-1.5 px-3 py-1.5 border rounded text-[10.5px] font-bold uppercase tracking-wider transition-all shrink-0
            ${activeTab === 'ROOT_DATABASE' 
              ? 'bg-[#140624] border-pink-500/80 text-pink-300 shadow-[0_0_10px_rgba(219,39,119,0.15)]' 
              : 'border-purple-950 bg-black/40 text-purple-400 hover:border-purple-800 hover:text-purple-300'
            }`}
        >
          <Database className="w-3.5 h-3.5" />
          IV. PIE Root Database
        </button>

        <button
          onClick={() => setActiveTab('ECSTATIC_VS_LEXICAL')}
          className={`flex items-center gap-1.5 px-3 py-1.5 border rounded text-[10.5px] font-bold uppercase tracking-wider transition-all shrink-0
            ${activeTab === 'ECSTATIC_VS_LEXICAL' 
              ? 'bg-[#140624] border-emerald-500/80 text-emerald-300 shadow-[0_0_10px_rgba(16,185,129,0.15)]' 
              : 'border-purple-950 bg-black/40 text-purple-400 hover:border-purple-800 hover:text-purple-300'
            }`}
        >
          <Languages className="w-3.5 h-3.5" />
          V. Ecstatic vs. Lexical Systems
        </button>

        <button
          onClick={() => setActiveTab('ANCIENT_PROTOCOLS')}
          className={`flex items-center gap-1.5 px-3 py-1.5 border rounded text-[10.5px] font-bold uppercase tracking-wider transition-all shrink-0
            ${activeTab === 'ANCIENT_PROTOCOLS' 
              ? 'bg-[#140624] border-amber-500/80 text-amber-300 shadow-[0_0_10px_rgba(245,158,11,0.15)]' 
              : 'border-purple-950 bg-black/40 text-purple-400 hover:border-purple-800 hover:text-purple-300'
            }`}
        >
          <ScrollText className="w-3.5 h-3.5" />
          VI. Ancient Protocol Library
        </button>
      </div>

      {/* Tab I: D3 Etymology Graph */}
      {activeTab === 'GRAPH' && (
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-5 w-full max-w-[1500px]">
          
          {/* Controls & Inputs Sidebar (4 cols) */}
          <div className="xl:col-span-4 flex flex-col gap-4">
            
            {/* Presets Card */}
            <div className="bg-[#0b0512] border border-purple-950/80 rounded-xl p-4 shadow-[inset_0_0_20px_rgba(168,85,247,0.02)] flex flex-col gap-3">
              <h3 className="text-fuchsia-300 font-bold uppercase tracking-wider text-xs flex items-center gap-2 font-mono">
                <BookOpen className="w-4 h-4 text-fuchsia-400" /> Presets Indo-European Roots
              </h3>
              
              <div className="grid grid-cols-1 gap-2 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                {Object.keys(ETYMO_PRESETS).map((key) => {
                  const data = ETYMO_PRESETS[key];
                  return (
                    <button
                      key={key}
                      onClick={() => {
                        setSelectedPreset(key);
                        setCustomWord('');
                      }}
                      className={`text-[10px] font-mono text-left py-2.5 px-3 border rounded transition-all flex flex-col gap-1 uppercase tracking-wide
                        ${selectedPreset === key && customWord === ''
                          ? 'bg-[#1a072d] border-fuchsia-500 text-fuchsia-300'
                          : 'border-purple-950/60 bg-black/35 text-purple-400 hover:border-purple-800 hover:text-purple-300'
                        }`}
                    >
                      <span className="font-bold flex items-center justify-between">
                        {key} <ArrowRight className="w-3 h-3 text-purple-500" />
                      </span>
                      <span className="text-[8.5px] text-purple-500 tracking-wider">
                        PIE Root: {data.rootName} ({data.rootMeaning})
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Custom Input Field */}
              <div className="mt-2 border-t border-purple-950/40 pt-3">
                <span className="text-[10px] font-mono text-purple-400 uppercase tracking-widest font-bold mb-2 block">
                  Project Custom Etymology Probe
                </span>
                <div className="relative">
                  <input
                    type="text"
                    value={customWord}
                    onChange={(e) => setCustomWord(e.target.value)}
                    placeholder="Enter base word (e.g. water, name)..."
                    className="w-full bg-black border border-purple-950 focus:border-fuchsia-500 rounded py-2 pl-3 pr-8 text-xs font-mono text-fuchsia-300 outline-none"
                  />
                  <Search className="w-3.5 h-3.5 text-purple-500 absolute right-2.5 top-2.5" />
                </div>
                <span className="text-[9px] text-purple-600 font-mono uppercase mt-1.5 block leading-relaxed">
                  *Computes direct mapping branches from generated custom Proto-Indo-European matrices on the fly.
                </span>
              </div>
            </div>

            {/* Selected Node Details SideCard */}
            <div className="bg-[#0b0512] border border-purple-950/80 rounded-xl p-4 shadow-[inset_0_0_20px_rgba(168,85,247,0.02)]">
              <h3 className="text-cyan-300 font-bold uppercase tracking-wider text-xs mb-3 flex items-center gap-2 font-mono">
                <Info className="w-4 h-4 text-cyan-400" /> Node Phylogeny details
              </h3>

              {selectedNode ? (
                <div className="font-mono text-xs flex flex-col gap-2.5">
                  <div className="p-2 sm:p-2.5 bg-black/45 border border-purple-950 rounded flex flex-col">
                    <span className="text-purple-500 uppercase text-[9px]">LOCKED COMPONENT Token:</span>
                    <span className="text-fuchsia-300 font-bold uppercase tracking-wider text-[13px]">{selectedNode.label}</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[10px]">
                    <div className="flex flex-col bg-black/30 p-2 border border-purple-950/40 rounded">
                      <span className="text-purple-600 uppercase text-[8.5px]">Evolution Type</span>
                      <span className="text-cyan-300 font-bold uppercase mt-0.5">{selectedNode.type}</span>
                    </div>

                    <div className="flex flex-col bg-black/30 p-2 border border-purple-950/40 rounded">
                      <span className="text-purple-600 uppercase text-[8.5px]">Estimated Era</span>
                      <span className="text-cyan-300 font-bold uppercase mt-0.5">{selectedNode.timePeriod || 'N/A'}</span>
                    </div>
                  </div>

                  {selectedNode.meaning && (
                    <div className="bg-black/30 p-2 border border-purple-950/40 rounded flex flex-col text-[10.5px]">
                      <span className="text-purple-600 uppercase text-[8.5px] mb-0.5">Semantic Content Value</span>
                      <span className="text-purple-300 uppercase leading-relaxed font-bold">{selectedNode.meaning}</span>
                    </div>
                  )}

                  {selectedNode.branch && (
                    <div className="p-2 border border-[#1a1c3a] bg-[#0c1324]/20 rounded text-[10.5px] flex items-center justify-between">
                      <span className="text-purple-500 uppercase text-[9px]">GENETIC STAGE BRANCH:</span>
                      <span className="text-purple-300 font-bold uppercase">{selectedNode.branch}</span>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-[10px] text-purple-600 font-mono uppercase tracking-wide leading-relaxed py-6 text-center">
                  Select or drag any active etymology node in the network to inspect deep linguistic telemetry and historical cognates.
                </div>
              )}
            </div>

          </div>

          {/* D3 visualizer SVG panel (8 cols) */}
          <div className="xl:col-span-8 flex flex-col gap-4">
            <div className="bg-black border border-purple-950 rounded-xl p-3 sm:p-4 flex flex-col min-h-[440px] shadow-[inset_0_0_40px_rgba(0,0,0,0.95)]">
              
              <div className="flex justify-between items-center font-mono border-b border-purple-950 pb-2 mb-3">
                <span className="text-fuchsia-300 font-bold uppercase tracking-widest text-[11px] flex items-center gap-2">
                  <Sparkles className="w-3.5 h-3.5 text-fuchsia-400" /> Dynamic Live Forced-Directed Phylogeny Node
                </span>
                <span className="text-[9px] text-fuchsia-500 uppercase font-bold animate-pulse">
                  ● D3 Physics Layer Real-Time Render
                </span>
              </div>

              {/* SVG D3 container */}
              <div className="flex-1 bg-black/60 rounded border border-purple-950/50 flex justify-center items-center overflow-hidden">
                <svg
                  ref={svgRef}
                  width="100%"
                  height="400"
                  viewBox="0 0 600 400"
                  className="max-w-full cursor-grab active:cursor-grabbing font-mono"
                />
              </div>

              <div className="mt-3 p-3 border border-purple-950 bg-purple-950/10 rounded-lg text-xxs font-mono text-purple-400 uppercase leading-relaxed">
                The nodes map out cognates. Note how <span className="text-fuchsia-300">*eg-ó</span> spreads across Italic (Latin ego), Hellenic (Greek ego), and Germanic branches translating cleanly into modern Yo, I, and Ich registers. Click on nodes to load etymology paths!
              </div>

            </div>
          </div>

        </div>
      )}

      {/* Tab II: Consonant Morphing Lab */}
      {activeTab === 'SOUND_MORPH' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 w-full max-w-[1500px]">
          
          {/* Controls */}
          <div className="bg-[#0b0512] border border-purple-950 rounded-xl p-4 shadow-[inset_0_0_20px_rgba(168,85,247,0.02)] flex flex-col gap-4 font-mono">
            <h3 className="text-cyan-300 font-bold uppercase tracking-wider text-xs flex items-center gap-2">
              <Volume2 className="w-4 h-4 text-cyan-400" /> Phonetic Frequency Consonant Lab
            </h3>
            
            <p className="text-[10px] text-purple-400 leading-relaxed uppercase">
              Demonstrating the mechanics of Grimm's sound laws live. Input classical sounds and morph them via Germanic sound shift frequencies.
            </p>

            <div className="bg-black/45 p-4 rounded border border-purple-950 flex flex-col gap-3">
              <span className="text-[10px] text-purple-400 uppercase font-bold">Input Latin or PIE voiceless stop vowel:</span>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={inputWord}
                  onChange={(e) => setInputWord(e.target.value)}
                  className="bg-black border border-purple-950 py-1 px-2.5 rounded text-xs font-mono text-cyan-400 focus:border-cyan-400 uppercase outline-none flex-1"
                />
                
                <button
                  onClick={synthesizePhoneticFrequencies}
                  className="bg-purple-950 border border-purple-800 hover:border-cyan-400 py-1.5 px-3 rounded text-[10.5px] font-bold text-fuchsia-300 transition-all flex items-center gap-1.5"
                >
                  <Play className="w-3.5 h-3.5" /> Synthesize
                </button>
              </div>

              <div className="flex gap-4 items-center">
                <label className="flex items-center gap-1.5 text-[9.5px] cursor-pointer text-purple-500">
                  <input
                    type="checkbox"
                    checked={audioFeedback}
                    onChange={(e) => setAudioFeedback(e.target.checked)}
                    className="accent-purple-500 cursor-pointer"
                  />
                  ENABLE SYNTH FREQUENCY FEEDBACK (WEB AUDIO API)
                </label>
              </div>
            </div>

            {/* Slider to shift */}
            <div className="bg-black/45 p-4 rounded border border-purple-950">
              <div className="flex justify-between items-center mb-1 text-xs">
                <span className="text-cyan-400 font-black">GERMANIC SHIFT CONVERGENCE:</span>
                <span className="text-cyan-300 font-bold">{grimmShiftPercent}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={grimmShiftPercent}
                onChange={(e) => setGrimmShiftPercent(Number(e.target.value))}
                className="w-full accent-cyan-400 bg-cyan-950/45 h-1.5 rounded-full cursor-pointer mt-2"
              />
              <div className="flex justify-between text-[8px] text-purple-600 mt-1 uppercase">
                <span>0% Classical (Latin / Sanskrit)</span>
                <span>80% West Germanic Shift</span>
                <span>100% High German Shift</span>
              </div>
            </div>

          </div>

          {/* Visualization Output Card */}
          <div className="bg-[#0b0512] border border-purple-950 rounded-xl p-4 flex flex-col justify-between font-mono">
            <div>
              <h3 className="text-fuchsia-300 font-bold uppercase tracking-wider text-xs mb-3 flex items-center gap-2">
                <Brain className="w-4 h-4 text-fuchsia-400" /> Transformed Word Synthesizer Output
              </h3>

              <div className="bg-black border border-purple-950 rounded-lg p-6 flex flex-col items-center justify-center gap-2 text-center min-h-[160px] relative overflow-hidden shadow-[inset_0_0_30px_rgba(0,0,0,0.85)]">
                <span className="text-purple-600 text-[8.5px] uppercase tracking-widest font-bold">MUTATED GERMANIC SHIFT ID:</span>
                
                {/* Dynamically simulated mutated word based on sliders */}
                <h2 className="text-2xl sm:text-3xl font-black text-cyan-300 uppercase tracking-widest select-all my-2 animate-fadeIn transition-all">
                  {getGrimmShiftValue(inputWord, grimmShiftPercent)}
                </h2>

                <div className="text-[10px] text-purple-400 max-w-sm font-bold uppercase">
                  {grimmShiftPercent === 0 
                    ? 'Pure Classical unshifted form (Latin / Sanskrit / Greek conserve consonants)'
                    : grimmShiftPercent > 0 && grimmShiftPercent <= 80
                    ? `Consonants shifted predictably according to Grimm's sound laws.`
                    : 'System shifted beyond Proto-Germanic into High German Consonant Shifts (du and ich)'
                  }
                </div>
              </div>
            </div>

            <div className="p-3 bg-fuchsia-950/10 border border-fuchsia-950/40 rounded text-xxs leading-relaxed">
              *The "du bist gut genug" lineage we discussed maps directly here. Classical consonants (unvoiced stops) undergo systemic, rule-governed wave transformation over long migratory periods. It is mathematical, acoustic, and logical!
            </div>
          </div>

        </div>
      )}

      {/* Tab III: Grimm's Sound Shift Laws (Cheat sheet & explanation) */}
      {activeTab === 'RULES' && (
        <div className="w-full max-w-[1500px] bg-[#0b0512] border border-purple-950 rounded-xl p-4 font-mono">
          <h3 className="text-fuchsia-300 font-bold uppercase tracking-wider text-xs mb-3 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-fuchsia-400" /> Systemic Consonant Mutations (Grimm's Sound Shift Laws)
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
            
            {/* Rule 1 */}
            <div className="p-3 bg-black/45 border border-purple-950 rounded flex flex-col gap-1.5">
              <span className="text-cyan-400 text-xs font-bold uppercase tracking-wider border-b border-purple-950 pb-1">I. Voiceless Stops to Fricatives</span>
              <div className="text-purple-300 text-[10.5px] leading-relaxed uppercase">
                <div className="mb-1"><span className="text-fuchsia-400 font-bold">*p → *f:</span> Latin <strong>p</strong>ed- ↔ English <strong>f</strong>oot</div>
                <div className="mb-1"><span className="text-fuchsia-400 font-bold">*t → *th (þ):</span> Latin <strong>t</strong>res ↔ English <strong>t</strong>hree</div>
                <div><span className="text-fuchsia-400 font-bold">*k → *h:</span> Latin <strong>c</strong>anis ↔ English <strong>h</strong>ound</div>
              </div>
            </div>

            {/* Rule 2 */}
            <div className="p-3 bg-black/45 border border-purple-950 rounded flex flex-col gap-1.5">
              <span className="text-cyan-400 text-xs font-bold uppercase tracking-wider border-b border-purple-950 pb-1">II. Voiced Stops to Voiceless</span>
              <div className="text-purple-300 text-[10.5px] leading-relaxed uppercase">
                <div className="mb-1"><span className="text-fuchsia-400 font-bold">*b → *p:</span> PIE *sli<strong>b</strong>- ↔ English sli<strong>p</strong></div>
                <div className="mb-1"><span className="text-fuchsia-400 font-bold">*d → *t:</span> Latin <strong>d</strong>eo/dō ↔ English <strong>t</strong>wo</div>
                <div><span className="text-fuchsia-400 font-bold">*g → *k:</span> Latin <strong>g</strong>ranum ↔ English <strong>c</strong>orn</div>
              </div>
            </div>

            {/* Rule 3 */}
            <div className="p-3 bg-black/45 border border-purple-950 rounded flex flex-col gap-1.5">
              <span className="text-cyan-400 text-xs font-bold uppercase tracking-wider border-b border-purple-950 pb-1">III. Aspirated to Plain Voiced</span>
              <div className="text-purple-300 text-[10.5px] leading-relaxed uppercase">
                <div className="mb-1"><span className="text-fuchsia-400 font-bold">*bʰ → *b:</span> Sanskrit <strong>bh</strong>rātṛ ↔ English <strong>b</strong>rother</div>
                <div className="mb-1"><span className="text-fuchsia-400 font-bold">*dʰ → *d:</span> Sanskrit <strong>dh</strong>ūlis ↔ English <strong>d</strong>ust</div>
                <div><span className="text-fuchsia-400 font-bold">*gʰ → *g:</span> Sanskrit Lon<strong>gh</strong>a ↔ English lon<strong>g</strong></div>
              </div>
            </div>

          </div>

          <div className="mt-4 p-3 bg-cyan-950/10 border border-cyan-950/40 rounded-lg text-xxs leading-relaxed uppercase text-cyan-400">
            *This confirms there is no randomness in IE sound mutation paths. Sound change is a continuous, predictable, mathematical trajectory of cognitive human speech across thousands of miles.
          </div>

        </div>
      )}

      {/* Tab IV: PIE Root Database */}
      {activeTab === 'ROOT_DATABASE' && (
        <div className="w-full max-w-[1500px] flex flex-col gap-4 font-mono">
          
          {/* Searching and Filter Panel */}
          <div className="bg-[#0b0512] border border-pink-950/60 rounded-xl p-4 shadow-[inset_0_0_20px_rgba(219,39,119,0.02)]">
            <div className="flex flex-col md:flex-row gap-3 items-center justify-between">
              <div>
                <h3 className="text-pink-300 font-bold uppercase tracking-wider text-xs flex items-center gap-2">
                  <Database className="w-4 h-4 text-pink-400" /> Proto-Indo-European Root Master Ledger
                </h3>
                <p className="text-[10px] text-purple-400 uppercase mt-0.5">
                  Analytical cognate index showing systemic voiceless step mutations and semantic shifts
                </p>
              </div>

              {/* Search bar */}
              <div className="relative w-full md:w-96">
                <Search className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-purple-500" />
                <input
                  type="text"
                  placeholder="SEARCH BY ROOT OR MEANING..."
                  value={pieSearch}
                  onChange={(e) => setPieSearch(e.target.value)}
                  className="w-full pl-8 pr-3 py-1.5 bg-black/50 border border-purple-900/60 rounded text-xs text-pink-200 placeholder-purple-600 focus:outline-none focus:border-pink-500/80 uppercase font-mono tracking-wider"
                />
              </div>
            </div>
          </div>

          {/* Database Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {PIE_ROOT_DATABASE.filter(item => 
              item.root.toLowerCase().includes(pieSearch.toLowerCase()) || 
              item.meaning.toLowerCase().includes(pieSearch.toLowerCase())
            ).map((item) => {
              const isExpanded = !!showCognatesMap[item.root];
              return (
                <div 
                  key={item.root} 
                  className="bg-[#09030e] border border-purple-950/80 hover:border-pink-900/40 rounded-xl p-4 transition-all duration-300 flex flex-col gap-3 shadow-md"
                >
                  {/* Title card */}
                  <div className="flex items-start justify-between border-b border-purple-950/50 pb-2">
                    <div>
                      <span className="text-sm font-black text-pink-300 tracking-tight font-mono">{item.root}</span>
                      <span className="text-[10px] text-fuchsia-400/80 ml-2 uppercase tracking-wide">Prefix/Root Group</span>
                    </div>
                    <span className="text-[10.5px] uppercase font-bold text-purple-400 bg-purple-950/40 border border-purple-900/40 px-2 py-0.5 rounded leading-none">
                      Active Node
                    </span>
                  </div>

                  {/* Core Meaning */}
                  <div>
                    <span className="text-[10px] text-purple-500 font-bold uppercase block mb-0.5">Primary Reconstructed Meaning:</span>
                    <p className="text-xs text-gray-300 uppercase leading-relaxed font-sans font-medium">{item.meaning}</p>
                  </div>

                  {/* Tri-Divergence Table (English, Sanskrit, Latin) */}
                  <div className="bg-black/35 border border-purple-950 rounded p-2.5 flex flex-col gap-2 font-mono text-xxs">
                    <div className="grid grid-cols-12 gap-1 border-b border-purple-950/40 pb-1 text-purple-400 font-bold uppercase">
                      <div className="col-span-3">Language</div>
                      <div className="col-span-3">Reflected Form</div>
                      <div className="col-span-6">Sound Shift / Mutation Pattern</div>
                    </div>

                    {/* English */}
                    <div className="grid grid-cols-12 gap-1 items-center border-b border-purple-950/20 pb-1">
                      <div className="col-span-3 text-cyan-400 font-bold uppercase">English</div>
                      <div className="col-span-3 text-pink-200 font-bold">{item.divergence.english.form}</div>
                      <div className="col-span-6 text-gray-400 uppercase leading-tight">
                        {item.divergence.english.shift}{" "}
                        <span className="text-fuchsia-400 font-semibold">[ex: {item.divergence.english.example}]</span>
                      </div>
                    </div>

                    {/* Sanskrit */}
                    <div className="grid grid-cols-12 gap-1 items-center border-b border-purple-950/20 pb-1">
                      <div className="col-span-3 text-yellow-500 font-bold uppercase">Sanskrit</div>
                      <div className="col-span-3 text-pink-200 font-medium">{item.divergence.sanskrit.form}</div>
                      <div className="col-span-6 text-gray-400 uppercase leading-tight">
                        {item.divergence.sanskrit.shift}{" "}
                        <span className="text-fuchsia-400 font-semibold">[ex: {item.divergence.sanskrit.example}]</span>
                      </div>
                    </div>

                    {/* Latin */}
                    <div className="grid grid-cols-12 gap-1 items-center">
                      <div className="col-span-3 text-emerald-400 font-bold uppercase">Latin</div>
                      <div className="col-span-3 text-pink-200 font-medium">{item.divergence.latin.form}</div>
                      <div className="col-span-6 text-gray-400 uppercase leading-tight">
                        {item.divergence.latin.shift}{" "}
                        <span className="text-fuchsia-400 font-semibold">[ex: {item.divergence.latin.example}]</span>
                      </div>
                    </div>
                  </div>

                  {/* Toggle Cognates and View Graph Segment */}
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setShowCognatesMap(prev => ({ ...prev, [item.root]: !isExpanded }))}
                      className="w-full text-center py-1 border border-purple-950 bg-purple-950/10 hover:bg-pink-950/10 hover:border-pink-900/50 text-[10px] text-pink-400 font-bold uppercase tracking-wider rounded transition-all flex items-center justify-center gap-1"
                    >
                      <Sparkles className="w-3 h-3 text-pink-400" />
                      {isExpanded ? "Hide Broad Cognates" : "Show Broad Cognates"}
                    </button>

                    <button
                      onClick={() => {
                        const presetKey = item.root.split('/')[0].trim() + " (" + item.divergence.english.form.split('/')[0].trim() + ")";
                        setSelectedPreset(presetKey);
                        setActiveTab('GRAPH');
                      }}
                      className="w-full text-center py-1 border border-cyan-950 bg-cyan-950/10 hover:bg-cyan-950/30 hover:border-cyan-900/50 text-[10px] text-cyan-400 font-bold uppercase tracking-wider rounded transition-all flex items-center justify-center gap-1"
                    >
                      <GitBranch className="w-3 h-3 text-cyan-400" />
                      View Topological Graph
                    </button>
                  </div>

                  {isExpanded && (
                      <div className="bg-black/50 border border-pink-950/30 rounded p-2 flex flex-col gap-1.5 animate-fadeIn">
                        <span className="text-[9px] text-pink-500 font-bold uppercase tracking-widest mb-1 block border-b border-pink-950/20 pb-0.5">
                          Extended Indo-European Dialectal Refraction:
                        </span>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xxs">
                          {item.cognates.map((cog, index) => (
                            <div key={index} className="flex gap-1.5 items-start p-1 bg-purple-950/5 border border-purple-950/35 rounded uppercase">
                              <span className="text-pink-400 font-bold shrink-0">{cog.lang}:</span>
                              <div className="text-gray-300">
                                <span className="font-bold text-gray-100">{cog.form}</span>
                                <span className="text-purple-400 text-[10px] ml-1">({cog.meaning})</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                </div>
              );
            })}
          </div>

          <div className="p-3 bg-pink-950/10 border border-pink-950/30 rounded-lg text-xxs tracking-normal leading-relaxed text-pink-400 uppercase">
            *Prefix structures show absolute mathematical alignment. Consonants morph systematically between Sanskrit, Latin, and English based strictly on Grimm's acoustic waveform laws. Every modern cognate traces back mathematically to its 5000 BCE center of gravity.
          </div>

        </div>
      )}

      {/* Tab V: Ecstatic vs. Lexical Systems */}
      {activeTab === 'ECSTATIC_VS_LEXICAL' && (
        <div className="w-full max-w-[1500px] flex flex-col gap-4 font-mono">
          
          {/* Main Context Card */}
          <div className="grid grid-cols-1 xl:grid-cols-12 gap-5">
            
            {/* Interactive Frequencies Panel (7 cols) */}
            <div className="xl:col-span-7 flex flex-col gap-4">
              
              <div className="bg-[#0b0512] border border-purple-950 rounded-xl p-4 flex flex-col gap-3">
                <h3 className="text-emerald-300 font-bold uppercase tracking-wider text-xs flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-emerald-400" /> Acoustic Phonetic Synthetics Analyzer
                </h3>
                <p className="text-[10px] text-purple-400 uppercase">
                  Simulating frequency characteristics of ecstatic glossolalia, structured semantics, and liturgical chants
                </p>

                {/* Preset selectors */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-2 border-b border-purple-950/40 pb-3">
                  {/* Glossolalia */}
                  <button
                    onClick={() => {
                      setSelectedEcstaticPreset('LIGHT_LANGUAGE');
                      setCustomEcstaticText('salidrin sin astrazax');
                    }}
                    className={`p-2.5 border rounded text-left flex flex-col gap-1 transition-all ${
                      selectedEcstaticPreset === 'LIGHT_LANGUAGE'
                        ? 'bg-pink-950/10 border-pink-500/80 text-pink-300'
                        : 'border-purple-950 bg-black/45 text-purple-400 hover:border-purple-900'
                    }`}
                  >
                    <span className="text-xxs font-black tracking-widest uppercase">I. Glossolalia Preset</span>
                    <span className="text-[10.5px] font-bold text-gray-200">"Salidrin Sin Astrazax"</span>
                    <span className="text-[9px] uppercase text-purple-500 mt-1">Non-conceptual vibrational resonance</span>
                  </button>

                  {/* Esperanto */}
                  <button
                    onClick={() => {
                      setSelectedEcstaticPreset('ESPERANTO_BRIDGE');
                      setCustomEcstaticText('viu n harmonio kai kun amo');
                    }}
                    className={`p-2.5 border rounded text-left flex flex-col gap-1 transition-all ${
                      selectedEcstaticPreset === 'ESPERANTO_BRIDGE'
                        ? 'bg-cyan-950/10 border-cyan-500/80 text-cyan-300'
                        : 'border-purple-950 bg-black/45 text-purple-400 hover:border-purple-900'
                    }`}
                  >
                    <span className="text-xxs font-black tracking-widest uppercase">II. Conlang Bridge</span>
                    <span className="text-[10.5px] font-bold text-gray-200">"Viu n harmonio kaj kun amo"</span>
                    <span className="text-[9px] uppercase text-purple-500 mt-1">Structured Synthetic Semantics</span>
                  </button>

                  {/* Sanskrit Protocol */}
                  <button
                    onClick={() => {
                      setSelectedEcstaticPreset('SANSKRIT_PROTOCOL');
                      setCustomEcstaticText('anahata hum sa swaha');
                    }}
                    className={`p-2.5 border rounded text-left flex flex-col gap-1 transition-all ${
                      selectedEcstaticPreset === 'SANSKRIT_PROTOCOL'
                        ? 'bg-purple-950/15 border-purple-500/80 text-purple-300'
                        : 'border-purple-950 bg-black/45 text-purple-400 hover:border-purple-900'
                    }`}
                  >
                    <span className="text-xxs font-black tracking-widest uppercase">III. Rigorous Liturgical</span>
                    <span className="text-[10.5px] font-bold text-gray-200">"Anahata hum sa swaha"</span>
                    <span className="text-[9px] uppercase text-purple-500 mt-1">Systemic Vedic sound sequence</span>
                  </button>
                </div>

                {/* Sub-Phoneme Display and Live Edit */}
                <div className="flex flex-col gap-1.5">
                  <span className="text-xxs text-purple-400 uppercase font-bold">Acoustic Input Sequence:</span>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={customEcstaticText || (selectedEcstaticPreset === 'LIGHT_LANGUAGE' ? 'salidrin sin astrazax' : selectedEcstaticPreset === 'ESPERANTO_BRIDGE' ? 'viu n harmonio kai kun amo' : 'anahata hum sa swaha')}
                      onChange={(e) => setCustomEcstaticText(e.target.value)}
                      className="flex-1 bg-black/50 border border-purple-950 rounded px-2.5 py-1.5 text-xs text-emerald-200 font-mono tracking-wider uppercase focus:outline-none focus:border-emerald-500/50"
                    />
                    <button
                      onClick={triggerEcstaticSynth}
                      className={`px-4 py-1.5 rounded bg-emerald-950/20 hover:bg-emerald-900/40 border border-emerald-800 text-xxs font-black uppercase text-emerald-300 tracking-wider transition-all flex items-center gap-1.5 ${
                        acousticScanActive ? 'animate-pulse border-emerald-500 text-emerald-100 shadow-[0_0_10px_rgba(16,185,129,0.2)]' : ''
                      }`}
                    >
                      <Play className="w-3.5 h-3.5" />
                      {acousticScanActive ? 'Scanning Freq...' : 'Trigger scan'}
                    </button>
                  </div>
                </div>

                {/* Simulated Acoustic Waveform Canvas */}
                <div className="relative border border-purple-950 bg-black/60 rounded-lg p-2 flex flex-col gap-1 overflow-hidden h-40">
                  <div className="absolute top-2 left-2 z-10 flex items-center gap-2 font-mono text-xxs uppercase">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping"></span>
                    <span className="text-emerald-400">Status: Spectral Oscillographic Analyzer Active</span>
                    <span className="text-[10px] text-purple-500">| Fundamental: {harmonicFeedbackHz} Hz</span>
                  </div>
                  
                  <canvas 
                    ref={canvasRef} 
                    width={550} 
                    height={150} 
                    className="w-full h-full rounded"
                  />
                </div>

                {/* Diagnostics Ledger */}
                <div className="p-3 bg-black/40 border border-purple-950 rounded uppercase font-mono text-xxs flex flex-col gap-1">
                  <span className="text-purple-400 font-bold">Phenogram Diagnostics Vector:</span>
                  <div className="grid grid-cols-2 gap-2 text-gray-300">
                    <div>
                      - Sound Wave Type: <span className="text-cyan-400">{selectedEcstaticPreset === 'LIGHT_LANGUAGE' ? 'Complex Sawtooth (varying peaks)' : selectedEcstaticPreset === 'ESPERANTO_BRIDGE' ? 'Stable Triangle (harmonic)' : 'Pure Sinusoidal'}</span>
                    </div>
                    <div>
                      - Cognitive Frame: <span className="text-cyan-400">{selectedEcstaticPreset === 'LIGHT_LANGUAGE' ? 'Non-Translational Waveform' : 'Synthesized / Morphological'}</span>
                    </div>
                    <div>
                      - Frequency Resonance: <span className="text-cyan-400">{harmonicFeedbackHz} Hz</span>
                    </div>
                    <div>
                      - Entropy Index: <span className="text-cyan-400">{selectedEcstaticPreset === 'LIGHT_LANGUAGE' ? 'Extremely High (unstructured)' : 'Predictable / Law-governed'}</span>
                    </div>
                  </div>
                </div>

              </div>

            </div>

            {/* Scientific Explanation Panel (5 cols) */}
            <div className="xl:col-span-5 flex flex-col gap-4">
              
              <div className="bg-[#0b0512] border border-purple-950 rounded-xl p-4 flex flex-col gap-3 h-full justify-between">
                <div>
                  <h3 className="text-purple-300 font-bold uppercase tracking-wider text-xs flex items-center gap-2">
                    <Brain className="w-4 h-4 text-purple-400" /> Neural & Acoustic Distinctions
                  </h3>
                  <div className="flex flex-col gap-2.5 mt-2 font-sans text-xs text-gray-300 leading-relaxed">
                    <p>
                      <strong className="text-pink-400 font-bold font-mono uppercase block text-xxs mb-0.5">I. Glossolalia (Trance Utility / "Light Language")</strong>
                      In physical linguistics, glossolalia represents rapid phonetic generation bypassing structural syntactical networks. Research (e.g., neuroscience scanning of Pentecostal and shamanic trance states) shows a marked <span className="text-fuchsia-400 font-semibold">decrease in prefrontal cortex activity</span>. Since no lexicon exists, there is no root divergence. It utilizes native phonemes to create soundscapes designed purely for somatic, aesthetic, or state-shifting feedback loops.
                    </p>

                    <p>
                      <strong className="text-cyan-400 font-bold font-mono uppercase block text-xxs mb-0.5">II. Conlangs (Esperanto / Constructed Languages)</strong>
                      These utilize conscious, formal mathematical syntax rules. While synthetic, they can easily map to PIE root precursors (e.g. Esperanto <span className="text-cyan-400">harmonio</span> derives via Latin/Greek from PIE <span className="text-cyan-400">*ar- / *h₂ar-</span> "to fit together").
                    </p>

                    <p>
                      <strong className="text-yellow-500 font-bold font-mono uppercase block text-xxs mb-0.5">III. Systemic Liturgical Formulas (Sanskrit Mantra)</strong>
                      Sanskrit utilizes rigid structural grammar and phonetic sequencing. Every syllable is documented and etymologically trackable:
                      <ul className="list-disc pl-4 mt-1 font-mono text-[10px] text-purple-300 flex flex-col gap-0.5 uppercase">
                        <li><strong>Anahata (अनाहत):</strong> "Unstruck" — Root word *han ("strike"). Represents cardiac subtle vibrations.</li>
                        <li><strong>Ham (Soham / सोऽहम्):</strong> Fusion of "Saḥ" (That) and "Aham" (I). The absolute formula of ultimate identity integration.</li>
                        <li><strong>Swaha (स्वाहा):</strong> Traditional performative Vedic sealant of ritual fire offerings.</li>
                      </ul>
                    </p>
                  </div>
                </div>

                <div className="mt-4 p-3 bg-emerald-950/15 border border-emerald-950/30 rounded-lg text-xxs leading-relaxed uppercase text-emerald-400">
                  *Clinical Conclusion: The operator utilizes Glossolalia to bypass logical prefrontal filters, while Sanskrit operates as a highly mathematics-driven sound program. Together they represent the two polar fields of acoustic output.
                </div>

              </div>

            </div>

          </div>

        </div>
      )}

      {/* Tab VI: Ancient Protocol Library */}
      {activeTab === 'ANCIENT_PROTOCOLS' && (
        <div className="w-full max-w-[1500px] flex flex-col gap-4 font-mono pb-8">
          
          <div className="bg-[#0b0512] border border-amber-950/60 rounded-xl p-4 flex flex-col gap-3 shadow-[inset_0_0_20px_rgba(245,158,11,0.02)]">
            <h3 className="text-amber-300 font-bold uppercase tracking-wider text-xs flex items-center gap-2">
              <ScrollText className="w-4 h-4 text-amber-400" /> Systemic Liturgical Formulas & Ancient Protocols
            </h3>
            <p className="text-[10.5px] text-amber-500/80 uppercase">
              Academic translation matrix isolating structural formulas from pseudo-scientific definitions
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            {ANCIENT_PROTOCOLS_DATA.map((protocol, idx) => (
              <div key={idx} className="bg-[#09030e] border border-amber-900/40 rounded-xl p-5 flex flex-col gap-4 shadow-md hover:border-amber-700/60 transition-colors">
                
                <div className="flex flex-col gap-1 border-b border-amber-900/40 pb-3 relative">
                  <div className="absolute right-0 top-0 bg-amber-950/40 border border-amber-900/30 rounded px-2.5 py-1">
                    <span className="text-xl font-bold text-amber-100 leading-none">{protocol.devanagari}</span>
                  </div>
                  <h4 className="text-xl font-black text-amber-300 tracking-tight font-sans pr-14">{protocol.term}</h4>
                  <span className="text-[11px] text-amber-500/60 uppercase tracking-widest font-bold">
                    {protocol.literalTranslation}
                  </span>
                </div>

                <div className="flex flex-col gap-3 text-xs leading-relaxed text-gray-300 font-sans">
                  
                  <div>
                    <span className="text-[9.5px] text-amber-500 font-bold font-mono uppercase block mb-1">
                      Structural Etymology:
                    </span>
                    <p className="bg-black/40 border border-amber-950/50 rounded p-2.5 text-amber-200/80 italic">
                      {protocol.etymology}
                    </p>
                  </div>

                  <div>
                    <span className="text-[9.5px] text-amber-500 font-bold font-mono uppercase block mb-1 mt-1">
                      Academic Context & Mechanism:
                    </span>
                    <p className="text-[11.5px]">
                      {protocol.historicalContext}
                    </p>
                  </div>

                  <div>
                    <span className="text-[9.5px] text-amber-500 font-bold font-mono uppercase block mb-1 mt-1">
                      Textual Lineage & Source:
                    </span>
                    <p className="text-gray-400 text-[11px]">
                      {protocol.textualLineage}
                    </p>
                  </div>

                </div>

              </div>
            ))}
          </div>

          <div className="mt-2 p-3 bg-amber-950/15 border border-amber-900/30 rounded-lg text-xxs tracking-wide leading-relaxed uppercase text-amber-500/80 font-mono">
            *Historical Objective: These terms represent highly rigid, mathematically structured sonic protocols engineered by classical Indic philosophers. They are historically distinct from unstructured trance output (glossolalia) and maintain precise grammatical and metaphysical constraints structurally derived from native Indo-European linguistic roots.
          </div>

        </div>
      )}

    </div>
  );
}
