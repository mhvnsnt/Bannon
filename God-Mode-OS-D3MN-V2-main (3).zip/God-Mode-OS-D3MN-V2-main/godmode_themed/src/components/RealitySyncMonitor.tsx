import React, { useState, useEffect } from 'react';
import { Activity, Globe, Database, Network } from 'lucide-react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';

interface SyncLog {
    timestamp: string;
    physicalTimeMs: number;
    event: string;
    details: any;
}

export default function RealitySyncMonitor() {
    const [logs, setLogs] = useState<SyncLog[]>([]);
    const [driftData, setDriftData] = useState<any[]>([]);

    useEffect(() => {
        fetchLogs();
        const interval = setInterval(fetchLogs, 5000); // Check every 5s
        return () => clearInterval(interval);
    }, []);

    const fetchLogs = async () => {
        try {
            const res = await fetch('/api/armada/quantum/sync/logs');
            const data = await res.json();
            if (data.success) {
                setLogs(data.logs.reverse().slice(0, 50)); // Keep last 50
                
                // Extract atomic sync drifts
                const drifts = data.logs
                    .filter((log: SyncLog) => log.event === 'ATOMIC_SYNC')
                    .map((log: SyncLog) => ({
                        time: new Date(log.timestamp).toLocaleTimeString(),
                        drift: log.details.drift || 0
                    }))
                    .slice(-20); // Last 20 syncs
                setDriftData(drifts);
            }
        } catch (e) {
             console.log("Failed to fetch reality sync logs");
        }
    };

    return (
        <div className="p-6 h-full overflow-auto text-white">
            <h2 className="text-2xl font-bold mb-4 text-emerald-400 border-b border-emerald-900 pb-2 flex items-center gap-2">
                <Globe className="w-6 h-6" />
                Reality Sync Monitor
            </h2>
            <p className="text-sm text-gray-400 mb-6">
                Tracking alignment between the structural engine timeline and physical spatial coordinates.
            </p>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
                {/* Drift Chart */}
                <div className="bg-[#111] border border-[#222] rounded-xl p-4 shadow-[0_0_15px_rgba(16,185,129,0.05)]">
                    <h3 className="text-sm font-bold tracking-widest text-emerald-500 uppercase mb-4 flex items-center gap-2">
                        <Activity className="w-4 h-4"/> Temporal Drift Tolerance
                    </h3>
                    <div className="h-48">
                         <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={driftData}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#222" />
                                <XAxis dataKey="time" stroke="#444" fontSize={10} />
                                <YAxis stroke="#444" fontSize={10} />
                                <Tooltip contentStyle={{ backgroundColor: '#000', border: '1px solid #333' }} />
                                <Line type="monotone" dataKey="drift" stroke="#10b981" strokeWidth={2} dot={false} />
                            </LineChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                 {/* Latent Action Stream */}
                 <div className="bg-[#111] border border-[#222] rounded-xl p-4 overflow-hidden relative">
                    <h3 className="text-sm font-bold tracking-widest text-cyan-500 uppercase mb-4 flex items-center gap-2">
                        <Network className="w-4 h-4"/> Physical Action Feed
                    </h3>
                    <div className="space-y-3 overflow-y-auto h-48 pr-2">
                        {logs.map((log, i) => (
                            <div key={i} className="flex flex-col border-l-2 border-emerald-500/50 pl-3">
                                <div className="flex justify-between items-center w-full">
                                   <span className="text-xs font-mono text-emerald-400">{log.event}</span>
                                   <span className="text-[10px] text-gray-500">{new Date(log.timestamp).toLocaleTimeString()}</span>
                                </div>
                                {log.details && (
                                   <div className="text-[10px] text-gray-400 mt-1 truncate">
                                       {JSON.stringify(log.details)}
                                   </div>
                                )}
                            </div>
                        ))}
                        {logs.length === 0 && (
                            <div className="text-gray-500 text-sm text-center mt-8">Establishing sync connection...</div>
                        )}
                    </div>
                 </div>
            </div>
        </div>
    );
}
