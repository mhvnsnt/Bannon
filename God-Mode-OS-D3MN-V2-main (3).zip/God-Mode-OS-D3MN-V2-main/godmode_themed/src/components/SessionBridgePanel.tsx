import React, { useEffect, useState } from 'react';
import { 
  Terminal, Database, Copy, Check, PlusCircle, Clock, 
  ExternalLink, FileCode, Target, ArrowRight, ShieldAlert,
  Bot, RefreshCw, Layers, History, HelpCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface Project {
  project: string;
  session_count: number;
  last_active: string;
  last_summary: string;
}

interface Session {
  id: string;
  platform: string;
  timestamp: string;
  summary: string;
  files_touched: string[];
  key_decisions: string[];
  next_target: string;
  title?: string;
  url?: string;
}

export default function SessionBridgePanel() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [selectedProject, setSelectedProject] = useState<string | null>(null);
  const [activePrompt, setActivePrompt] = useState<string>('');
  const [history, setHistory] = useState<Session[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [copied, setCopied] = useState<boolean>(false);
  const [showModal, setShowModal] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchProjects();
  }, []);

  const fetchProjects = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/godmode/projects');
      const data = await res.json();
      if (data.success) {
        setProjects(data.projects);
        if (data.projects.length > 0 && !selectedProject) {
          handleSelectProject(data.projects[0].project);
        }
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSelectProject = async (projName: string) => {
    setSelectedProject(projName);
    setError(null);
    setCopied(false);

    try {
      // Fetch prompt
      const promptRes = await fetch(`/api/godmode/last-session/${projName}`);
      const promptData = await promptRes.json();
      if (promptData.success) {
        setActivePrompt(promptData.injection_prompt || '');
      } else {
        setActivePrompt(`Error loading injection block: ${promptData.error || 'Unknown error'}`);
      }

      // Fetch history
      const historyRes = await fetch(`/api/godmode/session-history/${projName}`);
      const historyData = await historyRes.json();
      if (historyData.success) {
        setHistory(historyData.sessions || []);
      }
    } catch (err: any) {
      setError(`Failed to retrieve project details: ${err.message}`);
    }
  };

  const copyToClipboard = () => {
    if (!activePrompt) return;
    navigator.clipboard.writeText(activePrompt);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getPlatformIcon = (platform: string) => {
    const raw = platform.toLowerCase();
    if (raw.includes('claude')) {
      return <div className="text-amber-500 bg-amber-950/40 px-1.5 py-0.5 rounded text-[8px] font-black border border-amber-900/50">CLAUDE</div>;
    } else if (raw.includes('gemini') || raw.includes('aistudio')) {
      return <div className="text-cyan-400 bg-cyan-950/40 px-1.5 py-0.5 rounded text-[8px] font-black border border-cyan-900/50">GEMINI</div>;
    } else {
      return <div className="text-emerald-400 bg-emerald-950/40 px-1.5 py-0.5 rounded text-[8px] font-black border border-emerald-900/50">{platform.toUpperCase()}</div>;
    }
  };

  return (
    <div className="flex flex-col lg:flex-row h-full min-h-[500px] w-full bg-[#030305] text-[#00e5ff] font-sans border border-cyan-950/30 rounded-lg overflow-hidden shadow-2xl">
      {/* LEFT PANEL: Project Inventory */}
      <div className="w-full lg:w-80 border-r border-cyan-950/50 bg-[#050508] p-4 flex flex-col shrink-0">
        <div className="flex items-center justify-between border-b border-cyan-950 pb-3 mb-4">
          <h3 className="text-xs font-black uppercase tracking-widest text-[#00e5ff] flex items-center gap-2">
            <Database className="w-4 h-4 text-[#00e5ff]" />
            PROJECT INDEX
          </h3>
          <button 
            onClick={fetchProjects}
            className="p-1 hover:bg-cyan-950/50 border border-transparent hover:border-cyan-500/30 rounded transition-all text-cyan-400"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>

        {loading && projects.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center text-xs font-mono text-cyan-600 uppercase py-6">
            <RefreshCw className="w-6 h-6 animate-spin mb-2" />
            Synchronizing...
          </div>
        ) : projects.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center p-6 text-center text-xs font-mono text-cyan-700">
            <ShieldAlert className="w-8 h-8 text-cyan-600 mb-2 opacity-50" />
            NO UBL QUANTUM PROJECTS REGISTERED
            <p className="text-[10px] text-gray-500 mt-2 leading-relaxed">
              Use the Chrome/Tampermonkey session exporter in Claude or AI Studio to harvest sessions.
            </p>
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto space-y-2.5 pr-1 no-scrollbar">
            {projects.map((proj) => {
              const active = proj.project === selectedProject;
              return (
                <button
                  key={proj.project}
                  onClick={() => handleSelectProject(proj.project)}
                  className={`w-full text-left p-3.5 rounded-lg border transition-all flex flex-col justify-between group ${
                    active 
                      ? 'border-[#00e5ff] bg-cyan-950/20 shadow-[0_0_15px_rgba(0,e5,ff,0.1)]' 
                      : 'border-cyan-950/60 bg-[#09090e]/80 hover:bg-[#0d0d14]/80 hover:border-cyan-900/60'
                  }`}
                >
                  <div className="flex justify-between items-start w-full mb-1">
                    <span className={`text-xs font-black uppercase tracking-wider ${active ? 'text-white' : 'text-cyan-400 group-hover:text-cyan-300'}`}>
                      {proj.project}
                    </span>
                    <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-[#111] border border-cyan-950 text-cyan-500">
                      {proj.session_count} Syncs
                    </span>
                  </div>

                  <p className="text-[10px] text-gray-500 line-clamp-2 mt-1 leading-relaxed">
                    {proj.last_summary || 'No summary registered.'}
                  </p>

                  <div className="flex justify-between items-center mt-3 pt-2.5 border-t border-cyan-950/40 text-[9px] text-gray-500 font-mono">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-cyan-600" />
                      {new Date(proj.last_active).toLocaleDateString()}
                    </span>
                    <span className="text-[8px] opacity-0 group-hover:opacity-100 text-[#00e5ff] transition-all flex items-center gap-0.5">
                      RETRIEVE <ArrowRight className="w-2.5 h-2.5" />
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* RIGHT PANEL: Workspace Context Inoculator */}
      <div className="flex-1 bg-[#050508]/40 p-5 flex flex-col min-w-0">
        {selectedProject ? (
          <div className="flex-1 flex flex-col min-w-0">
            {/* Header Toolbar */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-cyan-950/80 pb-4 mb-4">
              <div>
                <h2 className="text-sm font-black uppercase tracking-widest text-[#00e5ff] flex items-center gap-1.5">
                  <Layers className="w-4 h-4 text-emerald-400" />
                  GOD-MODE OS CONTEXT RECOV PROTOCOL <span className="text-cyan-800">::</span> <span className="text-white">{selectedProject}</span>
                </h2>
                <span className="text-[10px] font-mono text-[#00d4c8]/60 uppercase ml-5.5 block">
                  Synchronous AI Session Context Injection Matrix
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={copyToClipboard}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-[#00e5ff]/10 hover:bg-[#00e5ff]/20 text-[#00e5ff] border border-[#00e5ff]/50 hover:border-[#00e5ff] rounded text-xs font-semibold uppercase tracking-wider transition-all"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" /> COPIED!
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" /> COPY CONTEXT
                    </>
                  )}
                </button>

                <button
                  onClick={() => setShowModal(true)}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 hover:border-emerald-500 rounded text-xs font-semibold uppercase tracking-wider transition-all"
                >
                  <PlusCircle className="w-3.5 h-3.5" /> NEW SESSION
                </button>
              </div>
            </div>

            {error && (
              <div className="mb-4 bg-red-950/20 border border-red-900/50 p-3 rounded text-xs text-red-400 font-mono">
                {error}
              </div>
            )}

            {/* Content Split: Formatted Prompt Textbox / Timeline */}
            <div className="flex-1 grid grid-cols-1 xl:grid-cols-5 gap-6 min-h-0 overflow-y-auto no-scrollbar">
              {/* Prompt Card */}
              <div className="xl:col-span-3 flex flex-col h-full bg-[#030305] border border-cyan-950/80 rounded-xl p-4 shadow-inner min-h-[350px]">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-[10px] font-mono text-emerald-400 font-bold uppercase tracking-wider flex items-center gap-1">
                    <Terminal className="w-3.5 h-3.5" /> INJECTION PROMPT
                  </span>
                  <span className="text-[9px] text-gray-500 font-mono uppercase">
                    Markdown Format · No Truncation
                  </span>
                </div>

                <div className="flex-1 relative mt-1 overflow-hidden rounded-lg border border-cyan-950/80">
                  <textarea
                    readOnly
                    value={activePrompt}
                    className="absolute inset-0 w-full h-full p-4.5 bg-black/80 text-cyan-300 font-mono text-[10.5px] leading-relaxed resize-none focus:outline-none no-scrollbar"
                  />
                </div>
              </div>

              {/* Session Timeline */}
              <div className="xl:col-span-2 flex flex-col h-full bg-[#030305] border border-cyan-950/80 rounded-xl p-4 shadow-inner min-h-[350px]">
                <div className="flex justify-between items-center mb-4">
                  <span className="text-[10px] font-mono text-cyan-400 font-bold uppercase tracking-wider flex items-center gap-1">
                    <History className="w-3.5 h-3.5" /> SESSION TIMELINE [LAST 10]
                  </span>
                  <span className="text-[9px] text-cyan-600 font-mono uppercase">
                    Chronological Stack
                  </span>
                </div>

                <div className="flex-1 overflow-y-auto space-y-4 pr-1 no-scrollbar">
                  {history.length === 0 ? (
                    <div className="h-full flex items-center justify-center text-center text-xs font-mono text-cyan-800">
                      No matching historical logs found for this sector.
                    </div>
                  ) : (
                    history.map((session, i) => (
                      <div key={session.id} className="relative pl-5 border-l border-cyan-950/80 pb-1">
                        {/* Bullet circle */}
                        <div className="absolute top-1 -left-1 w-2.5 h-2.5 rounded-full border border-cyan-400 bg-black shadow-[0_0_8px_cyan]" />

                        <div className="flex justify-between items-center mb-1">
                          <span className="text-[9px] text-gray-500 font-mono">
                            {new Date(session.timestamp).toLocaleString()}
                          </span>
                          {getPlatformIcon(session.platform)}
                        </div>

                        <div className="bg-[#09090e]/80 border border-cyan-950/50 p-2.5 rounded-lg mt-1.5 hover:border-cyan-900/50 transition-colors">
                          <p className="text-[10px] text-cyan-200 leading-relaxed font-mono whitespace-pre-wrap">
                            {session.summary}
                          </p>

                          {session.key_decisions && session.key_decisions.length > 0 && (
                            <div className="mt-2 pt-2 border-t border-cyan-950/50">
                              <span className="text-[8px] font-black uppercase text-amber-500 block mb-1">▶ DECISIONS REGISTERED</span>
                              <ul className="list-disc list-inside space-y-1 pl-1 text-[9px] text-gray-400 font-mono">
                                {session.key_decisions.map((dec, idx) => (
                                  <li key={idx}>{dec}</li>
                                ))}
                              </ul>
                            </div>
                          )}

                          {session.next_target && (
                            <div className="mt-2 pt-2 border-t border-cyan-950/50">
                              <span className="text-[8px] font-black uppercase text-cyan-400 block mb-0.5">▶ NEXT DIRECTIVE</span>
                              <span className="text-[9px] text-emerald-400 font-mono">{session.next_target}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-center p-8">
            <Layers className="w-12 h-12 text-cyan-950/30 mb-3 animate-pulse" />
            <h3 className="text-gray-400 text-xs font-bold uppercase tracking-wider mb-2">
              NO ACTIVE PROJECT SELECTED
            </h3>
            <p className="text-[10px] text-gray-500 max-w-sm leading-relaxed">
              Choose an active project profile from the index column to synthesize its recovery instruction matrices.
            </p>
          </div>
        )}
      </div>

      {/* NEW SESSION EXPLANATION MODAL */}
      <AnimatePresence>
        {showModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-[#050508] border-2 border-cyan-500/50 rounded-xl p-6.5 max-w-md w-full shadow-[0_0_50px_rgba(0,e5,ff,0.25)] flex flex-col text-gray-300 font-sans"
            >
              <h3 className="text-sm font-black uppercase tracking-widest text-[#00e5ff] border-b border-cyan-950 pb-3 mb-4 flex items-center gap-1.5">
                <HelpCircle className="w-4 h-4 text-emerald-400" />
                HOW TO INOCULATE SESSION CONTEXT
              </h3>

              <div className="space-y-4 text-xs leading-relaxed">
                <p>
                  To restore context seamlessly across separate intelligence models without memory truncation blocks, execute this operational flow:
                </p>

                <div className="space-y-2 font-mono text-[10.5px]">
                  <div className="flex gap-2 p-2 px-2.5 bg-cyan-950/20 border border-cyan-950 rounded">
                    <span className="text-cyan-400 font-bold">1.</span>
                    <span>Click the <strong>"COPY CONTEXT"</strong> button to load the recovery payload to your clipboard.</span>
                  </div>
                  <div className="flex gap-2 p-2 px-2.5 bg-cyan-950/20 border border-cyan-950 rounded">
                    <span className="text-cyan-400 font-bold">2.</span>
                    <span>Boot up your new session in <strong>Claude</strong>, <strong>Gemini AI Studio</strong>, or any LLM platform.</span>
                  </div>
                  <div className="flex gap-2 p-2 px-2.5 bg-cyan-950/20 border border-cyan-950 rounded">
                    <span className="text-cyan-400 font-bold">3.</span>
                    <span>Paste the prompt payload as the <strong>very first instruction line</strong> in that thread.</span>
                  </div>
                </div>

                <p className="text-[10px] text-gray-500 leading-relaxed font-mono">
                  This bypasses initial knowledge latency entirely. The compiler model instantly acquires full awareness of previously locked architectures, file scopes, and targeted directives.
                </p>
              </div>

              <div className="mt-6 flex justify-end gap-3 border-t border-cyan-950 pt-4">
                <button
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 bg-cyan-500/10 hover:bg-cyan-500/20 text-[#00e5ff] border border-cyan-500/30 hover:border-cyan-500 rounded text-xs font-bold uppercase tracking-wider transition-all"
                >
                  ACKNOWLEDGE
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
