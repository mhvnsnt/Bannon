import React, { useState, useEffect } from 'react';
import { Target, TrendingUp, TrendingDown, DollarSign, Plus, Crosshair, Zap, Download, AlertTriangle } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import { motion, AnimatePresence } from 'framer-motion';

export default function KineticPayloadPanel() {
  const [assets, setAssets] = useState<any[]>([]);
  const [debts, setDebts] = useState<any[]>([]);
  
  // Forms
  const [assetName, setAssetName] = useState('');
  const [assetValue, setAssetValue] = useState(0);
  const [assetFlow, setAssetFlow] = useState(0);

  const [debtName, setDebtName] = useState('');
  const [debtAmount, setDebtAmount] = useState(0);
  const [debtRate, setDebtRate] = useState(0);

  const loadData = async () => {
    try {
      const [assetsRes, debtsRes] = await Promise.all([
        fetch('/api/armada/quantum/kinetic/assets'),
        fetch('/api/armada/quantum/kinetic/debts')
      ]);
      const [assetsData, debtsData] = await Promise.all([
        assetsRes.json(),
        debtsRes.json()
      ]);
      
      if (assetsData.success) setAssets(assetsData.assets);
      if (debtsData.success) setDebts(debtsData.debts);
    } catch (e: any) {
      console.error(e);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleAddAsset = async () => {
    if (!assetName || assetValue <= 0) return;
    try {
      await fetch('/api/armada/quantum/kinetic/assets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ asset_name: assetName, asset_value: assetValue, cash_flow: assetFlow })
      });
      setAssetName(''); setAssetValue(0); setAssetFlow(0);
      loadData();
    } catch (e: any) {
      console.error(e);
    }
  };

  const handleAddDebt = async () => {
    if (!debtName || debtAmount <= 0) return;
    try {
      await fetch('/api/armada/quantum/kinetic/debts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ creditor: debtName, total_amount: debtAmount, remaining_amount: debtAmount, interest_rate: debtRate })
      });
      setDebtName(''); setDebtAmount(0); setDebtRate(0);
      loadData();
    } catch (e: any) {
      console.error(e);
    }
  };

  const totalAssets = assets.reduce((sum, a) => sum + a.asset_value, 0);
  const totalFlow = assets.reduce((sum, a) => sum + a.cash_flow, 0);
  const totalDebt = debts.reduce((sum, d) => sum + d.remaining_amount, 0);
  
  // Calculate Kinetic Momentum Trajectory (12 Months)
  const trajectoryData = [];
  let runningAssets = totalAssets;
  let runningDebt = totalDebt;
  for (let i = 0; i < 12; i++) {
    trajectoryData.push({
      month: `M${i}`,
      Assets: Math.floor(runningAssets),
      Liabilities: Math.floor(runningDebt),
      // Machine Learning Heuristic Projection (assuming 15% compounding improvement in flow targeting assets)
      MLProjectedAssets: Math.floor(runningAssets + (totalFlow * 0.15 * i * 12)) 
    });
    runningAssets += totalFlow;
    // VERY rough interest calc for demo visualization
    runningDebt += (runningDebt * (0.1 / 12)); 
    // Let's assume cashflow targets debt mostly to show impact
    runningDebt -= (totalFlow * 0.5); 
    if (runningDebt < 0) runningDebt = 0;
  }

  const [insight, setInsight] = useState<string>('');
  const [loadingInsight, setLoadingInsight] = useState(false);

  const getInsight = async () => {
    setLoadingInsight(true);
    setInsight('');
    try {
      const res = await fetch('/api/armada/quantum/kinetic/insight', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          assets, debts, cash_flow: totalFlow, net_worth: totalAssets - totalDebt
        })
      });
      const data = await res.json();
      if (data.success) {
        setInsight(data.strategy);
      }
    } catch (e: any) {
      console.error(e);
      setInsight('Failed to generate insight.');
    }
    setLoadingInsight(false);
  };

  const handleDownloadCSV = () => {
    const assetRows = assets.map(a => `Asset,${a.asset_name},${a.asset_value},${a.cash_flow},${new Date(a.created_at).toLocaleString()}`);
    const debtRows = debts.map(d => `Debt,${d.creditor},${d.remaining_amount},${d.interest_rate},${new Date(d.created_at).toLocaleString()}`);
    
    let csvContent = "data:text/csv;charset=utf-8,Type,Name/Creditor,Amount,Variable(Flow/Rate),Created At\n";
    csvContent += assetRows.join("\n") + "\n";
    csvContent += debtRows.join("\n") + "\n";
    csvContent += `\nSUMMARY,Total Assets,${totalAssets},Total Flow ${totalFlow},Total Liabilities ${totalDebt}`;

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Kinetic_Payload_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const isWealthDominanceReached = totalFlow >= 10000;

  return (
    <div className="flex flex-col h-full bg-[#0a0a0a] text-gray-200 font-mono p-6">
      <div className="flex items-center justify-between mb-6 border-b border-[#222] pb-4">
        <div className="flex items-center gap-3">
          <Target className="text-emerald-500 w-6 h-6 animate-pulse" />
          <h2 className="text-xl font-bold tracking-widest uppercase text-emerald-400 drop-shadow-[0_0_8px_rgba(16,185,129,0.5)]">Kinetic Payload Tracker</h2>
        </div>
        <div className="flex gap-2">
            <button 
                onClick={handleDownloadCSV}
                className="flex items-center gap-2 px-3 py-1 bg-[#1a1a1a] text-gray-400 border border-[#333] rounded hover:bg-[#222] hover:text-white transition-all font-bold tracking-widest uppercase text-xs"
            >
                <Download className="w-4 h-4" /> Export CSV
            </button>
            <button 
              onClick={getInsight} 
              disabled={loadingInsight}
              className="flex items-center gap-2 px-4 py-2 bg-emerald-900/40 text-emerald-300 border border-emerald-500/50 rounded hover:bg-emerald-800/60 transition-all font-bold tracking-widest uppercase text-xs disabled:opacity-50"
            >
              <Zap className={`w-4 h-4 ${loadingInsight ? 'animate-bounce text-yellow-400' : 'text-yellow-500'}`} />
              {loadingInsight ? 'Calculating Strategy...' : 'Generate Kinetic Strategy'}
            </button>
        </div>
      </div>

      <AnimatePresence>
          {isWealthDominanceReached && (
            <motion.div 
               initial={{ opacity: 0, y: -20, height: 0 }}
               animate={{ opacity: 1, y: 0, height: 'auto' }}
               exit={{ opacity: 0, height: 0 }}
               className="mb-4 bg-yellow-500/10 border border-yellow-500/50 text-yellow-400 p-3 rounded flex items-center justify-between shadow-[0_0_15px_rgba(234,179,8,0.2)]"
            >
               <div className="flex items-center gap-2">
                   <AlertTriangle className="w-5 h-5 animate-pulse" />
                   <span className="font-bold tracking-widest uppercase text-sm">WEALTH DOMINANCE THRESHOLD BREACHED</span>
               </div>
               <span className="text-xs opacity-80 uppercase tracking-widest text-yellow-200">Inductance flow exceeds $10k/mo. Proceed to Phase 3.</span>
            </motion.div>
          )}
      </AnimatePresence>

      <div className="grid grid-cols-6 gap-4 mb-6">
        <div className="bg-[#111] p-4 rounded border border-emerald-900/50 flex flex-col justify-center items-center shadow-[0_0_15px_rgba(16,185,129,0.1)] col-span-1">
          <span className="text-[10px] text-gray-500 tracking-widest uppercase mb-1">Total Assets</span>
          <span className="text-2xl font-bold text-emerald-400">${totalAssets.toLocaleString()}</span>
        </div>
        <div className="bg-[#111] p-4 rounded border border-red-900/50 flex flex-col justify-center items-center col-span-1">
          <span className="text-[10px] text-gray-500 tracking-widest uppercase mb-1">Total Liabilities</span>
          <span className="text-2xl font-bold text-red-500">${totalDebt.toLocaleString()}</span>
        </div>
        <div className="bg-[#111] p-4 rounded border border-cyan-900/50 flex flex-col justify-center items-center col-span-1">
          <span className="text-[10px] text-gray-500 tracking-widest uppercase mb-1">Monthly Cash Flow</span>
          <span className="text-2xl font-bold text-cyan-400">+${totalFlow.toLocaleString()}</span>
        </div>
        
        {/* Kinetic Inductance Meter */}
        <div className="bg-[#111] p-4 rounded border border-yellow-900/50 flex flex-col justify-center items-center relative overflow-hidden group col-span-1">
          <div className="absolute inset-0 bg-yellow-500/5 group-hover:bg-yellow-500/10 transition-colors"></div>
          <span className="text-[10px] text-gray-500 tracking-widest uppercase mb-2 relative z-10">Kinetic Inductance</span>
          <div className="w-full h-2 bg-[#222] rounded-full overflow-hidden relative z-10 mb-2">
             <motion.div 
               className="h-full bg-gradient-to-r from-yellow-600 to-yellow-400"
               initial={{ width: 0 }}
               animate={{ width: `${Math.min((totalFlow / 10000) * 100, 100)}%` }}
               transition={{ duration: 1.5, ease: "easeOut" }}
             />
          </div>
          <span className="text-xs font-bold text-yellow-500 relative z-10">{Math.min(Math.floor((totalFlow / 10000) * 100), 100)}% L-Torque</span>
        </div>

        <div className="bg-[#111] p-4 flex flex-col border border-[#222] rounded overflow-hidden relative group col-span-1">
           <Zap className="absolute right-[-10px] bottom-[-10px] w-20 h-20 text-yellow-500/10 group-hover:text-yellow-500/20 transition-all" />
           <span className="text-[10px] text-gray-500 tracking-widest uppercase z-10 mb-1">Kinetic Momentum (ML)</span>
           <motion.div 
               initial={{ opacity: 0 }} 
               animate={{ opacity: 1 }} 
               key={totalAssets + totalDebt} // Force re-render animation on data change
               transition={{ duration: 1 }}
               className="flex-1 w-full mt-2 z-10"
           >
              <ResponsiveContainer width="100%" height={50}>
                <AreaChart data={trajectoryData}>
                  <Area type="monotone" dataKey="Assets" stroke="#10b981" fill="#10b981" fillOpacity={0.2} strokeWidth={2} isAnimationActive={true} animationDuration={1000} />
                  <Area type="monotone" dataKey="MLProjectedAssets" stroke="#3b82f6" fill="none" strokeDasharray="3 3" strokeWidth={1} isAnimationActive={true} animationDuration={1000} />
                  <Area type="monotone" dataKey="Liabilities" stroke="#ef4444" fill="#ef4444" fillOpacity={0.1} strokeWidth={2} isAnimationActive={true} animationDuration={1000} />
                  <Tooltip contentStyle={{ backgroundColor: '#000', border: '1px solid #333', fontSize: '10px' }} />
                </AreaChart>
              </ResponsiveContainer>
           </motion.div>
        </div>

        {/* Capacitance Reservoir Meter */}
        <div className="bg-[#111] p-4 rounded border border-blue-900/50 flex flex-col justify-center items-center relative overflow-hidden group col-span-1">
          <div className="absolute inset-0 bg-blue-500/5 group-hover:bg-blue-500/10 transition-colors"></div>
          <span className="text-[10px] text-gray-500 tracking-widest uppercase mb-2 relative z-10 text-center">Capacitance Reservoir</span>
          <div className="flex-1 flex justify-center items-center w-full relative z-10">
             <div className="w-16 h-16 rounded-full border-4 border-[#222] relative flex items-center justify-center shadow-[0_0_15px_rgba(59,130,246,0.1)] overflow-hidden">
                <motion.div 
                   className="absolute bottom-0 w-full bg-gradient-to-t from-blue-600 to-cyan-400 opacity-80"
                   initial={{ height: 0 }}
                   animate={{ height: `${Math.min((totalAssets / (Math.max(totalDebt, 1))) * 20, 100)}%` }} // Very rough representation of asset-to-debt ratio acting as structural capacitor
                   transition={{ duration: 2, ease: "easeOut" }}
                />
             </div>
          </div>
          <span className="text-xs font-bold text-blue-400 relative z-10 text-center mt-2">C-Integrity: {Math.min(Math.floor((totalAssets / (Math.max(totalDebt, 1))) * 20), 100)}%</span>
        </div>

      </div>

      {insight && (
        <div className="mb-6 p-4 rounded bg-gradient-to-br from-[#111] to-[#0a1511] border border-emerald-500/30 shadow-[0_0_20px_rgba(16,185,129,0.1)]">
           <div className="flex items-center gap-2 mb-3 border-b border-emerald-500/20 pb-2">
             <Zap className="w-5 h-5 text-yellow-400" />
             <h3 className="font-bold uppercase tracking-widest text-emerald-300">Kinetic Execution Protocol</h3>
           </div>
           <div className="text-sm text-emerald-100 whitespace-pre-wrap leading-relaxed opacity-90">
             {insight}
           </div>
        </div>
      )}

      <div className="flex flex-col md:flex-row gap-6 flex-1 min-h-0">
        
        {/* Assets Section */}
        <div className="flex-1 flex flex-col gap-4 min-h-0 bg-[#0f1511] border border-emerald-900/30 rounded p-4 relative overflow-hidden">
           <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-900 to-transparent"></div>
           <div className="flex items-center gap-2 mb-2">
             <TrendingUp className="text-emerald-500 w-5 h-5" />
             <h3 className="font-bold uppercase tracking-widest text-emerald-300">Kinetic Assets</h3>
           </div>
           
           <div className="flex flex-col gap-2 mb-4 bg-black/50 p-3 rounded border border-[#222]">
             <div className="flex gap-2">
               <input value={assetName} onChange={e=>setAssetName(e.target.value)} placeholder="Asset Name" className="flex-1 bg-[#1a1a1a] p-2 text-xs border border-[#333] rounded focus:border-emerald-500 outline-none" />
               <input value={assetValue} onChange={e=>setAssetValue(Number(e.target.value))} type="number" placeholder="Value" className="w-20 bg-[#1a1a1a] p-2 text-xs border border-[#333] rounded focus:border-emerald-500 outline-none" />
             </div>
             <div className="flex gap-2">
               <input value={assetFlow} onChange={e=>setAssetFlow(Number(e.target.value))} type="number" placeholder="Monthly Cash Flow" className="flex-1 bg-[#1a1a1a] p-2 text-xs border border-[#333] rounded focus:border-emerald-500 outline-none" />
               <button onClick={handleAddAsset} className="bg-emerald-900/50 text-emerald-400 px-4 rounded text-xs uppercase tracking-widest hover:bg-emerald-800 transition-colors border border-emerald-500/30 font-bold"><Plus className="w-4 h-4 mx-auto" /></button>
             </div>
           </div>

           <div className="flex-1 overflow-y-auto pr-2 flex flex-col gap-2">
             <AnimatePresence>
                 {assets.map(a => (
                   <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, scale: 0.9 }} key={a.id} className="bg-[#111] border border-[#222] p-3 rounded flex justify-between items-center group">
                     <div className="flex flex-col">
                       <span className="font-bold text-gray-300">{a.asset_name}</span>
                       <span className="text-[10px] text-cyan-400">Flow: +${a.cash_flow}/mo</span>
                     </div>
                     <span className="text-emerald-400 font-bold text-sm bg-black px-2 py-1 rounded shadow-inner shadow-emerald-500/20">${a.asset_value.toLocaleString()}</span>
                   </motion.div>
                 ))}
             </AnimatePresence>
           </div>
        </div>

        {/* Debts Section */}
        <div className="flex-1 flex flex-col gap-4 min-h-0 bg-[#150f0f] border border-red-900/30 rounded p-4 relative overflow-hidden">
           <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-red-900 to-transparent"></div>
           <div className="flex items-center gap-2 mb-2">
             <TrendingDown className="text-red-500 w-5 h-5" />
             <h3 className="font-bold uppercase tracking-widest text-red-300">Target Eradication</h3>
           </div>
           
           <div className="flex flex-col gap-2 mb-4 bg-black/50 p-3 rounded border border-[#222]">
             <div className="flex gap-2">
               <input value={debtName} onChange={e=>setDebtName(e.target.value)} placeholder="Creditor" className="flex-1 bg-[#1a1a1a] p-2 text-xs border border-[#333] rounded focus:border-red-500 outline-none" />
               <input value={debtAmount} onChange={e=>setDebtAmount(Number(e.target.value))} type="number" placeholder="Amt" className="w-20 bg-[#1a1a1a] p-2 text-xs border border-[#333] rounded focus:border-red-500 outline-none" />
             </div>
             <div className="flex gap-2">
               <input value={debtRate} onChange={e=>setDebtRate(Number(e.target.value))} type="number" placeholder="APR (%)" className="flex-1 bg-[#1a1a1a] p-2 text-xs border border-[#333] rounded focus:border-red-500 outline-none" />
               <button onClick={handleAddDebt} className="bg-red-900/50 text-red-400 px-3 rounded text-[10px] uppercase tracking-widest hover:bg-red-800 transition-colors border border-red-500/30 font-bold flex items-center justify-center gap-1"><Crosshair className="w-3 h-3" /> Target</button>
             </div>
           </div>

           <div className="flex-1 overflow-y-auto pr-2 flex flex-col gap-2">
             <AnimatePresence>
                 {debts.map(d => (
                   <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, scale: 0.9 }} key={d.id} className="bg-[#111] border border-red-900/30 p-3 rounded flex justify-between items-center group relative overflow-hidden">
                     <div className="absolute inset-0 bg-red-500/5 translate-x-[-100%] group-hover:translate-x-0 transition-transform"></div>
                     <div className="flex flex-col relative z-10">
                       <span className="font-bold text-red-200">{d.creditor}</span>
                       <span className="text-[10px] text-red-500/80">APR: {d.interest_rate}%</span>
                     </div>
                     <span className="text-red-400 font-bold text-sm relative z-10 bg-black px-2 py-1 rounded shadow-inner shadow-red-500/20">${d.remaining_amount.toLocaleString()}</span>
                   </motion.div>
                 ))}
             </AnimatePresence>
           </div>
        </div>

      </div>
    </div>
  );
}
