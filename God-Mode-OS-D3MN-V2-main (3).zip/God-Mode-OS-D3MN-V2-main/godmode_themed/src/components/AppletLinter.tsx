import React, { useState } from 'react';
import { 
  FileCode, CheckCircle2, AlertTriangle, Play, HelpCircle, 
  Sparkles, Terminal, Activity, FileCheck, ArrowRight, Lightbulb
} from 'lucide-react';
import { motion } from 'framer-motion';

export default function AppletLinter() {
  const [code, setCode] = useState<string>(`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>God Mode OS Simple Applet</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-black text-white font-mono p-6">
    <div class="max-w-md mx-auto bg-zinc-900 border border-zinc-800 p-6 rounded-xl">
        <h1 class="text-lg font-bold text-fuchsia-500 mb-4">M. Heaven$ent Command Node</h1>
        
        <!-- INTERACTIVE COMPONENTS -->
        <button class="w-full py-2 bg-fuchsia-700 hover:bg-fuchsia-600 rounded font-bold uppercase tracking-wider transition-colors">
            Trigger Autonomic Saturation
        </button>

        <input type="text" placeholder="Enter target parameters..." class="w-full mt-3 p-2 bg-black border border-zinc-800 rounded text-sm focus:outline-none" />
    </div>

    <script>
        // Custom environmental resonance scripts go here
        console.log("System initialized.");
    </script>
</body>
</html>`);

  const [score, setScore] = useState<number | null>(null);
  const [logs, setLogs] = useState<string[]>([]);
  const [warnings, setWarnings] = useState<{ type: 'error' | 'warning' | 'info'; message: string; suggestion: string }[]>([]);
  const [isAuditing, setIsAuditing] = useState(false);

  const executeSystemAudit = () => {
    setIsAuditing(true);
    setLogs([
      "⚡ Initializing God Mode OS compiler engine...",
      "🔍 Loading custom abstract syntax tree (AST)...",
      "🛰️ Analyzing elements, attributes, state matrices..."
    ]);

    setTimeout(() => {
      const currentLogs = [
        "⚡ Initializing God Mode OS compiler engine...",
        "🔍 Loading custom abstract syntax tree (AST)...",
        "🛰️ Analyzing elements, attributes, state matrices...",
        "📝 Processing HTML structure and Tailwind configurations...",
        "🧠 Running integration checks for 'God Mode OS' environment..."
      ];

      let currentScore = 100;
      const issues: typeof warnings = [];

      // Check 1: ID targeting parity (God Mode OS relies on exact ID targeting)
      const buttonMatches = code.match(/<button[\s>]/gi) || [];
      const inputMatches = code.match(/<input[\s>]/gi) || [];
      const totalInteractive = buttonMatches.length + inputMatches.length;

      const idsFound = (code.match(/id=['"][^'"]+['"]/gi) || []).length;

      if (totalInteractive > 0 && idsFound < totalInteractive) {
        currentScore -= 20;
        issues.push({
          type: 'warning',
          message: `Interactive element components lack unique IDs. (Found ${idsFound} IDs for ${totalInteractive} interactive elements)`,
          suggestion: "Add unique identifier id='...' to all buttons and inputs. This allows God Mode OS automation engines to intercept and simulate user events with zero friction."
        });
      } else if (totalInteractive === 0) {
        issues.push({
          type: 'info',
          message: "No interactive elements (buttons/inputs) detected in sample file.",
          suggestion: "Add buttons or text inputs with unique ID credentials to develop rich terminal-driven widgets."
        });
      }

      // Check 2: Responsive Margins and Constraints (Fluid scale wrapper check)
      if (!code.includes('max-w-') && (code.includes('w-') || code.includes('width'))) {
        currentScore -= 15;
        issues.push({
          type: 'warning',
          message: "Hardcoded width parameters without responsive fluid encapsulation.",
          suggestion: "Integrate a container utilizing responsive Tailwind scaling classes like 'max-w-4xl mx-auto' to satisfy both desktop and mobile layouts."
        });
      }

      // Check 3: Theme compliance for God Mode OS (Dark themes preferred is absolute)
      if (code.includes('bg-white') || code.includes('text-black')) {
        currentScore -= 10;
        issues.push({
          type: 'info',
          message: "Light thematic elements detected.",
          suggestion: "Transition fully to high-contrast deep blacks (#000000) and charcoal greys (#121212) styled with fuchsia, cyan, or emerald accents to match God Mode OS premium branding."
        });
      }

      // Check 4: Tag mismatch checks
      const openMatches = code.match(/<[a-zA-Z1-6]+(?:\s[^>]*)?>/g) || [];
      const closeMatches = code.match(/<\/[a-zA-Z1-6]+>/g) || [];
      if (Math.abs(openMatches.length - closeMatches.length) > 3) {
        currentScore -= 15;
        issues.push({
          type: 'error',
          message: `Significant asymmetry in tag pairings. Opened: ${openMatches.length} vs Closed: ${closeMatches.length}`,
          suggestion: "Format code cleanly to assure each opened tag (e.g. <div>) is paired with its closing sibling. This prevents rendering cut-offs in downstream browser frames."
        });
      }

      // Check 5: Integration with God Mode OS (Vibration API, Autonomic System, Custom message receivers)
      const hasPostMessage = code.includes('window.parent.postMessage') || code.includes('postMessage');
      const hasVibration = code.includes('navigator.vibrate');
      if (!hasPostMessage) {
        issues.push({
          type: 'info',
          message: "Unconnected sandbox framework. Applet runs independently.",
          suggestion: "Implement 'window.parent.postMessage({ type: \"STATE_SYNC\", data: ... }, \"*\")' to report status metrics directly back to the Prime Core system."
        });
      }
      if (!hasVibration) {
        issues.push({
          type: 'info',
          message: "Kinetic feed triggers inactive.",
          suggestion: "Integrate triggerable kinetic haptics 'navigator.vibrate([100, 50, 100])' on action clicks to deliver deep procedural feedback."
        });
      }

      // Apply floor limit
      const finalScore = Math.max(0, currentScore);

      currentLogs.push(`🛰️ Audit finished. Calculated compliance: ${finalScore}%. Issues detected: ${issues.length}.`);
      setScore(finalScore);
      setWarnings(issues);
      setLogs(currentLogs);
      setIsAuditing(false);
    }, 1500);
  };

  return (
    <div className="w-full h-full bg-[#050505] p-5 font-mono text-gray-300 flex flex-col gap-5 overflow-y-auto no-scrollbar" id="applet-linter-root">
      
      {/* Header section with technical branding */}
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-zinc-800 pb-4 gap-4">
        <div>
          <h2 className="text-sm font-bold uppercase tracking-[0.25em] text-amber-400 flex items-center gap-2">
            <Activity className="w-4 h-4 text-amber-400 animate-pulse" />
            Quantum Applet Linter
          </h2>
          <p className="text-[10px] text-gray-500 uppercase tracking-widest mt-1">
            Structural AST validation engine for God Mode OS Integration
          </p>
        </div>
        {score !== null && (
          <div className="flex items-center gap-3">
            <span className="text-[10px] text-gray-500 uppercase tracking-wider">COMPLIANCE RATIO:</span>
            <span className={`text-[11px] font-bold px-2.5 py-1 rounded border ${
              score >= 90 ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' :
              score >= 70 ? 'bg-amber-500/10 text-amber-400 border-amber-500/30' :
              'bg-rose-500/10 text-rose-400 border-rose-500/30'
            }`}>
              {score}% COMPLIANT
            </span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 flex-1">
        
        {/* Left Column: Input Text Area */}
        <div className="lg:col-span-7 flex flex-col gap-3 min-h-[400px]">
          <div className="flex items-center justify-between px-3 py-1.5 bg-zinc-900 border border-zinc-800 rounded-t-lg">
            <div className="flex items-center gap-2">
              <FileCode className="w-3.5 h-3.5 text-zinc-400" />
              <span className="text-[10px] text-zinc-400 uppercase tracking-widest font-bold">Paste Applet Workspace Code (HTML/JSX)</span>
            </div>
            <span className="text-[9px] text-zinc-600 font-bold">READY TO DECODE</span>
          </div>
          
          <textarea
            value={code}
            onChange={(e) => setCode(e.target.value)}
            className="w-full flex-1 p-4 bg-black/90 border-x border-b border-zinc-850 rounded-b-lg font-mono text-[11px] leading-relaxed text-zinc-300 focus:outline-none focus:border-zinc-700 min-h-[300px] select-text no-scrollbar"
            placeholder="Type or paste HTML/TSX applet source here..."
            spellCheck="false"
            id="linter-source-editor"
          />

          <button
            onClick={executeSystemAudit}
            disabled={isAuditing}
            className="w-full py-2.5 bg-amber-500/10 hover:bg-amber-500/20 active:bg-amber-500/35 border border-amber-500/30 font-bold uppercase tracking-widest text-[10.5px] text-amber-400 rounded-lg transition-all flex items-center justify-center gap-2"
            id="btn-run-structural-linter"
          >
            <Activity className={`w-4 h-4 ${isAuditing ? 'animate-spin text-amber-500' : 'text-amber-400'}`} />
            <span>{isAuditing ? "PARSING COMPILED AST..." : "EXECUTE RECON ARCHITECTURE CHECK"}</span>
          </button>
        </div>

        {/* Right Column: Logs, Violations, Code Integration suggestions */}
        <div className="lg:col-span-5 flex flex-col gap-4">
          
          {/* Diagnostic Console Logs */}
          <div className="bg-black/85 rounded-lg border border-zinc-850 p-3">
            <div className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider mb-2 flex items-center gap-1.5 border-b border-zinc-850 pb-1.5">
              <Terminal className="w-3.5 h-3.5 text-amber-500" /> Compiler Trace
            </div>
            <div className="space-y-1 text-[10px] font-mono leading-relaxed max-h-40 overflow-y-auto min-h-[80px]">
              {logs.length === 0 ? (
                <span className="text-zinc-600 italic select-all">[STANDBY] Parser ready. Load source code and click RECON.</span>
              ) : (
                logs.map((log, idx) => (
                  <div key={idx} className={log.includes('WARNING') || log.includes('compliance') ? 'text-amber-400 font-bold' : log.includes('Finished') ? 'text-emerald-400' : 'text-zinc-500'}>
                    {log}
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Audit warnings / recommendations list */}
          <div className="flex-1 rounded-lg border border-zinc-850 bg-black/40 p-4 overflow-y-auto no-scrollbar space-y-3 min-h-[250px]">
            <div className="text-[10px] text-zinc-450 font-bold uppercase tracking-wider flex items-center gap-1.5 mb-2 border-b border-zinc-850 pb-2">
              <Lightbulb className="w-4 h-4 text-amber-400" /> Detected Structural Metrics
            </div>

            {warnings.length === 0 && score === null && (
              <div className="text-center py-8 text-zinc-600 text-[10.5px]">
                <FileCheck className="w-8 h-8 text-zinc-700 mx-auto mb-2 opacity-50" />
                <span>Diagnostics standby. Compile source to view AST compliance recommendations.</span>
              </div>
            )}

            {score !== null && warnings.length === 0 && (
              <div className="p-3 bg-emerald-550/10 border border-emerald-500/20 text-emerald-400 rounded text-[10px] space-y-1.5">
                <p className="font-bold uppercase tracking-wider">🌟 ALL COMPLIANCY CHECKS PASSED!</p>
                <p className="leading-relaxed">This applet follows pristine 'God Mode OS' standards. Unique event triggers and responsive wrappers are securely initialized.</p>
              </div>
            )}

            {warnings.map((issue, idx) => (
              <div 
                key={idx} 
                className={`p-3 rounded border text-[10.5px] leading-relaxed flex gap-2.5 ${
                  issue.type === 'error' ? 'bg-rose-950/10 border-rose-500/30' :
                  issue.type === 'warning' ? 'bg-amber-950/10 border-amber-500/30' :
                  'bg-zinc-900/40 border-zinc-800'
                }`}
              >
                <div className="shrink-0 mt-0.5">
                  {issue.type === 'error' ? <AlertTriangle className="w-4 h-4 text-rose-500" /> :
                   issue.type === 'warning' ? <AlertTriangle className="w-4 h-4 text-amber-400" /> :
                   <CheckCircle2 className="w-4 h-4 text-zinc-400" />}
                </div>
                <div>
                  <div className={`font-bold ${
                    issue.type === 'error' ? 'text-rose-400' :
                    issue.type === 'warning' ? 'text-amber-450' :
                    'text-zinc-300'
                  }`}>
                    {issue.message}
                  </div>
                  <div className="text-zinc-400 mt-1 text-[10px]">
                    <span className="text-amber-400 font-semibold uppercase text-[9px] tracking-wider block mb-0.5">Recommended Optimization:</span>
                    {issue.suggestion}
                  </div>
                </div>
              </div>
            ))}
          </div>

        </div>

      </div>

    </div>
  );
}
