import React from 'react';
import { Orbit, Activity, ShieldAlert, Cpu, Network, Sparkles, Terminal, Smartphone, CloudFog, Wifi } from 'lucide-react';

export default function MainSidebar() {
  return (
    <div className="flex flex-col h-full bg-black/90 border-r border-[#333] p-4 font-mono text-gray-400">
      <div className="flex items-center gap-3 mb-8 pb-4 border-b border-[#333]">
        <div className="w-8 h-8 rounded bg-fuchsia-900/40 border border-fuchsia-500/50 flex items-center justify-center">
          <Smartphone className="text-fuchsia-400 w-5 h-5" />
        </div>
        <div>
          <h1 className="text-fuchsia-400 font-bold uppercase tracking-widest text-sm">Mobile Proxy Node</h1>
          <p className="text-[10px] text-gray-500 uppercase tracking-widest">Local Ingestion Active</p>
        </div>
      </div>

      <div className="flex flex-col gap-2">
        <div className="text-[10px] text-fuchsia-500 uppercase tracking-widest mb-2 font-semibold flex items-center gap-2">
          <Orbit className="w-3 h-3" /> Spatial Vectors
        </div>
        
        <button className="flex items-center gap-3 p-2 rounded hover:bg-[#111] transition-colors text-left group">
          <Activity className="w-4 h-4 text-emerald-500 group-hover:text-emerald-400" />
          <span className="text-xs uppercase tracking-wider group-hover:text-gray-200">Kinetic Grid</span>
        </button>
        
        <button className="flex items-center gap-3 p-2 rounded hover:bg-[#111] transition-colors text-left group">
          <Network className="w-4 h-4 text-emerald-500 group-hover:text-emerald-400" />
          <span className="text-xs uppercase tracking-wider group-hover:text-gray-200">Swarm Routing</span>
        </button>

        <button className="flex items-center gap-3 p-2 rounded hover:bg-[#111] transition-colors text-left group">
          <Sparkles className="w-4 h-4 text-fuchsia-500 group-hover:text-fuchsia-400" />
          <span className="text-xs uppercase tracking-wider group-hover:text-gray-200">Abundance Matrix</span>
        </button>

        <div className="my-4 border-t border-[#333]" />

        <div className="text-[10px] text-blue-500 uppercase tracking-widest mb-2 font-semibold flex items-center gap-2">
          <CloudFog className="w-3 h-3" /> Cloud Compilation Bridge
        </div>

        <div className="p-3 bg-[#111] rounded border border-[#222]">
           <div className="flex justify-between items-center mb-2">
              <span className="text-[10px] uppercase text-gray-500">vLLM Cluster Status</span>
              <Wifi className="w-3 h-3 text-emerald-400 animate-pulse" />
           </div>
           <div className="flex justify-between items-center text-xs">
              <span className="text-blue-400">OpenRouter Pipe</span>
              <span className="text-emerald-500">SECURE</span>
           </div>
        </div>

        <button className="flex items-center justify-center gap-2 mt-2 p-2 bg-blue-900/20 border border-blue-900/50 rounded text-blue-400 hover:bg-blue-900/40 transition-colors text-[10px] uppercase tracking-widest font-bold">
           Run Compilation
        </button>

        <button className="flex items-center gap-3 p-2 rounded hover:bg-[#111] transition-colors text-left group mt-4">
          <ShieldAlert className="w-4 h-4 text-red-500 group-hover:text-red-400" />
          <span className="text-xs uppercase tracking-wider group-hover:text-gray-200">Security Vault</span>
        </button>
        
        <button className="flex items-center gap-3 p-2 rounded hover:bg-[#111] transition-colors text-left group">
          <Cpu className="w-4 h-4 text-indigo-500 group-hover:text-indigo-400" />
          <span className="text-xs uppercase tracking-wider group-hover:text-gray-200">Apex System Logic</span>
        </button>
      </div>

      <div className="mt-auto pt-4 border-t border-[#333]">
        <div className="flex items-center gap-2 text-[10px] uppercase font-bold text-gray-500 tracking-widest">
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          System Online
        </div>
      </div>
    </div>
  );
}
