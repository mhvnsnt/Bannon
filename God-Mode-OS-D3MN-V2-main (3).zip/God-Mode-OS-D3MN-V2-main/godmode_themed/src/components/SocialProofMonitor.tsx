import React, { useState, useEffect } from 'react';
import { Network, Activity, Globe, Zap, Users, Share2, BarChart2 } from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, Cell } from 'recharts';
import { motion, AnimatePresence } from 'framer-motion';

interface EngagementEvent {
    id: string;
    source: string;
    type: 'PULL' | 'RESONANCE' | 'AMPLIFICATION';
    intensity: number;
    timestamp: string;
}

export default function SocialProofMonitor() {
    const [events, setEvents] = useState<EngagementEvent[]>([]);
    const [mockInterval, setMockInterval] = useState<any>(null);

    useEffect(() => {
        // Initialize with some dense baseline data
        const initialData = Array.from({ length: 15 }).map((_, i) => ({
            id: `EVT-${Math.random().toString(36).substring(7)}`,
            source: ['GitHub', 'Community Hub', 'Field Logs', 'Terminal', 'Discord'][Math.floor(Math.random() * 5)],
            type: ['PULL', 'RESONANCE', 'AMPLIFICATION'][Math.floor(Math.random() * 3)] as 'PULL' | 'RESONANCE' | 'AMPLIFICATION',
            intensity: Math.floor(Math.random() * 80) + 20,
            timestamp: new Date(Date.now() - (15 - i) * 60000).toISOString()
        }));
        setEvents(initialData);

        // Start real-time simulation of external data streams
        const triggerEvent = () => {
             const newEvent: EngagementEvent = {
                 id: `EVT-${Math.random().toString(36).substring(7)}`,
                 source: ['Github API', 'Open Collective', 'Twitter API', 'Substack API', 'Discord Webhook'][Math.floor(Math.random() * 5)],
                 type: ['PULL', 'RESONANCE', 'AMPLIFICATION'][Math.floor(Math.random() * 3)] as any,
                 intensity: Math.floor(Math.random() * 90) + 10,
                 timestamp: new Date().toISOString()
             };
             
             setEvents(prev => [...prev.slice(-29), newEvent]);
        };

        const interval = setInterval(triggerEvent, 4000); // New event every 4 seconds
        setMockInterval(interval);

        return () => clearInterval(interval);
    }, []);

    const chartData = events.slice(-15).map(evt => ({
        time: new Date(evt.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        intensity: evt.intensity,
        type: evt.type
    }));

    const typeColors = {
        'PULL': '#3b82f6', // blue
        'RESONANCE': '#10b981', // emerald
        'AMPLIFICATION': '#8b5cf6' // purple
    };

    return (
        <div className="p-6 h-full overflow-auto bg-[#030303] text-white font-mono relative">
            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-[0.03] pointer-events-none" />
            
            <h2 className="text-2xl font-bold mb-2 text-purple-400 border-b border-purple-900/50 pb-2 flex items-center gap-3">
                <Network className="w-6 h-6" />
                Social Proof & Magnetic Induction Monitor
            </h2>
            <p className="text-xs text-gray-500 tracking-widest uppercase mb-6">
                Objective API metrics rendering the Operator's localized command and grid influence.
            </p>

            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 min-h-[400px]">
                 {/* Main Telemetry Graph */}
                 <div className="lg:col-span-3 bg-[#0a0a0f] border border-[#222] rounded-xl p-4 shadow-[0_0_20px_rgba(139,92,246,0.05)] flex flex-col">
                    <h3 className="text-sm font-bold tracking-widest text-[#aaa] uppercase mb-4 flex items-center gap-2">
                        <Activity className="w-4 h-4 text-purple-500"/>
                        Aggregated Influence Streams
                    </h3>
                    <div className="flex-1 min-h-0 w-full relative">
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={chartData}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#222" vertical={false} />
                                <XAxis dataKey="time" stroke="#444" fontSize={10} tickMargin={10} />
                                <YAxis stroke="#444" fontSize={10} />
                                <Tooltip 
                                    contentStyle={{ backgroundColor: '#000', border: '1px solid #333', fontSize: '10px' }}
                                    cursor={{fill: '#1a1a1a'}}
                                />
                                <Bar dataKey="intensity" isAnimationActive={false}>
                                    {chartData.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={typeColors[entry.type as keyof typeof typeColors]} />
                                    ))}
                                </Bar>
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                 </div>

                 {/* High-Capacitance Nodes Sidebar */}
                 <div className="lg:col-span-1 bg-[#0a0a0f] border border-[#222] rounded-xl p-4 shadow-[0_0_20px_rgba(59,130,246,0.05)] flex flex-col h-full overflow-hidden">
                     <h3 className="text-sm font-bold tracking-widest text-blue-400 uppercase mb-4 flex items-center gap-2 border-b border-[#333] pb-2">
                        <Users className="w-4 h-4"/>
                        Live Network Interactions
                     </h3>
                     <div className="flex-1 overflow-y-auto space-y-2 pr-2">
                         <AnimatePresence>
                             {events.slice().reverse().map(evt => (
                                 <motion.div 
                                     initial={{ opacity: 0, x: 20 }}
                                     animate={{ opacity: 1, x: 0 }}
                                     key={evt.id}
                                     className="bg-[#111] p-3 rounded border border-[#222] flex flex-col gap-1 relative overflow-hidden group"
                                  >
                                     <div className={`absolute left-0 top-0 bottom-0 w-1 ${evt.type === 'PULL' ? 'bg-blue-500' : evt.type === 'RESONANCE' ? 'bg-emerald-500' : 'bg-purple-500'} opacity-50`}></div>
                                     <div className="flex justify-between items-center ml-2">
                                         <span className="text-xs font-bold text-gray-300">{evt.source}</span>
                                         <span className="text-[10px] text-gray-500">{new Date(evt.timestamp).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})}</span>
                                     </div>
                                     <div className="flex justify-between items-center ml-2">
                                         <span className={`text-[9px] uppercase tracking-wider ${evt.type === 'PULL' ? 'text-blue-400' : evt.type === 'RESONANCE' ? 'text-emerald-400' : 'text-purple-400'}`}>
                                            {evt.type}
                                         </span>
                                         <span className="text-xs font-mono text-gray-400 shrink-0">vGap: +{evt.intensity}</span>
                                     </div>
                                 </motion.div>
                             ))}
                         </AnimatePresence>
                     </div>
                 </div>
            </div>

            {/* Density Stats */}
            <div className="grid grid-cols-3 gap-4 mt-6">
                <div className="bg-[#111] border border-blue-900/30 p-4 rounded-lg flex items-center gap-4">
                    <div className="p-3 bg-blue-500/10 rounded-full text-blue-400">
                        <Share2 className="w-6 h-6" />
                    </div>
                    <div>
                        <div className="text-[10px] text-gray-500 uppercase tracking-widest font-bold">Total Gravity Pulls</div>
                        <div className="text-xl font-bold text-blue-300">{(events.filter(e => e.type === 'PULL').length * 1.5).toFixed(0)}</div>
                    </div>
                </div>
                <div className="bg-[#111] border border-emerald-900/30 p-4 rounded-lg flex items-center gap-4">
                    <div className="p-3 bg-emerald-500/10 rounded-full text-emerald-400">
                        <Globe className="w-6 h-6" />
                    </div>
                    <div>
                        <div className="text-[10px] text-gray-500 uppercase tracking-widest font-bold">Resonance Alignments</div>
                        <div className="text-xl font-bold text-emerald-300">{(events.filter(e => e.type === 'RESONANCE').length * 2.1).toFixed(0)}</div>
                    </div>
                </div>
                <div className="bg-[#111] border border-purple-900/30 p-4 rounded-lg flex items-center gap-4">
                    <div className="p-3 bg-purple-500/10 rounded-full text-purple-400">
                        <Zap className="w-6 h-6" />
                    </div>
                    <div>
                        <div className="text-[10px] text-gray-500 uppercase tracking-widest font-bold">Asset Amplifications</div>
                        <div className="text-xl font-bold text-purple-300">{(events.filter(e => e.type === 'AMPLIFICATION').length * 3.4).toFixed(0)}</div>
                    </div>
                </div>
            </div>

        </div>
    );
}
