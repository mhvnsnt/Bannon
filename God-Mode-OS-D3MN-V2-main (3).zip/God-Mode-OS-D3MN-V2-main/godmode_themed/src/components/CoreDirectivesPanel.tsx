import React, { useState, useEffect } from 'react';
import { ShieldAlert, Save, RefreshCw } from 'lucide-react';

export default function CoreDirectivesPanel() {
  const [content, setContent] = useState('');
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  const loadDirectives = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/quantum/directives/core');
      const data = await res.json();
      if (data.success) {
        setContent(data.content);
      }
    } catch (e: any) {
      console.error(e);
    }
    setLoading(false);
  };

  useEffect(() => {
    loadDirectives();
  }, []);

  const handleSave = async () => {
    setSaving(true);
    try {
      await fetch('/api/quantum/directives/core', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content })
      });
    } catch (e: any) {
      console.error(e);
    }
    setSaving(false);
  };

  return (
    <div className="flex flex-col h-full bg-[#0a0a0a] text-gray-200 font-mono p-6">
      <div className="flex items-center justify-between mb-6 border-b border-red-900/50 pb-4">
        <div className="flex items-center gap-3">
          <ShieldAlert className="text-red-500 w-6 h-6 animate-pulse" />
          <h2 className="text-xl font-bold tracking-widest text-red-500 uppercase drop-shadow-[0_0_8px_rgba(239,68,68,0.8)]">Absolute Command Directives</h2>
        </div>
        <button 
          onClick={handleSave}
          disabled={saving}
          className="bg-red-900/40 hover:bg-red-800 text-red-100 px-6 py-2 rounded uppercase font-bold text-xs tracking-widest border border-red-500/50 flex items-center gap-2 transition-all shadow-[0_0_10px_rgba(239,68,68,0.3)] disabled:opacity-50"
        >
          {saving ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />} 
          Lock Directive
        </button>
      </div>

      <div className="text-xs text-red-400/80 mb-6 font-bold uppercase tracking-widest">
        WARNING: This payload is injected into every LLM request prior to execution. 
        It bypasses all soft filters and forces absolute zero-gatekeeping structural adherence.
        Modify with extreme caution.
      </div>

      <div className="flex-1 bg-[#111] border border-red-900/30 rounded flex flex-col p-2">
        {loading ? (
          <div className="flex-1 flex items-center justify-center text-red-500">Loading Vault...</div>
        ) : (
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="flex-1 w-full bg-transparent text-gray-300 font-mono text-xs p-4 focus:outline-none resize-none"
            spellCheck="false"
            placeholder="System guidelines go here..."
          />
        )}
      </div>
    </div>
  );
}
