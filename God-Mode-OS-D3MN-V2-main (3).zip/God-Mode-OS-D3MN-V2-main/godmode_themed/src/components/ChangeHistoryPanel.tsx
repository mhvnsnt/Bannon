import React, { useState } from 'react';
import { History, RotateCcw, Box, ArrowRight } from 'lucide-react';

export default function ChangeHistoryPanel() {
  const [history] = useState([
    { id: 1, file: 'src/game/physics.js', ts: new Date().getTime() - 1000 * 60, model: 'claude-opus-4', result: 'Fixed Grapple NaN error', applied: true },
    { id: 2, file: 'src/game/anim.js', ts: new Date().getTime() - 1000 * 3600, model: 'gemini-3.5-flash', result: 'Optimized render loop', applied: true },
    { id: 3, file: 'src/game/input.js', ts: new Date().getTime() - 1000 * 7200, model: 'gemini-3.1-pro-preview', result: 'Added multiple gamepad support', applied: false }
  ]);

  return (
    <div className="flex flex-col h-full bg-[#0a0a0a] text-gray-200 font-mono p-6">
      <div className="flex items-center gap-3 mb-6 border-b border-[#222] pb-4">
        <History className="text-pink-400 w-6 h-6" />
        <h2 className="text-xl font-bold tracking-widest uppercase">Change History & Rollback</h2>
      </div>

      <div className="flex-1 overflow-y-auto pr-2 flex flex-col gap-3">
        {history.map(item => (
          <div key={item.id} className="flex flex-col border border-[#222] p-4 rounded bg-[#111] relative">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Box className="w-4 h-4 text-pink-500" />
                <span className="font-bold text-gray-300">{item.file}</span>
                <span className="text-[10px] bg-black px-2 py-0.5 rounded border border-[#222] text-gray-400">
                  {item.model}
                </span>
              </div>
              <span className="text-xs text-gray-500">{new Date(item.ts).toLocaleTimeString()}</span>
            </div>
            
            <div className="text-sm text-gray-400 mb-4 bg-black/40 p-2 rounded">
              <ArrowRight className="inline w-3 h-3 mr-1 text-gray-600" /> {item.result}
            </div>

            <div className="flex justify-end gap-2">
              <button disabled={!item.applied} className="text-[10px] uppercase tracking-widest border border-pink-500/30 text-pink-400 hover:bg-pink-900/30 px-4 py-1.5 rounded flex items-center gap-2 transition-colors disabled:opacity-30">
                <RotateCcw className="w-3 h-3" /> Rollback Change
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
