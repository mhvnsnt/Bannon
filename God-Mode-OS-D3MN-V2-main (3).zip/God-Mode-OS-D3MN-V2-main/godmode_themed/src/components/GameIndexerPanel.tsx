import React, { useState } from 'react';
import { Search, Database, RefreshCw, FileCode } from 'lucide-react';

export default function GameIndexerPanel() {
  const [filePath, setFilePath] = useState('bannon_fighter.html');
  const [searchQuery, setSearchQuery] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [indexMessage, setIndexMessage] = useState('');

  const handleIndex = async () => {
    setLoading(true);
    setIndexMessage('');
    try {
      const res = await fetch('/api/quantum/index/file', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filePath })
      });
      const data = await res.json();
      if (data.success) {
        setIndexMessage(`Indexed ${data.indexedCount} symbols successfully.`);
      } else {
        setIndexMessage(`Error: ${data.error}`);
      }
    } catch (e: any) {
      setIndexMessage(`Error: ${e.message}`);
    }
    setLoading(false);
  };

  const handleSearch = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/quantum/index/search?q=${encodeURIComponent(searchQuery)}`);
      const data = await res.json();
      if (data.success) {
        setResults(data.results);
      }
    } catch (e: any) {
      console.error(e);
    }
    setLoading(false);
  };

  return (
    <div className="flex flex-col h-full bg-[#0a0a0a] text-gray-200 font-mono p-6">
      <div className="flex items-center gap-3 mb-6 border-b border-[#222] pb-4">
        <Database className="text-emerald-400 w-6 h-6" />
        <h2 className="text-xl font-bold tracking-widest uppercase">Bannon Game Indexer</h2>
      </div>

      <div className="flex flex-col gap-4 mb-8">
        <div className="flex items-center gap-4">
          <input 
            type="text" 
            value={filePath} 
            onChange={e => setFilePath(e.target.value)}
            className="flex-1 bg-[#111] border border-[#333] p-3 rounded text-sm focus:outline-none focus:border-emerald-500"
            placeholder="File path to index (e.g. game.html)"
          />
          <button 
            onClick={handleIndex}
            disabled={loading}
            className="bg-emerald-900/50 hover:bg-emerald-800 text-emerald-300 px-6 py-3 rounded uppercase font-bold text-xs tracking-widest border border-emerald-500/30 flex items-center gap-2 transition-colors disabled:opacity-50"
          >
            {loading ? <RefreshCw className="animate-spin w-4 h-4" /> : <Database className="w-4 h-4" />}
            Index File
          </button>
        </div>
        {indexMessage && <div className="text-xs text-emerald-400">{indexMessage}</div>}
      </div>

      <div className="flex flex-col gap-4 mb-6">
        <div className="text-xs text-gray-500 uppercase tracking-widest">Symbol Search</div>
        <div className="flex items-center gap-4">
          <input 
            type="text" 
            value={searchQuery} 
            onChange={e => setSearchQuery(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSearch()}
            className="flex-1 bg-[#111] border border-[#333] p-3 rounded text-sm focus:outline-none focus:border-emerald-500"
            placeholder="Search functions, classes..."
          />
          <button 
            onClick={handleSearch}
            disabled={loading}
            className="bg-[#222] hover:bg-[#333] px-6 py-3 rounded uppercase font-bold text-xs tracking-widest border border-[#444] flex items-center gap-2 transition-colors disabled:opacity-50"
          >
            <Search className="w-4 h-4" />
            Search
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto border border-[#222] rounded bg-[#0d0d0d] p-4 flex flex-col gap-2">
        {results.length === 0 ? (
          <div className="text-gray-600 text-xs tracking-widest text-center mt-10">NO RESULTS FOUND...</div>
        ) : (
          results.map((r, i) => (
            <div key={i} className="flex flex-col border border-[#222] p-3 rounded bg-[#111] gap-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <FileCode className="text-emerald-500 w-4 h-4" />
                  <span className="font-bold text-emerald-300">{r.name}</span>
                  <span className="text-[10px] bg-[#222] px-2 py-0.5 rounded text-gray-400">{r.symbol_type}</span>
                </div>
                <span className="text-xs text-gray-500">Line: {r.line_start}</span>
              </div>
              <div className="text-xs text-gray-400 bg-black p-2 rounded overflow-x-auto whitespace-pre">
                {r.code}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
