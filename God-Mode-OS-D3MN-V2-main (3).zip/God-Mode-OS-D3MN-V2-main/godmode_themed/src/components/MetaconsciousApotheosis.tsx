import React, { useState, useEffect, useRef } from 'react';
import { 
  Sparkles, Eye, Waves, Share2, Activity, Disc, Infinity, 
  Zap, Sliders, Cpu, Layers, Volume2, VolumeX, EyeOff, Gauge, Database, Save 
} from 'lucide-react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Points, PointMaterial } from '@react-three/drei';
import * as THREE from 'three';
import { useTaskQueue } from '../lib/taskQueue';

// ---------------------------------------------------------------------
// Multiverse Volumetric Timeline Points (Physics Dynamic Particle Cloud)
// ---------------------------------------------------------------------
interface MultiverseCloudProps {
  count?: number;
  branchingFactor: number;
  dmnConnectivity: number;
  priorConfidence: number;
}

const MultiverseCloud: React.FC<MultiverseCloudProps> = ({ 
  count = 4000, 
  branchingFactor, 
  dmnConnectivity, 
  priorConfidence 
}) => {
  const pointsRef = useRef<THREE.Points>(null);
  
  // High-performance Float32Array positions tracker
  const [positions] = useState(() => {
    const p = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
       const theta = 2 * Math.PI * Math.random();
       const phi = Math.acos(2 * Math.random() - 1);
       const r = 10 * Math.cbrt(Math.random());
       p[i * 3] = r * Math.sin(phi) * Math.cos(theta);
       p[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
       p[i * 3 + 2] = r * Math.cos(phi);
    }
    return p;
  });

  useFrame((state, delta) => {
    if (pointsRef.current) {
       // Self-rotation scaled by branching factors
       pointsRef.current.rotation.x += delta * 0.02;
       pointsRef.current.rotation.y += delta * 0.04 * (1 + branchingFactor * 0.4);
       
       const pos = pointsRef.current.geometry.attributes.position.array as Float32Array;
       
       // Chaos increases when DMN connectivity decreases (the predictive loop is ungrounded)
       // and when prior confidence values are extremely high overriding external constraints
       const chaosFactor = ((100 - dmnConnectivity) / 100) * 3.5 + (priorConfidence * 1.5);
       
       for(let i = 0; i < count; i++) {
          const idx = i * 3;
          
          // Phase waves calculation
          const speedOffset = state.clock.elapsedTime * 0.4 + pos[idx + 1] * 0.05;
          const driftX = Math.sin(speedOffset) * delta * chaosFactor * 3.0;
          const driftY = Math.cos(speedOffset) * delta * chaosFactor * 3.0;
          
          pos[idx] += driftX;
          pos[idx + 1] += driftY;
          
          // Restorative force pulls particles towards geometric center (simulating sensory correction force)
          // Higher DMN connectivity enforces rigid structural cohesion
          const pullCohesion = delta * (dmnConnectivity / 100) * 0.8;
          pos[idx] -= (pos[idx] * pullCohesion);
          pos[idx + 1] -= (pos[idx + 1] * pullCohesion);
          pos[idx + 2] -= (pos[idx + 2] * pullCohesion);
       }
       pointsRef.current.geometry.attributes.position.needsUpdate = true;
    }
  });

  return (
    <Points ref={pointsRef} positions={positions} stride={3} frustumCulled={false}>
      <PointMaterial 
         transparent 
         color="#d946ef" 
         size={0.065} 
         sizeAttenuation={true} 
         depthWrite={false} 
         blending={THREE.AdditiveBlending} 
      />
    </Points>
  );
};

// ---------------------------------------------------------------------
// MAIN SYSTEM PORTAL
// ---------------------------------------------------------------------
export function MetaconsciousApotheosis() {
    // 1. DMN & Bayesian Cognitive States
    const [dmnConnectivity, setDmnConnectivity] = useState<number>(100); // 0% (REM Dream) to 100% (Waking Reality)
    const [priorConfidence, setPriorConfidence] = useState<number>(0.5); // Bayesian weight
    const [timelineBranches, setTimelineBranches] = useState<number>(1.2);
    const [isPriorsOverriding, setIsPriorsOverriding] = useState<boolean>(false);
    
    // 2. Electro-Physical LC Resonance States
    const [C, setC] = useState<number>(18.5); // Capacitance (in microfarads uF)
    const [L, setL] = useState<number>(120.0); // Inductance (in millihenries mH)
    const [V, setV] = useState<number>(12.0); // Voltage across capacitor
    const [I, setI] = useState<number>(1.8); // Current through inductor
    
    // Calculated LC physical components
    const hL = L * 1e-3; // Henrys
    const fC = C * 1e-6; // Farads
    
    // Resonant frequency: 1 / (2 * pi * sqrt(L * C))
    const resonantFreq = hL > 0 && fC > 0 
      ? 1 / (2 * Math.PI * Math.sqrt(hL * fC)) 
      : 0;
      
    // Energy levels
    const capacitanceEnergy = 0.5 * fC * (V * V); // 0.5 * C * V^2 (Joules)
    const inductanceEnergy = 0.5 * hL * (I * I); // 0.5 * L * I^2 (Joules)

    // Auditory state
    const [harmonicEngineActive, setHarmonicEngineActive] = useState(false);
    const [continuousOscActive, setContinuousOscActive] = useState(false);
    const [audioContext, setAudioContext] = useState<AudioContext | null>(null);

    // Initialization check to avoid loading flash
    useEffect(() => {
        try {
            const savedDmn = localStorage.getItem('marquis_apotheosis_dmn');
            const savedPrior = localStorage.getItem('marquis_apotheosis_prior');
            const savedBranches = localStorage.getItem('marquis_apotheosis_branches');
            const savedC = localStorage.getItem('marquis_apotheosis_c');
            const savedL = localStorage.getItem('marquis_apotheosis_l');
            const savedV = localStorage.getItem('marquis_apotheosis_v');
            const savedI = localStorage.getItem('marquis_apotheosis_i');

            if (savedDmn !== null) setDmnConnectivity(Number(savedDmn));
            if (savedPrior !== null) setPriorConfidence(Number(savedPrior));
            if (savedBranches !== null) setTimelineBranches(Number(savedBranches));
            if (savedC !== null) setC(Number(savedC));
            if (savedL !== null) setL(Number(savedL));
            if (savedV !== null) setV(Number(savedV));
            if (savedI !== null) setI(Number(savedI));
            
            appendLog("Autonomous spatial calibration memory loaded from physical store.");
        } catch (err) {
            console.error("Failed to load apotheosis parameters:", err);
        }
    }, []);

    const saveSystemPreset = () => {
        try {
            localStorage.setItem('marquis_apotheosis_dmn', dmnConnectivity.toString());
            localStorage.setItem('marquis_apotheosis_prior', priorConfidence.toString());
            localStorage.setItem('marquis_apotheosis_branches', timelineBranches.toString());
            localStorage.setItem('marquis_apotheosis_c', C.toString());
            localStorage.setItem('marquis_apotheosis_l', L.toString());
            localStorage.setItem('marquis_apotheosis_v', V.toString());
            localStorage.setItem('marquis_apotheosis_i', I.toString());

            const checksumVal = (dmnConnectivity + priorConfidence + C + L).toFixed(2);
            appendLog(`[MEM SYNC APPROVED] Registered vector system key. Checksum: CS_${checksumVal}. Parameters linked to localized hardware state.`);
        } catch (err) {
            appendLog(`[MEM SYNC ERROR] Failed to lock calibration registry parameters.`);
        }
    };

    const clearSystemPreset = () => {
        try {
            localStorage.removeItem('marquis_apotheosis_dmn');
            localStorage.removeItem('marquis_apotheosis_prior');
            localStorage.removeItem('marquis_apotheosis_branches');
            localStorage.removeItem('marquis_apotheosis_c');
            localStorage.removeItem('marquis_apotheosis_l');
            localStorage.removeItem('marquis_apotheosis_v');
            localStorage.removeItem('marquis_apotheosis_i');
            setDmnConnectivity(100);
            setPriorConfidence(0.5);
            setTimelineBranches(1.2);
            setC(18.5);
            setL(120.0);
            setV(12.0);
            setI(1.8);
            appendLog(`[RESET MATRIX] System registry purged. Restored original default physical ratios.`);
        } catch (err) {}
    };

    const isMatrixSynchronized = () => {
        try {
            const savedC = localStorage.getItem('marquis_apotheosis_c');
            const savedDmn = localStorage.getItem('marquis_apotheosis_dmn');
            if (savedC === null || savedDmn === null) return false;
            return Math.abs(Number(savedC) - C) < 0.01 && Math.abs(Number(savedDmn) - dmnConnectivity) < 0.01;
        } catch (e) {
            return false;
        }
    };

    // Logs & Task Engine
    const [cognitiveLogs, setCognitiveLogs] = useState<string[]>([]);
    const { enqueue } = useTaskQueue();
    const canvasRef = useRef<HTMLCanvasElement | null>(null);
    const continuousOscRef = useRef<OscillatorNode | null>(null);
    const continuousGainRef = useRef<GainNode | null>(null);

    // Push new structured logs into cognitive telemetry panel
    const appendLog = (msg: string) => {
        const time = new Date().toLocaleTimeString();
        setCognitiveLogs(prev => [`[${time}] ${msg}`, ...prev].slice(0, 15));
    };

    // Calculate static Bayesian updates for the current cognitive frame
    // P(Model|Sensory) = P(Sensory|Model) * P(Model) / P(Sensory)
    const priorProb = priorConfidence;
    const sensoryLikelihood = dmnConnectivity / 100;
    const marginalSensory = (sensoryLikelihood * priorProb) + (0.12 * (1 - priorProb));
    const posteriorProb = marginalSensory > 0 ? (sensoryLikelihood * priorProb) / marginalSensory : 0;

    // React to cognitive state changes
    useEffect(() => {
        if (dmnConnectivity === 100) {
            appendLog(`Bayesian Sync Locked. Rigid reality feedback loop verified (DMN Connectivity at 100%).`);
        } else if (dmnConnectivity === 0) {
            appendLog(`DMN Uncoupled. REM Dream state initiated. Grounding feedback loop severed. Prior projections running unconstrained.`);
        } else {
            appendLog(`Priors updated: P(Model|Evidence) scaled to ${posteriorProb.toFixed(3)}. Integration buffer: ${dmnConnectivity}%.`);
        }
    }, [dmnConnectivity]);

    useEffect(() => {
        appendLog(`Resonant Grid Configured. C = ${C}μF (Electric) | L = ${L}mH (Magnetic) | Resonant Frequency f₀ = ${resonantFreq.toFixed(2)} Hz.`);
    }, [C, L]);

    // HTML5 Canvas Oscillation Wave Render (Electric vs Magnetic Energy Swapping)
    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        let animationId: number;
        let frameTime = 0;

        const drawResonantWaves = () => {
            const w = canvas.width = canvas.parentElement?.clientWidth || 300;
            const h = canvas.height = 110;
            ctx.clearRect(0, 0, w, h);
            
            const centerY = h / 2;

            // Render background coordinate lines
            ctx.strokeStyle = 'rgba(168, 85, 247, 0.08)';
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(0, centerY);
            ctx.lineTo(w, centerY);
            ctx.stroke();

            // Frequency horizontal stretch factor
            const waveStretchByFreq = Math.min(resonantFreq * 0.008, 12);

            // 1. Capacitance Field Wave (Electric potential: q(t) = Q₀ cos(ω₀t)) - Cyan Color
            ctx.strokeStyle = '#06b6d4';
            ctx.shadowColor = 'rgba(6, 182, 212, 0.4)';
            ctx.shadowBlur = 4;
            ctx.lineWidth = 1.8;
            ctx.beginPath();
            for (let x = 0; x < w; x++) {
                const angle = (x / w) * Math.PI * 4 * waveStretchByFreq + frameTime;
                // Amplitude driven by Capacitor Voltage V
                const y = centerY + Math.cos(angle) * (V * 1.5 + 4);
                if (x === 0) ctx.moveTo(x, y);
                else ctx.lineTo(x, y);
            }
            ctx.stroke();

            // 2. Inductance Field Wave (Magnetic velocity: i(t) = -I₀ sin(ω₀t)) - Fuchsia Color
            ctx.strokeStyle = '#d946ef';
            ctx.shadowColor = 'rgba(217, 70, 239, 0.4)';
            ctx.shadowBlur = 4;
            ctx.lineWidth = 1.8;
            ctx.beginPath();
            for (let x = 0; x < w; x++) {
                // Phase-shifted precisely by 90 degrees (Math.PI / 2) representing inductive reactance delay
                const angle = (x / w) * Math.PI * 4 * waveStretchByFreq + frameTime - (Math.PI / 2);
                // Amplitude driven by Inductance Current I
                const y = centerY + Math.cos(angle) * (I * 8.0 + 4);
                if (x === 0) ctx.moveTo(x, y);
                else ctx.lineTo(x, y);
            }
            ctx.stroke();

            ctx.shadowBlur = 0; // reset
            
            // Advance timeline relative to current resonant speed
            frameTime += 0.03 + (0.0001 * resonantFreq);
            animationId = requestAnimationFrame(drawResonantWaves);
        };

        drawResonantWaves();
        return () => cancelAnimationFrame(animationId);
    }, [resonantFreq, V, I]);

    // ---------------------------------------------------------------------
    // WebAudio Synthesis Hooks
    // ---------------------------------------------------------------------
    const initAudio = () => {
        if (!audioContext) {
            const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
            setAudioContext(ctx);
            appendLog("WebAudio spatial resonance synthesizer activated.");
            return ctx;
        }
        if (audioContext.state === 'suspended') {
            audioContext.resume();
        }
        return audioContext;
    };

    // Sub-atomic discrete pentatonic pings (triggered timeline loops)
    useEffect(() => {
        if (harmonicEngineActive && audioContext) {
            const triggerPing = () => {
                const osc = audioContext.createOscillator();
                const gain = audioContext.createGain();
                
                // Construct a strict physical system chord (Harmonics of f₀)
                const fundamental = Math.max(resonantFreq, 40); // clamp min to avoid deep infrasound
                const pentatonicMultipliers = [1, 1.25, 1.5, 1.875, 2.0, 2.5];
                const cleanRatio = pentatonicMultipliers[Math.floor(Math.random() * pentatonicMultipliers.length)];
                
                let targetFreq = fundamental * cleanRatio;
                // Fold down to human hearing sweet spot (120Hz to 1200Hz) if excessive
                while (targetFreq > 1200) targetFreq /= 2;
                while (targetFreq < 120) targetFreq *= 2;

                osc.type = 'sine';
                osc.frequency.setValueAtTime(targetFreq, audioContext.currentTime);

                // Quick, smooth attack-decay curve simulating physical discharges
                gain.gain.setValueAtTime(0, audioContext.currentTime);
                gain.gain.linearRampToValueAtTime(0.06, audioContext.currentTime + 0.04);
                gain.gain.exponentialRampToValueAtTime(0.0001, audioContext.currentTime + 1.8);

                osc.connect(gain);
                gain.connect(audioContext.destination);

                osc.start();
                osc.stop(audioContext.currentTime + 1.8);
            };

            // Pace of atomic feedback loops scales directly with the timeline branches matrix
            const intervalDuration = Math.max(150, 900 - (timelineBranches * 80));
            const pingLoop = setInterval(triggerPing, intervalDuration);
            
            return () => clearInterval(pingLoop);
        }
    }, [harmonicEngineActive, audioContext, resonantFreq, timelineBranches]);

    // Continuous Resonant Hum Carrier Wave (Dual oscillator synth mimicking physical magnetic hum)
    useEffect(() => {
        if (continuousOscActive && audioContext) {
            // Build dual-voice hum oscillator
            const osc = audioContext.createOscillator();
            const gainNode = audioContext.createGain();

            // Map resonant frequency directly
            const targetFreq = Math.min(Math.max(resonantFreq, 45), 250); // Keep hum low & physical

            osc.type = 'sawtooth';
            osc.frequency.setValueAtTime(targetFreq, audioContext.currentTime);

            // Squelch harsh high frequencies with actual bi-quad lowpass filter
            const filter = audioContext.createBiquadFilter();
            filter.type = 'lowpass';
            filter.frequency.setValueAtTime(targetFreq * 1.5, audioContext.currentTime);

            // Safe, smooth ramp on activation
            gainNode.gain.setValueAtTime(0, audioContext.currentTime);
            gainNode.gain.linearRampToValueAtTime(0.02, audioContext.currentTime + 0.5);

            osc.connect(filter);
            filter.connect(gainNode);
            gainNode.connect(audioContext.destination);

            osc.start();

            continuousOscRef.current = osc;
            continuousGainRef.current = gainNode;

            appendLog(`Continuous physical inductor hum engaged at fundamental ${targetFreq.toFixed(1)}Hz.`);
        } else {
            // Fade out cleanly if deactivated
            if (continuousOscRef.current && continuousGainRef.current && audioContext) {
                const currentGain = continuousGainRef.current;
                const currentOsc = continuousOscRef.current;
                
                try {
                    currentGain.gain.cancelScheduledValues(audioContext.currentTime);
                    currentGain.gain.setValueAtTime(currentGain.gain.value, audioContext.currentTime);
                    currentGain.gain.linearRampToValueAtTime(0, audioContext.currentTime + 0.3);
                    setTimeout(() => {
                        try { currentOsc.stop(); } catch(e){}
                    }, 400);
                } catch (err) {}
            }
            continuousOscRef.current = null;
            continuousGainRef.current = null;
        }

        return () => {
            if (continuousOscRef.current) {
                try { continuousOscRef.current.stop(); } catch(e){}
            }
        };
    }, [continuousOscActive, audioContext, resonantFreq]);

    const toggleHarmonics = () => {
        const ctx = initAudio();
        if (ctx) {
            setHarmonicEngineActive(!harmonicEngineActive);
        }
    };

    const toggleContinuousHum = () => {
        const ctx = initAudio();
        if (ctx) {
            setContinuousOscActive(!continuousOscActive);
        }
    };

    const triggerAutonomousCalibration = () => {
        enqueue(async () => {
            appendLog(`[CALIBRATION] Initiating autonomous spatial resonance sweeps...`);
            let step = 0;
            const interval = setInterval(() => {
                if (step < 5) {
                    setC(prev => Math.min(100, Math.max(1, prev + (Math.random() > 0.5 ? 4.5 : -4.5))));
                    setL(prev => Math.min(1000, Math.max(10, prev + (Math.random() > 0.5 ? 60 : -60))));
                    setDmnConnectivity(prev => Math.max(0, Math.min(100, prev + (Math.random() > 0.5 ? 10 : -10))));
                    step++;
                } else {
                    clearInterval(interval);
                    appendLog(`[CALIBRATION SUCCESS] System stable. Spatial resonance impedance matched.`);
                }
            }, 400);
        });
    };

    return (
       <div className="w-full h-full bg-[#05000a] text-purple-400 font-mono p-4 flex flex-col border-l border-purple-900/30 overflow-hidden" id="metaconscious-apotheosis-portal">
           
           {/* HUD Header */}
           <div className="border-b border-purple-900/40 pb-3 mb-4 shrink-0 flex justify-between items-end">
              <div>
                  <h2 className="text-sm font-bold uppercase tracking-widest text-fuchsia-300 flex items-center gap-2">
                    <Infinity className="w-4 h-4 animate-pulse text-fuchsia-400" /> Metaconscious Apotheosis Engine
                  </h2>
                  <p className="text-[10px] text-purple-500/80 mt-1">
                     The Marquis Theory Matrix: Unified Neuro-Electrical Resonance Sandbox
                  </p>
              </div>
              <div className="text-[9px] bg-purple-950/20 border border-purple-900/30 px-3 py-1 flex items-center gap-3 rounded">
                  <span className="flex items-center gap-1">
                     <span className={`w-1.5 h-1.5 rounded-full ${dmnConnectivity > 40 ? 'bg-emerald-400' : 'bg-fuchsia-400 animate-pulse'}`} />
                     {dmnConnectivity > 40 ? 'REALITY_LOCKED' : 'UNCONSTRAINED_DREAM'}
                  </span>
                  <span className="text-purple-600">|</span>
                  <span>f₀: {resonantFreq.toFixed(1)} Hz</span>
              </div>
           </div>

           {/* Main 3-Section Panel Layout */}
           <div className="flex-1 grid grid-cols-12 gap-4 overflow-y-auto custom-scrollbar pr-1">
               
               {/* Column 1: Bayesian Default Mode Network Simulator (4/12 width) */}
               <div className="col-span-12 lg:col-span-4 flex flex-col gap-4">
                   <div className="bg-[#0b0314] border border-purple-900/30 rounded p-4 relative shadow-[inset_0_0_15px_rgba(217,70,239,0.02)]">
                       <h3 className="text-xs uppercase font-bold text-fuchsia-400 flex items-center gap-2 mb-3 border-b border-purple-900/20 pb-2">
                          <Cpu className="w-3.5 h-3.5 text-fuchsia-400" /> Default Mode Network (DMN)
                       </h3>
                       
                       <p className="text-[10px] text-purple-500 mb-4 leading-relaxed">
                          In dreams, the model-generating Default Mode Network is uncoupled from reality-testing centers. Toggle below to sever the structural sensory correction feedback loops.
                       </p>

                       {/* Interactive Connectivity Presets */}
                       <div className="grid grid-cols-2 gap-2 mb-4">
                           <button 
                               onClick={() => setDmnConnectivity(100)}
                               className={`py-1.5 text-[10px] font-bold border rounded transition-all ${dmnConnectivity === 100 ? 'bg-purple-900/30 border-purple-500 text-purple-300 shadow-[0_0_8px_rgba(168,85,247,0.2)]' : 'border-purple-950/50 text-purple-700 hover:bg-purple-900/10'}`}
                           >
                               WAKING RESOLUTION
                           </button>
                           <button 
                               onClick={() => setDmnConnectivity(0)}
                               className={`py-1.5 text-[10px] font-bold border rounded transition-all ${dmnConnectivity === 0 ? 'bg-fuchsia-900/30 border-fuchsia-500 text-fuchsia-300 shadow-[0_0_8px_rgba(217,70,239,0.2)]' : 'border-purple-950/50 text-purple-700 hover:bg-purple-900/10'}`}
                           >
                               REM DREAM VELOCITY
                           </button>
                       </div>

                       {/* Slider Inputs */}
                       <div className="flex flex-col gap-3">
                           <div>
                               <div className="flex justify-between text-[10px] mb-1">
                                   <span className="text-purple-400">DMN Connectivity Rate:</span>
                                   <span className="font-bold text-fuchsia-400">{dmnConnectivity}%</span>
                               </div>
                               <input 
                                   type="range" 
                                   min="0" 
                                   max="100" 
                                   value={dmnConnectivity} 
                                   onChange={(e) => setDmnConnectivity(Number(e.target.value))}
                                   className="w-full h-1 bg-purple-950 rounded-lg appearance-none cursor-pointer accent-fuchsia-500"
                               />
                               <span className="text-[9px] text-purple-600 block mt-0.5">Enforces physical/sensory correction values onto the prediction model.</span>
                           </div>

                           <div>
                               <div className="flex justify-between text-[10px] mb-1">
                                   <span className="text-purple-400">Bayesian Prior Confidence Weight:</span>
                                   <span className="font-bold text-fuchsia-400">{priorConfidence.toFixed(2)}</span>
                               </div>
                               <input 
                                   type="range" 
                                   min="0.05" 
                                   max="0.95" 
                                   step="0.05"
                                   value={priorConfidence} 
                                   onChange={(e) => setPriorConfidence(Number(e.target.value))}
                                   className="w-full h-1 bg-purple-950 rounded-lg appearance-none cursor-pointer accent-fuchsia-500"
                               />
                               <span className="text-[9px] text-purple-600 block mt-0.5">Calculates how firmly the brain asserts preconceived cognitive models.</span>
                           </div>

                           <div>
                               <div className="flex justify-between text-[10px] mb-1">
                                   <span className="text-purple-400">Timeline Branching Multiplier:</span>
                                   <span className="font-bold text-fuchsia-400">{timelineBranches.toFixed(2)}x</span>
                               </div>
                               <input 
                                   type="range" 
                                   min="0.5" 
                                   max="5.0" 
                                   step="0.1"
                                   value={timelineBranches} 
                                   onChange={(e) => setTimelineBranches(Number(e.target.value))}
                                   className="w-full h-1 bg-purple-950 rounded-lg appearance-none cursor-pointer accent-fuchsia-500"
                               />
                           </div>
                       </div>
                   </div>

                   {/* Bayesian Math readout statistics */}
                   <div className="bg-[#030107] border border-purple-900/20 rounded p-4 text-[10px]">
                       <h4 className="text-purple-300 font-bold uppercase tracking-wider mb-2 flex items-center gap-1.5">
                           <Sliders className="w-3 h-3 text-cyan-400" /> BAYESIAN ERROR CALCULATOR
                       </h4>
                       <div className="space-y-1.5 leading-relaxed text-purple-500">
                           <div className="flex justify-between">
                               <span>Prior Expectation Model P(Model):</span>
                               <span className="text-cyan-400">{(priorProb * 100).toFixed(0)}%</span>
                           </div>
                           <div className="flex justify-between">
                               <span>Sensory Verity Likelihood P(Sensors | Model):</span>
                               <span className="text-cyan-400">{(sensoryLikelihood * 100).toFixed(0)}%</span>
                           </div>
                           <div className="flex justify-between font-bold border-t border-purple-950 pt-1.5 mt-1 text-purple-300">
                               <span>Posterior Probability P(Model | Evidence):</span>
                               <span className="text-fuchsia-400">{(posteriorProb * 100).toFixed(1)}%</span>
                           </div>
                       </div>
                       <div className="mt-3 text-[9px] bg-black/40 border border-purple-950/50 p-2 rounded text-purple-600">
                           {dmnConnectivity === 0 
                             ? "CRITICAL WARNING: Sensory correction loop severed. Internal model predictions overriding localized physical reality validation." 
                             : `Bayesian prediction aligned. Model maintains ${dmnConnectivity}% coupling to active localized physical constraints.`}
                       </div>
                   </div>

                    {/* Spatial Calibration Memory Registry */}
                    <div className="bg-[#0c0316] border border-purple-900/30 rounded p-4 mb-4 text-[10px] shadow-[inset_0_0_12px_rgba(168,85,247,0.03)]">
                        <h4 className="text-fuchsia-300 font-bold uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
                            <Database className="w-3.5 h-3.5 text-fuchsia-400" /> SPATIAL CALIBRATION REPOSITORY
                        </h4>
                        
                        <p className="text-[9px] text-purple-500 mb-3 leading-relaxed">
                            Sync current tuning ratios (Capacitance, Inductance, DMN state vectors) into persistent memory to lock in local physics configurations.
                        </p>

                        <div className="grid grid-cols-2 gap-2 mb-3">
                            <button 
                                onClick={saveSystemPreset}
                                className="px-3 py-2 border border-purple-800 hover:border-fuchsia-500 bg-purple-950/30 hover:bg-purple-900/20 text-fuchsia-300 font-bold text-xxs tracking-wider uppercase rounded transition-all flex items-center justify-center gap-1.5"
                            >
                                <Save className="w-3.5 h-3.5 text-fuchsia-400" /> SYNC VECTOR
                            </button>
                            <button 
                                onClick={clearSystemPreset}
                                className="px-3 py-2 border border-purple-950 hover:border-purple-800 bg-transparent hover:bg-purple-950/25 text-purple-600 hover:text-purple-400 font-bold text-xxs tracking-wider uppercase rounded transition-all"
                            >
                                PURGE MEMORY
                            </button>
                        </div>

                        <div className="flex items-center justify-between bg-black/50 border border-purple-950/80 rounded px-2.5 py-1.5 text-[8.5px]">
                            <span className="text-purple-600 font-bold uppercase">STATE RESIDUAL STATUS:</span>
                            <span className={`font-bold uppercase tracking-widest ${isMatrixSynchronized() ? 'text-emerald-400' : 'text-amber-500 animate-pulse'}`}>
                                {isMatrixSynchronized() ? '● LOCKED_SYNCHRONIZED' : '● UNCOMMITTED_CALIBRATION'}
                            </span>
                        </div>
                    </div>
                </div>

               {/* Column 2: RLC Physical Inductor & Capacitor Sandbox (4/12 width) */}
               <div className="col-span-12 lg:col-span-4 flex flex-col gap-4">
                   <div className="bg-[#02050f] border border-cyan-900/30 rounded p-4 shadow-[inset_0_0_15px_rgba(6,182,212,0.01)] flex-1 flex flex-col justify-between">
                       <div>
                           <h3 className="text-xs uppercase font-bold text-cyan-400 flex items-center gap-2 mb-3 border-b border-cyan-900/20 pb-2">
                              <Zap className="w-3.5 h-3.5 text-cyan-400" /> LC Oscillating Grid
                           </h3>
                           
                           <p className="text-[10px] text-cyan-500 mb-4 leading-relaxed">
                              Dial in the Capacitance (electric field $½CV²$) and Inductance (magnetic field $½LI²$). These parameters naturally oscillate at resonant frequency $f₀$.
                           </p>

                           {/* Oscillation Wave Canvas */}
                           <div className="bg-black border border-cyan-950/80 rounded mb-4 overflow-hidden relative">
                               <div className="absolute top-1 text-[8px] tracking-wider left-2 text-cyan-600 font-bold uppercase flex items-center gap-2">
                                  <span>CAPACITANCE POTENTIAL (V)</span>
                                  <span className="text-purple-600">●</span>
                                  <span className="text-fuchsia-500">INDUCTANCE FORCE (I)</span>
                               </div>
                               <canvas ref={canvasRef} className="w-full block bg-[#000000]" />
                           </div>

                           {/* Silders and values */}
                           <div className="space-y-3.5">
                               <div>
                                   <div className="flex justify-between text-[10px] mb-1">
                                       <span className="text-cyan-400">Capacitance Slider (C):</span>
                                       <span className="font-bold text-cyan-300">{C.toFixed(1)} μF</span>
                                   </div>
                                   <input 
                                       type="range" 
                                       min="1.0" 
                                       max="100.0" 
                                       step="0.5"
                                       value={C} 
                                       onChange={(e) => setC(Number(e.target.value))}
                                       className="w-full h-1 bg-cyan-950 rounded-lg appearance-none cursor-pointer accent-cyan-500"
                                   />
                               </div>

                               <div>
                                   <div className="flex justify-between text-[10px] mb-1">
                                       <span className="text-cyan-400">Inductance Slider (L):</span>
                                       <span className="font-bold text-cyan-300">{L.toFixed(0)} mH</span>
                                   </div>
                                   <input 
                                       type="range" 
                                       min="10" 
                                       max="1000" 
                                       step="10"
                                       value={L} 
                                       onChange={(e) => setL(Number(e.target.value))}
                                       className="w-full h-1 bg-cyan-950 rounded-lg appearance-none cursor-pointer accent-cyan-500"
                                   />
                               </div>

                               {/* Voltage and Current Sliders to scale amplitude dynamically */}
                               <div className="grid grid-cols-2 gap-3 pt-1">
                                   <div>
                                       <div className="flex justify-between text-[9px] mb-1">
                                           <span className="text-cyan-400">Voltage (V):</span>
                                           <span className="text-cyan-300 font-bold">{V} V</span>
                                       </div>
                                       <input 
                                           type="range" 
                                           min="1" 
                                           max="24" 
                                           value={V} 
                                           onChange={(e) => setV(Number(e.target.value))}
                                           className="w-full h-0.5 bg-cyan-950 cursor-pointer accent-cyan-400"
                                       />
                                   </div>
                                   <div>
                                       <div className="flex justify-between text-[9px] mb-1">
                                           <span className="text-pink-400">Current (I):</span>
                                           <span className="text-pink-300 font-bold">{I} A</span>
                                       </div>
                                       <input 
                                           type="range" 
                                           min="0.1" 
                                           max="5.0" 
                                           step="0.1"
                                           value={I} 
                                           onChange={(e) => setI(Number(e.target.value))}
                                           className="w-full h-0.5 bg-cyan-950 cursor-pointer accent-fuchsia-400"
                                       />
                                   </div>
                               </div>
                           </div>
                       </div>

                       {/* Sonification synthesizer triggers */}
                       <div className="border-t border-cyan-950/60 pt-4 mt-4 flex flex-col gap-2">
                           <button 
                               onClick={toggleHarmonics}
                               className={`w-full py-1.5 border rounded font-bold text-[10px] uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 ${harmonicEngineActive ? 'bg-cyan-900/30 text-cyan-300 border-cyan-500 shadow-[0_0_8px_rgba(6,182,212,0.15)]' : 'bg-transparent text-cyan-700 border-cyan-900/40 hover:bg-cyan-900/10'}`}
                           >
                               {harmonicEngineActive ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
                               {harmonicEngineActive ? "DISCRETE PINGS LIVE" : "ENABLE DISCRETE RESONANCE"}
                           </button>

                           <button 
                               onClick={toggleContinuousHum}
                               className={`w-full py-1.5 border rounded font-bold text-[10px] uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 ${continuousOscActive ? 'bg-fuchsia-900/30 text-fuchsia-300 border-fuchsia-500 shadow-[0_0_8px_rgba(217,70,239,0.15)]' : 'bg-transparent text-fuchsia-700 border-fuchsia-900/40 hover:bg-fuchsia-900/10'}`}
                           >
                               {continuousOscActive ? <Volume2 className="w-3.5 h-3.5 text-fuchsia-400" /> : <VolumeX className="w-3.5 h-3.5 text-fuchsia-400" />}
                               {continuousOscActive ? "PHYSICAL HUM BOUND" : "BIND INDUCTOR HUM"}
                           </button>
                       </div>
                   </div>

                   {/* Energy Density Stats Box */}
                   <div className="bg-[#01050d] border border-cyan-950 rounded p-4 text-[10px]">
                       <h4 className="text-cyan-300 font-bold uppercase tracking-wider mb-2 flex items-center gap-1.5">
                           <Gauge className="w-3 h-3 text-cyan-400" /> ENERGY SYSTEM CONVERSION
                       </h4>
                       <div className="space-y-1.5 leading-relaxed text-cyan-500">
                           <div className="flex justify-between">
                               <span>Electric Potential Energy (½CV²):</span>
                               <span className="text-cyan-400 font-mono">{(capacitanceEnergy * 1000).toFixed(4)} mJ</span>
                           </div>
                           <div className="flex justify-between">
                               <span>Magnetic Inductive Energy (½LI²):</span>
                               <span className="text-fuchsia-400 font-mono">{(inductanceEnergy * 1000).toFixed(4)} mJ</span>
                           </div>
                           <div className="flex justify-between border-t border-cyan-950/80 pt-1.5 mt-1 font-bold text-cyan-300">
                               <span>Resonant Frequency f₀:</span>
                               <span className="text-fuchsia-300 text-xs">{resonantFreq.toFixed(2)} Hz</span>
                           </div>
                       </div>
                   </div>
               </div>

               {/* Column 3: Multiverse Probability WebGL & Live Ledger (4/12 width) */}
               <div className="col-span-12 lg:col-span-4 flex flex-col gap-4">
                   {/* WebGL Stage */}
                   <div className="bg-black border border-purple-900/40 rounded flex flex-col relative overflow-hidden h-64 lg:h-80 shadow-[inset_0_0_30px_rgba(168,85,247,0.05)]">
                       
                       {/* Overlay HUD with core variables */}
                       <div className="absolute top-3 left-3 z-10 pointer-events-none flex flex-col">
                           <span className="text-[9px] text-fuchsia-400/80 font-bold uppercase tracking-widest flex items-center gap-1">
                               <Share2 className="w-3 h-3 text-fuchsia-400" />
                               6D Vector Grid
                           </span>
                           <span className="text-[8px] text-purple-600 font-mono mt-0.5">
                               Variance Scale: {(timelineBranches * resonantFreq * 0.1).toFixed(1)}
                           </span>
                       </div>

                       <div className="absolute bottom-3 right-3 z-10 pointer-events-none">
                            <span className="text-[8px] bg-purple-950/60 text-purple-400 px-2 py-1 border border-purple-900/40 rounded flex items-center gap-1">
                               <Activity className="w-2.5 h-2.5 animate-pulse" />
                               {(resonantFreq * timelineBranches * 0.12).toFixed(1)} TR/s
                            </span>
                       </div>

                       <Canvas camera={{ position: [0, 0, 10], fov: 60 }} gl={{ alpha: true, antialias: false }}>
                           <ambientLight intensity={0.2} />
                           <MultiverseCloud 
                              branchingFactor={timelineBranches} 
                              dmnConnectivity={dmnConnectivity} 
                              priorConfidence={priorConfidence} 
                           />
                       </Canvas>
                   </div>

                   {/* Cognitive Telemetry Log */}
                   <div className="flex-1 flex flex-col bg-black/60 border border-purple-900/20 rounded p-4">
                       <div className="flex justify-between items-center mb-2.5 border-b border-purple-950 pb-1.5 shrink-0">
                           <h4 className="text-[10px] uppercase font-bold text-purple-300 flex items-center gap-1.5">
                               <Layers className="w-3.5 h-3.5 text-fuchsia-400" /> Telemetry Ledger
                           </h4>
                           <button 
                               onClick={triggerAutonomousCalibration}
                               className="text-[8px] bg-purple-950/80 hover:bg-purple-900 border border-purple-800 text-purple-400 text-xxs font-bold px-2 py-0.5 rounded tracking-widest uppercase transition-colors"
                           >
                               SWEEP IMPEDANCE
                           </button>
                       </div>
                       
                       <div className="flex-1 overflow-y-auto h-40 custom-scrollbar text-[9px] text-purple-500/80 leading-relaxed font-mono">
                           {cognitiveLogs.length === 0 ? (
                               <div className="text-purple-805/40 italic">Monitoring physical matrix and neural priors...</div>
                           ) : (
                               cognitiveLogs.map((log, index) => (
                                   <div key={index} className="border-b border-purple-950/20 py-1 font-mono transition-opacity">
                                       {log}
                                   </div>
                               ))
                           )}
                       </div>
                   </div>
               </div>

           </div>
       </div>
    );
}
