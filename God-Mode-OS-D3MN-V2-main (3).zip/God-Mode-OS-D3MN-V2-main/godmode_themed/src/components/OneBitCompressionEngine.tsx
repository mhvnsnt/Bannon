import React, { useState, useEffect } from 'react';
import { Cpu, Zap, Activity, ShieldAlert, Cpu as CpuIcon, MemoryStick, Server, Network } from 'lucide-react';

export function OneBitCompressionEngine() {
  const [compressionRatio, setCompressionRatio] = useState(0);
  const [modelWeights, setModelWeights] = useState<number[]>([]);
  const [isCompressing, setIsCompressing] = useState(false);
  const [activeNode, setActiveNode] = useState<string | null>(null);
  const [entropy, setEntropy] = useState<number>(0);
  const [executionMode, setExecutionMode] = useState<'CLOUD' | 'WEBCONTAINER' | 'PURE_WASM'>('CLOUD');
  const [ollamaStatus, setOllamaStatus] = useState<'DISCONNECTED' | 'SCANNING' | 'LOCKED'>('DISCONNECTED');

  useEffect(() => {
    // initialize random model weights
    setModelWeights(Array.from({ length: 64 }, () => Math.random()));
    
    const interval = setInterval(() => {
      const e = Math.random() * 100;
      setEntropy(e);
      if (e > 80 && executionMode !== 'PURE_WASM') {
         setExecutionMode('PURE_WASM');
      } else if (e > 40 && e <= 80 && executionMode === 'CLOUD') {
         setExecutionMode('WEBCONTAINER');
      }

      if (Math.random() > 0.8) {
         setActiveNode(`NODE-${Math.floor(Math.random() * 1000)}`);
         setTimeout(() => setActiveNode(null), 500);
      }
    }, 2000);
    return () => clearInterval(interval);
  }, [executionMode]);

  const compressModel = () => {
    setIsCompressing(true);
    let step = 0;
    const quantize = setInterval(() => {
       step += 5;
       setCompressionRatio(step);
       // quantize weights slowly to 0 or 1
       setModelWeights(prev => prev.map(w => w > 0.5 ? 1 : 0));
       
       if (step >= 100) {
          clearInterval(quantize);
          setIsCompressing(false);
       }
    }, 100);
  };

  const pingOllama = () => {
     setOllamaStatus('SCANNING');
     setTimeout(() => {
         setOllamaStatus(Math.random() > 0.5 ? 'LOCKED' : 'DISCONNECTED');
     }, 1500);
  };

  return (
    <div className="w-full h-full bg-[#050505] text-amber-500 font-mono p-4 flex flex-col border-l border-amber-900/40 overflow-hidden">
      <div className="border-b border-amber-900/50 pb-3 mb-4 shrink-0 flex justify-between items-center">
        <div>
           <h2 className="text-sm font-bold uppercase tracking-widest text-amber-400 flex items-center gap-2">
             <Cpu className="w-4 h-4" /> One-Bit Compression Engine & Web Assembly Override
           </h2>
           <p className="text-[10px] text-amber-700 mt-1">Radical Efficiency. Localized Intelligence without external reliance. Offline capability.</p>
        </div>
        <div className="flex gap-2">
            <div className={`text-[10px] px-2 py-1 border rounded font-bold animate-pulse ${executionMode === 'PURE_WASM' ? 'bg-red-900/40 text-red-500 border-red-500/50' : executionMode === 'WEBCONTAINER' ? 'bg-blue-900/40 text-blue-500 border-blue-500/50' : 'bg-emerald-900/40 text-emerald-500 border-emerald-500/50'}`}>
               EXEC: {executionMode}
            </div>
            <div className="text-[10px] bg-amber-900/20 text-amber-400 px-2 py-1 border border-amber-500/30 rounded font-bold">
               COMPRESSION: {compressionRatio}%
            </div>
        </div>
      </div>

      <div className="flex-1 grid grid-cols-2 gap-4 pb-4 overflow-y-auto custom-scrollbar">
         <div className="flex flex-col gap-4">
             <div className="bg-[#0a0a0a] border border-amber-900/30 rounded p-4 flex flex-col gap-4 shadow-[0_0_15px_rgba(245,158,11,0.02)]">
                <h3 className="text-xs uppercase font-bold text-amber-500 flex items-center gap-2">
                  <Zap className="w-3 h-3" /> Matrix Quantization
                </h3>
                
                <div className="flex-1 grid grid-cols-8 gap-1 p-2 bg-black border border-amber-900/20 rounded">
                   {modelWeights.map((w, i) => (
                      <div 
                        key={i} 
                        className={`w-full aspect-square rounded-[1px] transition-colors duration-300 ${w > 0.5 ? 'bg-amber-400' : 'bg-amber-950/40'}`}
                        style={{ opacity: isCompressing ? Math.random() : 1 }}
                      />
                   ))}
                </div>

                <button 
                   onClick={compressModel}
                   disabled={isCompressing || compressionRatio === 100}
                   className="w-full py-2 bg-amber-900/20 hover:bg-amber-900/40 border border-amber-500/50 rounded font-bold text-xs uppercase tracking-widest text-amber-400 transition-colors disabled:opacity-50"
                >
                   {isCompressing ? 'QUANTIZING WEIGHTS...' : compressionRatio === 100 ? 'ONE-BIT LOCKED' : 'INITIATE 1-BIT COMPRESSION'}
                </button>
             </div>

             <div className="bg-[#0a0a0a] border border-amber-900/30 rounded p-4 flex flex-col gap-4 shadow-[0_0_15px_rgba(245,158,11,0.02)]">
                <h3 className="text-xs uppercase font-bold text-amber-500 flex items-center gap-2">
                  <Server className="w-3 h-3" /> Local Ollama Integration
                </h3>
                <div className="text-[10px] text-amber-700 italic">
                  Mapping to localhost:11434 to ingest quantized 1-bit models.
                </div>
                <div className="flex justify-between items-center p-2 bg-black border border-amber-900/20 rounded">
                   <span className="text-[10px] uppercase font-bold text-amber-600">llama.cpp 1-bit payload:</span>
                   <span className={`text-[10px] font-bold ${ollamaStatus === 'LOCKED' ? 'text-emerald-500' : ollamaStatus === 'SCANNING' ? 'text-amber-500 animate-pulse' : 'text-red-500'}`}>
                      {ollamaStatus}
                   </span>
                </div>
                <button 
                   onClick={pingOllama}
                   className="w-full py-1 text-[10px] uppercase tracking-widest border border-amber-900/50 hover:bg-amber-900/20 text-amber-500 rounded transition"
                >
                   Ping Localhost Vector
                </button>
             </div>
         </div>

         <div className="bg-[#0a0a0a] border border-amber-900/30 rounded p-4 flex flex-col gap-4 relative overflow-hidden shadow-[0_0_15px_rgba(245,158,11,0.02)]">
             <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
                <CpuIcon className="w-32 h-32" />
             </div>
             <h3 className="text-xs uppercase font-bold text-amber-500 flex items-center gap-2">
               <Activity className="w-3 h-3" /> Bare Metal Fallback Metrics
             </h3>
             <div className="flex flex-col gap-2 flex-1 relative z-10">
                 <div className="flex flex-col gap-1 mb-2">
                    <div className="flex justify-between text-[10px] text-amber-600">
                        <span>Network Entropy</span>
                        <span>{entropy.toFixed(1)}%</span>
                    </div>
                    <div className="w-full bg-black border border-amber-900/30 h-1.5 rounded">
                        <div className={`h-full ${entropy > 80 ? 'bg-red-500' : entropy > 40 ? 'bg-amber-500' : 'bg-emerald-500'} transition-all`} style={{ width: `${entropy}%` }} />
                    </div>
                 </div>

                 {[
                   { label: 'External Node API Calls', value: executionMode === 'PURE_WASM' ? '0/s (OFFLINE)' : '12.4 /s' },
                   { label: 'WebContainer State', value: executionMode === 'WEBCONTAINER' ? 'RUNNING (In-Browser Server)' : 'SLEEP' },
                   { label: 'Local Memory Footprint', value: compressionRatio === 100 ? '1.2 MB' : '45.8 MB' },
                   { label: 'WASM Physics Engine', value: executionMode === 'PURE_WASM' ? 'ACTIVE' : 'STANDBY' },
                   { label: 'Inference Latency', value: compressionRatio === 100 ? '0.4 ms' : '15.2 ms' },
                   { label: 'Active Edge Node', value: activeNode || 'IDLE' }
                 ].map((stat, idx) => (
                    <div key={idx} className="flex justify-between items-center p-2 border-b border-amber-900/20 text-xs">
                        <span className="text-amber-700">{stat.label}</span>
                        <span className="font-bold text-amber-300">{stat.value}</span>
                    </div>
                 ))}
             </div>
         </div>
      </div>
    </div>
  );
}
