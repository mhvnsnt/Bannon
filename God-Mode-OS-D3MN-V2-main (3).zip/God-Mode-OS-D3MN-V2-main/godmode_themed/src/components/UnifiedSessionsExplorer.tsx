import React, { useEffect, useState } from 'react';
import { Database, Download, FileText, Target, Crosshair, ArrowRight } from 'lucide-react';

export function UnifiedSessionsExplorer() {
  const [sessions, setSessions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/godmode/session/unified')
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          setSessions(data.sessions);
        }
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return <div className="p-4 text-xs font-mono text-gray-500 uppercase">Loading session archive...</div>;
  }

  return (
    <div className="flex flex-col h-full bg-[#0a0a0a] border border-[#1e1e1e] rounded-lg overflow-hidden">
      <div className="p-3 border-b border-[#1e1e1e] flex items-center justify-between">
        <h3 className="text-[10px] font-bold text-gray-300 font-mono flex items-center">
          <Database className="w-3 h-3 mr-2" />
          DNA ARCHIVE (UNIFIED SESSIONS)
        </h3>
      </div>
      
      <div className="flex-1 overflow-y-auto p-3 space-y-4">
        {sessions.length === 0 ? (
          <div className="text-[10px] font-mono text-gray-600 text-center py-8">
            No exported sessions found. Install the Tampermonkey script and export JSON snapshots.
          </div>
        ) : (
          sessions.map((session, i) => (
             <div key={session.id || i} className="p-3 border border-[#2a2a2a] bg-[#111] rounded shadow-inner">
               <div className="flex justify-between items-center mb-2">
                 <div className="text-[9px] uppercase font-bold text-emerald-400 bg-emerald-900/30 px-2 py-0.5 rounded-full inline-block">
                   [{session.platform}] {session.project}
                 </div>
                 <div className="text-[8px] text-gray-500 font-mono">
                   {new Date(session.timestamp).toLocaleString()}
                 </div>
               </div>
               
               <div className="space-y-2 mt-3">
                 <div>
                   <p className="text-[10px] text-gray-400 leading-relaxed font-mono whitespace-pre-wrap">
                     <span className="text-gray-300 font-bold mb-1 flex items-center"><FileText className="w-3 h-3 mr-1"/> SUMMARY</span>
                     {session.summary}
                   </p>
                 </div>

                 {session.key_decisions && (
                   <div className="pt-2 border-t border-[#1e1e1e]">
                     <p className="text-[10px] text-amber-300/80 leading-relaxed font-mono whitespace-pre-wrap">
                       <span className="font-bold text-amber-500 mb-1 flex items-center"><Target className="w-3 h-3 mr-1"/> KEY DECISIONS</span>
                       {session.key_decisions}
                     </p>
                   </div>
                 )}

                 {session.next_target && (
                   <div className="pt-2 border-t border-[#1e1e1e]">
                     <p className="text-[10px] text-cyan-300/80 leading-relaxed font-mono whitespace-pre-wrap">
                       <span className="font-bold text-cyan-500 mb-1 flex items-center"><Crosshair className="w-3 h-3 mr-1"/> NEXT TARGET</span>
                       {session.next_target}
                     </p>
                   </div>
                 )}
               </div>
               
             </div>
          ))
        )}
      </div>
    </div>
  );
}
