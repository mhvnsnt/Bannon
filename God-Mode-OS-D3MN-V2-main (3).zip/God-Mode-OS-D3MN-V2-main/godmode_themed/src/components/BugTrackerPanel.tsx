import React, { useState, useEffect } from 'react';
import { BugIcon, Check, Plus, AlertCircle } from 'lucide-react';

export default function BugTrackerPanel() {
  const [bugs, setBugs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [newTitle, setNewTitle] = useState('');
  const [newLocation, setNewLocation] = useState('');
  const [newDesc, setNewDesc] = useState('');

  const loadBugs = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/quantum/bugs');
      const data = await res.json();
      if (data.success) {
        setBugs(data.bugs);
      }
    } catch (e: any) {
      console.error(e);
    }
    setLoading(false);
  };

  useEffect(() => {
    loadBugs();
  }, []);

  const handleAddBug = async () => {
    if (!newTitle) return;
    try {
      await fetch('/api/quantum/bugs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: newTitle, location: newLocation, description: newDesc })
      });
      setNewTitle('');
      setNewLocation('');
      setNewDesc('');
      loadBugs();
    } catch (e: any) {
      console.error(e);
    }
  };

  const handleToggleStatus = async (id: number, currentStatus: string) => {
    try {
      const newStatus = currentStatus === 'OPEN' ? 'CLOSED' : 'OPEN';
      await fetch(`/api/quantum/bugs/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus, fixed_in_commit: newStatus === 'CLOSED' ? 'Manual/Diff' : '' })
      });
      loadBugs();
    } catch (e: any) {
      console.error(e);
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#0a0a0a] text-gray-200 font-mono p-6">
      <div className="flex items-center gap-3 mb-6 border-b border-[#222] pb-4">
        <BugIcon className="text-red-400 w-6 h-6" />
        <h2 className="text-xl font-bold tracking-widest uppercase">System Bug Tracker</h2>
      </div>

      <div className="flex flex-col gap-3 mb-8 bg-[#111] border border-[#333] p-4 rounded">
        <div className="text-xs text-red-400 uppercase tracking-widest font-bold">Log New Defect</div>
        <div className="flex gap-4">
          <input 
            type="text" 
            value={newTitle} 
            onChange={e => setNewTitle(e.target.value)}
            className="flex-1 bg-[#0a0a0a] border border-[#222] p-2 text-sm focus:outline-none focus:border-red-500 rounded"
            placeholder="Defect Title"
          />
          <input 
            type="text" 
            value={newLocation} 
            onChange={e => setNewLocation(e.target.value)}
            className="w-1/3 bg-[#0a0a0a] border border-[#222] p-2 text-sm focus:outline-none focus:border-red-500 rounded"
            placeholder="Location (e.g. game.ts, player.js)"
          />
        </div>
        <textarea 
          value={newDesc} 
          onChange={e => setNewDesc(e.target.value)}
          className="w-full bg-[#0a0a0a] border border-[#222] p-2 text-sm focus:outline-none focus:border-red-500 rounded h-20 resize-none"
          placeholder="Steps to reproduce, expected behavior, visual glitches..."
        />
        <div className="flex justify-end">
          <button 
            onClick={handleAddBug}
            disabled={!newTitle}
            className="bg-red-900/50 hover:bg-red-800 text-red-300 px-6 py-2 rounded uppercase font-bold text-xs tracking-widest border border-red-500/30 flex items-center gap-2 transition-colors disabled:opacity-50"
          >
            <Plus className="w-4 h-4" /> Log Bug
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto pr-2 flex flex-col gap-3">
        {bugs.length === 0 && !loading && (
          <div className="text-gray-600 text-xs tracking-widest text-center mt-10">NO BUGS TRACKED</div>
        )}
        {bugs.map(bug => (
          <div key={bug.id} className={`flex flex-col border p-4 rounded ${bug.status === 'OPEN' ? 'bg-[#150a0a] border-red-900/50' : 'bg-[#0a150a] border-emerald-900/50'} relative group`}>
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                {bug.status === 'OPEN' ? <AlertCircle className="text-red-500 w-5 h-5" /> : <Check className="text-emerald-500 w-5 h-5" />}
                <h3 className={`font-bold text-sm ${bug.status === 'OPEN' ? 'text-red-300' : 'text-emerald-300 line-through opacity-70'}`}>
                  {bug.title}
                </h3>
              </div>
              <button 
                onClick={() => handleToggleStatus(bug.id, bug.status)}
                className={`text-[10px] tracking-widest uppercase px-3 py-1 rounded border transition-colors ${
                  bug.status === 'OPEN' ? 'border-emerald-500/30 text-emerald-400 hover:bg-emerald-900/30' : 'border-red-500/30 text-red-400 hover:bg-red-900/30'
                }`}
              >
                Mark {bug.status === 'OPEN' ? 'Fixed' : 'Open'}
              </button>
            </div>
            
            <div className="mt-2 text-xs text-gray-400 flex gap-4">
              <span className="bg-black px-2 py-1 rounded border border-[#222]">LOC: {bug.location || 'UNKNOWN'}</span>
              <span className="bg-black px-2 py-1 rounded border border-[#222]">LOGGED: {new Date(bug.created_at).toLocaleString()}</span>
            </div>
            
            {bug.description && (
              <div className="mt-3 text-sm text-gray-300 whitespace-pre-wrap bg-black/40 p-3 rounded">
                {bug.description}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
