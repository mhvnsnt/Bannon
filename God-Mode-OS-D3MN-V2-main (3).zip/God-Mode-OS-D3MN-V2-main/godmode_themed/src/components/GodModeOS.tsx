import React, { useState, useEffect } from 'react';
import { PANELS } from '../App';
import { motion, AnimatePresence } from 'framer-motion';
import { Activity, Shield, Terminal, Database, Upload, Layers, Target, Play, Pause, Network } from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';

interface IngestedData {
    id: string;
    pattern: string;
    signature: string;
    variables: Record<string, number>;
    timestamp: string;
}

export default function GodModeOS({ onNavigate }: { onNavigate: (id: string, isRightPanel: boolean) => void }) {
  const [systemTime, setSystemTime] = useState("");
  const [rawInput, setRawInput] = useState('');
  const [dataFeed, setDataFeed] = useState<IngestedData[]>([]);
  const [isCompiling, setIsCompiling] = useState(false);
  const [engineStatus, setEngineStatus] = useState<'IDLE' | 'ACTIVE' | 'PROCESSING'>('ACTIVE');
  
  useEffect(() => {
     const updateTime = () => {
         const now = new Date();
         setSystemTime(now.toLocaleTimeString('en-US', { hour12: false }) + '.' + now.getMilliseconds().toString().padStart(3, '0'));
     };
     const t = setInterval(updateTime, 50);
     return () => clearInterval(t);
  }, []);

    useEffect(() => {
        fetchInputData();
        const interval = setInterval(fetchInputData, 10000); // Check every 10s
        return () => clearInterval(interval);
    }, []);

    const fetchInputData = async () => {
        try {
            const res = await fetch('/api/armada/quantum/nexus/data');
            const data = await res.json();
            if (data.success) {
                setDataFeed(data.logs.reverse().slice(0, 50));
            }
        } catch (e: any) {
            console.error("Failed to fetch nexus data.");
        }
    };

    const handleIngestion = async () => {
        if (!rawInput.trim()) return;
        setIsCompiling(true);
        setEngineStatus('PROCESSING');
        
        try {
            const payload = {
                pattern: `ASSET-DROP-${Math.floor(Math.random() * 10000)}`,
                signature: `RESONANCE-${Math.random().toString(36).substring(7).toUpperCase()}`,
                variables: {
                    L_Mass: Math.floor(Math.random() * 80) + 20,
                    C_Density: Math.floor(Math.random() * 80) + 20,
                    Social_Proof_Resonance: Math.floor(Math.random() * 100)
                }
            };

            await fetch('/api/armada/quantum/nexus/ingest', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            setRawInput('');
            await fetchInputData();
        } catch (e: any) {
             console.error("Ingestion failed.");
        }
        
        setIsCompiling(false);
        setEngineStatus('ACTIVE');
    };

    const chartData = dataFeed.slice(0, 20).reverse().map(d => ({
        time: new Date(d.timestamp).toLocaleTimeString(),
        L_Torque: d.variables?.L_Mass || 0,
        C_Integrity: d.variables?.C_Density || 0,
        Social_Proof: d.variables?.Social_Proof_Resonance || 0
    }));

  return (
    <div className="flex flex-col p-6 w-full h-full overflow-y-auto bg-[#030303] text-gray-200 relative font-mono">
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-[0.03] pointer-events-none" />
      <div className="absolute top-0 w-full h-1 bg-gradient-to-r from-transparent via-cyan-500/50 to-transparent shadow-[0_0_15px_#06b6d4] opacity-50" />

      <div className="flex flex-col gap-6 max-w-[1600px] mx-auto w-full relative z-10 pb-20">
        
        {/* Superior Header */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 border-b border-[#222] pb-6">
           <div className="flex flex-col gap-3">
             <div className="flex items-center gap-3">
               <div className="flex items-center justify-center w-10 h-10 bg-cyan-950 border border-cyan-500/50 shadow-[0_0_20px_rgba(6,182,212,0.3)]">
                 <Terminal className="text-cyan-400 w-5 h-5" />
               </div>
               <div>
                  <h1 className="text-3xl font-black tracking-[0.2em] text-white flex items-center gap-3 uppercase">
                   God Mode <span className="text-cyan-400 font-light">OS</span><br/>
                   <span className="text-lg text-emerald-400 mt-1">God-Mode OS Living Nexus</span>
                  </h1>
                  <p className="text-xs text-gray-500 font-mono mt-1 tracking-widest uppercase">
                    Prime Node Authority & Local Sector Spatial Command
                  </p>
               </div>
             </div>
           </div>

           <div className="flex gap-4 items-center">
              <div className="flex flex-col items-end">
                 <span className="text-[10px] text-gray-500 tracking-widest uppercase font-mono mb-1">LOCAL SIDEREAL TIME</span>
                 <span className="text-xl font-mono font-light tracking-[0.2em] text-cyan-500">{systemTime}</span>
              </div>
              <div className="h-10 w-px bg-[#333]" />
              <div className="flex flex-col gap-1 items-end">
                 <div className="flex items-center gap-2 text-[10px] tracking-widest uppercase text-emerald-500 font-bold">
                    {engineStatus === 'ACTIVE' ? <Play className="w-3 h-3 animate-pulse" /> : engineStatus === 'PROCESSING' ? <Activity className="w-3 h-3 animate-spin"/> : <Pause className="w-3 h-3" />}
                    Engine: {engineStatus}
                 </div>
                 <div className="flex items-center gap-2 text-[10px] tracking-widest uppercase text-amber-500 font-bold">
                    <Shield className="w-3 h-3" /> Defenses Minted
                 </div>
              </div>
           </div>
        </div>

        {/* Primary Node Authority Dashboard Elements */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Ingestion & Asset Deployment */}
            <div className="bg-[#0a0a0f]/80 backdrop-blur-sm rounded-xl border border-cyan-900/40 p-4 flex flex-col shadow-[0_4px_20px_rgba(0,0,0,0.5)]">
                 <h3 className="text-sm font-bold tracking-widest text-cyan-400 uppercase flex items-center gap-2 mb-4 border-b border-cyan-900/50 pb-2">
                     <Upload className="w-4 h-4"/> High-Density Asset Deployment
                 </h3>
                 <p className="text-xs text-gray-400 mb-4">Deploy projects, sonic architecture, or structural codes. Zero friction execution to generate immediate local grid resonance and Social Proof.</p>
                 <textarea 
                     value={rawInput}
                     onChange={(e) => setRawInput(e.target.value)}
                     placeholder="Enter logic, sonic architecture, or raw physical density commands..."
                     className="flex-1 min-h-[120px] w-full bg-[#111] text-cyan-100 p-3 rounded font-mono text-sm border border-[#333] focus:border-cyan-500 focus:outline-none focus:ring-1 focus:ring-cyan-500/50 resize-none transition-all placeholder-gray-700"
                 />
                 <button 
                     onClick={handleIngestion}
                     disabled={isCompiling || !rawInput.trim()}
                     className="mt-4 w-full py-3 bg-cyan-900/40 text-cyan-300 font-bold tracking-widest uppercase text-xs rounded border border-cyan-500/50 hover:bg-cyan-800/60 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                 >
                     {isCompiling ? <Activity className="w-4 h-4 animate-spin"/> : <Target className="w-4 h-4"/>}
                     {isCompiling ? 'Deploying to Grid...' : 'Deploy Asset & Generate Resonance'}
                 </button>
            </div>

            {/* Resonance Chart */}
            <div className="bg-[#0a0a0f]/80 backdrop-blur-sm rounded-xl border border-[#222] p-4 flex flex-col shadow-[0_4px_20px_rgba(0,0,0,0.5)] lg:col-span-2">
                 <h3 className="text-sm font-bold tracking-widest text-emerald-400 uppercase flex items-center gap-2 mb-4 border-b border-[#333] pb-2">
                     <Activity className="w-4 h-4"/> Magnetic Induction & Local Torque
                 </h3>
                 <div className="flex-1 w-full min-h-[200px] relative">
                     <ResponsiveContainer width="100%" height="100%">
                         <AreaChart data={chartData}>
                             <defs>
                                 <linearGradient id="colorL" x1="0" y1="0" x2="0" y2="1">
                                     <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                                     <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                                 </linearGradient>
                                 <linearGradient id="colorC" x1="0" y1="0" x2="0" y2="1">
                                     <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                                     <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                                 </linearGradient>
                                 <linearGradient id="colorS" x1="0" y1="0" x2="0" y2="1">
                                     <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3}/>
                                     <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                                 </linearGradient>
                             </defs>
                             <CartesianGrid strokeDasharray="3 3" stroke="#222" vertical={false} />
                             <XAxis dataKey="time" stroke="#444" fontSize={10} tickMargin={10} />
                             <YAxis stroke="#444" fontSize={10} />
                             <Tooltip contentStyle={{ backgroundColor: '#000', border: '1px solid #333', fontSize: '10px', color: '#fff' }} itemStyle={{ color: '#fff' }} />
                             <Area type="monotone" dataKey="L_Torque" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#colorL)" isAnimationActive={true} animationDuration={800} />
                             <Area type="monotone" dataKey="C_Integrity" stroke="#3b82f6" strokeWidth={2} fillOpacity={1} fill="url(#colorC)" isAnimationActive={true} animationDuration={800} />
                             <Area type="monotone" dataKey="Social_Proof" stroke="#8b5cf6" strokeWidth={2} fillOpacity={1} fill="url(#colorS)" isAnimationActive={true} animationDuration={800} />
                         </AreaChart>
                     </ResponsiveContainer>
                 </div>
            </div>
        </div>

        {/* Local Sector Magnetic Field Events (Asset Drops) */}
        {dataFeed.length > 0 && (
            <div className="bg-[#0a0a0f]/80 backdrop-blur-sm rounded-xl border border-[#222] p-4 flex flex-col shadow-[0_4px_20px_rgba(0,0,0,0.5)] overflow-hidden relative">
                 <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-cyan-500 via-purple-500 to-emerald-500 opacity-50"></div>
                 <h3 className="text-sm font-bold tracking-widest text-[#aaa] uppercase flex items-center gap-2 mb-4 border-b border-[#333] pb-2 mt-2">
                   <Network className="w-4 h-4"/> Local Sector Magnetic Field Events (Asset Drops)
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                     <AnimatePresence>
                        {dataFeed.slice(0, 4).map((data) => (
                            <motion.div 
                                initial={{ opacity: 0, scale: 0.9 }}
                                animate={{ opacity: 1, scale: 1 }}
                                key={data.id} 
                                className="bg-[#111] border border-[#222] p-3 rounded flex flex-col group relative overflow-hidden"
                            >
                                <div className="absolute left-0 top-0 bottom-0 w-1 bg-cyan-900/50 group-hover:bg-cyan-500 transition-colors"></div>
                                <div className="flex flex-col ml-2 mb-3">
                                    <span className="font-bold text-gray-200 text-xs truncate">{data.pattern}</span>
                                    <span className="text-[9px] text-cyan-600 font-mono tracking-wider truncate">{data.signature}</span>
                                </div>
                                <div className="grid grid-cols-3 gap-1 mt-auto">
                                   {Object.entries(data.variables).map(([key, val]) => {
                                        let colorClass = 'text-blue-400';
                                        if (key.includes('L_')) colorClass = 'text-emerald-400';
                                        if (key.includes('Social')) colorClass = 'text-purple-400';
                                        return (
                                            <div key={key} className="flex flex-col items-center bg-[#1a1a1a] border border-[#333] rounded py-1 px-1">
                                               <span className="text-[8px] text-gray-500 uppercase tracking-tighter truncate w-full text-center">{key.replace('_', '')}</span>
                                               <span className={`text-[10px] font-bold ${colorClass}`}>{val}</span>
                                            </div>
                                        )
                                   })}
                                </div>
                            </motion.div>
                        ))}
                    </AnimatePresence>
                </div>
            </div>
        )}

        <div className="h-px bg-gradient-to-r from-transparent via-[#333] to-transparent my-4" />
        <h3 className="text-sm font-bold tracking-widest text-cyan-500 uppercase flex items-center gap-2 mb-2">
            <Layers className="w-4 h-4"/> Primary & Secondary Structural Modules
        </h3>

        {/* Modules Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
          {PANELS.filter(p => p.id !== 'god_mode_os').map((p, idx) => (
            <motion.button
              key={p.id}
              initial={{ opacity: 0, y: 15, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ delay: idx * 0.015, duration: 0.3, ease: 'easeOut' }}
              onClick={() => onNavigate(p.id, !p.isMain)}
              className={`flex flex-col items-start gap-4 p-5 border transition-all text-left group relative overflow-hidden backdrop-blur-sm
                 ${p.isMain ? 'bg-[#0a0a0f]/80 border-indigo-900/40 hover:bg-[#0f0f1a] hover:border-indigo-500/60 shadow-[0_4px_20px_rgba(0,0,0,0.5)] hover:shadow-[0_4px_30px_rgba(99,102,241,0.2)] rounded-lg' 
                 : 'bg-[#111111]/80 border-[#333] hover:bg-[#1a1a1a] hover:border-[#555] rounded-lg'}
              `}
            >
              {/* Decoration Line */}
              {p.isMain && (
                 <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-indigo-500 to-cyan-400 opacity-0 group-hover:opacity-100 transition-opacity" />
              )}
              
              <div className="flex justify-between w-full items-start">
                 <div className={`p-3 rounded flex items-center justify-center transition-transform group-hover:scale-110 shadow-sm ${p.isMain ? 'bg-indigo-950/50 border border-indigo-500/30' : 'bg-[#222] border border-[#333]'}`}>
                   {p.icon}
                 </div>
                 <div className="flex items-center gap-1 opacity-20 group-hover:opacity-100 transition-opacity">
                    <div className={`w-1 h-1 rounded-full ${p.isMain ? 'bg-cyan-400' : 'bg-gray-400'}`} />
                    <div className={`w-1 h-1 rounded-full ${p.isMain ? 'bg-indigo-400' : 'bg-gray-500'}`} />
                 </div>
              </div>

              <div className="flex flex-col gap-1.5 mt-2">
                <span className={`font-bold tracking-wide uppercase text-xs ${p.isMain ? 'text-indigo-100' : 'text-gray-300'}`}>{p.label}</span>
                <span className={`text-[10px] tracking-widest uppercase font-mono ${p.isMain ? 'text-indigo-400/80' : 'text-gray-500'}`}>
                  {p.isMain ? "Prime Architecture Module" : "Secondary Workspace Panel"}
                </span>
              </div>
            </motion.button>
          ))}
        </div>
      </div>
    </div>
  );
}
