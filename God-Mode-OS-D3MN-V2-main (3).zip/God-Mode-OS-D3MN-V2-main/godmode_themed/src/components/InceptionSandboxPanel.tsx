import React, { useState, useEffect, useRef } from 'react';
import { 
  Terminal, 
  Play, 
  Square, 
  RotateCw, 
  Plus, 
  Eye, 
  History, 
  Layers, 
  Gamepad2, 
  Settings, 
  Flame, 
  Activity, 
  CheckCircle2, 
  Database,
  Code,
  Shield,
  ExternalLink
} from 'lucide-react';
import axios from 'axios';

interface Preset {
  id: string;
  name: string;
  rootFile: string;
  sourceFile: string;
  command: string;
}

interface SandboxServer {
  id: string;
  name: string;
  port: number;
  status: 'IDLE' | 'RUNNING' | 'ERROR';
  command: string;
  createdAt: string;
  startedAt?: string;
  logCount: number;
}

export function InceptionSandboxPanel() {
  // Configured servers & presets
  const [servers, setServers] = useState<SandboxServer[]>([]);
  const [presets, setPresets] = useState<Preset[]>([]);
  
  // Controls state
  const [selectedPresetId, setSelectedPresetId] = useState<string>('bannon-game');
  const [selectedPort, setSelectedPort] = useState<number>(8080);
  const [activeServerPort, setActiveServerPort] = useState<number>(8080);
  
  // Custom File creator
  const [customAppId, setCustomAppId] = useState<string>('micro-game');
  const [customAppName, setCustomAppName] = useState<string>('Neon Quantum Cyberdome');
  const [htmlContent, setHtmlContent] = useState<string>(`<div style="padding: 20px;">
  <h2>NEON QUANTUM CYBERDOME</h2>
  <canvas id="gameCanvas" width="300" height="150" style="background:#000; border:2px solid #a855f7; display:block; margin: 10px auto;"></canvas>
  <button id="fireBtn" style="background:#a855f7; color:white; border:none; padding:8px 16px; border-radius:4px; font-weight:bold; cursor:pointer;">ENGAGE REACTION</button>
</div>`);
  const [cssContent, setCssContent] = useState<string>(`h2 { color: #f43f5e !important; text-shadow: 0 0 8px rgba(244,63,94,0.6) !important; }
button:hover { background-color: #ec4899 !important; box-shadow: 0 0 10px #ec4899; }`);
  const [jsContent, setJsContent] = useState<string>(`const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
let x = 150, y = 75, dx = 2, dy = 1;

function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.beginPath();
    ctx.arc(x, y, 10, 0, Math.PI * 2);
    ctx.fillStyle = "#38bdf8";
    ctx.shadowBlur = 10;
    ctx.shadowColor = "#38bdf8";
    ctx.fill();
    ctx.closePath();
    
    if (x < 10 || x > canvas.width - 10) dx = -dx;
    if (y < 10 || y > canvas.height - 10) dy = -dy;
    x += dx; y += dy;
    requestAnimationFrame(draw);
}
draw();

document.getElementById('fireBtn').addEventListener('click', () => {
   dx *= 1.3;
   dy *= 1.3;
   document.getElementById('dynamic-log').innerText = 'Reaction velocity accelerated: ' + dx.toFixed(2);
});`);

  // Logs & UI
  const [consoleLogs, setConsoleLogs] = useState<string>('Loading telemetry channel...\n');
  const [activeTab, setActiveTab] = useState<'launcher' | 'creation'>('launcher');
  const [iframeKey, setIframeKey] = useState<number>(0);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const logEndRef = useRef<HTMLDivElement>(null);

  // Poll for servers every 2 seconds & specific console logs
  useEffect(() => {
    fetchStatus();
    const interval = setInterval(() => {
      fetchStatus();
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  // Poll logs for active selected port
  useEffect(() => {
    fetchLogs(activeServerPort);
    const logInterval = setInterval(() => {
      fetchLogs(activeServerPort);
    }, 1500);

    return () => clearInterval(logInterval);
  }, [activeServerPort]);

  const fetchStatus = async () => {
    try {
      const res = await axios.get('/api/armada/inception/servers');
      if (res.data.success) {
        setServers(res.data.servers);
        setPresets(res.data.presets);
      }
    } catch (e) {}
  };

  const fetchLogs = async (port: number) => {
    try {
      const res = await axios.get(`/api/armada/inception/logs/${port}`);
      if (res.data.success) {
        setConsoleLogs(res.data.logs || 'Server silent. Standing by.\n');
        // Auto-scroll logs
        if (logEndRef.current) {
          logEndRef.current.scrollIntoView({ behavior: 'smooth' });
        }
      }
    } catch (e) {}
  };

  const triggerStart = async () => {
    try {
      setErrorMsg(null);
      const res = await axios.post('/api/armada/inception/start', {
        port: selectedPort,
        presetId: selectedPresetId
      });
      if (res.data.success) {
        setSuccessMsg(`Flawlessly ignited sandbox on Port ${selectedPort}`);
        setActiveServerPort(selectedPort);
        setTimeout(() => setSuccessMsg(null), 3000);
        fetchStatus();
        setIframeKey(k => k + 1); // reload preview
      }
    } catch (err: any) {
      setErrorMsg(err.response?.data?.error || err.message);
    }
  };

  const triggerReboot = async (port: number) => {
    try {
      setErrorMsg(null);
      // Find preset for running server
      const current = servers.find(s => s.port === port);
      const presetId = current ? current.id : selectedPresetId;
      
      const res = await axios.post('/api/armada/inception/reboot', {
        port,
        presetId
      });
      
      if (res.data.success) {
        setSuccessMsg(`Server on Port ${port} successfully hot-swapped & rebooted.`);
        setActiveServerPort(port);
        setTimeout(() => setSuccessMsg(null), 3000);
        setIframeKey(k => k + 1);
        fetchStatus();
      }
    } catch (err: any) {
      setErrorMsg(err.response?.data?.error || err.message);
    }
  };

  const triggerStop = async (port: number) => {
    try {
      setErrorMsg(null);
      const res = await axios.post('/api/armada/inception/stop', { port });
      if (res.data.success) {
        setSuccessMsg(`Successfully offline-terminated container on port ${port}`);
        setTimeout(() => setSuccessMsg(null), 3000);
        fetchStatus();
      }
    } catch (err: any) {
      setErrorMsg(err.response?.data?.error || err.message);
    }
  };

  const compileCustomApp = async () => {
    try {
      setErrorMsg(null);
      const res = await axios.post('/api/armada/inception/create', {
        id: customAppId,
        name: customAppName,
        htmlContent,
        cssContent,
        jsContent
      });

      if (res.data.success) {
        setSuccessMsg(`Custom sandbox layout compiled and registered under ID: ${res.data.preset.id}`);
        setSelectedPresetId(res.data.preset.id);
        setActiveTab('launcher');
        setTimeout(() => setSuccessMsg(null), 4000);
        fetchStatus();
      }
    } catch (err: any) {
      setErrorMsg(err.response?.data?.error || err.message);
    }
  };

  // Resolve proxy source
  const proxyUrl = `/api/armada/inception/proxy/${activeServerPort}/`;

  return (
    <div className="flex flex-col h-full bg-[#07070a] text-gray-200 font-sans border border-[#222] rounded-xl overflow-hidden relative">
      
      {/* Header */}
      <div className="p-4 bg-gradient-to-r from-[#0d0d14] to-[#08080f] border-b border-[#222] flex flex-col md:flex-row justify-between items-start md:items-center gap-4 z-10">
        <div>
          <h2 className="text-sm font-bold tracking-widest text-[#f43f5e] uppercase flex items-center gap-2">
            <Flame className="w-4 h-4 text-rose-500 animate-pulse" />
            INCEPTION NESTED SANDBOX ENGINE (6D REALITY CELL)
          </h2>
          <p className="text-[10px] text-gray-400 font-mono mt-0.5">
            Create, compile, ignite, and live-proxy custom servers on any node port of your choice.
          </p>
        </div>
        
        {/* Toggle tabs */}
        <div className="flex items-center gap-1 bg-black/60 p-1 border border-[#333] rounded-lg">
          <button 
            onClick={() => setActiveTab('launcher')}
            className={`px-3 py-1 text-[10px] font-bold uppercase tracking-wider rounded-md transition-all ${
              activeTab === 'launcher' 
                ? 'bg-[#1e1124] text-fuchsia-400 border border-fuchsia-500/20' 
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <Layers className="w-3 h-3 inline mr-1" /> Config & Launcher
          </button>
          <button 
            onClick={() => setActiveTab('creation')}
            className={`px-3 py-1 text-[10px] font-bold uppercase tracking-wider rounded-md transition-all ${
              activeTab === 'creation' 
                ? 'bg-[#1e1124] text-fuchsia-400 border border-fuchsia-500/20' 
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <Code className="w-3 h-3 inline mr-1" /> Reality Compiler
          </button>
        </div>
      </div>

      {/* Main Area */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden min-h-0">
        
        {/* Workspace controls / Creation (Left Column) */}
        <div className="w-full md:w-[420px] border-r border-[#222] bg-[#0c0c12] flex flex-col overflow-y-auto">
          {successMsg && (
            <div className="m-3 p-2.5 bg-emerald-950/70 border border-emerald-500/30 text-emerald-300 rounded-lg text-xs font-mono flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}
          {errorMsg && (
            <div className="m-3 p-2.5 bg-rose-950/70 border border-rose-500/30 text-rose-300 rounded-lg text-xs font-mono">
              <span className="font-bold uppercase">[ERR]:</span> {errorMsg}
            </div>
          )}

          {activeTab === 'launcher' ? (
            <div className="p-4 flex flex-col gap-5">
              
              {/* Launcher block */}
              <div className="border border-[#222] bg-black/30 p-4 rounded-xl relative">
                <div className="absolute top-0 right-4 transform -translate-y-1/2 px-2 py-0.5 bg-[#f43f5e] text-black text-[9px] font-bold tracking-widest uppercase rounded">
                  DEPLOY MATRIX
                </div>
                
                <h3 className="text-xs font-bold uppercase text-gray-300 flex items-center gap-1.5 mb-3">
                  <Settings className="w-4 h-4 text-[#f43f5e]" /> Node Command Parameters
                </h3>

                <div className="flex flex-col gap-3">
                  <div>
                    <label className="text-[10px] font-bold uppercase text-gray-400 tracking-wider font-mono">Select Server Preset</label>
                    <select
                      value={selectedPresetId}
                      onChange={(e) => setSelectedPresetId(e.target.value)}
                      className="w-full bg-[#111116] border border-[#333] text-xs text-white p-2 mt-1 rounded focus:outline-none focus:ring-1 focus:ring-rose-500 font-mono"
                    >
                      {presets.map(p => (
                        <option key={p.id} value={p.id}>{p.name} [{p.id}]</option>
                      ))}
                    </select>
                  </div>

                  <div className="flex gap-2">
                    <div className="flex-1">
                      <label className="text-[10px] font-bold uppercase text-gray-400 tracking-wider font-mono">Allocate Node Port</label>
                      <input
                        type="number"
                        value={selectedPort}
                        onChange={(e) => setSelectedPort(parseInt(e.target.value) || 8080)}
                        className="w-full bg-[#111116] border border-[#333] text-xs text-white p-2 mt-1 rounded focus:outline-none focus:ring-1 focus:ring-rose-500 font-mono"
                        placeholder="e.g. 8080"
                      />
                    </div>
                    <div className="flex items-end shadow-lg">
                      <button
                        onClick={triggerStart}
                        className="h-[34px] w-full bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-bold text-xs uppercase tracking-widest px-4 rounded transition-all flex items-center justify-center gap-1.5"
                      >
                        <Play className="w-3.5 h-3.5 fill-white" /> IGNITE
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Active Servers List table */}
              <div className="border border-[#222] bg-black/30 p-4 rounded-xl">
                <h3 className="text-xs font-bold uppercase text-gray-300 flex items-center gap-1.5 mb-3">
                  <Activity className="w-4 h-4 text-[#a855f7]" /> Active Port Registry
                </h3>

                {servers.length === 0 ? (
                  <div className="text-center py-6 text-xs text-gray-600 font-mono">
                    No active node virtual hosts registered.
                  </div>
                ) : (
                  <div className="flex flex-col gap-3">
                    {servers.map((srv) => (
                      <div 
                        key={srv.port}
                        onClick={() => {
                          setActiveServerPort(srv.port);
                        }}
                        className={`p-3 rounded-lg border transition-all cursor-pointer ${
                          activeServerPort === srv.port 
                            ? 'bg-[#18111e] border-[#a855f7]/40 shadow-md shadow-[#a855f7]/5' 
                            : 'bg-black/40 border-[#222] hover:border-[#333]'
                        }`}
                      >
                        <div className="flex justify-between items-center">
                          <span className="text-xs font-bold text-white tracking-wide truncate pr-2 font-mono">
                            {srv.name}
                          </span>
                          <span className={`text-[9px] px-1.5 py-0.5 rounded font-mono font-bold ${
                            srv.status === 'RUNNING' 
                              ? 'bg-emerald-950/70 border border-emerald-500/20 text-emerald-400' 
                              : 'bg-rose-950/70 border border-rose-500/20 text-rose-400'
                          }`}>
                            {srv.status}
                          </span>
                        </div>

                        <div className="flex items-center gap-2 mt-2 font-mono text-[10px] text-gray-500">
                          <span className="text-fuchsia-400 font-bold">PORT {srv.port}</span>
                          <span>•</span>
                          <span className="truncate max-w-[140px]">{srv.id}</span>
                        </div>

                        {/* Interactive cell buttons */}
                        <div className="flex justify-end gap-1.5 mt-3 pt-2.5 border-t border-[#222]">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              triggerReboot(srv.port);
                            }}
                            className="bg-[#1f1d18] border border-amber-500/20 text-amber-400 hover:bg-[#1a1308] px-2.5 py-1 rounded text-[9px] font-bold uppercase transition-colors flex items-center gap-1"
                            title="Hot Swap / Restart server state safely"
                          >
                            <RotateCw className="w-2.5 h-2.5" /> REBOOT
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              triggerStop(srv.port);
                            }}
                            className="bg-[#241316] border border-rose-500/20 text-rose-400 hover:bg-[#1b0a0d] px-2.5 py-1 rounded text-[9px] font-bold uppercase transition-colors flex items-center gap-1"
                            title="Halt processes and clean ports"
                          >
                            <Square className="w-2.5 h-2.5 fill-rose-400" /> HALT
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Secure Port forwarding overview */}
              <div className="p-3 bg-zinc-950/70 border border-[#222] rounded-xl text-[11px] leading-relaxed text-gray-400 font-mono">
                <div className="flex items-center gap-1 mb-1.5 text-zinc-300 font-bold">
                  <Shield className="w-3.5 h-3.5 text-cyan-400" />
                  <span>SECURE LOOPBACK PORT INTEGRITY</span>
                </div>
                All internal nodes (e.g. 8080, 5000, 3002) run inside the isolated environment. Sandbox engine proxies internal loopback endpoints into the secure client viewport beautifully.
              </div>

            </div>
          ) : (
            <div className="p-4 flex flex-col gap-4 font-mono">
              <div className="border border-[#222] bg-black/40 p-3.5 rounded-xl">
                <h3 className="text-xs font-bold uppercase text-fuchsia-400 mb-3 flex items-center gap-1.5">
                  <Plus className="w-4 h-4 text-fuchsia-400" /> Register New Sandbox Project
                </h3>

                <div className="flex flex-col gap-3 text-xs">
                  <div>
                    <label className="text-[10px] font-bold uppercase text-gray-400">Isolated ID (Alphanumeric)</label>
                    <input
                      type="text"
                      value={customAppId}
                      onChange={(e) => setCustomAppId(e.target.value)}
                      className="w-full bg-[#111116] border border-[#333] p-1.5 rounded mt-1 text-white focus:outline-none focus:border-fuchsia-500"
                      placeholder="e.g. quantum-grid"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-bold uppercase text-gray-400">System Applet Display Name</label>
                    <input
                      type="text"
                      value={customAppName}
                      onChange={(e) => setCustomAppName(e.target.value)}
                      className="w-full bg-[#111116] border border-[#333] p-1.5 rounded mt-1 text-white focus:outline-none focus:border-fuchsia-500"
                      placeholder="e.g. Neon Horizon Engine"
                    />
                  </div>
                </div>
              </div>

              {/* Code blocks Injection section */}
              <div className="flex flex-col border border-[#222] bg-black/40 rounded-xl overflow-hidden">
                <div className="p-2 border-b border-[#222] bg-black/80 flex justify-between items-center text-[10px] font-bold uppercase tracking-widest text-[#a855f7]">
                  <span>CODE STRUCTURING BLOCKS</span>
                </div>
                
                <div className="p-3 flex flex-col gap-3 text-xs">
                  <div>
                    <label className="text-[9px] font-bold uppercase text-gray-400">HTML markup</label>
                    <textarea
                      value={htmlContent}
                      onChange={(e) => setHtmlContent(e.target.value)}
                      className="w-full h-24 bg-[#0a0a0c] border border-[#333] p-2 mt-1 rounded text-gray-300 font-mono text-[11px] resize-none focus:outline-none focus:border-[#a855f7]"
                      spellCheck="false"
                    />
                  </div>

                  <div>
                    <label className="text-[9px] font-bold uppercase text-gray-400">CSS stylesheet overrides</label>
                    <textarea
                      value={cssContent}
                      onChange={(e) => setCssContent(e.target.value)}
                      className="w-full h-20 bg-[#0a0a0c] border border-[#333] p-2 mt-1 rounded text-rose-400 font-mono text-[11px] resize-none focus:outline-none focus:border-[#a855f7]"
                      spellCheck="false"
                    />
                  </div>

                  <div>
                    <label className="text-[9px] font-bold uppercase text-gray-400">JS script runtime</label>
                    <textarea
                      value={jsContent}
                      onChange={(e) => setJsContent(e.target.value)}
                      className="w-full h-28 bg-[#0a0a0c] border border-[#333] p-2 mt-1 rounded text-cyan-400 font-mono text-[11px] resize-none focus:outline-none focus:border-[#a855f7]"
                      spellCheck="false"
                    />
                  </div>

                  <button
                    onClick={compileCustomApp}
                    className="w-full bg-gradient-to-r from-fuchsia-600 to-purple-600 hover:from-fuchsia-500 hover:to-purple-500 text-white font-bold py-2 px-4 rounded mt-2 transition-all flex items-center justify-center gap-1.5 uppercase text-xs tracking-wider"
                  >
                    <Database className="w-3.5 h-3.5" /> COMPILE & REGISTER PRESET
                  </button>
                </div>
              </div>

            </div>
          )}
        </div>

        {/* Live App Iframe Viewport and Terminal Logs (Right Columns) */}
        <div className="flex-1 flex flex-col overflow-hidden">
          
          {/* Iframe stage */}
          <div className="flex-1 bg-black relative flex flex-col border-b border-[#222]">
            <div className="px-4 py-2 bg-[#0a0a0f] border-b border-[#222] flex justify-between items-center text-xs">
              <div className="flex items-center gap-2">
                <span className="inline-block w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                <span className="font-mono text-[11px] text-gray-400">PORT PROXY RENDER VIEW:</span>
                <span className="bg-[#1c121e] px-2 py-0.5 rounded text-fuchsia-400 font-mono font-bold text-[10px] tracking-wider border border-fuchsia-500/20">
                  {proxyUrl}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIframeKey(k => k + 1)}
                  className="p-1 px-2 hover:bg-[#222] rounded text-gray-400 hover:text-white transition-colors text-[10px] uppercase font-mono font-bold flex items-center gap-1"
                  title="Flash View / Reload Sandbox state"
                >
                  <RotateCw className="w-3 h-3" /> RELOAD VIEW
                </button>
                <a 
                  href={proxyUrl} 
                  target="_blank" 
                  rel="noreferrer"
                  className="p-1 px-2 hover:bg-[#222] rounded text-gray-400 hover:text-white transition-colors text-[10px] uppercase font-mono font-bold flex items-center gap-1"
                >
                  <ExternalLink className="w-3 h-3" /> FULL TAB
                </a>
              </div>
            </div>

            <div className="flex-1 relative bg-[#030303] flex items-center justify-center">
              {activeServerPort ? (
                <iframe
                  key={`${activeServerPort}-${iframeKey}`}
                  src={proxyUrl}
                  className="w-full h-full bg-[#050508] border-none"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  referrerPolicy="no-referrer"
                  title={`Sandbox Inception Proxy Port - ${activeServerPort}`}
                />
              ) : (
                <div className="text-center font-mono text-xs text-gray-600 flex flex-col items-center gap-3 py-10 px-4">
                  <Gamepad2 className="w-10 h-10 text-[#333]" />
                  Awaiting sandbox instance creation or selection.<br />Select or spin up a virtual host on the left side menu.
                </div>
              )}
            </div>
          </div>

          {/* Terminal telemetry console */}
          <div className="h-[210px] bg-[#030305] flex flex-col overflow-hidden relative shrink-0">
            <div className="px-4 py-1.5 bg-[#0a0a0e] border-b border-[#222] text-zinc-400 font-mono text-[10px] tracking-widest uppercase flex items-center justify-between">
              <span className="flex items-center gap-1 text-[#f43f5e] font-bold">
                <Terminal className="w-3.5 h-3.5" /> Inception Engine Console Telemetry [Port: {activeServerPort}]
              </span>
              <span className="text-[9px] text-[#555] font-bold">WAL MODE CORE ALIENATED RUN TIME</span>
            </div>
            
            <div className="flex-1 p-3.5 overflow-y-auto font-mono text-[11px] leading-relaxed text-cyan-400 font-thin bg-[#040407] tracking-wider whitespace-pre-wrap select-text selection:bg-[#ec4899] selection:text-white">
              {consoleLogs}
              <div ref={logEndRef} />
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}

export default InceptionSandboxPanel;
