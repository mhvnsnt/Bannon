import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import { SystemOverseer } from "./components/SystemOverseer";
import { SystemHealthMonitor } from "./components/SystemHealthMonitor";
import "./index.css";

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/firebase-messaging-sw.js").then(
      (registration) => {
        console.log("Background Sync Protocol registered:", registration.scope);
      },
      (err) => {
        console.log("Background Sync Protocol registration failed:", err);
      },
    );
  });
}

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <SystemOverseer>
      <App />
      <SystemHealthMonitor />
    </SystemOverseer>
  </StrictMode>,
);
