import { defineConfig } from 'vite'
import tailwindcss from '@tailwindcss/vite'
import react from '@vitejs/plugin-react'

const injectEyesPlugin = () => {
  return {
    name: 'inject-eyes',
    transformIndexHtml(html) {
      return html.replace(
        '</body>',
        () => `<script>
          // Automatically injected by God Mode OS for "AI Sight"
          (function() {
             if (window !== window.parent) {
                const logData = (msg, meta = {}) => {
                    try { window.parent.postMessage({ type: 'bannon-log', message: msg, ...meta }, '*'); } catch(e){}
                };
                
                const origLog = console.log;
                const origErr = console.error;
                const origWarn = console.warn;
                console.log = function(...args) { logData("LOG: " + args.join(' ')); origLog.apply(this, args); };
                console.error = function(...args) { logData("ERR: " + args.join(' ')); origErr.apply(this, args); };
                console.warn = function(...args) { logData("WARN: " + args.join(' ')); origWarn.apply(this, args); };
                
                window.addEventListener('error', function(e) { logData("WINDOW_ERR: " + e.message + " at " + e.filename + ":" + e.lineno); });
                window.addEventListener('unhandledrejection', function(e) { logData("PROMISE_REJECT: " + e.reason); });
                
                // Network Fetch Capturing
                const origFetch = window.fetch;
                window.fetch = async function(...args) {
                    const url = typeof args[0] === 'string' ? args[0] : (args[0] && args[0].url ? args[0].url : 'unknown');
                    logData("FETCH_REQ: " + url.substring(0, 100));
                    try {
                        const res = await origFetch.apply(this, args);
                        logData("FETCH_RES: " + url.substring(0, 100) + " [" + res.status + "]");
                        return res;
                    } catch(err) {
                        logData("FETCH_ERR: " + url.substring(0, 100) + " - " + err.message);
                        throw err;
                    }
                };

                // XHR Overrides
                const origOpen = window.XMLHttpRequest.prototype.open;
                window.XMLHttpRequest.prototype.open = function(method, url) {
                    this._url = url;
                    return origOpen.apply(this, arguments);
                };
                const origSend = window.XMLHttpRequest.prototype.send;
                window.XMLHttpRequest.prototype.send = function(...args) {
                    if (this._url && typeof this._url === 'string') {
                        logData("XHR_REQ: " + this._url.substring(0, 100));
                        this.addEventListener('load', function() { logData("XHR_RES: " + this._url.substring(0, 100) + " [" + this.status + "]"); });
                        this.addEventListener('error', function() { logData("XHR_ERR: " + this._url.substring(0, 100)); });
                    }
                    return origSend.apply(this, args);
                };

                // Kinetic Click & Capture
                window.addEventListener('click', function(e) {
                   const t = e.target;
                   const tag = t.tagName ? t.tagName.toLowerCase() : 'element';
                   const idStr = t.id ? '#' + t.id : '';
                   const clsStr = t.className && typeof t.className === 'string' ? '.' + t.className.replace(/\\s+/g, '.') : '';
                   logData(\`USER_CLICK: <\${tag}\${idStr}\${clsStr}> at (X:\${e.clientX}, Y:\${e.clientY})\`);
                }, true);
                
                window.addEventListener('input', function(e) {
                   const t = e.target;
                   if (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA') {
                       const idStr = t.id ? '#' + t.id : '';
                       logData('USER_INPUT: <' + t.tagName.toLowerCase() + idStr + '> = "' + (t.value.length > 30 ? t.value.substring(0, 30) + '...' : t.value) + '"');
                   }
                }, true);

                // React Fiber Utility
                const getReactName = (el) => {
                    for (let key in el) {
                        if (key.startsWith('__reactFiber$')) {
                            try { return el[key]?.return?.elementType?.name || el[key]?.return?.type?.name; } catch(e){}
                        }
                    }
                    return null;
                };

                let lastSnap = '';
                setInterval(() => {
                   // Comprehensive Spatial Capture
                   const elements = document.querySelectorAll('button, a, input, select, textarea, [role], .clickable, h1, h2, h3, p, [data-component], [data-testid]');
                   const DOMTree = Array.from(elements).slice(0, 35).map(e => {
                       const rect = e.getBoundingClientRect();
                       const reactName = getReactName(e);
                       const tag = reactName ? reactName : e.tagName.toLowerCase();
                       const idAttr = e.id ? \` id="\${e.id}"\` : '';
                       const clsAttr = typeof e.className === 'string' && e.className ? \` class="\${e.className}"\` : '';
                       const text = (tag === 'p' || tag.startsWith('h') || tag === 'button') ? \` text="\${e.textContent.substring(0, 40).trim()}"\` : '';
                       const val = (tag === 'input' || tag === 'textarea') && e.value ? \` val="\${e.value.substring(0, 30)}"\` : '';
                       const xy = \` bounds="x:\${Math.round(rect.x)},y:\${Math.round(rect.y)},w:\${Math.round(rect.width)},h:\${Math.round(rect.height)}"\`;
                       return \`  <\${tag}\${idAttr}\${clsAttr}\${xy}\${text}\${val}>\`;
                   }).join('\\n');
                   
                   const fullSnap = \`\\n[SPATIAL DOM TOPOLOGY]:\\n\` + (DOMTree || '  (Empty DOM)');
                   if (fullSnap !== lastSnap) {
                       lastSnap = fullSnap;
                       logData("DOM Structure Update: " + fullSnap);
                   }
                }, 3000);
             }
          })();
        </script></body>`
      )
    }
  }
}

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react(), tailwindcss(), injectEyesPlugin()],
  server: {
    host: '0.0.0.0',
    port: 3000
  },
  build: {
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (id.includes('node_modules')) {
            if (id.includes('three')) return 'three';
            if (id.includes('framer-motion')) return 'motion';
            return 'vendor';
          }
          if (id.includes('ForgeStudio')) return 'forge-studio';
          if (id.includes('QuantumChat')) return 'quantum-chat';
        }
      }
    }
  }
})
