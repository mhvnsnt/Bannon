import fs from 'fs';
import path from 'path';

export const initializeFileSystemWatcher = (db: any) => {
    // -------------------------------------------------------------
    // VAULT SENTINEL ARCHITECTURE
    // -------------------------------------------------------------
    // Master Grid Node Watcher for Dooly County Dominion Matrix
    // Scans specifically for raw .wav master acquisitions to instantly route
    // into the autonomous pipeline, bypassing all third party compression schemas.

    const vaultRoots = [
       path.join(process.cwd(), 'music_vault'),
       path.join(process.cwd(), 'src/assets/sigils'),
       path.join(process.cwd(), 'src/assets/blueprints')
    ];

    vaultRoots.forEach(dir => {
       if (!fs.existsSync(dir)) {
          fs.mkdirSync(dir, { recursive: true });
          console.log(`[VAULT SENTINEL] Forged missing architectural node: ${dir}`);
       }
       
       // Engaging raw fs.watch to monitor the file system event loop intimately.
       // We log the physical ingestion to the internal SQLite database for Prime RAG context.
       fs.watch(dir, { persistent: true }, (eventType, filename) => {
           if (filename) {
               console.log(`[VAULT WATCHER] Physical grid perturbation detected in ${dir}: [${eventType}] ${filename}`);
               
               const ext = path.extname(filename).toLowerCase();
               const isMasterTrack = ext === '.wav' || ext === '.flac';
               const isBinarySigil = ext === '.svg' || ext === '.png';

               let category = 'Unclassified Entropy';
               if (isMasterTrack) category = 'Sonic Master Frequency';
               else if (isBinarySigil) category = 'Binary Graphic Sigil';

               const metadata = {
                   target_file: filename,
                   grid_location: dir,
                   status: 'Ingested into Dooly Dominion Matrix',
                   category: category,
                   timestamp: new Date().toISOString(),
                   system_event: eventType
               };
               
               try {
                   // Lock the state into the immutable internal intelligence cache
                   const stmt = db.prepare(`INSERT INTO intelligence_cache (id, session_id, input_vector, output_vector) VALUES (?, ?, ?, ?)`);
                   const crypto = require('crypto');
                   stmt.run(
                     crypto.randomUUID(), 
                     'fs-watcher-sentinel', 
                     `[PHYSICAL ACQUISITION]: ${filename}`, 
                     JSON.stringify(metadata)
                   );
                   console.log(`[VAULT WATCHER] Grid mapped. Master vector secured.`);
               } catch (e: any) {
                   console.error(`[VAULT WATCHER] Entropy detected in DB insertion:`, e.message);
               }
           }
       });
       console.log(`[VAULT WATCHER] Terminal Sentinel active and locked on ${dir}`);
    });
};
