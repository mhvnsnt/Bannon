// vaultBackup.ts
import fs from 'fs';
import path from 'path';
import cron from 'node-cron';

const dbPath = path.join(process.cwd(), 'rag_vault.db');
const backupDir = path.join(process.cwd(), 'backups');

export function initializeVaultBackup() {
    if (!fs.existsSync(backupDir)) {
        fs.mkdirSync(backupDir);
    }

    // Schedule backup at midnight every day
    cron.schedule('0 0 * * *', () => {
        const backupPath = path.join(backupDir, `vault_backup_${Date.now()}.db`);
        fs.copyFile(dbPath, backupPath, (err) => {
            if (err) {
                console.error('Vault redundancy failure', err);
            } else {
                console.log('Vault schema successfully secured at midnight routine');
            }
        });
    });
}
