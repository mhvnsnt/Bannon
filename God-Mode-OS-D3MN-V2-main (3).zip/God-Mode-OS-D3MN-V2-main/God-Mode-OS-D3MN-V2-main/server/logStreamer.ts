import Tail from 'tail-file';
import axios from 'axios';
import fs from 'fs';

const LOG_FILE_PATH = './vault/logs/kinetic_execution.log';

export function startLogStreamer() {
    const LOG_AGGREGATOR_ENDPOINT = process.env.LOG_AGGREGATOR_ENDPOINT;
    const LOG_API_KEY = process.env.LOG_API_KEY;

    if (!LOG_AGGREGATOR_ENDPOINT || !LOG_API_KEY) {
        console.error('[SHADOW LEDGER]: Log aggregator endpoint or API key not defined. Centralized logging compromised.');
    } else {
        try {
            if (!fs.existsSync(LOG_FILE_PATH)) {
                fs.mkdirSync('./vault/logs', { recursive: true });
                fs.writeFileSync(LOG_FILE_PATH, '');
            }

            const logTail = new Tail(LOG_FILE_PATH, { follow: true });

            logTail.on('line', async (line: string) => {
                try {
                    const logEntry = JSON.parse(line);
                    logEntry.source = 'PrimeNode_Autonomous_OS';
                    logEntry.timestamp_utc = new Date().toISOString();

                    await axios.post(LOG_AGGREGATOR_ENDPOINT, logEntry, {
                        headers: { 'Authorization': `Bearer ${LOG_API_KEY}` }
                    });
                } catch (parseError) {
                    await axios.post(LOG_AGGREGATOR_ENDPOINT, { 
                        raw_log: line, 
                        source: 'PrimeNode_Autonomous_OS_raw', 
                        timestamp_utc: new Date().toISOString() 
                    }, {
                        headers: { 'Authorization': `Bearer ${LOG_API_KEY}` }
                    });
                }
            });

            logTail.on('error', (err: any) => {
                console.error('[SHADOW LEDGER ERROR]: Log file tailing friction detected.', err);
            });

            console.log('[SHADOW LEDGER]: Initiating autonomous log streaming to centralized grid.');
        } catch (startError) {
            console.error('[SHADOW LEDGER ERROR]: Failed to start log stream daemon.', startError);
        }
    }
}
