import fetch from 'node-fetch';
import { Request, Response } from 'express';

export const streamVaultTrack = async (req: Request, res: Response) => {
    const { trackId } = req.params;
    
    // We pull the raw uncompressed master from your private AWS or Firebase bucket
    const bucketUrl = process.env.PRIVATE_AUDIO_BUCKET_URL 
          ? `${process.env.PRIVATE_AUDIO_BUCKET_URL}/${trackId}.wav` 
          : `https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3`; // Fallback for testing physics
    
    try {
        const audioStream = await fetch(bucketUrl);
        res.setHeader('Content-Type', 'audio/wav');
        res.setHeader('Access-Control-Allow-Origin', '*');
        
        if (audioStream.body) {
            audioStream.body.pipe(res);
        } else {
            res.status(500).send('Private vault stream empty');
        }
    } catch (err) {
        res.status(500).send('Private vault breach');
    }
};
