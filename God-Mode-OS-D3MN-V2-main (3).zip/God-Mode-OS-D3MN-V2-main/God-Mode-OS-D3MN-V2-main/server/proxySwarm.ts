import axios from 'axios';

// The engine automatically routes all traffic through a rotating proxy grid
export const swarmClient = axios.create({
    baseURL: 'https://api.reddit.com',
    proxy: {
        protocol: 'http',
        host: 'gate.smartproxy.com', // Your residential proxy provider
        port: 7000,
        auth: {
            username: process.env.PROXY_USER || '',
            password: process.env.PROXY_PASSWORD || ''
        }
    }
});

export async function proxyStrike(endpoint: string, payload: any) {
    console.log('[SWARM ROUTER]: Maskin origin coordinates. Executin strike...');
    return await swarmClient.post(endpoint, payload);
}
