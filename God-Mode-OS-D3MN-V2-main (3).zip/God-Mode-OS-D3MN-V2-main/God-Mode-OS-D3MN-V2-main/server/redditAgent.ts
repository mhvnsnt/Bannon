import Snoowrap from 'snoowrap';

// Headless Reddit Infiltration Core
let redditAgent: Snoowrap | null = null;

export function initializeRedditAgent(io: any) {
    if (!process.env.REDDIT_CLIENT_ID || !process.env.REDDIT_CLIENT_SECRET) {
        console.log("[SYS] Reddit Infiltrator offline. Set REDDIT credentials to activate.");
        return;
    }

    try {
        redditAgent = new Snoowrap({
            userAgent: 'PrimeNode_Autonomous_v1',
            clientId: process.env.REDDIT_CLIENT_ID,
            clientSecret: process.env.REDDIT_CLIENT_SECRET,
            username: process.env.REDDIT_MASTER_USER,
            password: process.env.REDDIT_MASTER_PASSWORD
        });
        
        console.log(`[REDDIT STRIKE]: API authenticated for ${process.env.REDDIT_MASTER_USER}. Ready to deploy payloads.`);
        io.emit('agent-log', `[REDDIT STRIKE]: API authenticated. Ready for autonomous deployment.`);
    } catch(err) {
        console.error("Reddit Agent init failed", err);
    }
}

export async function autonomousCommunityDomination(targetSubreddit: string, contentPayload: string, io: any) {
    if (!redditAgent) {
        io.emit('agent-log', `[REDDIT ERROR]: System offline. Credentials missing from environment matrix.`);
        return { success: false, message: 'Agent offline' };
    }

    io.emit('agent-log', `[REDDIT STRIKE]: Infiltratin ${targetSubreddit} grid...`);
    console.log(`[REDDIT STRIKE]: Infiltratin ${targetSubreddit} grid...`);
    
    try {
        // Autonomously deploy the kinetic payload
        const submission = await (redditAgent.getSubreddit(targetSubreddit) as any).submitSelfpost({
            subredditName: targetSubreddit,
            title: 'The Core Blueprint: Absolute Structural Reality',
            text: contentPayload
        });
        
        console.log(`[REDDIT STRIKE]: Payload delivered. Anchor coordinate: ${submission.name}`);
        io.emit('agent-log', `[REDDIT STRIKE]: Payload delivered securely at anchor: ${submission.name}`);
        
        return { success: true, anchor: submission.name };
    } catch (error: any) {
        console.error('[REDDIT ERROR]: Target grid rejected the payload.', error.message);
        io.emit('agent-log', `[REDDIT ERROR]: Target grid deployed countermeasures. Payload rejected.`);
        return { success: false, error: error.message };
    }
}
