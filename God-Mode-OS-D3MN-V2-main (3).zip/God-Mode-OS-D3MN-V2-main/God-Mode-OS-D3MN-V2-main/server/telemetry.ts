import si from 'systeminformation';

let broadcastFn: (data: any) => void = () => {};

export function setBroadcastFn(fn: (data: any) => void) {
    broadcastFn = fn;
}

export function streamToMobileHUD(data: any) {
    broadcastFn(data);
}

export async function broadcastMetalTelemetry() {
    setInterval(async () => {
        try {
            const cpu = await si.currentLoad().catch(() => null);
            const mem = await si.mem().catch(() => null);
            const temps = await si.cpuTemperature().catch(() => null);

            let cpuLoadVal: string = 'N/A';
            if (cpu && typeof cpu.currentLoad === 'number' && !isNaN(cpu.currentLoad)) {
                cpuLoadVal = cpu.currentLoad.toFixed(2);
            } else {
                cpuLoadVal = '0.00';
            }

            let memUsageVal: string = '0.00';
            if (mem && typeof mem.active === 'number' && typeof mem.total === 'number' && mem.total > 0) {
                 const calc = (mem.active / mem.total) * 100;
                 if (!isNaN(calc)) {
                     memUsageVal = calc.toFixed(2);
                 }
            }

            let coreTemp: string | number = 'Optimal';
            if (temps && temps.main !== undefined && temps.main !== null) {
                if (typeof temps.main === 'number' && !isNaN(temps.main)) {
                    coreTemp = temps.main;
                } else if (typeof temps.main === 'string') {
                    coreTemp = temps.main;
                }
            }

            const payload = {
                cpuLoad: cpuLoadVal,
                memoryUsage: memUsageVal,
                coreTemp: coreTemp,
            };

            const currentLoadNum = cpu && typeof cpu.currentLoad === 'number' && !isNaN(cpu.currentLoad) ? cpu.currentLoad : 0;
            const currentTempNum = temps && typeof temps.main === 'number' && !isNaN(temps.main) ? temps.main : 0;

            // If thermal limits exceed safe boundaries push a warning to the glass
            if (currentLoadNum > 90 || currentTempNum > 85) {
                streamToMobileHUD({ status: 'WARNING', message: 'Thermal perimeter breached. Throttlin queue.', payload });
            } else {
                streamToMobileHUD({ status: 'TELEMETRY', payload });
            }
        } catch (error) {
            console.error('[TELEMETRY ERROR]: Sensor disconnect.');
        }
    }, 5000); // Pulse check every 5 seconds
}
