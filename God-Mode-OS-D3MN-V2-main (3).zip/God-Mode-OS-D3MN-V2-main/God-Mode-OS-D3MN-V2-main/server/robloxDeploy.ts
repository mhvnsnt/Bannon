import axios from 'axios';
import fs from 'fs';

export async function deployToRobloxCloud(universeId: string, placeId: string, rbxlFilePath: string) {
    console.log(`[ROBLOX DEPLOY]: Forcin local physics matrix to live servers...`);

    const fileBuffer = fs.readFileSync(rbxlFilePath);

    try {
        await axios.post(
            `https://apis.roblox.com/universes/v1/${universeId}/places/${placeId}/versions`,
            fileBuffer,
            {
                headers: {
                    'x-api-key': process.env.ROBLOX_OPEN_CLOUD_KEY,
                    'Content-Type': 'application/xml'
                }
            }
        );
        console.log('[ROBLOX DEPLOY]: The game environment has been successfully updated.');
    } catch (error) {
        console.error('[ROBLOX DEPLOY]: Deployment friction detected.', error);
    }
}
