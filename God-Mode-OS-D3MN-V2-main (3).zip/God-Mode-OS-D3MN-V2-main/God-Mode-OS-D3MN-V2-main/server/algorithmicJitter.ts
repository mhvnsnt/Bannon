// The Entropy Delay Function
export async function executeWitJitter(actionPayload: Function, minFriction: number, maxFriction: number) {
    // Calculates a random millisecond delay to simulate human neurokinetics
    const humanDelay = Math.floor(Math.random() * (maxFriction - minFriction + 1) + minFriction);
    
    console.log(`[ALGORITHMIC JITTER]: Injectin ${humanDelay}ms of humanized entropy before strike.`);
    
    return new Promise((resolve) => {
        setTimeout(async () => {
            const result = await actionPayload();
            resolve(result);
        }, humanDelay);
    });
}
