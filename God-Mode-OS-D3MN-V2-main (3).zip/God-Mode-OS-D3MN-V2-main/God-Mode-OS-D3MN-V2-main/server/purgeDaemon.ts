import cron from 'node-cron';
import fs from 'fs/promises';
import path from 'path';
import fsSync from 'fs';

// Helper to ensure directory exists
const ensureDir = (dir: string) => {
    if (!fsSync.existsSync(dir)) {
        fsSync.mkdirSync(dir, { recursive: true });
    }
}

// Execute every Sunday at absolute midnight
cron.schedule('0 0 * * 0', async () => {
    console.log('[CHRONOS DAEMON]: Initiatin absolute system purge.');

    const directoriesToPurge = [
        './vault/renders',
        './vault/temp_audio',
        './vault/headless_cache'
    ];

    for (const dir of directoriesToPurge) {
        ensureDir(dir);
        try {
            const files = await fs.readdir(dir);
            for (const file of files) {
                // Keep the structural directories but burn the temporary payloads
                if (file !== '.gitkeep') {
                    await fs.unlink(path.join(dir, file));
                }
            }
            console.log(`[CHRONOS DAEMON]: Cleared entropy from ${dir}`);
        } catch (error) {
            console.error(`[CHRONOS DAEMON]: Friction accessin ${dir}`, error);
        }
    }
    
    console.log('[CHRONOS DAEMON]: System optimized. Ready for incoming week vectors.');
});
