import twilio from 'twilio';
import isOnline from 'is-online';

export function startDeadManSwitch() {
    if (!process.env.TWILIO_SID || !process.env.TWILIO_AUTH_TOKEN) {
        console.warn("[DEAD MAN SWITCH]: Twilio tokens empty, skipping alert daemon.");
        return;
    }
    
    let isCurrentlyOffline = false;
    
    // Using dynamic import or require issue fix by importing default properly
    const smsClient = twilio(process.env.TWILIO_SID, process.env.TWILIO_AUTH_TOKEN);

    // The heartbeat monitor checks the global connection every 60 seconds
    setInterval(async () => {
        try {
            const gridConnection = await isOnline();
            
            if (!gridConnection && !isCurrentlyOffline) {
                isCurrentlyOffline = true;
                console.log('[DEAD MAN SWITCH]: Global grid severed. Initiatin emergency SMS protocol.');
                
                try {
                    await smsClient.messages.create({
                        body: '[PRIME NODE FATAL]: The autonomous compute node has lost global network connectivity. Check physical hardware.',
                        from: process.env.TWILIO_PHONE_NUMBER,
                        to: process.env.MASTER_PHONE_NUMBER
                    });
                    console.log('[DEAD MAN SWITCH]: Master Overseer notified.');
                } catch (error) {
                    console.error('[DEAD MAN SWITCH ERROR]: Communication lines completely dead.');
                }
            } else if (gridConnection && isCurrentlyOffline) {
                isCurrentlyOffline = false;
                console.log('[DEAD MAN SWITCH]: Global grid restored. Standing down.');
            }
        } catch(e) {
             console.error('[DEAD MAN SWITCH ERROR]', e);
        }
    }, 60000);
}
