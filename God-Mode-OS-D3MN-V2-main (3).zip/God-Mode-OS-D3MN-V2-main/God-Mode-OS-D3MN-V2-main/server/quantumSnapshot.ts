import cron from 'node-cron';
import { exec } from 'child_process';
import util from 'util';
import fs from 'fs';

const ensureDirSync = (dir: string) => {
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

const execPromise = util.promisify(exec);

// Executes every night at 3 AM absolute time
export function startQuantumSnapshot() {
    cron.schedule('0 3 * * *', async () => {
        console.log('[QUANTUM SNAPSHOT]: Initiatin master memory backup...');
        
        const timestamp = Date.now();
        const dbPath = './rag_vault.db'; // Using our defined SQLite DB name
        const backupDir = './vault/backups';
        ensureDirSync(backupDir);
        const backupPath = `${backupDir}/memory_${timestamp}.db`;
        
        // Ensure DB exists before backing up
        if (!fs.existsSync(dbPath)) {
            console.log('[QUANTUM SNAPSHOT]: DB not found, skipping sync.');
            return;
        }

        try {
            // Create a local physical copy first
            await execPromise(`cp ${dbPath} ${backupPath}`);
            
            // Push the encrypted memory to the external off site grid
            // await execPromise(`aws s3 cp ${backupPath} s3://core-blueprint-vault/backups/`);
            
            console.log('[QUANTUM SNAPSHOT]: Memory vault successfully anchored off site.');
        } catch (error) {
            console.error('[QUANTUM SNAPSHOT ERROR]: Backup friction detected.', error);
        }
    });
}
