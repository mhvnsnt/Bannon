import Imap from 'imap-simple';
import axios from 'axios';

export async function interceptVerificationEmail() {
    console.log('[INBOX INTERCEPT]: Scanin Prime domain for target verification vectors...');
    
    if (!process.env.CATCHALL_EMAIL || !process.env.CATCHALL_PASSWORD) {
        console.log('[INBOX INTERCEPT]: CATCHALL_EMAIL missing. Skipping intercept.');
        return;
    }

    const config = {
        imap: {
            user: process.env.CATCHALL_EMAIL,
            password: process.env.CATCHALL_PASSWORD,
            host: 'imap.gmail.com',
            port: 993,
            tls: true,
            authTimeout: 3000
        }
    };

    try {
        const connection = await Imap.connect(config);
        await connection.openBox('INBOX');

        const searchCriteria = ['UNSEEN', ['FROM', 'noreply@reddit.com']];
        const fetchOptions = { bodies: ['TEXT'], markSeen: true };
        const results = await connection.search(searchCriteria, fetchOptions);

        results.forEach(res => {
            const emailBody = res.parts[0].body as string;
            // Regex to extract the exact confirmation URL from the raw email text
            const urlMatch = emailBody.match(/(https:\/\/www\.reddit\.com\/verification\/[^\s]+)/);
            
            if (urlMatch) {
                console.log('[INBOX INTERCEPT]: Verification link acquired. Forcin activation...');
                // The autonomous node silently clicks the link using Axios
                axios.get(urlMatch[0]).catch(e => console.error(e));
            }
        });

        connection.end();
    } catch(e) {
        console.error('[INBOX INTERCEPT ERROR]', e);
    }
}
