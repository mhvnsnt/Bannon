import { Client, GatewayIntentBits } from 'discord.js';

// The autonomous Discord overseer core logic
export function initializeDiscordOverseer(io: any) {
    if (!process.env.DISCORD_PRIME_TOKEN) {
        console.log("[SYS] Discord Overseer offline. Set DISCORD_PRIME_TOKEN to activate.");
        return;
    }

    const discordAgent = new Client({ 
        intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] 
    });

    discordAgent.on('ready', () => {
        console.log(`[DISCORD STRIKE]: Connected as ${discordAgent.user?.tag}. Perimeter secured.`);
        io.emit('agent-log', `[DISCORD STRIKE]: Connected as ${discordAgent.user?.tag}. Perimeter secured.`);
    });

    discordAgent.on('messageCreate', async (message) => {
        // Ignore other automated nodes to prevent infinite loops
        if (message.author.bot) return;

        io.emit('agent-log', `[DISCORD INGESTER]: Reading telemetry from ${message.author.username}...`);

        // Heuristic Bazi Entropy Filter (Mocked for demonstration)
        const content = message.content.toLowerCase();
        const flaggedWords = ['spam', 'scam', 'free nitro', 'crypto pump', 'buy now'];
        
        const hasFriction = flaggedWords.some(word => content.includes(word));
        
        if (hasFriction) {
            io.emit('agent-log', `[DISCORD EXECUTOR]: High friction detected from ${message.author.username}. Purgin message and blockin node.`);
            
            try {
                await message.delete();
                // Autonomously warn or ban the entity based on your strict Core Blueprint rules
                if (message.member && message.member.timeout) {
                    await message.member.timeout(600000, 'Violated the absolute Leo Ascendant parameters.');
                }
                io.emit('agent-log', `[LOCKED]: Discord grid secured.`);
            } catch (error) {
                console.error('[DISCORD ERROR]: Insufficient absolute privileges.', error);
                io.emit('agent-log', `[DISCORD ERROR]: Target resistant. Insufficient absolute privileges.`);
            }
        }
    });

    try {
        discordAgent.login(process.env.DISCORD_PRIME_TOKEN);
    } catch(err) {
        console.error("Failed to login to discord", err);
    }
}
