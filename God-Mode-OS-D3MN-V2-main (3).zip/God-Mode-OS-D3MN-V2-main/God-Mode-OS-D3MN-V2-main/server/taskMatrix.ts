import { executeOmniGodMode } from './masterLoop';

// In-Memory Queue Replacement for BullMQ
class InMemoryQueue {
    name: string;
    private queue: any[] = [];
    private isProcessing: boolean = false;
    private listeners: Record<string, Function[]> = { completed: [], failed: [] };

    constructor(name: string) {
        this.name = name;
    }

    async add(name: string, data: any) {
        const job = { id: Math.random().toString(36).substring(7), name, data };
        this.queue.push(job);
        this.processQueue();
        return job;
    }

    on(event: string, callback: Function) {
        if (this.listeners[event]) {
            this.listeners[event].push(callback);
        }
    }

    private async processQueue() {
        if (this.isProcessing) return;
        this.isProcessing = true;

        while (this.queue.length > 0) {
            const job = this.queue.shift();
            console.log(`[IN-MEMORY MATRIX]: Executin kinetic align ID ${job.id}`);
            try {
                const { prompt, targetGrid } = job.data;
                await executeOmniGodMode(prompt, targetGrid);
                this.listeners.completed.forEach(cb => cb(job));
            } catch (err) {
                console.error(`[IN-MEMORY MATRIX]: Entropy detected in ${job?.id}. Failed.`, err);
                this.listeners.failed.forEach(cb => cb(job, err));
            }
            // Concurrency 1 protects the thermal limits
            await new Promise(resolve => setTimeout(resolve, 100));
        }

        this.isProcessing = false;
    }
}

// Initialize the Heavy Compute Queue without Redis
export const primeExecutionQueue = new InMemoryQueue('OmniStrikeQueue');

primeExecutionQueue.on('completed', (job: any) => {
    console.log(`[IN-MEMORY MATRIX]: Strike ${job.id} mathematically flawless.`);
});

primeExecutionQueue.on('failed', (job: any, err: any) => {
    console.error(`[IN-MEMORY MATRIX]: Entropy detected in ${job?.id}. Requeuin...`, err);
});

