import { useEffect, useRef } from 'react';
import { circuitBreaker } from '../lib/CircuitBreaker';

// Isolated utility function to run heavy Evaluation Loops
// This prevents main thread blocking
export function runHeavyDaemonEvaluation(): Promise<number> {
    return new Promise((resolve) => {
        // Simulating heavy background computation
        const start = performance.now();
        let i = 0;
        
        // Randomly simulate a heavy computational task dragging the loop
        const simulatedLoad = Math.random() > 0.8 ? 500 : 50; 
        
        setTimeout(() => {
            const end = performance.now();
            resolve(end - start);
        }, simulatedLoad);
    });
}

export function useDaemonLoop() {
    const loopActive = useRef(false);

    useEffect(() => {
        const executionThreshold = 300; // 300ms circuit breaker threshold
        
        const loopInterval = setInterval(async () => {
            if (loopActive.current) return;
            loopActive.current = true;

            try {
                // Wrap evaluation in a race condition format
                const executionPromise = runHeavyDaemonEvaluation();
                
                const timeoutPromise = new Promise<number>((_, reject) => 
                    setTimeout(() => reject(new Error("EXECUTION TIMEOUT: Daemon Threshold 300ms Exceeded")), executionThreshold)
                );

                const execTime = await Promise.race([executionPromise, timeoutPromise]);
                // console.log(`[SYS] Daemon execution completed in ${execTime}ms`);
            } catch (err: any) {
                console.warn(`[FATAL] ${err.message}. Triggering loop break and queueing to next cycle...`);
                await circuitBreaker.forceBreak();
            } finally {
                loopActive.current = false;
            }

        }, 2000); // 2-second background simulation cycle

        return () => clearInterval(loopInterval);
    }, []);
}
