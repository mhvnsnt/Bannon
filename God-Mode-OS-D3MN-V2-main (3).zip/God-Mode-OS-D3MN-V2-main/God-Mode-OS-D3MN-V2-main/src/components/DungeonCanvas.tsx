import React, { useRef, useMemo, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Environment, Sphere } from '@react-three/drei';
import * as THREE from 'three';
import { useVolumetricBulge } from '../hooks/useVolumetricBulge';
import { AutonomicMetrics } from '../hooks/useAutonomicSystem';

const OrganicMesh = ({ metrics }: { metrics: AutonomicMetrics }) => {
  const meshRef = useRef<THREE.Mesh>(null);
  
  // Bulge Hook
  const { uniforms, onGrabStart, onGrabEnd, updateMetabolics, tick } = useVolumetricBulge(
    1.2, // Target radius
    new THREE.Vector3(0, 0, 1) // Expansion vector weight
  );

  useFrame((state, delta) => {
    tick(delta);
    updateMetabolics(metrics.metabolicHeat, metrics.systemSaturation);
    
    // Animate the grab active value back to 0 slowly for elastic return
    if (uniforms.uGrabActive.value > 0) {
       // We'll let user clicks hold for extreme tension testing
    }
  });

  const onPointerDown = (e: any) => {
    e.stopPropagation();
    onGrabStart(e.point);
  };
  
  const onPointerUp = (e: any) => {
    e.stopPropagation();
    onGrabEnd();
  };

  const onPointerOut = (e: any) => {
    onGrabEnd();
  };

  const customMaterial = useMemo(() => {
    const mat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color(0x3a1010), // Deep biomechanical red
      emissive: new THREE.Color(0x100000),
      roughness: 0.8,
      metalness: 0.1,
      transmission: 0.2, // Subsurface light
      thickness: 0.5,
      clearcoat: 0.1,
      transparent: true,
      side: THREE.DoubleSide
    });

    mat.onBeforeCompile = (shader) => {
      // Pass our uniforms
      shader.uniforms.uTime = uniforms.uTime;
      shader.uniforms.uGrabActive = uniforms.uGrabActive;
      shader.uniforms.uGrabCenter = uniforms.uGrabCenter;
      shader.uniforms.uRadius = uniforms.uRadius;
      shader.uniforms.uMetabolicHeat = uniforms.uMetabolicHeat;
      shader.uniforms.uSaturation = uniforms.uSaturation;

      // Vertex shader injections
      shader.vertexShader = `
        uniform float uTime;
        uniform float uGrabActive;
        uniform vec3 uGrabCenter;
        uniform float uRadius;
        uniform float uSaturation;
        
        varying float vStretchPoint; // Pass extreme tension to fragment for tearing
        varying vec2 vUv;
        
        ${shader.vertexShader}
      `;

      shader.vertexShader = shader.vertexShader.replace(
        '#include <begin_vertex>',
        `
        #include <begin_vertex>
        vUv = uv;
        
        // Simulating the heartbeat / strain via saturation
        float pulse = sin(uTime * 3.0) * uSaturation * 0.05;
        
        // Apply volumetric bulge on grab
        float dist = distance(position, uGrabCenter);
        float effect = max(0.0, 1.0 - (dist / uRadius));
        
        // Calculate extreme tension yielding
        vStretchPoint = effect * uGrabActive;
        
        // Push along normal
        vec3 bulge = normal * effect * uGrabActive * 0.6; // Increased push to test limits
        
        transformed += bulge + (normal * pulse);
        `
      );

      // Fragment shader injections logic
      shader.fragmentShader = `
        uniform float uTime;
        uniform float uMetabolicHeat;
        uniform float uSaturation;
        varying float vStretchPoint;
        varying vec2 vUv;

        // Simple 2D noise for organic tear tracking
        float random (in vec2 st) {
            return fract(sin(dot(st.xy, vec2(12.9898,78.233))) * 43758.5453123);
        }
        float noise (in vec2 st) {
            vec2 i = floor(st);
            vec2 f = fract(st);

            // Four corners in 2D of a tile
            float a = random(i);
            float b = random(i + vec2(1.0, 0.0));
            float c = random(i + vec2(0.0, 1.0));
            float d = random(i + vec2(1.0, 1.0));

            vec2 u = f * f * (3.0 - 2.0 * f);

            return mix(a, b, u.x) +
                    (c - a)* u.y * (1.0 - u.x) +
                    (d - b) * u.x * u.y;
        }

        ${shader.fragmentShader}
      `;

      // Modify roughness and specular (clearcoat mostly) for "thermodynamic exudation" (sweat sheen)
      shader.fragmentShader = shader.fragmentShader.replace(
        '#include <roughnessmap_fragment>',
        `
        #include <roughnessmap_fragment>
        
        // Map metabolic heat (37 to 40) to roughness drop and sweat/fluid sheen
        float heatFactor = clamp((uMetabolicHeat - 37.0) / 3.0, 0.0, 1.0);
        
        // Dynamic wetness based on saturation & heat
        float sweatAlpha = uSaturation * heatFactor;
        
        // Lower roughness -> sharper specular (slick, wet look)
        roughnessFactor = mix(roughnessFactor, 0.02, sweatAlpha);
        `
      );
      
      shader.fragmentShader = shader.fragmentShader.replace(
        '#include <clearcoat_normal_fragment_begin>',
        `
        #include <clearcoat_normal_fragment_begin>
        float hwet = clamp((uMetabolicHeat - 37.0) / 3.0, 0.0, 1.0) * uSaturation;
        clearcoatRoughnessFactor = mix(clearcoatRoughnessFactor, 0.05, hwet);
        `
      );

      // Add tissue tearing beyond yield threshold
      shader.fragmentShader = shader.fragmentShader.replace(
        '#include <alphamap_fragment>',
        `
        #include <alphamap_fragment>
        
        // Structural Tearing Mechanics
        // If tension exceeds 0.45, begin calculating micro-tears using noise.
        // Above 0.55, structural failure opens macroscopic gaps.
        if (vStretchPoint > 0.45) {
            float n = noise(vUv * 50.0 + uTime * 0.1);
            float tearThreshold = mix(1.0, 0.3, (vStretchPoint - 0.45) * 5.0);
            
            if (n > tearThreshold) {
               // Sub-surface failure/excoriation
               diffuseColor.rgb *= 0.1; // Expose darker inner layer
               diffuseColor.a -= (n - tearThreshold) * 2.0; 
            }
        }
        
        // Fluid engorgement redness at high strain
        if (vStretchPoint > 0.3) {
            diffuseColor.r += vStretchPoint * 0.5; // flush with heat/blood
        }
        `
      );
    };

    return mat;
  }, [uniforms]);

  return (
    <Sphere 
       ref={meshRef} 
       args={[1.5, 96, 96]} // High poly density for smooth stretching/tearing
       material={customMaterial}
       onPointerDown={onPointerDown}
       onPointerUp={onPointerUp}
       onPointerOut={onPointerOut}
    />
  );
};

export const DungeonCanvas = ({ metrics }: { metrics: AutonomicMetrics }) => {
  return (
    <div className="w-full h-full relative cursor-crosshair">
       <div className="absolute top-2 left-2 z-10 font-mono text-[10px] text-emerald-500 uppercase flex flex-col gap-1 pointer-events-none">
          <span className="bg-black/50 px-1 border border-emerald-900/50">Biomechanical Mesh Node</span>
          <span className="text-emerald-700">Hold Left Click: Apply Tension Grip & Yield testing</span>
          <span className="text-[9px] text-[#888]">Metabolic/Thermodynamic Heat: {metrics.metabolicHeat.toFixed(2)}C</span>
       </div>
       <Canvas shadows camera={{ position: [0, 0, 5], fov: 45 }}>
          <ambientLight intensity={0.5} />
          <pointLight position={[10, 10, 10]} intensity={1.5} color={0xffaabb} />
          <pointLight position={[-10, -10, -10]} intensity={0.5} color={0xaabbff} />
          <OrganicMesh metrics={metrics} />
          <OrbitControls enableZoom={false} enablePan={false} />
       </Canvas>
    </div>
  );
};
