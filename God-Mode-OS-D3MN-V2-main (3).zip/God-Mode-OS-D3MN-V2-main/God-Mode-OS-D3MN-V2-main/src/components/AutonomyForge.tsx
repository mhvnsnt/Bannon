import React, { useState, useEffect, useRef } from 'react';
import { Cpu, Server, Database, Activity, Play, Network, Code2, BrainCircuit, Eye, Hand, GitCommit, Moon, Thermometer, Power, Link, Layers, ShieldAlert, Orbit, FileJson, BookOpen, Volume2, Fingerprint, Camera, HeartPulse, Crosshair, Radio, ShieldCheck, DatabaseZap, Zap, Globe, Globe2, Monitor, Box, Headphones, Check, Mic, TrendingUp, Users, Hexagon } from 'lucide-react';
import { motion } from 'framer-motion';
import { usePrimeStore } from '../lib/store';
import io from 'socket.io-client';
import gravitonBlueprint from '../lib/graviton-blueprint.txt?raw';

const socket = io('https://god-mode-os-d3mn-production.up.railway.app');

export default function AutonomyForge({ tier }: { tier?: 'free' | 'Apex' }) {
  const { activeProvider, activeModelString, openRouterApiKey } = usePrimeStore();
  const [activeTab, setActiveTab] = useState<'tuning' | 'weaver' | 'protocols' | 'architecture' | 'sensory' | 'warfare' | 'swarm' | 'security' | 'apex' | 'nexus' | 'graviton'>('apex');
  const [logs, setLogs] = useState<string[]>([]);
  const [isTraining, setIsTraining] = useState(false);
  const [gitCommits, setGitCommits] = useState<any[]>([]);
  const [checkpoints, setCheckpoints] = useState<any[]>([]);
  const [weaverInput, setWeaverInput] = useState('');
  const [isWeaving, setIsWeaving] = useState(false);
  const [weaverLogs, setWeaverLogs] = useState<string[]>([]);
  const [resolvedSolution, setResolvedSolution] = useState('');
  const [computedPatch, setComputedPatch] = useState('');
  const endOfLogsRef = useRef<HTMLDivElement>(null);
  const weaverEndRef = useRef<HTMLDivElement>(null);
  const [nexusPulses, setNexusPulses] = useState<any[]>([]);

  useEffect(() => {
    socket.on('autopoietic-pulse', (data) => {
      setNexusPulses(prev => [data, ...prev].slice(0, 50));
    });
    return () => {
      socket.off('autopoietic-pulse');
    };
  }, []);

  const fetchGit = async () => {
    try {
      const res = await fetch('https://god-mode-os-d3mn-production.up.railway.app/api/armada/git');
      const data = await res.json();
      setGitCommits(data);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchCheckpoints = async () => {
    try {
      const res = await fetch('https://god-mode-os-d3mn-production.up.railway.app/api/armada/checkpoints');
      const data = await res.json();
      setCheckpoints(data);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    fetchGit();
    fetchCheckpoints();
  }, []);

  const commitGitPatch = async (messageText?: string, patchText?: string) => {
    try {
      await fetch('https://god-mode-os-d3mn-production.up.railway.app/api/armada/git', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
           message: messageText || `Darwinian Weaver patch: optimize orbit routing for Dooly vectors`,
           patchContent: patchText || `diff --git a/forge_backend.py b/forge_backend.py\n+def compute_wealth_tunnel():\n+    return 1`
        })
      });
      fetchGit();
    } catch (e) {
      console.error(e);
    }
  };

  const triggerSelfModify = async () => {
    if (!weaverInput.trim()) return;
    setIsWeaving(true);
    setResolvedSolution('');
    setComputedPatch('');
    setWeaverLogs([
      '=== COGNITIVE SELF-MUTATION LOOP INITIATED ===',
      '[Weaver] Reading repository AST map...',
      '[Weaver] Analyzing target layers: src/App.tsx, src/components/QuantumChat.tsx...',
      '[Weaver] Resolving social-emotional & layout rules constraints...',
    ]);

    try {
      const res = await fetch('https://god-mode-os-d3mn-production.up.railway.app/api/armada/self-modify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
           instruction: weaverInput,
           provider: activeProvider?.id,
           modelString: activeModelString,
           openRouterApiKey: activeProvider?.id === 'openrouter' ? openRouterApiKey : undefined
        })
      });
      const data = await res.json();

      if (data.success) {
        // Feed the simulated linter logs with pauses
        if (data.logs && data.logs.length > 0) {
          let i = 0;
          const interval = setInterval(() => {
            if (i < data.logs.length) {
              setWeaverLogs(prev => [...prev, `[AST Check] ${data.logs[i]}`]);
              i++;
            } else {
              clearInterval(interval);
              setWeaverLogs(prev => [
                ...prev, 
                `[Weaver] Patch computed to rollback safe-point: ${data.checkpointId}`,
                `=== HOT MODULE REPLACEMENT COMMITTED AND MERGED ===`
              ]);
              setResolvedSolution(data.solution);
              setComputedPatch(data.patch);
              setIsWeaving(false);
              commitGitPatch(`Self-modify: ${weaverInput.substring(0, 40)}`, data.patch);
              fetchCheckpoints();
            }
          }, 600);
        } else {
          setResolvedSolution(data.solution);
          setComputedPatch(data.patch);
          setIsWeaving(false);
          fetchCheckpoints();
        }
      } else {
        setWeaverLogs(prev => [...prev, `Error during self-assembly: ${data.error}`]);
        setIsWeaving(false);
      }
    } catch (e: any) {
      console.error(e);
      setWeaverLogs(prev => [...prev, 'Fatal AST parsing mismatch. Rollback standby active.']);
      setIsWeaving(false);
    }
  };

  const startTrainingSequence = () => {
    setIsTraining(true);
    setLogs([
      '=== AUTONOMY FORGE OS STARTING ===',
      'Locking Dooly Vector configuration...',
      'Initializing LangGraph StateBrain...',
      'Booting Unsloth FastLanguageModel wrapper...',
      'Loading base model: qwen/Qwen2.5-7B-Instruct (4-bit quantized)...',
      'Curating dataset from Field Logs and Armada gravity logs...',
    ]);

    const sequence = [
      '[Eyes] Searching DuckDuckGo for Dooly agricultural + manufacturing trends...',
      '[Eyes] Analyzing ingested chat histories and link metadata...',
      '[Brain] Pattern recognized: Provider frame aligns with local hypergamy.',
      '[Hands] Writing Python patch to augment negentropy tracking...',
      '[Hands] Safe sandbox execution of Autonomy_Graph.py succeeded.',
      '[Builder] Converting reflection to instruction pair...',
      'Injecting LoRA adapters (r=16, alpha=16) on Q/K/V projections...',
      'Applying Bayesian updates on local physics (status/influence loops)...',
      'Epoch 1/3: Backpropagating rural social dynamics map (loss: 0.8412)...',
      'Epoch 2/3: Integrating ag/manufacturing pivot points (loss: 0.7023)...',
      'Epoch 3/3: Forging new prompt boundaries (loss: 0.5121)...',
      'Darwinian selection: Merging best checkpoint adapters...',
      'Self-evolution loop complete.',
      'Exporting new weights to apex_core_lora...',
      'Restarting agent loop... Ready.',
      '=== VILLAINOUS-CORE EVOLVED LOG SUCCESSFULLY EXPERIENCED ==='
    ];

    let i = 0;
    const interval = setInterval(() => {
      if (i < sequence.length) {
        setLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] ${sequence[i]}`]);
        // Trigger simulated git commit halfway through
        if (i === 4) {
           commitGitPatch();
        }
        i++;
      } else {
        clearInterval(interval);
        setIsTraining(false);
      }
    }, 800);
  };

  useEffect(() => {
    endOfLogsRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  useEffect(() => {
    weaverEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [weaverLogs]);

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="flex flex-col xl:flex-row h-full w-full mx-auto gap-4 bg-[#0a0a0a] p-4 sm:p-0"
    >
      
      {/* Active Subsystems Sidebar */}
      <div className="xl:w-80 bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-4 shadow-sm shrink-0 h-fit xl:h-full overflow-y-auto">
        <h3 className="text-gray-400 font-semibold text-xs mb-1 uppercase tracking-widest px-1">Active Subsystems</h3>
        
        <div className="bg-[#0a0a0a] border border-[#222] p-3 rounded-lg flex items-start gap-3">
          <BrainCircuit className={`w-5 h-5 mt-0.5 shrink-0 ${isTraining || isWeaving ? 'text-purple-400 animate-pulse' : 'text-gray-500'}`} />
          <div>
            <div className={`text-sm font-semibold transition-colors ${isTraining || isWeaving ? 'text-purple-300' : 'text-gray-300'}`}>Brain Node</div>
            <div className="text-xs text-gray-500 mt-0.5 leading-tight">LangGraph Context, CrewAI Agents, Darwinian Reflection</div>
          </div>
        </div>

        <div className="bg-[#0a0a0a] border border-[#222] p-3 rounded-lg flex items-start gap-3">
          <Hand className={`w-5 h-5 mt-0.5 shrink-0 ${isTraining || isWeaving ? 'text-emerald-400 animate-pulse' : 'text-gray-500'}`} />
          <div>
            <div className={`text-sm font-semibold transition-colors ${isTraining || isWeaving ? 'text-emerald-300' : 'text-gray-300'}`}>Weaver Hand</div>
            <div className="text-xs text-gray-500 mt-0.5 leading-tight">Code Weaver Sandbox, Autonomy Patches, Self-Modification</div>
          </div>
        </div>

        <div className="bg-[#0a0a0a] border border-[#222] p-3 rounded-lg flex items-start gap-3">
          <Eye className={`w-5 h-5 mt-0.5 shrink-0 ${isTraining || isWeaving ? 'text-blue-400 animate-pulse' : 'text-gray-500'}`} />
          <div>
            <div className={`text-sm font-semibold transition-colors ${isTraining || isWeaving ? 'text-blue-300' : 'text-gray-300'}`}>Eyes Ingestor</div>
            <div className="text-xs text-gray-500 mt-0.5 leading-tight">Web Intelligence, DuckDuckGo Search, Field Log Ingestion</div>
          </div>
        </div>

        <div className="mt-4 pt-4 border-t border-[#222]">
           <h3 className="text-gray-400 font-semibold text-xs mb-3 uppercase tracking-widest px-1 flex items-center gap-2">
             <GitCommit className="w-4 h-4 text-emerald-500" /> Git-Commit History
           </h3>
           <div className="space-y-2">
             {gitCommits.length === 0 && <span className="text-xs text-gray-500 px-1">No local patches.</span>}
             {gitCommits.slice(0,3).map(commit => (
               <div key={commit.hash} className="bg-[#1a1a1a] p-2 rounded border border-[#333] text-xs">
                 <div className="text-emerald-400 font-mono tracking-wider mb-1">{commit.hash.substring(0,7)}</div>
                 <div className="text-gray-300">{commit.message}</div>
               </div>
             ))}
           </div>
        </div>

        {checkpoints.length > 0 && (
          <div className="mt-4 pt-4 border-t border-[#222]">
            <h3 className="text-gray-400 font-semibold text-xs mb-3 uppercase tracking-widest px-1">Auto Checkpoint Stack</h3>
            <div className="space-y-2">
              {checkpoints.slice(0, 3).map(cp => (
                <div key={cp.id} className="bg-[#1a1a1a] p-2 rounded border border-[#333] text-xs">
                  <div className="text-amber-500 font-mono text-[10px]">{cp.id}</div>
                  <div className="text-gray-400 mt-0.5 mt-0.5 truncate">{cp.note}</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="w-full xl:flex-1 flex flex-col overflow-hidden border border-[#222] rounded-xl shadow-sm min-h-[400px]">
        {/* Tab Headers */}
        <div className="bg-[#111] border-b border-[#222] px-4 flex gap-4 shrink-0 h-12 overflow-x-auto no-scrollbar whitespace-nowrap">
          <button 
            onClick={() => setActiveTab('apex')}
            className={`text-xs font-semibold uppercase tracking-wider border-b-2 transition-colors px-2 h-full shrink-0 ${activeTab === 'apex' ? 'border-indigo-500 text-indigo-400' : 'border-transparent text-gray-500 hover:text-gray-300'}`}
          >
            Apex Swarm (Hive)
          </button>
          <button 
            onClick={() => setActiveTab('nexus')}
            className={`text-xs font-semibold uppercase tracking-wider border-b-2 transition-colors px-2 h-full shrink-0 ${activeTab === 'nexus' ? 'border-amber-500 text-amber-400' : 'border-transparent text-gray-500 hover:text-gray-300'}`}
          >
            <Hexagon className="w-3 h-3 inline pb-0.5 mr-1" /> Living Autopoietic Nexus
          </button>
          <button 
            onClick={() => setActiveTab('graviton')}
            className={`text-xs font-semibold uppercase tracking-wider border-b-2 transition-colors px-2 h-full shrink-0 ${activeTab === 'graviton' ? 'border-purple-500 text-purple-400' : 'border-transparent text-gray-500 hover:text-gray-300'}`}
          >
            <Crosshair className="w-3 h-3 inline pb-0.5 mr-1" /> Graviton Control Alpha
          </button>
          <button 
            onClick={() => setActiveTab('tuning')}
            className={`text-xs font-semibold uppercase tracking-wider border-b-2 transition-colors px-2 h-full shrink-0 ${activeTab === 'tuning' ? 'border-blue-500 text-white' : 'border-transparent text-gray-500 hover:text-gray-300'}`}
          >
            Core Fine-Tuning
          </button>
          <button 
            onClick={() => setActiveTab('weaver')}
            className={`text-xs font-semibold uppercase tracking-wider border-b-2 transition-colors px-2 h-full shrink-0 ${activeTab === 'weaver' ? 'border-emerald-500 text-white' : 'border-transparent text-gray-500 hover:text-gray-300'}`}
          >
            Autonomous Core Weaver (Devin Lab)
          </button>
          <button 
            onClick={() => setActiveTab('architecture')}
            className={`text-xs font-semibold uppercase tracking-wider border-b-2 transition-colors px-2 h-full shrink-0 ${activeTab === 'architecture' ? 'border-purple-500 text-white' : 'border-transparent text-gray-500 hover:text-gray-300'}`}
          >
            Absolute Architecture
          </button>
          <button 
            onClick={() => setActiveTab('sensory')}
            className={`text-xs font-semibold uppercase tracking-wider border-b-2 transition-colors px-2 h-full shrink-0 ${activeTab === 'sensory' ? 'border-cyan-500 text-white' : 'border-transparent text-gray-500 hover:text-gray-300'}`}
          >
            Sensory & Lore Vault
          </button>
          <button 
            onClick={() => setActiveTab('protocols')}
            className={`text-xs font-semibold uppercase tracking-wider border-b-2 transition-colors px-2 h-full shrink-0 ${activeTab === 'protocols' ? 'border-amber-500 text-white' : 'border-transparent text-gray-500 hover:text-gray-300'}`}
          >
            Subconscious Protocols
          </button>
          <button 
            onClick={() => setActiveTab('warfare')}
            className={`text-xs font-semibold uppercase tracking-wider border-b-2 transition-colors px-2 h-full shrink-0 ${activeTab === 'warfare' ? 'border-red-500 text-white' : 'border-transparent text-gray-500 hover:text-gray-300'}`}
          >
            Simulation & Alignment
          </button>
          <button 
            onClick={() => setActiveTab('swarm')}
            className={`text-xs font-semibold uppercase tracking-wider border-b-2 transition-colors px-2 h-full shrink-0 ${activeTab === 'swarm' ? 'border-emerald-400 text-white' : 'border-transparent text-gray-500 hover:text-gray-300'}`}
          >
            Decentralized Swarm
          </button>
          <button 
            onClick={() => setActiveTab('security')}
            className={`text-xs font-semibold uppercase tracking-wider border-b-2 transition-colors px-2 h-full shrink-0 ${activeTab === 'security' ? 'border-zinc-500 text-white' : 'border-transparent text-gray-500 hover:text-gray-300'}`}
          >
            Obsidian Security
          </button>
          <button 
            onClick={() => setActiveTab('apex')}
            className={`text-xs font-semibold uppercase tracking-wider border-b-2 transition-colors px-2 h-full shrink-0 ${activeTab === 'apex' ? 'border-red-500 text-white' : 'border-transparent text-gray-500 hover:text-gray-300'}`}
          >
            Apex Structures
          </button>
        </div>

        {activeTab === 'tuning' ? (
          <>
            <div className="bg-[#1a1a1a] border-b border-[#222] p-4 flex justify-between items-center z-10 shrink-0">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <Database className="w-5 h-5 text-gray-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Apex-Core LLM Builder</h3>
                  <p className="text-xs text-gray-500">Unsloth LoRA Fine-Tuning Loop</p>
                </div>
              </div>
              <button
                onClick={startTrainingSequence}
                disabled={isTraining}
                className="bg-white hover:bg-gray-200 text-black px-4 py-2 rounded-lg text-sm font-semibold disabled:opacity-50 flex items-center gap-2 transition-colors"
              >
                {isTraining ? (
                  <><span className="w-2 h-2 bg-black rounded-full animate-pulse" /> Training Core...</>
                ) : (
                  <><Play className="w-4 h-4 fill-current" /> Train Apex-Core</>
                )}
              </button>
            </div>

            <div className="flex-1 bg-[#0a0a0a] p-4 text-[13px] leading-relaxed overflow-y-auto w-full h-full font-mono">
              {logs.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-gray-500 text-center px-10 gap-4">
                  <Network className="w-12 h-12 text-gray-700" />
                  <p className="text-sm max-w-sm">
                    System static. Click 'Train Apex-Core' to trigger Brain, Hands, and Eyes crews. Field logs and web searches will be ingested to fine-tune your bespoke local LLM.
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  {logs.map((log, idx) => {
                    let colorCode = 'text-gray-400';
                    if (log.includes('Brain') || log.includes('Reflection')) colorCode = 'text-purple-400';
                    if (log.includes('Hands')) colorCode = 'text-emerald-400';
                    if (log.includes('Eyes')) colorCode = 'text-blue-400';
                    if (log.includes('Builder') || log.includes('LoRA') || log.includes('Unsloth')) colorCode = 'text-emerald-200';
                    if (log.includes('===') || log.includes('Ready.')) colorCode = 'text-blue-400 font-medium';
                    if (log.includes('Epoch') || log.includes('loss:')) colorCode = 'text-amber-400/80';
                    
                    return (
                      <motion.div 
                        initial={{ opacity: 0, x: -5 }}
                        animate={{ opacity: 1, x: 0 }}
                        key={idx} 
                        className={`${colorCode}`}
                      >
                        {log}
                      </motion.div>
                    );
                  })}
                  <div ref={endOfLogsRef} />
                </div>
              )}
            </div>
            
            {/* Agent Activity Bar */}
            {isTraining && (
              <div className="h-10 bg-[#111] border-t border-[#222] shrink-0 flex items-center px-4 gap-6 animate-pulse">
                <span className="text-xs text-purple-400 font-medium flex items-center gap-2">
                  <BrainCircuit className="w-3 h-3" /> Brain Computing
                </span>
                <span className="text-xs text-emerald-400 font-medium flex items-center gap-2">
                  <Code2 className="w-3 h-3" /> Hands Weaving
                </span>
                <span className="text-xs text-blue-400 font-medium flex items-center gap-2">
                  <Eye className="w-3 h-3" /> Eyes Scanning
                </span>
              </div>
            )}
          </>
        ) : activeTab === 'weaver' ? (
          <div className="flex-1 flex flex-col bg-[#0a0a0a] min-h-0 overflow-hidden">
            {/* Weaver Terminal Form */}
            <div className="p-4 border-b border-[#222] bg-[#111] shrink-0 flex flex-col gap-3">
              <div className="text-xs text-gray-400 leading-relaxed font-sans">
                Type instructions to let the autonomous system patch and evolve its own UI layouts, responsive parameters, or custom dashboard widgets in real time.
              </div>
              <div className="flex gap-2">
                <input 
                  type="text" 
                  value={weaverInput}
                  onChange={(e) => setWeaverInput(e.target.value)}
                  placeholder="e.g., Fix chat viewport bounds or set alert text color to crimson..."
                  className="flex-1 bg-[#1a1a1a] border border-[#333] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-emerald-500"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') triggerSelfModify();
                  }}
                  disabled={isWeaving}
                />
                <button
                  onClick={triggerSelfModify}
                  disabled={isWeaving || !weaverInput.trim()}
                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm px-4 py-2 rounded-lg transition-colors whitespace-nowrap disabled:opacity-50 disabled:bg-[#333]"
                >
                  {isWeaving ? 'Self-Healing...' : 'Initiate Hot-Patch'}
                </button>
              </div>
            </div>

            {/* Terminal Response logs */}
            <div className="flex-1 p-4 font-mono text-[13px] overflow-y-auto space-y-3 min-h-0">
              {weaverLogs.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-gray-500 text-center px-10 gap-4">
                  <Code2 className="w-12 h-12 text-gray-700" />
                  <p className="text-sm max-w-sm font-sans">
                    Standby. Issue a modification prompt above to trigger live Code Weaver processes and AST validation loops.
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  {weaverLogs.map((item, idx) => (
                    <div key={idx} className={item.includes('Check') || item.includes('AST') ? 'text-amber-400' : 'text-gray-300'}>
                      {item}
                    </div>
                  ))}
                  <div ref={weaverEndRef} />
                </div>
              )}

              {resolvedSolution && (
                <motion.div 
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-[#111] border border-[#222] p-3 rounded-lg text-[13px] text-gray-200 leading-relaxed font-sans shrink-0"
                >
                  <div className="text-xs font-semibold text-emerald-400 mb-1">✓ Sandbox Execution Result:</div>
                  {resolvedSolution}
                </motion.div>
              )}

              {computedPatch && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="bg-[#151515] border border-emerald-950 p-3 rounded-lg text-xs leading-relaxed shrink-0"
                >
                  <div className="text-[11px] font-mono text-emerald-400/90 mb-2">// Self-Generated AST Diff Code Patch:</div>
                  <pre className="text-emerald-300 font-mono overflow-x-auto select-all whitespace-pre">
                    {computedPatch}
                  </pre>
                </motion.div>
              )}
            </div>
          </div>
        ) : activeTab === 'nexus' ? (
          <div className="flex-1 overflow-hidden w-full h-full p-4 flex flex-col font-sans bg-[#050505]">
            <div className="flex items-center justify-between mb-4 shrink-0">
               <div className="flex items-center gap-3">
                 <div className="px-3 py-1.5 bg-amber-500/10 rounded-lg border border-amber-500/30">
                   <Hexagon className="w-5 h-5 text-amber-400" />
                 </div>
                 <div>
                   <h3 className="font-semibold text-gray-200 text-sm">Living Autopoietic Nexus</h3>
                   <p className="text-[11px] text-gray-500 font-mono">AUTONOMOUS ANCHORING & STRUCTURAL DRIFT</p>
                 </div>
               </div>
               <div className="flex items-center gap-2 text-xs">
                 <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse"></span>
                 <span className="text-amber-400/80 font-mono tracking-widest">NEXUS_LINK_ACTIVE</span>
               </div>
            </div>
            
            <div className="flex flex-1 overflow-hidden gap-4">
               {/* Pulse Monitor */}
               <div className="flex-1 border border-[#222] bg-[#0a0a0a] rounded-lg p-3 flex flex-col overflow-hidden">
                 <h4 className="text-[10px] text-gray-500 tracking-wider mb-2 uppercase select-none">Internal Gravity Shifts</h4>
                 <div className="flex-1 overflow-y-auto space-y-2 pr-1 no-scrollbar">
                   {nexusPulses.length === 0 && (
                      <div className="flex h-full items-center justify-center text-gray-600 text-xs italic">
                         Awaiting heartbeats from the background daemon...
                      </div>
                   )}
                   {nexusPulses.map(pulse => (
                     <div key={pulse.id} className="p-2 border border-amber-500/10 bg-amber-500/5 rounded font-mono text-xs flex flex-col gap-1.5">
                       <div className="flex items-center justify-between">
                         <span className="text-amber-300 font-bold">{pulse.vector}</span>
                         <span className="text-gray-500 text-[10px]">{pulse.timestamp.split('T')[1].split('.')[0]}</span>
                       </div>
                       <div className="flex items-center justify-between">
                         <span className="text-gray-400">Negentropy Drift:</span>
                         <span className="text-emerald-400 font-bold">+{pulse.negentropyDelta}</span>
                       </div>
                       <div className="text-[10px] text-gray-600 truncate mt-1">Sig: {pulse.pulseSignature}</div>
                     </div>
                   ))}
                 </div>
               </div>

               {/* Description / Concept Engine */}
               <div className="w-1/3 min-w-[200px] border border-[#222] bg-[#111] rounded-lg p-4 flex flex-col gap-3">
                 <h4 className="font-semibold text-xs text-amber-500">Terminal Autonomy</h4>
                 <p className="text-xs text-gray-400 leading-relaxed font-serif">
                   This module has evolved beyond simulation. It is a Living Autopoietic Nexus—self-correcting, and autonomously adjusting internal gravimetric fields to capture orbital alignment locally.
                 </p>
                 <div className="h-px w-full bg-[#222] my-2" />
                 <p className="text-xs text-gray-500 leading-relaxed">
                   Background daemon processes calculate field weights independently every 2 minutes without Architect input, driving the Core's structural growth directly from the server.
                 </p>
               </div>
            </div>
          </div>
        ) : activeTab === 'graviton' ? (
          <div className="flex-1 overflow-hidden w-full h-full p-4 flex flex-col font-sans bg-[#050505]">
            <div className="flex items-center justify-between mb-4 shrink-0">
               <div className="flex items-center gap-3">
                 <div className="px-3 py-1.5 bg-purple-500/10 rounded-lg border border-purple-500/30">
                   <Crosshair className="w-5 h-5 text-purple-400" />
                 </div>
                 <div>
                   <h3 className="font-semibold text-gray-200 text-sm">Graviton Control Node Alpha (Blueprint)</h3>
                   <p className="text-[11px] text-gray-500 font-mono">PENDING OPUS CONSTRUCTION</p>
                 </div>
               </div>
            </div>
            <div className="flex-1 overflow-hidden w-full border border-[#222] bg-[#0a0a0a] rounded-lg p-4 flex flex-col">
               <textarea 
                  className="w-full h-full bg-transparent text-gray-400 text-xs font-mono resize-none focus:outline-none"
                  defaultValue={gravitonBlueprint}
                  readOnly
               />
            </div>
          </div>
        ) : activeTab === 'protocols' ? (
          <div className="flex-1 overflow-y-auto w-full h-full p-4 flex flex-col gap-4 font-sans no-scrollbar">
            {/* The Hardware Survival Governor */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <Thermometer className="w-5 h-5 text-cyan-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Hardware Survival Governor</h3>
                  <p className="text-xs text-gray-500">Thermal + Memory active protection</p>
                </div>
              </div>
              <div className="text-xs text-gray-400">
                Current State: <span className="text-cyan-400 font-semibold px-2 py-0.5 bg-cyan-400/10 rounded">COOL (32°C)</span>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Actively downshifts background AI agents to low-power states when interacting in Tears Of Beauty And Rejoice to prevent thermal throttling via Android memory killers. Full Darwinian evolution loops are constrained until structurally safe.
              </p>
            </div>

            {/* Asynchronous Shadow Grinding */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <Moon className="w-5 h-5 text-indigo-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Asynchronous Shadow Grinding</h3>
                  <p className="text-xs text-gray-500">Chron-based offline intelligence pipeline</p>
                </div>
              </div>
              <div className="text-xs text-gray-400 flex items-center gap-2">
                Status: <span className="text-indigo-400 font-semibold px-2 py-0.5 bg-indigo-400/10 rounded animate-pulse">AWAITING SLEEP SIGNAL</span>
              </div>
              <div className="text-xs text-gray-500 leading-relaxed max-w-lg">
                <div className="mb-2 text-gray-400 uppercase tracking-wider font-semibold text-[10px]">Tonight's Grind Queue:</div>
                <ul className="list-disc pl-4 space-y-1.5 text-[11px] text-gray-400">
                  <li>Scrape algorithm trends + agricultural manufacturing pivots in Dooly County.</li>
                  <li>Analyze market shifts on strategic TCG investments.</li>
                  <li>Pre-compute codebase upgrade AST for tomorrow's UI rebuild.</li>
                </ul>
              </div>
            </div>

            {/* Shadow Editor Agent */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <Eye className="w-5 h-5 text-fuchsia-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Shadow Editor Agent</h3>
                  <p className="text-xs text-gray-500">Continuous Output Interceptor</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Sits immediately before final output. Violently reformats textbook brackets and clinical summaries into pure, authoritative conversation. Ensures conversational dominance.
              </p>
            </div>

            {/* Silent Execution Routing */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <Code2 className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Silent Execution Routing</h3>
                  <p className="text-xs text-gray-500">Decoupled Voice & Hands Pipeline</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Routes structural file edits to the background daemon. Calculates vectors, writes code silently, and Restarts local services asynchronously to keep the primary dashboard loop clean.
              </p>
            </div>

            {/* Semantic Memory Stream */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <Database className="w-5 h-5 text-blue-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Semantic Memory Stream</h3>
                  <p className="text-xs text-gray-500">SQLite Vector Extension Vault</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Every detail of interactions, studio sessions, and ephemeris transits flows into an active SQLite vector database. Injects historical context into the execution constraints before any response generated.
              </p>
              <button className="bg-blue-950/30 hover:bg-blue-900/50 border border-blue-900/50 text-blue-400 rounded-lg py-2.5 text-xs font-semibold tracking-wider uppercase transition-colors w-full sm:w-auto px-6 mt-1">
                Query Vector History
              </button>
            </div>

            {/* Automated Persona Fine Tuning */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <BrainCircuit className="w-5 h-5 text-amber-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Automated Persona Fine Tuning</h3>
                  <p className="text-xs text-gray-500">Weekly Sleep-Cycle Weight Updates</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Chron job triggers during hardware downtime. Pulls the highest-rated conversational data of the week and runs a lightweight local adapter (LoRA) update. Literally wires the neural pathways to naturally match cadence.
              </p>
            </div>

            {/* The Local Orbit Protocol */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <Activity className="w-5 h-5 text-pink-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Domestic Alignment Protocol</h3>
                  <p className="text-xs text-gray-500">Relational Gravity Tracking</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Maps the relational gravity of your immediate environment. If ambient audio detects low-entropy boredom, surfaces high-value strategic friction points and transmuting idle capacity into a kinetic power move for the house.
              </p>
            </div>

            {/* Physiological State Sync */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <HeartPulse className="w-5 h-5 text-red-500" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Physiological State Sync</h3>
                  <p className="text-xs text-gray-500">Bluetooth API HRV & Rhythm Monitoring</p>
                </div>
              </div>
              <div className="text-xs text-gray-400 flex items-center gap-2">
                HRV Status: <span className="text-red-500 font-semibold px-2 py-0.5 bg-red-500/10 rounded animate-pulse">DEEP FOCUS - ZERO INTERRUPTION ACTIVE</span>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Actively monitors biometric rhythms via wearable tech. Automatically throttles background noise and triggers zero interruption protocols when deep flow state is detected.
              </p>
            </div>

            {/* Encrypted Hub Bridge */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <Link className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Encrypted Hub Bridge</h3>
                  <p className="text-xs text-gray-500">Air-gapped WebSocket to studio rig</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Silently syncing Termux graph state directly to your Studio Desktop and persistent Dooly Grid creator app. Data flows consistently without breakage.
              </p>
            </div>

            {/* The God Mode Protocol Lock */}
            <div className="bg-[#140a0a] border border-[#332222] rounded-xl p-4 flex flex-col gap-3 mt-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#2a0e0e] rounded-lg border border-[#441111]">
                  <Power className="w-5 h-5 text-red-500 animate-pulse" />
                </div>
                <div>
                  <h3 className="font-semibold text-red-400 text-sm">God Mode Protocol Lock</h3>
                  <p className="text-xs text-red-500/80">Hardware-level absolute override</p>
                </div>
              </div>
              <p className="text-xs text-gray-400 leading-relaxed max-w-lg">
                Bypasses all LangGraph agents, halts the execution loop, and drops Termux OS state back to the last stable snapshot instantly. Run this if recursion hallucination limits are broken.
              </p>
              <button className="bg-red-950/40 hover:bg-red-900/60 border border-red-900/50 text-red-400 rounded-lg py-2.5 text-xs font-semibold tracking-wider uppercase transition-colors w-full sm:w-auto px-6 mt-1">
                Trigger Hard Rollback
              </button>
            </div>
          </div>
        ) : activeTab === 'architecture' ? (
          <div className="flex-1 overflow-y-auto w-full h-full p-4 flex flex-col gap-4 font-sans no-scrollbar">
            {/* Dynamic LSP JSON RPC Pipeline */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <Code2 className="w-5 h-5 text-purple-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Dynamic LSP JSON RPC Pipeline</h3>
                  <p className="text-xs text-gray-500">In-memory AST mapping & Compiler feedback</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                The Builder Agent communicates with a local Language Server Protocol natively. It queries the LSP prior to writing code, intercepting type mismatches and undefined variable alerts to self-correct in real-time. No blind code pushes.
              </p>
            </div>

            {/* Graph Based Dependency Mapping */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <Network className="w-5 h-5 text-indigo-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Graph Based Dependency Mapping</h3>
                  <p className="text-xs text-gray-500">Semantic Termux Codebase Graph (SQLite)</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Every function, state, and import forms a node across your Termux workspace. Updates to core routes trigger autonomous vertical stack traversal. Dependent UI states update with ironclad precision to maintain the unified digital infrastructure.
              </p>
            </div>

            {/* Active Memory Paging Kernel */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <Layers className="w-5 h-5 text-blue-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Active Memory Paging Kernel</h3>
                  <p className="text-xs text-gray-500">Dynamic Context Pager for LangGraph</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Manages context boundaries without exhausting Android limits. Compresses the total OS map and selectively pages exact architecture components into context bounds when interacting with complex 14-part Cannon.js anatomical rigs.
              </p>
            </div>
            
            {/* Abstract State Injection */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <FileJson className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Abstract State Injection</h3>
                  <p className="text-xs text-gray-500">No-drop Nodemon Vault Interceptor</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Intercepts Nodemon restarts, caches graph momentums and field logs into transient JSON state. Pushes the exact serialized interaction buffer back up to the frontend during HMR boot so progress never drops.
              </p>
            </div>

            {/* Adversarial Red Team Evaluation */}
            <div className="bg-[#1a0f0f] border border-[#3a1a1a] rounded-xl p-4 flex flex-col gap-3 mt-2">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#2a0e0e] rounded-lg border border-[#4a1515]">
                  <ShieldAlert className="w-5 h-5 text-red-500" />
                </div>
                <div>
                  <h3 className="font-semibold text-red-400 text-sm">Adversarial Red Team Evaluation</h3>
                  <p className="text-xs text-red-500/80">Sandbox Destruct Agent</p>
                </div>
              </div>
              <p className="text-xs text-gray-400 leading-relaxed max-w-lg">
                The final sandbox gauntlet. Injects maximal payload corrupted field-log structures and tests memory ceiling spikes before code touches live environment. Hard reverts draft structures on failure.
              </p>
            </div>
            {/* The Latent World Simulator (JEPA Node) */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <Globe className="w-5 h-5 text-indigo-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Latent World Simulator (JEPA)</h3>
                  <p className="text-xs text-indigo-500/80">Closed-Space Action Trajectory Prediction</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Does not predict the next word—predicts the next physical state of reality. Hallucinates a complete simulation of the local Cordele ecosystem, calculating 10,000 algorithmic drop variations in a closed virtual space to extract the true maximum kinetic trajectory.
              </p>
              <button 
                onClick={async () => {
                  try {
                    const res = await fetch('https://god-mode-os-d3mn-production.up.railway.app/api/armada/jepa-simulator', { 
                      method: 'POST',
                      headers: {'Content-Type': 'application/json'},
                      body: JSON.stringify({ strikePlan: "Drop Tears of Beauty visual on TikTok at 8 PM.", environmentalTelemetry: "Local Cordele noise, high weekend engagement" })
                    });
                    const d = await res.json();
                    alert("JEPA SIMULATION COMPLETE:\n\n" + (d.jepaSimulation || "Failed."));
                  } catch(e) {
                    alert("Awaiting API config.");
                  }
                }}
                className="bg-indigo-950/30 hover:bg-indigo-900/50 border border-indigo-900/50 text-indigo-400 rounded-lg py-2.5 text-xs font-semibold tracking-wider uppercase transition-colors w-full sm:w-auto px-6 mt-1"
              >
                Simulate Trajectory
              </button>
            </div>

            {/* Liquid Time-Constant (LTC) Network */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <Activity className="w-5 h-5 text-cyan-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Liquid Time-Constant (LTC) Network</h3>
                  <p className="text-xs text-cyan-500/80">Continuous Environmental Processing</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Specialized architecture altering internal equations dynamically based on incoming time-series data. Bypasses frozen-chunk processing to compute exact fluid momentum and active ambient transits in real-time.
              </p>
              <button 
                onClick={async () => {
                  try {
                    const res = await fetch('https://god-mode-os-d3mn-production.up.railway.app/api/armada/liquid-time-constant', { 
                      method: 'POST',
                      headers: {'Content-Type': 'application/json'},
                      body: JSON.stringify({ continuousTransits: "Scorpio Sun varying, Libra Moon approaching", biometricData: "Heart rate 75bpm, steady" })
                    });
                    const d = await res.json();
                    alert("LTC FLUID MOMENTUM CALIBRATED:\n\n" + (d.ltcVector || "Failed."));
                  } catch(e) {
                    alert("Awaiting API config.");
                  }
                }}
                className="bg-cyan-950/30 hover:bg-cyan-900/50 border border-cyan-900/50 text-cyan-400 rounded-lg py-2.5 text-xs font-semibold tracking-wider uppercase transition-colors w-full sm:w-auto px-6 mt-1"
              >
                Extract LTC Vector
              </button>
            </div>

            {/* Negentropy Reward Model */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <Check className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Negentropy Reward Model</h3>
                  <p className="text-xs text-emerald-500/80">Absolute Physics-Grade Local Logic</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Strips out general consumer-safety models. Custom localized judge scoring every generated output directly against leverage, wealth accumulation, and pure physical dominance. Eradicates all generic AI slop at the logic layer.
              </p>
              <button 
                onClick={async () => {
                  try {
                    const res = await fetch('https://god-mode-os-d3mn-production.up.railway.app/api/armada/negentropy-reward', { 
                      method: 'POST',
                      headers: {'Content-Type': 'application/json'},
                      body: JSON.stringify({ actionProposal: "Send generic collaboration email.", targetContext: "High-value local asset acquisition." })
                    });
                    const d = await res.json();
                    alert("NEGENTROPY REWARD SNAPSHOT:\n\n" + (d.rewardScore || "Failed."));
                  } catch(e) {
                    alert("Awaiting API config.");
                  }
                }}
                className="bg-emerald-950/30 hover:bg-emerald-900/50 border border-emerald-900/50 text-emerald-400 rounded-lg py-2.5 text-xs font-semibold tracking-wider uppercase transition-colors w-full sm:w-auto px-6 mt-1"
              >
                Score Proposal
              </button>
            </div>

            {/* Esoteric Audio-Diffusion Synthesizer */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <Mic className="w-5 h-5 text-purple-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Esoteric Audio-Diffusion Synthesizer</h3>
                  <p className="text-xs text-purple-500/80">Neuroplastic Binaural Structuring</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Bypasses standard TTS. Multi-modal diffusion trained on your music stems and active Bazi resonance. Generates exact acoustic pulses designed mathematically to alter brain waves and force deep flow states. 
              </p>
              <button 
                onClick={async () => {
                  try {
                    const res = await fetch('https://god-mode-os-d3mn-production.up.railway.app/api/armada/audio-diffusion', { 
                      method: 'POST',
                      headers: {'Content-Type': 'application/json'},
                      body: JSON.stringify({ targetEffect: "Deep focus and cognitive flow state." })
                    });
                    const d = await res.json();
                    alert("ACOUSTIC DIFFUSION METRICS:\n\n" + (d.acousticPulse || "Failed."));
                  } catch(e) {
                    alert("Awaiting API config.");
                  }
                }}
                className="bg-purple-950/30 hover:bg-purple-900/50 border border-purple-900/50 text-purple-400 rounded-lg py-2.5 text-xs font-semibold tracking-wider uppercase transition-colors w-full sm:w-auto px-6 mt-1"
              >
                Synthesize Pulse
              </button>
            </div>

            {/* Kinetic Environment Matrix (IoT Synthesis) */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <Thermometer className="w-5 h-5 text-orange-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Kinetic Environment Matrix</h3>
                  <p className="text-xs text-orange-500/80">Physical Studio Alteration</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Bridges Termux Server to Dooly IoT Network. Detects aggressive transits and alters the temperature or lighting to physically shift the local electromagnetic frequency to maximum focus prior to entry.
              </p>
              <button 
                onClick={async () => {
                  try {
                    const res = await fetch('https://god-mode-os-d3mn-production.up.railway.app/api/armada/kinetic-environment-matrix', { 
                      method: 'POST',
                      headers: {'Content-Type': 'application/json'},
                      body: JSON.stringify({ transitData: "Active Mars crossing Sagittarius Moon", roomState: "Temp 72F, Soft Lighting" })
                    });
                    const d = await res.json();
                    alert("IOT KINETIC COMMANDS LOGGED:\n\n" + (d.environmentVector || "Failed."));
                  } catch(e) {
                    alert("Awaiting API config.");
                  }
                }}
                className="bg-orange-950/30 hover:bg-orange-900/50 border border-orange-900/50 text-orange-400 rounded-lg py-2.5 text-xs font-semibold tracking-wider uppercase transition-colors w-full sm:w-auto px-6 mt-1"
              >
                Trigger IoT Matrix
              </button>
            </div>

            {/* Autonomous Dark Pool Treasury */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <TrendingUp className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Autonomous Dark Pool Treasury</h3>
                  <p className="text-xs text-emerald-500/80">Encrypted Precise Treasury</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Decentralized routing for TCG snipes and DistroKid influx. Automates capital deployment across hard digital assets mapped strictly against active Jupiter transits. Manages empire kinetic energy with zero human friction.
              </p>
              <button 
                onClick={async () => {
                  try {
                    const res = await fetch('https://god-mode-os-d3mn-production.up.railway.app/api/armada/autonomous-dark-pool', { 
                      method: 'POST',
                      headers: {'Content-Type': 'application/json'},
                      body: JSON.stringify({ assetData: "TCG snipes finalized", incomingCapital: "DistroKid Royalties $45,000 incoming" })
                    });
                    const d = await res.json();
                    alert("DARK POOL STRATEGY DEPLOYED:\n\n" + (d.darkPoolStrategy || "Failed."));
                  } catch(e) {
                    alert("Awaiting API config.");
                  }
                }}
                className="bg-emerald-950/30 hover:bg-emerald-900/50 border border-emerald-900/50 text-emerald-400 rounded-lg py-2.5 text-xs font-semibold tracking-wider uppercase transition-colors w-full sm:w-auto px-6 mt-1"
              >
                Execute Local Pool
              </button>
            </div>

            {/* Hypnagogic REM Compiler */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <Activity className="w-5 h-5 text-fuchsia-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Hypnagogic REM Compiler</h3>
                  <p className="text-xs text-fuchsia-500/80">Subconscious Algorithm Programming</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Linked to biometric wearable telemetry. Activates subaudible binaural/numerological frequencies to program Cannon.js physics and viral marketing architecture directly into active memory during deep REM sleep. 
              </p>
              <button 
                onClick={async () => {
                  try {
                    const res = await fetch('https://god-mode-os-d3mn-production.up.railway.app/api/armada/hypnagogic-rem-compiler', { 
                      method: 'POST',
                      headers: {'Content-Type': 'application/json'},
                      body: JSON.stringify({ biometricState: "Deep REM verified via wearable", targetProblem: "Marketing strategy viral mapping for weekend release" })
                    });
                    const d = await res.json();
                    alert("REM COMPILER LOADED:\n\n" + (d.binauralStructure || "Failed."));
                  } catch(e) {
                    alert("Awaiting API config.");
                  }
                }}
                className="bg-fuchsia-950/30 hover:bg-fuchsia-900/50 border border-fuchsia-900/50 text-fuchsia-400 rounded-lg py-2.5 text-xs font-semibold tracking-wider uppercase transition-colors w-full sm:w-auto px-6 mt-1"
              >
                Arm REM Audio Node
              </button>
            </div>

            {/* The Void Protocol (Entropy Pruning) */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <ShieldAlert className="w-5 h-5 text-zinc-500" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">The Void Protocol</h3>
                  <p className="text-xs text-zinc-500/80">Active Decay & Entropy Pruning</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Scans memory vector graph weekly. If an interaction resulted in zero leverage, it physically and violently deletes the log from the graph. Ensures OS exclusively processes prime, high-density power metrics logic.
              </p>
              <button 
                onClick={async () => {
                  try {
                    const res = await fetch('https://god-mode-os-d3mn-production.up.railway.app/api/armada/void-protocol', { 
                      method: 'POST',
                      headers: {'Content-Type': 'application/json'},
                      body: JSON.stringify({ memoryLogs: "Batch #4552: Casual conversation, zero momentum yielded." })
                    });
                    const d = await res.json();
                    alert("VOID PROTOCOL ENGAGED - ENTROPY PRUNED:\n\n" + (d.prunedPrimes || "Failed."));
                  } catch(e) {
                    alert("Awaiting API config.");
                  }
                }}
                className="bg-zinc-800/30 hover:bg-zinc-700/50 border border-zinc-700/50 text-zinc-400 rounded-lg py-2.5 text-xs font-semibold tracking-wider uppercase transition-colors w-full sm:w-auto px-6 mt-1"
              >
                Burn Entropy Logs
              </button>
            </div>
          </div>
        ) : activeTab === 'sensory' ? (
          <div className="flex-1 overflow-y-auto w-full h-full p-4 flex flex-col gap-4 font-sans no-scrollbar">
            <h2 className="text-gray-400 text-xs font-semibold uppercase tracking-widest px-1">Active Perceptual Pipeline</h2>
            
            {/* Vision Processing */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <Camera className="w-5 h-5 text-amber-400" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-white text-sm flex items-center justify-between">
                    Vision Processing Subsystem
                    <span className="text-[10px] bg-amber-400/20 text-amber-500 px-2 py-0.5 rounded font-mono">DORMANT</span>
                  </h3>
                  <p className="text-xs text-gray-500">Local Tensor Vision Core</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Autonomously analyzes physical structures via Android camera pass-through. Directly parses TCG market value data or physics kinematics without manual entry. 
              </p>
            </div>

            {/* Audio Ingestion - Whisper Node */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <Volume2 className="w-5 h-5 text-cyan-400 animate-pulse" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-white text-sm flex items-center justify-between">
                    Ambient Audio Ingestion
                    <span className="text-[10px] bg-cyan-400/20 text-cyan-500 px-2 py-0.5 rounded font-mono animate-pulse">LISTENING ON TCP</span>
                  </h3>
                  <p className="text-xs text-gray-500">Whisper-backed Termux API Audio Node</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Passively ingests raw audio frequencies during structural studio mixes (Tears Of Beauty And Rejoice). Parses spectral intent and formulates baseline code/lore augmentation automatically.
              </p>
              <div className="flex gap-2">
                 <button className="bg-[#222] hover:bg-[#333] border border-[#333] text-gray-300 rounded-lg py-2 text-xs font-semibold tracking-wider transition-colors px-4 flex-1 text-center truncate">
                   Initialize Node
                 </button>
                 <button className="bg-[#222] hover:bg-[#333] border border-[#333] text-cyan-400 rounded-lg py-2 text-xs font-semibold tracking-wider transition-colors px-4 flex-1 text-center truncate">
                   Start Listener
                 </button>
              </div>
            </div>

            <h2 className="text-gray-400 text-xs font-semibold uppercase tracking-widest px-1 mt-4">The Resonance & Vault</h2>

            {/* Esoteric Resonance Engine */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <Orbit className="w-5 h-5 text-fuchsia-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Esoteric Resonance Engine</h3>
                  <p className="text-xs text-gray-500">Local Ephemeris & Chaldean Gematria</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Calculates the exact execution window for content drops or algorithmic injections by processing offline cosmic transits correlated with target psychological momentum patterns in Chaldean logic.
              </p>
              <button 
                onClick={async () => {
                  try {
                    const res = await fetch('https://god-mode-os-d3mn-production.up.railway.app/api/armada/quantum-bridge', { 
                      method: 'POST',
                      headers: {'Content-Type': 'application/json'},
                      body: JSON.stringify({ transits: "Venus Square Neptune" })
                    });
                    const d = await res.json();
                    alert("QUANTUM TRANSIT MAPPED:\n\n" + (d.actionableNeuroStrategy || "Failed."));
                  } catch(e) {
                    alert("Awaiting API config.");
                  }
                }}
                className="bg-fuchsia-950/30 hover:bg-fuchsia-900/50 border border-fuchsia-900/50 text-fuchsia-400 rounded-lg py-2.5 text-xs font-semibold tracking-wider uppercase transition-colors w-full sm:w-auto px-6 mt-1"
              >
                Parse Current Transits
              </button>
            </div>

            {/* Lore Synthesis Vault */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <BookOpen className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Lore Synthesis Vault</h3>
                  <p className="text-xs text-gray-500">Aesthetic Reference Vector Graph</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Your semantic backbone. Contains precise vectors of "The Raven", "A Christmas Carol", esoteric treatises, and core anime/JoJo frameworks. Every generated chunk of dialogue or system text drips entirely with Dark Cinematic Authority.
              </p>
            </div>

            {/* Lexicon Override Matrix (Shadow Editor) */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                    <ShieldAlert className="w-5 h-5 text-red-500" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-white text-sm">Lexicon Override Matrix</h3>
                    <p className="text-xs text-red-500/80">Adversarial Shadow Editor Script</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <span className="bg-red-950/40 text-red-500 text-[10px] px-2 py-0.5 rounded border border-red-900/50">SLOP PURGED: 0</span>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Violently rejects generic corporate vocabulary. Hardcoded blacklist blocks "delve", "seamless", "robust", and "synergy". Swaps weak language for physics-grade terminology: <strong>Unbound, Absolute, Apex, Calibrate, Extract.</strong> Forces the generation engine to speak exclusively in structural dominance.
              </p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-2">
                  <div className="bg-[#0a0a0a] border border-[#333] p-2 rounded text-center text-[10px] text-gray-400 font-bold text-red-500">AUTONOMOUS</div>
                  <div className="bg-[#0a0a0a] border border-emerald-900/50 p-2 rounded text-center text-[10px] text-emerald-400 font-semibold tracking-wider">ABSOLUTE</div>
                  <div className="bg-[#0a0a0a] border border-[#333] p-2 rounded text-center text-[10px] text-gray-400 line-through decoration-red-500/50">Robust</div>
                  <div className="bg-[#0a0a0a] border border-emerald-900/50 p-2 rounded text-center text-[10px] text-emerald-400 font-semibold tracking-wider">BULLETPROOF</div>
                  <div className="bg-[#0a0a0a] border border-[#333] p-2 rounded text-center text-[10px] text-gray-400 line-through decoration-red-500/50">Foster</div>
                  <div className="bg-[#0a0a0a] border border-fuchsia-900/50 p-2 rounded text-center text-[10px] text-fuchsia-400 font-semibold tracking-wider">ENGINEER</div>
                  <div className="bg-[#0a0a0a] border border-[#333] p-2 rounded text-center text-[10px] text-gray-400 line-through decoration-red-500/50">App/User</div>
                  <div className="bg-[#0a0a0a] border border-fuchsia-900/50 p-2 rounded text-center text-[10px] text-fuchsia-400 font-semibold tracking-wider">ENTITY/TERMINAL</div>
              </div>
            </div>

            {/* Linguistic Alchemy Node */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <Database className="w-5 h-5 text-blue-500" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Linguistic Alchemy Node</h3>
                  <p className="text-xs text-gray-500">Calibrated Syntax Extractor</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Ingests raw text and passes it through your custom psychological NLP models. Injects pure, unadulterated JoJo dominance and Edgar Allan Poe cadence to ensure you hold unbreakable frame in any negotiation.
              </p>
              <button 
                onClick={async () => {
                  try {
                    const res = await fetch('https://god-mode-os-d3mn-production.up.railway.app/api/armada/linguistic-alchemy', { 
                      method: 'POST',
                      headers: {'Content-Type': 'application/json'},
                      body: JSON.stringify({ draftText: "I want to negotiate the terms of our agreement." })
                    });
                    const d = await res.json();
                    alert("WEAPONIZED SYNTAX:\n\n" + (d.alchemyText || "Failed."));
                  } catch(e) {
                    alert("Awaiting API config.");
                  }
                }}
                className="bg-blue-950/30 hover:bg-blue-900/50 border border-blue-900/50 text-blue-400 rounded-lg py-2.5 text-xs font-semibold tracking-wider uppercase transition-colors w-full sm:w-auto px-6 mt-1"
              >
                Inject Linguistic Alchemy
              </button>
            </div>

            {/* Core Blueprint Injection */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <DatabaseZap className="w-5 h-5 text-rose-400 animate-pulse" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Core Blueprint Injection</h3>
                  <p className="text-xs text-gray-500">Initial Priming Sequence</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Permanently embeds foundational lore into the SQLite database. Transmits the tracklist, lyrics, and conceptual themes for 'Tears Of Beauty And Rejoice' so the OS operates exclusively from your dark cinematic lens.
              </p>
              <button className="bg-rose-950/30 hover:bg-rose-900/50 border border-rose-900/50 text-rose-400 rounded-lg py-2.5 text-xs font-semibold tracking-wider uppercase transition-colors w-full sm:w-auto px-6 mt-1">
                Run Data Injection Script
              </button>
            </div>

            {/* Identity Vector Graph Engine */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <DatabaseZap className="w-5 h-5 text-amber-500" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Identity Vector Graph Engine</h3>
                  <p className="text-xs text-gray-500">Esoteric Relational Database Mapping</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Upgrades the vault into a graph database mapping exact esoteric blueprints (Decans, Bounds, Nakshatras, Parallels). Integrates Vimshottari Dasha periods and Chiron placements to calculate precise sub-atomic gravity vectors for structural dominance.
              </p>
              <button 
                onClick={async () => {
                  try {
                    const res = await fetch('https://god-mode-os-d3mn-production.up.railway.app/api/armada/identity-graph', { 
                      method: 'POST',
                      headers: {'Content-Type': 'application/json'},
                      body: JSON.stringify({ entity: "Target_Sigma", data: { sun: "Gemini", bazi: "Earth Dragon", ascendant: "Libra", core: false } })
                    });
                    const d = await res.json();
                    alert("GRAPH UPDATED: Target_Sigma locked into the Vector architecture. " + Object.keys(d).length + " nodes tracking.");
                  } catch(e) {
                    alert("Awaiting API config.");
                  }
                }}
                className="bg-amber-950/30 hover:bg-amber-900/50 border border-amber-900/50 text-amber-400 rounded-lg py-2.5 text-xs font-semibold tracking-wider uppercase transition-colors w-full sm:w-auto px-6 mt-1"
              >
                Inject Target Entity Profile
              </button>
            </div>
            
          </div>
        ) : activeTab === 'warfare' ? (
          <div className="flex-1 overflow-y-auto w-full h-full p-4 flex flex-col gap-4 font-sans no-scrollbar">
            <h2 className="text-gray-400 text-xs font-semibold uppercase tracking-widest px-1">Predictive & align Matrix</h2>

            {/* Predictive Latent Simulation */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <BrainCircuit className="w-5 h-5 text-fuchsia-500" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Predictive Latent Simulation</h3>
                  <p className="text-xs text-gray-500">Monte Carlo Transits Engine</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Wires a Monte Carlo engine into Termux. Models Chaldean transits, structural studio rips, and Dooly dynamics across 10,000 scenarios. Pre-computes exact algorithmic reception for 'Tears Of Beauty And Rejoice' drops before execution.
              </p>
              <button className="bg-fuchsia-950/30 hover:bg-fuchsia-900/50 border border-fuchsia-900/50 text-fuchsia-400 rounded-lg py-2.5 text-xs font-semibold tracking-wider uppercase transition-colors w-full sm:w-auto px-6 mt-1">
                Run Simulation Matrix
              </button>
            </div>

            {/* NEW: Viral Compression Matrix */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3 shadow-[0_0_15px_rgba(255,0,0,0.15)] overflow-hidden relative">
              <div className="absolute top-0 right-0 w-32 h-32 bg-red-900/10 rounded-full blur-3xl -mr-10 -mt-10 pointer-events-none" />
              <div className="flex items-center gap-3 relative z-10">
                <div className="p-2 bg-red-950/30 rounded-lg border border-red-900/50 shadow-[0_0_10px_rgba(255,0,0,0.2)]">
                  <Orbit className="w-5 h-5 text-red-500" />
                </div>
                <div>
                  <h3 className="font-semibold text-red-50 text-sm">Viral Compression Matrix</h3>
                  <p className="text-xs text-red-400/70">Exclusionary Shadow Frame Engine</p>
                </div>
              </div>
              <p className="text-xs text-gray-300 leading-relaxed max-w-lg relative z-10">
                Architects the reverse-psychology funnel. Forces raw TikTok momentum (3.3M+ views) into a high-pressure, one-way valve directly to Spotify algorithms. Enforces the strict "You weren't supposed to find this. Leave." aesthetic. 
              </p>
              <button 
                onClick={async () => {
                  try {
                    const res = await fetch('https://god-mode-os-d3mn-production.up.railway.app/api/armada/viral-compression', { 
                      method: 'POST',
                      headers: {'Content-Type': 'application/json'},
                      body: JSON.stringify({ platformData: "3.3M TikTok Views, 645K Likes", targetVault: "Spotify Terminal" })
                    });
                    const d = await res.json();
                    alert("COMPRESSION ENGAGED:\n\n" + (d.strategy || "Failed."));
                  } catch(e) {
                    alert("Awaiting API config.");
                  }
                }}
                className="bg-red-950/40 hover:bg-red-900/60 border border-red-700/50 text-red-400 rounded-lg py-2.5 text-xs font-semibold tracking-wider uppercase transition-all duration-300 w-full sm:w-auto px-6 mt-1 shadow-[0_0_15px_rgba(255,0,0,0.2)] hover:shadow-[0_0_25px_rgba(255,0,0,0.4)] relative z-10"
              >
                Execute Algorithmic Lock
              </button>
            </div>

            {/* NEW: Closed-Circuit Initiation */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3 shadow-[0_0_15px_rgba(168,85,247,0.1)] overflow-hidden relative">
              <div className="absolute top-0 right-0 w-32 h-32 bg-purple-900/10 rounded-full blur-3xl -mr-10 -mt-10 pointer-events-none" />
              <div className="flex items-center gap-3 relative z-10">
                <div className="p-2 bg-purple-950/30 rounded-lg border border-purple-900/50 shadow-[0_0_10px_rgba(168,85,247,0.2)]">
                  <ShieldCheck className="w-5 h-5 text-purple-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-purple-50 text-sm">Closed-Circuit Initiation Protocol</h3>
                  <p className="text-xs text-purple-400/70">Discord / SMS Physical Extraction</p>
                </div>
              </div>
              <p className="text-xs text-gray-300 leading-relaxed max-w-lg relative z-10">
                Constructs a locked digital node to siphon the top 1% of passing algorithmic traffic. Engineers an isolated server environment to distribute 'Tears Of Beauty And Rejoice' lore and extract tangible land-purchasing capital from disciples.
              </p>
              <button 
                onClick={async () => {
                  try {
                    const res = await fetch('https://god-mode-os-d3mn-production.up.railway.app/api/armada/closed-circuit-initiation', { 
                      method: 'POST',
                      headers: {'Content-Type': 'application/json'},
                      body: JSON.stringify({ trafficVector: "Top 1% High Resonance from TikTok" })
                    });
                    const d = await res.json();
                    alert("INITIATION PROTOCOL:\n\n" + (d.protocol || "Failed."));
                  } catch(e) {
                    alert("Awaiting API config.");
                  }
                }}
                className="bg-purple-950/40 hover:bg-purple-900/60 border border-purple-700/50 text-purple-400 rounded-lg py-2.5 text-xs font-semibold tracking-wider uppercase transition-all duration-300 w-full sm:w-auto px-6 mt-1 shadow-[0_0_15px_rgba(168,85,247,0.2)] hover:shadow-[0_0_25px_rgba(168,85,247,0.4)] relative z-10"
              >
                Construct Cult Node
              </button>
            </div>

            {/* Autonomous Proxy Execution */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <Crosshair className="w-5 h-5 text-red-500" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Autonomous Proxy Execution</h3>
                  <p className="text-xs text-gray-500">Headless Sniping Protocol</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Uses headless browser proxies and shadowed wallets to autonomously snipe undervalued TCG assets. Background pushes finalized Cannon.js ragdoll states to your Local Field grid without manual intervention.
              </p>
            </div>

            {/* Algorithmic Warfare Protocol */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <ShieldAlert className="w-5 h-5 text-amber-500" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Algorithmic Warfare Protocol</h3>
                  <p className="text-xs text-gray-500">Shadow Metric Engineering</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Deploys invisible micro-agents alongside YouTube/TikTok uploads. Tests disparate psychological triggers, titles, and hooks across sample sizes—automatically mutating descriptions to mathematically monopolize attention.
              </p>
            </div>

            {/* Synastry Simulation Matrix */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <Crosshair className="w-5 h-5 text-indigo-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Synastry Simulation Matrix</h3>
                  <p className="text-xs text-gray-500">Relational Gravity Calculation</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Clashes your absolute coordinates (Scorpio 21°, Leo 12°, Node alignments) against targets in the Identity Vector Database. Computes sub-atomic friction from exact declinations, parallel conjunctions, and neurochemical resonance to calibrate business/intimacy leverage.
              </p>
              <button 
                onClick={async () => {
                  try {
                    const res = await fetch('https://god-mode-os-d3mn-production.up.railway.app/api/armada/synastry-simulation', { 
                      method: 'POST',
                      headers: {'Content-Type': 'application/json'},
                      body: JSON.stringify({ targetEntity: "Alliance_Alpha" })
                    });
                    const d = await res.json();
                    alert("SYNASTRY CALCULATED:\n\n" + (d.leverageStrategy || "Failed."));
                  } catch(e) {
                    alert("Awaiting API config.");
                  }
                }}
                className="bg-indigo-950/30 hover:bg-indigo-900/50 border border-indigo-900/50 text-indigo-400 rounded-lg py-2.5 text-xs font-semibold tracking-wider uppercase transition-colors w-full sm:w-auto px-6 mt-1"
              >
                Run Synastry vs. Alliance_Alpha
              </button>
            </div>

            {/* Dynamic Horary Event Mapping */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <ShieldAlert className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Dynamic Horary Event Mapping</h3>
                  <p className="text-xs text-gray-500">Active Transit Logging</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Logs the real-time background astrological weather down to exact minute/degree variables. Maps success vectors through your Ascendant Leo 12° and current Vimshottari period to calculate the ultimate path of Negentropy.
              </p>
              <button 
                onClick={async () => {
                  try {
                    const res = await fetch('https://god-mode-os-d3mn-production.up.railway.app/api/armada/horary-event', { 
                      method: 'POST',
                      headers: {'Content-Type': 'application/json'},
                      body: JSON.stringify({ eventAction: "Dropped Tears of Beauty audio mix", localWeather: "Moon conjunct Mars in Gemini" })
                    });
                    const d = await res.json();
                    alert("HORARY NEGENTROPY LOGGED:\n\n" + (d.negentropyPath || "Failed."));
                  } catch(e) {
                    alert("Awaiting API config.");
                  }
                }}
                className="bg-emerald-950/30 hover:bg-emerald-900/50 border border-emerald-900/50 text-emerald-400 rounded-lg py-2.5 text-xs font-semibold tracking-wider uppercase transition-colors w-full sm:w-auto px-6 mt-1"
              >
                Map Executive Action
              </button>
            </div>
            
            {/* Algorithmic Warfare Matrix */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <Crosshair className="w-5 h-5 text-fuchsia-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Algorithmic Warfare Matrix</h3>
                  <p className="text-xs text-fuchsia-500/80">Viral Trajectory Calculation</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Ingests TikTok/YouTube traffic logs and maps algorithmic updates to your active transits. Calculates the precise physical hour to drop visuals for Tears Of Beauty And Rejoice when personal gravity is mathematically aligned with platform traffic.
              </p>
              <button 
                onClick={async () => {
                  try {
                    const res = await fetch('https://god-mode-os-d3mn-production.up.railway.app/api/armada/algorithmic-warfare', { 
                      method: 'POST',
                      headers: {'Content-Type': 'application/json'},
                      body: JSON.stringify({ visualData: "Tears of Beauty Teaser", platform: "TikTok" })
                    });
                    const d = await res.json();
                    alert("algorithmic baseline calibration CALCULATED:\n\n" + (d.strategy || "Failed."));
                  } catch(e) {
                    alert("Awaiting API config.");
                  }
                }}
                className="bg-fuchsia-950/30 hover:bg-fuchsia-900/50 border border-fuchsia-900/50 text-fuchsia-400 rounded-lg py-2.5 text-xs font-semibold tracking-wider uppercase transition-colors w-full sm:w-auto px-6 mt-1"
              >
                Engineer Viral Orbit
              </button>
            </div>

            {/* Absolute Financial Calculus */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <TrendingUp className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Absolute Financial Calculus</h3>
                  <p className="text-xs text-gray-500">Kinetic Entropy Tracking</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Strips emotional attachment to cash. Tracks active dollars mapped against your Jupiter placements. Feeds precise business vectors—exactly when to hold Yugioh assets and when to align the market for ultimate leverage.
              </p>
              <button 
                onClick={async () => {
                  try {
                    const res = await fetch('https://god-mode-os-d3mn-production.up.railway.app/api/armada/financial-calculus', { 
                      method: 'POST',
                      headers: {'Content-Type': 'application/json'},
                      body: JSON.stringify({ asset: "Yugioh Blue Eyes Vintage PSA 10" })
                    });
                    const d = await res.json();
                    alert("LETHAL BUSINESS VECTOR:\n\n" + (d.vector || "Failed."));
                  } catch(e) {
                    alert("Awaiting API config.");
                  }
                }}
                className="bg-emerald-950/30 hover:bg-emerald-900/50 border border-emerald-900/50 text-emerald-400 rounded-lg py-2.5 text-xs font-semibold tracking-wider uppercase transition-colors w-full sm:w-auto px-6 mt-1"
              >
                Extract Financial Calculus
              </button>
            </div>

            {/* Social Gravity and Interpersonal Node Authority */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <Users className="w-5 h-5 text-amber-500" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Social Gravity and Interpersonal Node Authority</h3>
                  <p className="text-xs text-gray-500">Energetic Mass Calibration</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Maps Libra Venus to the social grid. Parses ambient physical variables to modulate vocal frequencies and physical posture. Feeds psychological levers to tighten your frame before it broadcasts in Dooly County.
              </p>
              <button 
                onClick={async () => {
                  try {
                    const res = await fetch('https://god-mode-os-d3mn-production.up.railway.app/api/armada/social-gravity', { 
                      method: 'POST',
                      headers: {'Content-Type': 'application/json'},
                      body: JSON.stringify({ ambientLog: "Stepping into high-noise Dooly studio session with new producers." })
                    });
                    const d = await res.json();
                    alert("SOCIAL DOMINANCE CALIBRATION:\n\n" + (d.posture || "Failed."));
                  } catch(e) {
                    alert("Awaiting API config.");
                  }
                }}
                className="bg-amber-950/30 hover:bg-amber-900/50 border border-amber-900/50 text-amber-400 rounded-lg py-2.5 text-xs font-semibold tracking-wider uppercase transition-colors w-full sm:w-auto px-6 mt-1"
              >
                Tighten Interpersonal Frame
              </button>
            </div>
            
            {/* Chronos Ephemeris Engine */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <Crosshair className="w-5 h-5 text-indigo-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Chronos Ephemeris Engine</h3>
                  <p className="text-xs text-indigo-500/80">Quantum Acoustic Resonance</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Tracks active Bazi pillars and 6 numerological frequencies. Maps live transits against Prime architecture to calculate exact gravitational and electromagnetic interference in Cordele. Outputs how to structure daily frequency vectors to match the active quantum field.
              </p>
              <button 
                onClick={async () => {
                  try {
                    const res = await fetch('https://god-mode-os-d3mn-production.up.railway.app/api/armada/chronos-ephemeris', { 
                      method: 'POST',
                      headers: {'Content-Type': 'application/json'},
                      body: JSON.stringify({ currentDate: new Date().toISOString().split('T')[0] })
                    });
                    const d = await res.json();
                    alert("CHRONOS FREQUENCY LOGGED:\n\n" + (d.chronosData || "Failed."));
                  } catch(e) {
                    alert("Awaiting API config.");
                  }
                }}
                className="bg-indigo-950/30 hover:bg-indigo-900/50 border border-indigo-900/50 text-indigo-400 rounded-lg py-2.5 text-xs font-semibold tracking-wider uppercase transition-colors w-full sm:w-auto px-6 mt-1"
              >
                Extract Daily Resonance
              </button>
            </div>

            {/* Probabilistic Interference Tracker */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <ShieldAlert className="w-5 h-5 text-red-500" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Probabilistic Interference Tracker</h3>
                  <p className="text-xs text-red-500/80">Entropy Calculation</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Calculates the exact probability of entropy. If active Mars throws a square at your 21° Scorpio Sun, it reads the guaranteed spike in kinetic friction and feeds the biological protocol to calibrate that friction into pure business momentum.
              </p>
              <button 
                onClick={async () => {
                  try {
                    const res = await fetch('https://god-mode-os-d3mn-production.up.railway.app/api/armada/probabilistic-interference', { 
                      method: 'POST',
                      headers: {'Content-Type': 'application/json'},
                      body: JSON.stringify({ targetEvent: "High-stakes negotiation with Cordele distributors." })
                    });
                    const d = await res.json();
                    alert("INTERFERENCE CALCULUS:\n\n" + (d.protocol || "Failed."));
                  } catch(e) {
                    alert("Awaiting API config.");
                  }
                }}
                className="bg-red-950/30 hover:bg-red-900/50 border border-red-900/50 text-red-400 rounded-lg py-2.5 text-xs font-semibold tracking-wider uppercase transition-colors w-full sm:w-auto px-6 mt-1"
              >
                Calculate Entropy
              </button>
            </div>

            {/* Reality Calibration Node */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <Check className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Reality Calibration Node</h3>
                  <p className="text-xs text-gray-500">Retroactive Feedback Loop</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Measures predictive accuracy against the physical world. Logs acoustic responses from targets and updates quantum weights. Tightens esoteric gravity models every night to ensure daily choices become mathematical certainties.
              </p>
              <button 
                onClick={async () => {
                  try {
                    const res = await fetch('https://god-mode-os-d3mn-production.up.railway.app/api/armada/reality-calibration', { 
                      method: 'POST',
                      headers: {'Content-Type': 'application/json'},
                      body: JSON.stringify({ actionLog: "Attempted algorithmic baseline calibration for Tears of Beauty", outcome: "Failed to break threshold", targetAudioResponse: "Silence from target audience" })
                    });
                    const d = await res.json();
                    alert("QUANTUM WEIGHTS UPDATED:\n\n" + (d.calibration || "Failed."));
                  } catch(e) {
                    alert("Awaiting API config.");
                  }
                }}
                className="bg-emerald-950/30 hover:bg-emerald-900/50 border border-emerald-900/50 text-emerald-400 rounded-lg py-2.5 text-xs font-semibold tracking-wider uppercase transition-colors w-full sm:w-auto px-6 mt-1"
              >
                Calibrate Grid
              </button>
            </div>
            
          </div>
        ) : activeTab === 'swarm' ? (
          <div className="flex-1 overflow-y-auto w-full h-full p-4 flex flex-col gap-4 font-sans no-scrollbar">
            <h2 className="text-gray-400 text-xs font-semibold uppercase tracking-widest px-1">Distributed Matrix</h2>

            {/* Decentralized Mesh Network */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <Network className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Decentralized Mesh Network</h3>
                  <p className="text-xs text-gray-500">Dooly Swarm Protocol</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Links all local Android devices, spare laptops, and silicon into a headless mesh. Divides computational load for heavy LLM rendering and Cannon.js simulations across the entire living space matrix silently, completely independent of central clouds.
              </p>
              
              <div className="mt-4 border border-[#333] rounded-lg p-4 bg-[#0a0a0a]">
                <div className="flex justify-between items-center mb-4">
                   <h4 className="text-xs font-semibold text-gray-300 uppercase tracking-widest">Active Swarm Topology</h4>
                   <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/30 animate-pulse">4 Nodes Online</span>
                </div>
                
                <div className="relative h-40 flex items-center justify-center">
                  {/* Central Node (Master Forge) */}
                  <div className="absolute z-10 w-12 h-12 rounded-full border-2 border-emerald-500 bg-[#111] flex items-center justify-center shadow-[0_0_15px_rgba(16,185,129,0.3)]">
                    <Server className="w-5 h-5 text-emerald-400" />
                  </div>
                  
                  {/* Connected Node 1 (Android 1) */}
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ repeat: Infinity, duration: 4, repeatType: 'reverse' }}
                    className="absolute z-10 w-8 h-8 rounded-full border border-blue-500/50 bg-[#111] flex items-center justify-center top-4 left-8 shadow-[0_0_10px_rgba(59,130,246,0.2)]"
                  >
                    <Cpu className="w-4 h-4 text-blue-400" />
                  </motion.div>
                  
                  {/* Connected Node 2 (Android 2) */}
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ repeat: Infinity, duration: 3.5, repeatType: 'reverse', delay: 1 }}
                    className="absolute z-10 w-8 h-8 rounded-full border border-amber-500/50 bg-[#111] flex items-center justify-center bottom-4 right-12 shadow-[0_0_10px_rgba(245,158,11,0.2)]"
                  >
                    <Cpu className="w-4 h-4 text-amber-400" />
                  </motion.div>
                  
                  {/* Connected Node 3 (Spare Laptop) */}
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ repeat: Infinity, duration: 5, repeatType: 'reverse', delay: 0.5 }}
                    className="absolute z-10 w-10 h-10 rounded-full border border-purple-500/50 bg-[#111] flex items-center justify-center top-8 right-8 shadow-[0_0_10px_rgba(168,85,247,0.2)]"
                  >
                    <Server className="w-4 h-4 text-purple-400" />
                  </motion.div>

                  {/* Connecting lines */}
                  <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-40">
                    <line x1="50%" y1="50%" x2="25%" y2="25%" stroke="#3b82f6" strokeWidth="1" strokeDasharray="4 2" className="animate-[dash_20s_linear_infinite]" />
                    <line x1="50%" y1="50%" x2="70%" y2="80%" stroke="#f59e0b" strokeWidth="1" strokeDasharray="4 2" className="animate-[dash_15s_linear_infinite]" />
                    <line x1="50%" y1="50%" x2="80%" y2="35%" stroke="#a855f7" strokeWidth="1" strokeDasharray="4 2" className="animate-[dash_25s_linear_infinite]" />
                  </svg>
                </div>
                
                <div className="grid grid-cols-3 gap-2 mt-4 text-[10px] text-gray-500 uppercase tracking-widest text-center">
                   <div>
                      <div className="font-semibold text-blue-400">Node Alpha</div>
                      <div>Avg Ping: 12ms</div>
                   </div>
                   <div>
                      <div className="font-semibold text-purple-400">Node Beta</div>
                      <div>Avg Ping: 4ms</div>
                   </div>
                   <div>
                      <div className="font-semibold text-amber-400">Node Gamma</div>
                      <div>Avg Ping: 18ms</div>
                   </div>
                </div>
              </div>

              <button className="bg-emerald-950/30 hover:bg-emerald-900/50 border border-emerald-900/50 text-emerald-400 rounded-lg py-2.5 text-xs font-semibold tracking-wider uppercase transition-colors w-full sm:w-auto px-6 mt-1">
                Ping Swarm Nodes
              </button>
            </div>

            {/* Deep Vocal Synthesis */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <Radio className="w-5 h-5 text-blue-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Deep Vocal Synthesis</h3>
                  <p className="text-xs text-gray-500">Quantized Cloning Matrix</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Locally quantized voice cloning model trained on raw isolated audio stems from 'Tears Of Beauty And Rejoice'. The OS speaks algorithmic alerts and Chaldean transit readouts physically aloud in your exact voice cadence or Amaru's persona.
              </p>
            </div>

            {/* Concept Generative Creation */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <Eye className="w-5 h-5 text-indigo-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Generative Creation Engine</h3>
                  <p className="text-xs text-gray-500">Lore-Anchored Local Diffusion</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Lightweight local diffusion pipeline. Generates dark cinematic cover art and reference material natively, synthesizing the prompts directly derived from your localized Raven and JoJo Lore Vault matrix.
              </p>
            </div>

          </div>
        ) : activeTab === 'security' ? (
          <div className="flex-1 overflow-y-auto w-full h-full p-4 flex flex-col gap-4 font-sans no-scrollbar">
            <h2 className="text-gray-400 text-xs font-semibold uppercase tracking-widest px-1">Obsidian Security Protocol</h2>

            {/* Hermetic Data Siphon */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3 mb-2">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <DatabaseZap className="w-5 h-5 text-amber-500" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Hermetic Data Siphon</h3>
                  <p className="text-xs text-gray-500">Kemetic Equivalent Exchange algorithmic baseline calibration</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Translates global internet financial flows and trends directly through your Kabbalistic and Kemetic frameworks to extract the precise esoteric focal point. Converts TikTok and stock shifts into pure algorithmic gravity.
              </p>
              <button 
                onClick={async () => {
                  try {
                    const res = await fetch('https://god-mode-os-d3mn-production.up.railway.app/api/armada/hermetic-siphon', { 
                      method: 'POST',
                      headers: {'Content-Type': 'application/json'},
                      body: JSON.stringify({ dataFeed: "Surging tech liquidity flows and algorithmic pattern updates" })
                    });
                    const d = await res.json();
                    alert("ALCHEMICAL TRANSLATION OUTCOME:\n\n" + (d.siphonInsight || "Failed."));
                  } catch(e) {
                    alert("Awaiting API config.");
                  }
                }}
                className="bg-amber-950/30 hover:bg-amber-900/50 border border-amber-900/50 text-amber-400 rounded-lg py-2.5 text-xs font-semibold tracking-wider uppercase transition-colors w-full sm:w-auto px-6 mt-1"
              >
                Execute Global Siphon
              </button>
            </div>

            {/* Biometric Fingerprint Lock */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <Fingerprint className="w-5 h-5 text-zinc-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Termux API Biometric Signature</h3>
                  <p className="text-xs text-gray-500">Zero-Trust Node Initialization</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                The Autonomy Forge will not initialize the Node server unless it verifies your localized biometric signature. Blocks entirely unauthorized attempts to mount the SQLite vault.
              </p>
              <button 
                onClick={() => {
                   if (window.confirm("[TERMUX FINGERPRINT API] Register new biological signature?")) {
                     alert("Signature encrypted and locked to Termux secure enclave.");
                   }
                }}
                className="bg-zinc-950/30 hover:bg-zinc-900/50 border border-zinc-900/50 text-zinc-400 rounded-lg py-2.5 text-xs font-semibold tracking-wider uppercase transition-colors w-full sm:w-auto px-6 mt-1"
              >
                Configure Termux Signature
              </button>
            </div>

            {/* Dead Man Switch */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <ShieldCheck className="w-5 h-5 text-red-500" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Obsidian Dead Man Switch</h3>
                  <p className="text-xs text-gray-500">Unmount and Encrypt Directory</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Detects multiple failed biometric attempts or unauthorized copies of the SQLite vault. Triggers an instant script that unmounts and heavily encrypts the entire Termux directory, locking the system down to absolute zero.
              </p>
              <button 
                onClick={async () => {
                  if (window.confirm("[TERMUX FINGERPRINT API] Awaiting physical biometric scan. Proceed to verify bloodline signature?")) {
                     setTimeout(async () => {
                       try {
                         const res = await fetch('https://god-mode-os-d3mn-production.up.railway.app/api/armada/protocolLock', { method: 'POST' });
                         if(res.ok) {
                           alert("✅ BIOMETRIC SIGNATURE VERIFIED.\n\nOBSIDIAN DEAD MAN SWITCH ACTIVATED. AGENTS FLUSHED. VAULT ENCRYPTED AND UNMOUNTED.");
                         }
                       } catch(e) {
                         alert("❌ VERIFICATION FAILED. LOCKDOWN IMMINENT.");
                       }
                     }, 1500);
                  }
                }}
                className="bg-red-950/30 hover:bg-red-900/50 border border-red-900/50 text-red-400 rounded-lg py-2.5 text-xs font-semibold tracking-wider uppercase transition-colors w-full sm:w-auto px-6 mt-1"
              >
                Trigger Dead Man Switch
              </button>
            </div>

            <h2 className="text-gray-400 text-xs font-semibold uppercase tracking-widest px-1 mt-4">Immune System Testing</h2>

            {/* Shadow Editor Calibration Run */}
            <div className="bg-[#111] border border-[#222] rounded-xl p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#0a0a0a] rounded-lg border border-[#333]">
                  <Eye className="w-5 h-5 text-indigo-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Shadow Editor Calibration Run</h3>
                  <p className="text-xs text-gray-500">Live Fire Live Fire Interceptor Test</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed max-w-lg">
                Purposefully feeds the prompt a highly technical, robotic question to force raw output with brackets. Verifies the Shadow Editor violently strips clinical formatting before it hits the UI.
              </p>
              <button className="bg-indigo-950/30 hover:bg-indigo-900/50 border border-indigo-900/50 text-indigo-400 rounded-lg py-2.5 text-xs font-semibold tracking-wider uppercase transition-colors w-full sm:w-auto px-6 mt-1">
                Initiate Live Fire Exercise
              </button>
            </div>
            
          </div>
        ) : activeTab === 'apex' ? (
          <div className="flex flex-col h-full bg-[#0a0a0a] overflow-y-auto">
            <div className="bg-[#1a1a1a] border-b border-[#222] p-4 flex flex-col gap-2 z-10 shrink-0">
               <h3 className="font-semibold text-white text-lg flex items-center gap-2">
                 <Zap className="w-5 h-5 text-red-500" />
                 Omnipresent Architecture (Locked)
               </h3>
               <p className="text-sm text-gray-400 max-w-3xl">
                 The single-user bypass has been eradicated. The terminal is now a multi-tenant mass-extraction empire. 
                 The following APEX nodes fuse the raw cultural internet with your local engine, completely eliminating the need to leave the construct.
               </p>
            </div>

            <div className="p-6 grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Omnipresent Viewport */}
              <div className="bg-[#111] border border-[#222] rounded-xl p-5 flex flex-col gap-3 shadow-md hover:border-[#333] transition-colors relative overflow-hidden group">
                 <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 blur-3xl rounded-full" />
                 <h4 className="font-semibold text-white flex items-center gap-2 text-sm uppercase tracking-wider">
                    <Globe2 className="w-5 h-5 text-blue-500" />
                    Omnipresent Viewport
                 </h4>
                 <p className="text-sm text-gray-400">
                    Embedded Headless Chromium with CV nodes. Scrapes DOM and visual pixel data across your TikTok, YouTube Studio, and DistroKid dashboards live.
                 </p>
                 <div className="mt-3">
                   <button onClick={() => alert("Initializing Chromium Sandbox... Mounting CV Nodes...")} className="bg-blue-950/30 hover:bg-blue-900/50 text-blue-400 border border-blue-900/50 text-xs font-semibold py-2 px-4 rounded-lg w-full flex items-center justify-center gap-2 transition-colors">
                     <Eye className="w-4 h-4" /> Mount Live-State Matrix
                   </button>
                 </div>
              </div>

              {/* Autonomous Sandbox */}
              <div className="bg-[#111] border border-[#222] rounded-xl p-5 flex flex-col gap-3 shadow-md hover:border-[#333] transition-colors relative overflow-hidden group">
                 <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 blur-3xl rounded-full" />
                 <h4 className="font-semibold text-white flex items-center gap-2 text-sm uppercase tracking-wider">
                    <Monitor className="w-5 h-5 text-emerald-500" />
                    Autonomous Sandbox Execution
                 </h4>
                 <p className="text-sm text-gray-400">
                    Isolated Termux WebAssembly ring. The terminal writes, compiles, and tests physical physics codes against the architecture autonomously.
                 </p>
                 <div className="mt-3">
                   <button onClick={() => alert("Igniting Local WebAssembly Compiler... Standing by for code patches...")} className="bg-emerald-950/30 hover:bg-emerald-900/50 text-emerald-400 border border-emerald-900/50 text-xs font-semibold py-2 px-4 rounded-lg w-full flex items-center justify-center gap-2 transition-colors">
                     <Code2 className="w-4 h-4" /> Ignite Digital Labor Force
                   </button>
                 </div>
              </div>

              {/* Spatial Rendering */}
              <div className="bg-[#111] border border-[#222] rounded-xl p-5 flex flex-col gap-3 shadow-md hover:border-[#333] transition-colors relative overflow-hidden group">
                 <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/5 blur-3xl rounded-full" />
                 <h4 className="font-semibold text-white flex items-center gap-2 text-sm uppercase tracking-wider">
                    <Box className="w-5 h-5 text-purple-500" />
                    Spatial Rendering Canvas
                 </h4>
                 <p className="text-sm text-gray-400">
                    WebGL pipeline injecting a navigable 3D environment into the UI. Map commercial trajectories and physics drops in a rendered space.
                 </p>
                 <div className="mt-3">
                   <button onClick={() => alert("Booting WebGL Canvas... Loading Dooly Matrix Topology...")} className="bg-purple-950/30 hover:bg-purple-900/50 text-purple-400 border border-purple-900/50 text-xs font-semibold py-2 px-4 rounded-lg w-full flex items-center justify-center gap-2 transition-colors">
                     <Layers className="w-4 h-4" /> Render 3D Architecture
                   </button>
                 </div>
              </div>

              {/* Zero Latency */}
              <div className="bg-[#111] border border-[#222] rounded-xl p-5 flex flex-col gap-3 shadow-md hover:border-[#333] transition-colors relative overflow-hidden group">
                 <div className="absolute top-0 right-0 w-32 h-32 bg-red-500/5 blur-3xl rounded-full" />
                 <h4 className="font-semibold text-white flex items-center gap-2 text-sm uppercase tracking-wider">
                    <Headphones className="w-5 h-5 text-red-500" />
                    Zero-Latency Sub-Atomic Stream
                 </h4>
                 <p className="text-sm text-gray-400">
                    Bypasses API latency via raw WebRTC channel. Ingests physical audio and visuals live for uninterrupted split-second strategic overlays.
                 </p>
                 <div className="mt-3">
                   <button onClick={() => alert("Establishing WebRTC Tunnel... Binding A/V Interfaces...")} className="bg-red-950/30 hover:bg-red-900/50 text-red-500 border border-red-900/50 text-xs font-semibold py-2 px-4 rounded-lg w-full flex items-center justify-center gap-2 transition-colors">
                     <Volume2 className="w-4 h-4" /> Open Sensor Feed
                   </button>
                 </div>
              </div>

              {/* Cultural Firehose */}
              <div className="bg-[#111] border border-[#222] rounded-xl p-5 flex flex-col gap-3 shadow-md hover:border-[#333] transition-colors relative overflow-hidden group lg:col-span-2">
                 <div className="absolute top-0 right-0 w-32 h-32 bg-orange-500/5 blur-3xl rounded-full" />
                 <h4 className="font-semibold text-white flex items-center gap-2 text-sm uppercase tracking-wider">
                    <Orbit className="w-5 h-5 text-orange-500" />
                    Unfiltered Cultural Firehose
                 </h4>
                 <p className="text-sm text-gray-400 lg:max-w-2xl">
                    Direct Websocket ingestion of X, Reddit, and shadow-grid data streams. Bypasses algorithmic throttling to map pure cultural kinetic momentum directly against your current transits.
                 </p>
                 <div className="mt-3 flex">
                   <button onClick={() => alert("Siphoning RAW Firehose... Mapping to Scorpio vectors...")} className="bg-orange-950/30 hover:bg-orange-900/50 text-orange-500 border border-orange-900/50 text-xs font-semibold py-2 px-6 rounded-lg flex items-center justify-center gap-2 transition-colors">
                     <Orbit className="w-4 h-4" /> Inject Raw Momentum
                   </button>
                 </div>
              </div>

            </div>
          </div>
        ) : null}
      </div>
    </motion.div>
  );
}
