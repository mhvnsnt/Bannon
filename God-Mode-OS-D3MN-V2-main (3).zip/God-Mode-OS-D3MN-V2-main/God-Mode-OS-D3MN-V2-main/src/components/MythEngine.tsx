import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { useGodModeStore } from '../store/useGodModeStore';
import { analyzeFrequencies } from '../lib/audioEngine';

export const MythEngine = () => {
    const mountRef = useRef<HTMLDivElement>(null);
    const kineticVelocity = useGodModeStore(state => state.kineticVelocity);

    useEffect(() => {
        if (!mountRef.current) return;

        const scene = new THREE.Scene();
        scene.fog = new THREE.FogExp2(0x000000, 0.0019);
        const camera = new THREE.PerspectiveCamera(70, window.innerWidth / window.innerHeight, 0.1, 2000);
        camera.position.set(0, 8, 200);

        const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, preserveDrawingBuffer: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        mountRef.current.appendChild(renderer.domElement);

        let animationFrameId: number;

        const animate = () => {
            animationFrameId = requestAnimationFrame(animate);
            
            // Analyze the audio stream and persist into global state
            analyzeFrequencies();

            // The Kinetic Bridge
            // We read the global kinetic velocity from the Zustand store
            // If you execute a massive IK align the field snaps to Rubedo form
            const formTarget = Math.min(1, Math.max(0, kineticVelocity * 0.8));
            
            // Also apply audio pulse logic based on audio analysis globally updated
            const audioPulse = useGodModeStore.getState().bassAvg;
            camera.position.z = 200 - (formTarget * 26) - (audioPulse * 20);

            renderer.render(scene, camera);
        };

        animate();

        // Absolute Memory Teardown Protocol
        return () => {
            cancelAnimationFrame(animationFrameId);
            renderer.dispose();
            if (mountRef.current) {
                mountRef.current.removeChild(renderer.domElement);
            }
        };
    }, [kineticVelocity]); // Component only updates when physical impact occurs

    return <div ref={mountRef} style={{ width: '100vw', height: '100vh', position: 'fixed', zIndex: 1 }} />;
};
