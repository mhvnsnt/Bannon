import React, { Component, ErrorInfo, ReactNode } from 'react';

interface Props { children: ReactNode; }
interface State { hasError: boolean; errorData: string; }

export class SystemOverseer extends Component<Props, State> {
    public state: State = { hasError: false, errorData: '' };

    public static getDerivedStateFromError(error: Error): State {
        return { hasError: true, errorData: error.message };
    }

    public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
        // We immediately write the failure to the SQLite vault
        fetch('https://god-mode-os-d3mn-production.up.railway.app/api/vault/kinetic-log', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                session_id: 'error-boundary', 
                stage_transition: 'DESYNC',
                bass_sensitivity: 0, 
                turbulence: 0 
            })
        }).catch(err => console.error("Failed to log error to vault", err));
    }

    public render() {
        if (this.state.hasError) {
            return (
                <div style={{ padding: '20px', color: '#d11f2a', fontFamily: 'monospace', height: '100vh', backgroundColor: '#0a0000', zIndex: 9999, position: 'relative' }}>
                    <h2>SYSTEM DESYNCHRONIZATION DETECTED</h2>
                    <p style={{marginBottom: '20px'}}>The anomaly has been logged to the RAG vault. Rebootin the active container.</p>
                    <button onClick={() => window.location.reload()} 
                            style={{ background: '#ffaa00', color: '#000', padding: '10px', border: 'none', fontWeight: 'bold', cursor: 'pointer' }}>
                        FORCE REBOOT
                    </button>
                    <div style={{marginTop: '20px', color: '#555', fontSize: '12px'}}>
                        {this.state.errorData}
                    </div>
                </div>
            );
        }
        return this.props.children;
    }
}
