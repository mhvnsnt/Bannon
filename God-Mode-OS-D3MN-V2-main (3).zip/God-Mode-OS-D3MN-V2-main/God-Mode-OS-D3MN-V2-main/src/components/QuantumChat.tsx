import React, { useState, useRef, useEffect } from 'react';
import { usePrimeStore } from '../lib/store';
import { ArmadaNode, ChatMessage, ToolCall, ChatSession, PROVIDERS, AttachedFile } from '../types';
import { Send, Bot, User, Sparkles, Copy, Check, Camera, Mic, Code2, Network, Zap, Loader2, GitCommit, PlaySquare, Orbit, ShieldAlert, Menu, Plus, MessageSquare, ChevronDown, Paperclip, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import io from 'socket.io-client';
import SpatialSandbox from './SpatialSandbox';
import { getChatSessions, getChatMessages, syncChatSession } from '../lib/persistence';

const socket = io('https://god-mode-os-d3mn-production.up.railway.app');

// Helper to extract code strings for sandbox payload
function extractCodeBlock(content: string) {
  const match = content.match(/```(?:\w+)?\n([\s\S]*?)```/);
  return match ? match[1] : content;
}

// Regex-based stream filter to strip non-printable characters and force telemetry JSON structures into monospace blocks
function filterStreamContent(content: any): React.ReactNode {
  if (content === undefined || content === null) return '';
  let text = '';
  if (typeof content === 'object') {
    try {
      text = JSON.stringify(content, null, 2);
    } catch (e) {
      text = String(content);
    }
  } else {
    text = String(content);
  }

  // Strip non-printable/control characters (keeping \n \r \t)
  const cleanText = text.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x9F]/g, '');

  const trimmed = cleanText.trim();
  const isJsonLike = (trimmed.startsWith('{') && trimmed.endsWith('}')) || (trimmed.startsWith('[') && trimmed.endsWith(']'));

  if (isJsonLike) {
    return (
      <pre className="font-mono text-[10px] bg-[#050505] text-emerald-400 p-2 rounded border border-emerald-950/50 overflow-x-auto max-w-full leading-normal whitespace-pre">
        <code>{cleanText}</code>
      </pre>
    );
  }

  return <span className="whitespace-pre-wrap">{cleanText}</span>;
}

// ... (other components like CopyButton, IntentBadge, KineticExecutionHUD remain unchanged until OmniStrikeHUD)
function CopyButton({ text, className, showLabel = false }: { text: string; className?: string, showLabel?: boolean }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <button
      onClick={handleCopy}
      className={`flex items-center gap-1.5 p-1.5 text-xs text-gray-400 hover:text-white hover:bg-[#333] rounded-md transition-colors ${className || ''}`}
      title="Copy message"
    >
      {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
      {showLabel && <span>{copied ? 'Copied!' : 'Copy'}</span>}
    </button>
  );
}

function IntentBadge({ intent }: { intent?: 'strategy' | 'code' | 'build' | 'deploy' }) {
  if (!intent) return null;
  const config = {
    strategy: { icon: Network, color: 'text-purple-400', bg: 'bg-purple-900/20' },
    code: { icon: Code2, color: 'text-emerald-400', bg: 'bg-emerald-900/20' },
    build: { icon: Zap, color: 'text-amber-400', bg: 'bg-amber-900/20' },
    deploy: { icon: PlaySquare, color: 'text-blue-400', bg: 'bg-blue-900/20' },
  };
  const { icon: Icon, color, bg } = config[intent] || config.strategy;
  
  return (
    <div className={`flex items-center gap-1.5 px-2 py-1 rounded text-[10px] font-mono tracking-wider uppercase border border-[#333] ${bg} ${color}`}>
      <Icon className="w-3 h-3" />
      {intent} Route Executed
    </div>
  );
}

function KineticExecutionHUD({ tools }: { tools: ToolCall[] }) {
  if (!tools || tools.length === 0) return null;
  
  return (
    <div className="mt-3 flex flex-col gap-2 w-full max-w-sm font-mono text-xs">
      {tools.map(tool => (
        <div key={tool.id} className="bg-[#111] border border-[#222] rounded-lg overflow-hidden relative shadow-lg shadow-black/50">
           <div className="absolute top-0 left-0 bottom-0 w-0.5 bg-indigo-500/50" />
           <div className="p-2 flex items-center justify-between border-b border-[#222] bg-[#161616]">
             <div className="flex items-center gap-2">
               {tool.status === 'running' && <Loader2 className="w-3 h-3 text-indigo-400 animate-spin" />}
               {tool.status === 'success' && <div className="w-3 h-3 rounded-full bg-emerald-500 flex items-center justify-center shrink-0"><Check className="w-2 h-2 text-black" /></div>}
               {tool.status === 'pending' && <div className="w-3 h-3 rounded-full border border-gray-600" />}
               <span className={`${tool.status === 'success' ? 'text-gray-300' : 'text-gray-400'} font-semibold truncate`}>{tool.name}</span>
             </div>
             {tool.status === 'running' && <span className="text-[9px] text-indigo-400 animate-pulse uppercase">Execute</span>}
             {tool.status === 'success' && <span className="text-[9px] text-emerald-500 uppercase flex items-center gap-1"><Check className="w-2 h-2" /> Locked</span>}
           </div>
           
           <AnimatePresence>
             {tool.logs.length > 0 && (
               <motion.div 
                 initial={{ height: 0, opacity: 0 }}
                 animate={{ height: 'auto', opacity: 1 }}
                 className="p-2 bg-black/50 text-gray-500 whitespace-pre-wrap leading-relaxed border-t border-[#333] max-h-32 overflow-y-auto"
               >
                 {tool.logs.map((log, idx) => (
                   <div key={idx} className="flex gap-2">
                     <GitCommit className="w-3 h-3 text-[#333] shrink-0 mt-0.5" />
                     <span className="truncate">{log}</span>
                   </div>
                 ))}
               </motion.div>
             )}
           </AnimatePresence>
        </div>
      ))}
    </div>
  );
}

function OmniStrikeHUD({ command }: { command: string }) {
  const [executionQueue, setExecutionQueue] = useState<any[]>([]);

  useEffect(() => {
     if (!command) return;

     const handleUpdate = (data: any) => {
        setExecutionQueue((prev) => {
           const newQueue = [...prev];
           const existingIdx = newQueue.findIndex(item => item.target === data.target && item.status !== 'LOCKED');
           if (existingIdx > -1) {
              newQueue[existingIdx] = data;
           } else {
              newQueue.push(data);
           }
           return newQueue;
        });

        if (data.status === 'LOCKED' || data.status === 'FRICTION_DETECTED') {
           // Optional: Trigger temporal vault storage visually or via fetch
           // Handled inside SSE
        }
     };

     socket.on('kinetic-update', handleUpdate);
     
     const eventSource = new EventSource(`/api/armada/omni-strike-stream?command=${encodeURIComponent(command)}&vectorType=CODE_GENERATION`);
     
     eventSource.onmessage = (event) => {
        const data = JSON.parse(event.data);
        handleUpdate(data);

        if (data.status === 'LOCKED' || data.status === 'FRICTION_DETECTED') {
           eventSource.close();
           fetch('https://god-mode-os-d3mn-production.up.railway.app/api/armada/vault-temporal', {
             method: 'POST',
             headers: { 'Content-Type': 'application/json' },
             body: JSON.stringify({ intelligencePayload: data.payload, category: 'Omni align Execution', transits: {} })
           });
        }
     };

     return () => {
         eventSource.close();
         socket.off('kinetic-update', handleUpdate);
     };
  }, [command]);

  if (executionQueue.length === 0) return null;

  return (
    <div className="mt-3 p-3 bg-black border border-[#333] rounded-xl font-mono text-xs w-full max-w-md shadow-2xl relative overflow-hidden">
       <div className="absolute top-0 right-0 p-2 opacity-5"><Zap className="w-24 h-24 text-emerald-500" /></div>
       <div className="uppercase tracking-wider text-gray-500 font-semibold mb-3 flex items-center gap-2 border-b border-[#222] pb-2 relative z-10">
         <Network className="w-4 h-4 text-emerald-500" /> Omni-align Matrix
       </div>
       <div className="flex flex-col gap-2 relative z-10">
         {executionQueue.map((task, idx) => (
            <div key={idx} className="flex gap-3 items-start bg-[#111] p-2 rounded border border-[#222]">
               <div className="shrink-0 mt-0.5">
                  {task.status === 'INGESTING' && <Loader2 className="w-3 h-3 text-blue-400 animate-spin" />}
                  {task.status === 'EXECUTING' && <Loader2 className="w-3 h-3 text-amber-500 animate-spin" />}
                  {task.status === 'SYNTHESIZING' && <Orbit className="w-3 h-3 text-purple-400 animate-spin-slow" />}
                  {task.status === 'LOCKED' && <Check className="w-3 h-3 text-emerald-500" />}
                  {task.status === 'FRICTION_DETECTED' && <ShieldAlert className="w-3 h-3 text-red-500" />}
               </div>
               <div className="flex flex-col gap-1 w-full overflow-hidden">
                  <div className="flex justify-between items-center w-full">
                     <span className={`font-semibold truncate ${task.status === 'LOCKED' ? 'text-emerald-500' : 'text-gray-300'}`}>[{task.target}]</span>
                     <span className="text-[9px] uppercase tracking-wider text-gray-500">{task.status}</span>
                  </div>
                  <span className="text-gray-400 leading-relaxed max-w-[280px] break-words">
                     {filterStreamContent(task.payload || task.message)}
                  </span>
               </div>
            </div>
         ))}
       </div>
    </div>
  );
}

export default function QuantumChat() {
  const activeNode = usePrimeStore(state => state.activeNode);
  const setActiveNode = usePrimeStore(state => state.setActiveNode);
  const activeProvider = usePrimeStore(state => state.activeProvider);
  const setActiveProvider = usePrimeStore(state => state.setActiveProvider);
  const activeModelString = usePrimeStore(state => state.activeModelString);
  const setActiveModelString = usePrimeStore(state => state.setActiveModelString);
  const projectFiles = usePrimeStore(state => state.projectFiles);
  const setProjectFiles = usePrimeStore(state => state.setProjectFiles);
  
  const [modelDropdownOpen, setModelDropdownOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isComputing, setIsComputing] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [loadingOlder, setLoadingOlder] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState(() => 'session-' + Date.now());
  const [useTaxonomy, setUseTaxonomy] = useState(false);
  const [attachedFiles, setAttachedFiles] = useState<AttachedFile[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<BlobPart[]>([]);
  const endRef = useRef<HTMLDivElement>(null);

  // File Ingestion and Workspace Explorer State Setup
  const [sidebarTab, setSidebarTab] = useState<'orbits' | 'forge'>('orbits');
  const [ingestLoading, setIngestLoading] = useState<string | null>(null);
  const [ingestFileStatus, setIngestFileStatus] = useState<string | null>(null);
  const ingestFileInputRef = useRef<HTMLInputElement>(null);

  // Trigger file ingestion inside memories database
  const ingestWorkspaceFile = async (filePath: string, content: string) => {
    setIngestLoading(filePath);
    setIngestFileStatus(`Slicin chunks for ${filePath}...`);
    try {
      const res = await fetch('https://god-mode-os-d3mn-production.up.railway.app/api/armada/ingest-file', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filePath, content })
      });
      if (res.ok) {
        const data = await res.json();
        setIngestFileStatus(`Indexed ${data.chunkCount} chunks inside vault!`);
        setTimeout(() => {
          setIngestFileStatus(null);
          setIngestLoading(null);
        }, 3000);
      } else {
        setIngestFileStatus("Error ingestin file");
        setTimeout(() => setIngestLoading(null), 3000);
      }
    } catch (e: any) {
      setIngestFileStatus("Network error: " + e.message);
      setTimeout(() => setIngestLoading(null), 3000);
    }
  };

  // Process standard external file drop/upload and ingest into the SQLite memory matrix
  const handleDeviceFileIngestion = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    
    const file = files[0];
    setIngestLoading(file.name);
    setIngestFileStatus(`Readin ${file.name}...`);
    
    const reader = new FileReader();
    reader.onload = async (event) => {
      const fileContent = event.target?.result as string;
      await ingestWorkspaceFile(file.name, fileContent);
    };
    reader.readAsText(file);
    if (ingestFileInputRef.current) {
      ingestFileInputRef.current.value = '';
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    Array.from(files).forEach(file => {
        const reader = new FileReader();
        reader.onload = (event) => {
            if (event.target?.result) {
                setAttachedFiles(prev => [...prev, {
                    name: file.name,
                    type: file.type,
                    base64: event.target!.result as string
                }]);
            }
        };
        reader.readAsDataURL(file);
    });
    // Reset file input so same file can be selected again
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleCameraUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    Array.from(files).forEach(file => {
        const reader = new FileReader();
        reader.onload = (event) => {
            if (event.target?.result) {
                setAttachedFiles(prev => [...prev, {
                    name: 'Camera_Capture_' + Date.now() + '.jpg',
                    type: file.type,
                    base64: event.target!.result as string
                }]);
            }
        };
        reader.readAsDataURL(file);
    });
    if (cameraInputRef.current) {
      cameraInputRef.current.value = '';
    }
  };

  const toggleRecording = async () => {
    if (isRecording) {
      if (mediaRecorderRef.current) {
         mediaRecorderRef.current.stop();
      }
      setIsRecording(false);
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];
      mediaRecorder.ondataavailable = (event) => {
         if (event.data.size > 0) {
             audioChunksRef.current.push(event.data);
         }
      };
      mediaRecorder.onstop = () => {
         const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
         const reader = new FileReader();
         reader.readAsDataURL(audioBlob);
         reader.onloadend = () => {
             const base64data = reader.result as string;
             setAttachedFiles(prev => [...prev, { 
                name: 'VoiceNote_' + Date.now() + '.webm', 
                size: audioBlob.size, 
                type: 'audio/webm', 
                base64: base64data 
             }]);
         };
         stream.getTracks().forEach(t => t.stop());
      };
      mediaRecorder.start();
      setIsRecording(true);
    } catch (e) {
      console.error("Mic access denied or error:", e);
      alert("Microphone access is required for voice input.");
    }
  };

  const removeFile = (index: number) => {
    setAttachedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const loadSessions = async () => {
    try {
      // First try to fetch from Firebase for cross-platform continuity
      const fmSessions = await getChatSessions();
      if (fmSessions && fmSessions.length > 0) {
        setSessions(fmSessions as ChatSession[]);
        return;
      }
      
      // Fallback
      const res = await fetch('https://god-mode-os-d3mn-production.up.railway.app/api/chats').catch(() => null);
      if (!res || !res.ok) return;
      const data = await res.json().catch(() => []);
      if (data && data.length > 0) {
         setSessions(data);
      }
    } catch (e) {
      console.error('Failed to load sessions', e);
    }
  };

  const loadOlderMessages = async (sessionId: string, reset = false) => {
    if ((!hasMore && !reset) || loadingOlder) return;
    setLoadingOlder(true);

    const oldestTimestamp = reset ? new Date().toISOString() : (messages[0]?.timestamp || new Date().toISOString());
    try {
      // Try fetching from Firebase
      const fmMessages = await getChatMessages(sessionId);
      if (fmMessages && fmMessages.length > 0) {
        setMessages(fmMessages);
        setHasMore(false);
        return;
      }

      // Fallback
      const res = await fetch(`https://god-mode-os-d3mn-production.up.railway.app/api/chats/${encodeURIComponent(sessionId)}/messages?limit=15&beforeTimestamp=${encodeURIComponent(oldestTimestamp)}`)
          .catch(() => null);
          
      if (!res || !res.ok) {
          setHasMore(false);
          return;
      }
      
      const olderMsgs = await res.json().catch(() => []);
      
      if (!olderMsgs || olderMsgs.length < 15) setHasMore(false);
      if (!olderMsgs) return;
      
      const formatted = olderMsgs.map((msg: any) => ({
        id: msg.id,
        role: msg.role === 'model' || msg.role === 'armada' ? 'armada' : msg.role,
        content: msg.content,
        timestamp: msg.timestamp
      }));
      
      if (reset) {
         setMessages(formatted.reverse());
      } else {
         setMessages(prev => [...formatted.reverse(), ...prev]);
      }
    } catch (e) {
      console.error("Failed to load older messages", e);
    } finally {
      setLoadingOlder(false);
    }
  };

  useEffect(() => {
    loadSessions();
    loadOlderMessages(currentSessionId, true);
  }, [currentSessionId]);

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const target = e.target as HTMLDivElement;
    if (target.scrollTop === 0 && hasMore) {
      loadOlderMessages(currentSessionId);
    }
  };

  useEffect(() => {
    if (messages.length <= 15) {
      endRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    let intent: 'strategy' | 'code' | 'build' | 'deploy' = 'strategy';
    const lowerInput = input.toLowerCase();
    if (lowerInput.includes('code') || lowerInput.includes('react') || lowerInput.includes('script') || lowerInput.includes('unity')) intent = 'code';
    if (lowerInput.includes('build') || lowerInput.includes('compile') || lowerInput.includes('sandbox')) intent = 'build';
    if (lowerInput.includes('deploy') || lowerInput.includes('publish')) intent = 'deploy';

    const finalInput = useTaxonomy 
      ? `[OMNI-TAXONOMY DIRECTIVE ACTIVE: Explain/Respond to the following according to the 4-layer taxonomy (Laymen, Physics, Quantum, OS)]\n${input}` 
      : input;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: finalInput,
      timestamp: new Date().toISOString(),
      intent,
      attachedFiles: attachedFiles.length > 0 ? attachedFiles : undefined
    };

    setMessages(prev => {
      const newMsgs = [...prev, userMsg];
      syncChatSession(currentSessionId, newMsgs);
      return newMsgs;
    });
    setInput('');
    setAttachedFiles([]);
    setIsComputing(true);

    const { activeNode, activeProvider, activeModelString, openRouterApiKey } = usePrimeStore.getState();

    try {
      if (intent === 'code' || intent === 'build' || intent === 'deploy') {
         socket.emit('omni-strike', input);
      }
      const fetchWithRetry = async (url: string, options: any, retries = 3): Promise<Response> => {
        for (let i = 0; i < retries; i++) {
          try {
             const res = await fetch(url, options);
             if (res.ok) return res;
             if (i === retries - 1) return res;
          } catch(e) {
             if (i === retries - 1) throw e;
          }
          await new Promise(r => setTimeout(r, 1000 * (i + 1))); // exponential backoff
        }
        throw new Error("Unreachable");
      };

      const response = await fetchWithRetry('https://god-mode-os-d3mn-production.up.railway.app/api/armada/chat', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'x-session-id': currentSessionId
        },
        body: JSON.stringify({ 
          messages: [...messages, userMsg],
          targetNode: activeNode,
          intent,
          provider: activeProvider.id,
          modelString: activeModelString,
          openRouterApiKey: activeProvider.id === 'openrouter' ? openRouterApiKey : undefined
        })
      });

      if (!response || !response.ok) {
         const errText = response ? await response.text() : "Network error";
         console.error("Daemon returned unhandled error:", response?.status, errText);
         throw new Error(`Daemon unreachable: ${response?.status} - ${errText}`);
      }

      const data = await response.json();
      
      const armadaMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'armada',
        content: data.response || data.error || 'Connection failed.',
        nodeUsed: data.node,
        timestamp: data.timestamp || new Date().toISOString(),
        toolCalls: data.toolCalls
      };

      setMessages(prev => {
        const newMsgs = [...prev, armadaMsg];
        syncChatSession(currentSessionId, newMsgs);
        return newMsgs;
      });
    } catch (e) {
      console.error(e);
      setMessages(prev => {
        const newMsgs = [...prev, {
          id: Date.now().toString(),
          role: 'system' as const,
          content: 'There was an error communicating with the daemon at the specified URL.',
          timestamp: new Date().toISOString()
        }];
        syncChatSession(currentSessionId, newMsgs);
        return newMsgs;
      });
    } finally {
      setIsComputing(false);
    }
  };

  return (
    <div className="flex h-full w-full mx-auto overflow-hidden relative">
      {/* Sidebar */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            initial={{ width: 0, opacity: 0 }}
            animate={{ width: 280, opacity: 1 }}
            exit={{ width: 0, opacity: 0 }}
            className="h-full bg-[#0a0a0a] border-r border-[#1a1a1a] flex flex-col shrink-0 overflow-hidden"
          >
            {/* Sidebar Tabs */}
            <div className="flex border-b border-[#1a1a1a] text-[10px] font-mono tracking-wider shrink-0 bg-[#070707]">
              <button 
                onClick={() => setSidebarTab('orbits')}
                className={`flex-1 py-3 text-center uppercase border-b-2 font-semibold transition-all ${sidebarTab === 'orbits' ? 'border-blue-500 text-blue-400 bg-[#0c0c0c]' : 'border-transparent text-gray-500 hover:text-gray-300'}`}
              >
                Orbits
              </button>
              <button 
                onClick={() => setSidebarTab('forge')}
                className={`flex-1 py-3 text-center uppercase border-b-2 font-semibold transition-all ${sidebarTab === 'forge' ? 'border-purple-500 text-purple-400 bg-[#0c0c0c]' : 'border-transparent text-gray-500 hover:text-gray-300'}`}
              >
                Forge FS
              </button>
            </div>

            {sidebarTab === 'orbits' ? (
              <>
                <div className="p-4 border-b border-[#1a1a1a] shrink-0">
                  <button 
                    onClick={() => {
                       setCurrentSessionId('session-' + Date.now());
                       setMessages([]);
                       loadSessions();
                       if (window.innerWidth < 768) setSidebarOpen(false);
                    }}
                    className="w-full flex items-center justify-between gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg transition-colors"
                  >
                    <span className="font-semibold text-sm tracking-wide flex items-center gap-2">
                      <Plus className="w-4 h-4" /> New Vector
                    </span>
                  </button>
                </div>
                <div className="flex-1 overflow-y-auto p-2">
                  <div className="text-xs uppercase tracking-widest text-gray-500 font-semibold mb-2 px-2">Archived Orbits</div>
                   {sessions.map(s => (
                      <button
                        key={s.id}
                        onClick={() => {
                            setCurrentSessionId(s.id);
                            if (window.innerWidth < 768) setSidebarOpen(false);
                        }}
                        className={`w-full text-left p-2 rounded-lg flex items-start gap-2 transition-colors ${currentSessionId === s.id ? 'bg-[#222] text-white' : 'text-gray-400 hover:bg-[#1a1a1a]'}`}
                      >
                         <MessageSquare className="w-4 h-4 mt-1 shrink-0" />
                         <div className="flex flex-col truncate w-full">
                            <span className="text-sm truncate">{s.title}</span>
                            <span className="text-[10px] text-gray-600">{new Date(s.updatedAt).toLocaleDateString()}</span>
                         </div>
                      </button>
                   ))}
                </div>
              </>
            ) : (
              <div className="flex-1 flex flex-col overflow-hidden p-3 gap-3">
                <div className="text-[10px] uppercase tracking-widest text-purple-400 font-bold px-1 font-mono">WORKSPACE FILES</div>
                
                {/* File Tree View */}
                <div className="flex-1 overflow-y-auto space-y-1.5 pr-1 custom-scrollbar">
                  {Object.keys(projectFiles).map((filePath) => (
                    <div 
                      key={filePath}
                      className="group/file p-2 bg-[#111]/80 hover:bg-[#161616] border border-[#222] rounded-lg flex flex-col gap-2 transition-all"
                    >
                      <div className="flex justify-between items-center gap-2">
                        <span className="text-xs font-mono text-gray-300 truncate font-semibold" title={filePath}>
                          {filePath}
                        </span>
                        <Code2 className="w-3.5 h-3.5 text-purple-400 shrink-0 opacity-60" />
                      </div>
                      
                      <div className="flex items-center gap-1.5">
                        <button 
                          onClick={() => {
                            setInput(prev => prev + `\n\n[File Reference ${filePath}]:\n\`\`\`\n${projectFiles[filePath]}\n\`\`\`\n`);
                            if (window.innerWidth < 768) setSidebarOpen(false);
                          }}
                          className="flex-1 text-center py-1 bg-[#1c1c1c] hover:bg-[#252525] border border-[#333] text-[9px] font-mono font-semibold uppercase tracking-wider text-indigo-400 hover:text-indigo-300 rounded transition-colors cursor-pointer"
                          title="Append file contents inside active Chat prompt"
                        >
                          Ref
                        </button>
                        <button 
                          onClick={() => ingestWorkspaceFile(filePath, projectFiles[filePath])}
                          className="flex-1 text-center py-1 bg-purple-900/30 hover:bg-purple-900/60 border border-purple-500/30 hover:border-purple-500/60 text-[9px] font-mono font-semibold uppercase tracking-wider text-purple-300 rounded transition-all cursor-pointer"
                          title="Chunk & ingest file inside local memory vault"
                          disabled={ingestLoading !== null}
                        >
                          Vault
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                {/* File Ingestion System Zone */}
                <div className="border-t border-[#1a1a1a] pt-3 shrink-0 flex flex-col gap-2">
                  <div className="text-[10px] uppercase tracking-widest text-[#555] font-bold px-1 font-mono">INGEST SYSTEM VAULT</div>
                  
                  <input 
                    type="file"
                    ref={ingestFileInputRef}
                    onChange={handleDeviceFileIngestion}
                    className="hidden"
                  />
                  
                  <button
                    onClick={() => ingestFileInputRef.current?.click()}
                    disabled={ingestLoading !== null}
                    className="w-full py-2 bg-gradient-to-r from-purple-950/20 to-indigo-950/20 hover:from-purple-900/30 hover:to-indigo-900/30 border border-dashed border-[#333] hover:border-purple-500/50 rounded-lg text-[10px] font-mono font-bold uppercase tracking-widest text-indigo-300 hover:text-indigo-200 transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    {ingestLoading ? (
                      <Loader2 className="w-3.5 h-3.5 text-indigo-400 animate-spin" />
                    ) : (
                      <Paperclip className="w-3.5 h-3.5" />
                    )}
                    Upload to Memory
                  </button>

                  {ingestFileStatus && (
                    <div className="p-2.5 bg-black border border-[#222] rounded-lg text-[10px] font-mono text-cyan-400 break-words leading-relaxed animate-pulse text-center">
                      {ingestFileStatus}
                    </div>
                  )}
                </div>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex flex-col h-full w-full flex-1 max-w-4xl mx-auto overflow-hidden relative min-h-0">
        {/* Model Selector Header */}
        <div className="flex justify-between items-center py-4 px-4 shrink-0 bg-[#0a0a0a] z-10 w-full overflow-hidden gap-2 border-b border-[#1a1a1a]">
          <div className="flex items-center gap-3">
            <button onClick={() => setSidebarOpen(!sidebarOpen)} className="p-2 text-gray-400 hover:text-white rounded-lg hover:bg-[#222] transition-colors shrink-0 flex items-center gap-2">
               <Menu className="w-5 h-5" />
               <span className="font-semibold text-sm tracking-widest uppercase md:hidden text-gray-500">History</span>
            </button>
            
            {/* Visual Daemon Status Indicator */}
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-full border bg-black border-[#222] text-[10px] font-mono select-none">
              {isComputing ? (
                <>
                  <span className="w-2 h-2 rounded-full bg-amber-500 animate-ping inline-block" />
                  <span className="text-amber-400 font-bold uppercase tracking-widest animate-pulse">DAEMON COGNITION ACTIVE</span>
                </>
              ) : ingestLoading ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 text-indigo-400 animate-spin" />
                  <span className="text-indigo-400 font-bold uppercase tracking-widest">INGESTIN: {ingestLoading}</span>
                </>
              ) : (
                <>
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse inline-block" />
                  <span className="text-emerald-400 uppercase tracking-widest">DAEMON STATE: ALIGNED</span>
                </>
              )}
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-6 pb-6 min-h-0" onScroll={handleScroll}>
        {loadingOlder && (
          <div className="text-center py-2 text-xs text-gray-500 font-mono animate-pulse">Loading older vectors...</div>
        )}
        {messages.map((msg, i) => (
          <motion.div 
            initial={{ opacity: 0, y: 10, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.3, ease: 'easeOut' }}
            key={msg.id} 
            className={`flex gap-4 max-w-3xl group ${msg.role === 'user' ? 'ml-auto flex-row-reverse' : 'mr-auto'}`}
          >
            <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 mt-1 ${msg.role === 'user' ? 'bg-blue-600' : 'bg-gray-800'}`}>
              {msg.role === 'user' ? <User className="w-5 h-5 text-white" /> : <Bot className="w-5 h-5 text-gray-200" />}
            </div>
            
            <div className={`flex flex-col relative ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
              {msg.role === 'armada' && msg.nodeUsed && (
                <div className="flex items-center gap-2 mb-1">
                  <div className="text-xs text-gray-500 font-medium">{msg.nodeUsed} Model</div>
                </div>
              )}
              {msg.role === 'user' && msg.intent && (
                <div className="mb-2">
                  <IntentBadge intent={msg.intent} />
                </div>
              )}
              <div className="flex flex-col gap-1 max-w-full">
                {msg.toolCalls && msg.toolCalls.length > 0 && msg.role === 'armada' && (
                  <KineticExecutionHUD tools={msg.toolCalls} />
                )}
                {msg.role === 'user' && msg.intent === 'deploy' && (
                  <OmniStrikeHUD command={msg.content} />
                )}
                {/* Render mediaUrls if present */}
                {msg.mediaUrls && msg.mediaUrls.map((url, mediaIdx) => (
                   <div key={mediaIdx} className="mb-3 rounded-xl overflow-hidden border border-[#333] inline-block">
                      {url.startsWith('data:video') || url.endsWith('.mp4') ? (
                         <video src={url} controls className="max-w-full max-h-80 object-contain bg-black" />
                      ) : (
                         <img src={url} alt="Generated Media" className="max-w-full max-h-80 object-contain bg-black" />
                      )}
                      {url.startsWith('data:image') && (
                        <div className="bg-[#111] p-2 flex justify-end border-t border-[#333]">
                          <motion.a 
                            initial={{ scale: 0.9, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            transition={{ type: "spring", stiffness: 400, damping: 10 }}
                            href={url} 
                            download="Generated_Construct.png" 
                            className="text-xs text-cyan-300 font-semibold px-4 py-1.5 bg-cyan-900/40 border border-cyan-500/50 rounded shadow-[0_0_8px_rgba(34,211,238,0.3)] hover:bg-cyan-800/60 hover:shadow-[0_0_12px_rgba(34,211,238,0.5)] transition-all flex items-center gap-2"
                          >
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                            Save to Device
                          </motion.a>
                        </div>
                      )}
                   </div>
                ))}
                {msg.attachedFiles && msg.attachedFiles.length > 0 && (
                  <div className="flex flex-wrap gap-2 mb-2 justify-end">
                    {msg.attachedFiles.map((f, i) => (
                      <div key={i} className="flex gap-2 p-2 bg-[#222] border border-[#333] rounded-lg items-center">
                        {f.type.startsWith('image/') ? (
                          <img src={f.base64} alt={f.name} className="w-10 h-10 object-cover rounded bg-black" />
                        ) : (
                          <Paperclip className="w-5 h-5 text-gray-400" />
                        )}
                        <span className="text-[10px] text-gray-300 font-mono truncate max-w-[120px]">{f.name}</span>
                      </div>
                    ))}
                  </div>
                )}
                <div className={`px-5 py-3.5 rounded-2xl text-[15px] leading-relaxed max-w-full overflow-hidden ${
                  msg.role === 'user' 
                    ? 'bg-[#262626] text-white rounded-tr-sm' 
                    : 'text-gray-100 bg-transparent'
                }`} style={{ wordWrap: 'break-word', whiteSpace: 'pre-wrap' }}>
                  {msg.role === 'armada' && msg.content.includes('new CANNON.Body') ? (
                    <div className="flex flex-col gap-4">
                       <div className="break-words max-w-full whitespace-pre-wrap">{msg.content}</div>
                       <SpatialSandbox codePayload={extractCodeBlock(msg.content)} />
                    </div>
                  ) : msg.content.includes('\`\`\`html') && msg.role === 'armada' ? (
                    <div className="flex flex-col gap-4 w-full">
                       <span className="break-words max-w-full whitespace-pre-wrap leading-relaxed">{msg.content.split('\`\`\`html')[0]}</span>
                       <div className="border border-purple-500/50 shadow-[0_0_30px_rgba(168,85,247,0.3)] rounded-xl overflow-hidden bg-black h-[600px] w-full relative group">
                          <div className="absolute top-0 left-0 w-full bg-gradient-to-r from-purple-900/60 to-cyan-900/60 backdrop-blur-md text-white text-[10px] font-mono p-2 flex justify-between items-center z-10 border-b border-purple-500/30">
                             <div className="flex items-center gap-2 uppercase tracking-[0.2em] font-bold">
                                <Orbit className="w-4 h-4 text-cyan-400 animate-spin" style={{ animationDuration: '3s' }} />
                                Omni-Compiler: Digital Construct Manifested
                             </div>
                             <div className="flex gap-2">
                                <button 
                                  onClick={() => {
                                     const content = msg.content.split('\`\`\`html')[1]?.split('\`\`\`')[0] || '';
                                     const blob = new Blob([content], { type: 'text/html' });
                                     const url = URL.createObjectURL(blob);
                                     const a = document.createElement('a');
                                     a.href = url;
                                     a.download = `app_${Date.now()}.html`;
                                     a.click();
                                     URL.revokeObjectURL(url);
                                  }}
                                  className="bg-purple-600/50 hover:bg-purple-500 px-2 py-0.5 rounded border border-purple-500/50 text-white cursor-pointer transition-colors"
                                >DOWNLOAD ARTIFACT</button>
                                <span className="bg-black/50 px-2 py-0.5 rounded border border-purple-500/30 text-purple-300 hidden sm:inline-block">SANDBOX: ACTIVE</span>
                                <span className="bg-black/50 px-2 py-0.5 rounded border border-cyan-500/30 text-cyan-300 hidden sm:inline-block">GPU: ALLOCATED</span>
                             </div>
                          </div>
                          <iframe 
                             title="Live Preview" 
                             srcDoc={msg.content.split('\`\`\`html')[1]?.split('\`\`\`')[0] || ''} 
                             className="w-full h-full pt-10"
                             sandbox="allow-scripts allow-same-origin allow-popups"
                          />
                       </div>
                       <span className="break-words max-w-full whitespace-pre-wrap leading-relaxed">{msg.content.split('\`\`\`html')[1]?.split('\`\`\`').slice(1).join('\`\`\`')}</span>
                    </div>
                  ) : msg.content.includes('```html') && msg.role === 'armada' ? (
                    <div className="flex flex-col gap-4 w-full">
                       <span className="break-words max-w-full whitespace-pre-wrap leading-relaxed">{msg.content.split('```html')[0]}</span>
                       <div className="border border-purple-500/50 shadow-[0_0_30px_rgba(168,85,247,0.3)] rounded-xl overflow-hidden bg-black h-[600px] w-full relative group">
                          <div className="absolute top-0 left-0 w-full bg-gradient-to-r from-purple-900/60 to-cyan-900/60 backdrop-blur-md text-white text-[10px] font-mono p-2 flex justify-between items-center z-10 border-b border-purple-500/30">
                             <div className="flex items-center gap-2 uppercase tracking-[0.2em] font-bold">
                                <Orbit className="w-4 h-4 text-cyan-400 animate-spin" style={{ animationDuration: '3s' }} />
                                Omni-Compiler: Digital Construct Manifested
                             </div>
                             <div className="flex gap-2">
                                <button 
                                  onClick={() => {
                                     const content = msg.content.split('```html')[1]?.split('```')[0] || '';
                                     const blob = new Blob([content], { type: 'text/html' });
                                     const url = URL.createObjectURL(blob);
                                     const a = document.createElement('a');
                                     a.href = url;
                                     a.download = `app_${Date.now()}.html`;
                                     a.click();
                                     URL.revokeObjectURL(url);
                                  }}
                                  className="bg-purple-600/50 hover:bg-purple-500 px-2 py-0.5 rounded border border-purple-500/50 text-white cursor-pointer transition-colors"
                                >DOWNLOAD ARTIFACT</button>
                                <span className="bg-black/50 px-2 py-0.5 rounded border border-purple-500/30 text-purple-300 hidden sm:inline-block">SANDBOX: ACTIVE</span>
                                <span className="bg-black/50 px-2 py-0.5 rounded border border-cyan-500/30 text-cyan-300 hidden sm:inline-block">GPU: ALLOCATED</span>
                             </div>
                          </div>
                          <iframe 
                             title="Live Preview" 
                             srcDoc={msg.content.split('```html')[1]?.split('```')[0] || ''} 
                             className="w-full h-full pt-10"
                             sandbox="allow-scripts allow-same-origin allow-popups"
                          />
                       </div>
                       <span className="break-words max-w-full whitespace-pre-wrap leading-relaxed">{msg.content.split('```html')[1]?.split('```').slice(1).join('```')}</span>
                    </div>
                  ) : (
                    <div className="break-words max-w-full">{msg.content}</div>
                  )}
                </div>
                <div className={`flex items-center gap-2 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <CopyButton text={msg.content} showLabel={true} />
                  
                  {msg.role === 'armada' && msg.content.includes('```') && (
                    <button
                      onClick={() => {
                        const code = extractCodeBlock(msg.content);
                        setProjectFiles(prev => ({
                          ...prev,
                          '/App.tsx': code
                        }));
                        setIngestFileStatus && setIngestFileStatus("Successfully synched code back to Forge Sandbox!");
                        setTimeout(() => setIngestFileStatus && setIngestFileStatus(null), 3000);
                      }}
                      className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs text-indigo-400 bg-indigo-900/20 border border-indigo-500/30 hover:bg-indigo-900/40 hover:text-indigo-300 rounded-md transition-all cursor-pointer font-mono"
                      title="Sync Code Block directly to /App.tsx inside Forge Studio"
                    >
                      <Code2 className="w-3.5 h-3.5" />
                      <span>Sync to Forge</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          </motion.div>
        ))}
        {isComputing && (
          <motion.div 
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex gap-4 max-w-3xl mr-auto"
          >
            <div className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center flex-shrink-0 animate-pulse">
              <Sparkles className="w-4 h-4 text-gray-400" />
            </div>
            <div className="px-5 py-3 text-gray-400 italic">Thinking...</div>
          </motion.div>
        )}
        <div ref={endRef} />
      </div>

      {/* Input Area */}
      <div className="p-4 bg-[#0a0a0a] border-t border-[#1a1a1a] shrink-0 w-full pb-safe z-10">
        <div className="max-w-4xl mx-auto relative w-full">
          
          <div className="mb-2 flex items-center justify-between relative">
            <div className="flex items-center">
              <button 
                onClick={() => setModelDropdownOpen(!modelDropdownOpen)}
                className="flex items-center gap-1.5 text-xs text-gray-400 font-mono hover:text-gray-200 transition-colors bg-[#111] border border-[#222] px-2 py-1 rounded-md"
              >
                 <span>{activeProvider.name}</span>
                 {activeModelString && <span className="text-gray-500">[{activeModelString}]</span>}
                 <ChevronDown className="w-3 h-3" />
              </button>
              <AnimatePresence>
                {modelDropdownOpen && (
                   <motion.div 
                     initial={{ opacity: 0, y: 5 }}
                     animate={{ opacity: 1, y: 0 }}
                     exit={{ opacity: 0, y: 5 }}
                     className="absolute bottom-full left-0 mb-1 w-64 bg-[#1a1a1a] border border-[#333] rounded-lg shadow-xl z-50 overflow-hidden max-h-64 overflow-y-auto"
                   >
                      {PROVIDERS.map(p => (
                         <div key={p.id} className="border-b border-[#222] last:border-0">
                            <button 
                               className={`w-full text-left px-3 py-2 text-xs font-mono transition-colors flex flex-col hover:bg-[#222] ${activeProvider.id === p.id ? 'text-indigo-400' : 'text-gray-400'}`}
                               onClick={() => { setActiveProvider(p); setModelDropdownOpen(false); }}
                            >
                               <div className="flex items-center justify-between w-full">
                                  <span>{p.name}</span>
                                  {activeProvider.id === p.id && <Check className="w-3 h-3" />}
                               </div>
                               {p.endpoint && <span className="text-[9px] text-gray-600 block mt-0.5">{p.endpoint}</span>}
                            </button>
                            {activeProvider.id === p.id && p.models && (
                               <div className="bg-[#111] px-2 py-1 flex flex-wrap gap-1">
                                  {p.models.map(m => (
                                     <button 
                                        key={m}
                                        onClick={() => { setActiveModelString(m); setModelDropdownOpen(false); }}
                                        className={`text-[9px] px-1.5 py-0.5 rounded border ${activeModelString === m ? 'bg-indigo-900 border-indigo-500 text-indigo-200' : 'bg-[#222] border-[#333] text-gray-500 hover:text-gray-300'}`}
                                     >
                                        {m}
                                     </button>
                                  ))}
                               </div>
                            )}
                         </div>
                      ))}
                   </motion.div>
                )}
              </AnimatePresence>
              
              <button 
                onClick={() => setUseTaxonomy(!useTaxonomy)}
                className={`ml-2 flex items-center gap-1.5 text-[10px] font-mono transition-colors border px-2 py-1 rounded-md uppercase tracking-widest ${useTaxonomy ? 'bg-purple-900/40 text-purple-400 border-purple-500/50 shadow-[0_0_10px_rgba(168,85,247,0.3)]' : 'bg-[#111] text-gray-500 border-[#222] hover:text-gray-400 hover:border-[#333]'}`}
                title="Force 4-Layer Taxonomy Response"
              >
                 <Orbit className={`w-3 h-3 ${useTaxonomy ? 'animate-spin-slow' : ''}`} />
                 Omni-Taxonomy Force
              </button>
            </div>
            
            <div className="text-[10px] font-mono text-cyan-500/70 border border-cyan-900/30 bg-cyan-900/10 px-2 py-1 rounded uppercase tracking-[0.2em] animate-pulse">
                Omni-Compiler Target: Ready
            </div>
          </div>

          <div className="bg-[#1a1a1a] rounded-2xl border border-[#333] shadow-lg flex flex-col p-2 focus-within:border-blue-500/50 transition-colors">
            {attachedFiles.length > 0 && (
              <div className="flex flex-wrap gap-2 px-3 pt-2 pb-1">
                {attachedFiles.map((f, i) => (
                  <div key={i} className="flex items-center gap-2 bg-[#222] border border-[#333] rounded-lg p-1.5 relative group">
                    {f.type.startsWith('image/') ? (
                      <img src={f.base64} alt={f.name} className="w-8 h-8 object-cover rounded bg-black" />
                    ) : (
                      <Paperclip className="w-4 h-4 text-gray-400 ml-1" />
                    )}
                    <span className="text-[10px] text-gray-300 font-mono truncate max-w-[100px]">{f.name}</span>
                    <button 
                      onClick={() => removeFile(i)}
                      className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-red-500 rounded-full text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="w-2.5 h-2.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
            <div className="flex items-end">
              <input 
                type="file" 
                multiple 
                ref={fileInputRef} 
                onChange={handleFileUpload} 
                className="hidden" 
              />
              <button 
                className="text-gray-400 hover:text-white p-3 rounded-xl transition-colors hover:bg-[#333] shrink-0 mb-1" 
                title="Attach Files"
                onClick={() => fileInputRef.current?.click()}
              >
                <Plus className="w-5 h-5" />
              </button>
              <textarea
                className="w-full bg-transparent text-white px-3 py-3 max-h-48 min-h-[56px] focus:outline-none resize-none"
                placeholder="Message your OS..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSend();
                  }
                }}
                rows={input.split('\n').length > 1 ? Math.min(input.split('\n').length, 5) : 1}
              />
              <div className="flex items-center gap-1 mb-1 mr-1">
                <input 
                   type="file" 
                   accept="image/*" 
                   capture="environment" 
                   ref={cameraInputRef} 
                   onChange={handleCameraUpload} 
                   className="hidden" 
                />
                <button 
                  className="text-gray-400 hover:text-white p-2 rounded-xl transition-colors hover:bg-[#333]" 
                  title="Upload Media (Vision)"
                  onClick={() => cameraInputRef.current?.click()}
                >
                  <Camera className="w-5 h-5" />
                </button>
                <button 
                  className={`p-2 rounded-xl transition-colors z-20 hover:bg-[#333] ${isRecording ? 'text-red-500 animate-pulse' : 'text-gray-400 hover:text-white'}`}
                  title="Voice Input (Hearing)"
                  onClick={toggleRecording}
                >
                  <Mic className="w-5 h-5" />
                </button>
                <button
                  onClick={handleSend}
                  disabled={(!input.trim() && attachedFiles.length === 0) || isRecording || isComputing}
                  className="bg-white hover:bg-gray-200 disabled:opacity-50 disabled:bg-gray-700 text-black p-3 rounded-xl transition-colors flex-shrink-0 ml-1"
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
          <div className="text-center text-xs text-gray-500 mt-2 flex justify-center items-center gap-2">
            The AI can make mistakes. Consider verifying important information.
          </div>
        </div>
      </div>
     </div>
    </div>
  );
}
