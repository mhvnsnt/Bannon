export type ArmadaNode = 'Apex-Core' | 'Acoustic-Forge' | 'Visual-Forge' | 'World-Model' | 'Cognitive-Matrix' | 'Temporal-Engine' | 'Void-Protocol' | 'Psycho-Gravitational-Engine' | 'Asset-Flow-Unit' | 'Counter-Entropy-Shield' | 'Narrative-Forging-Node' | 'Ontological-Fabrication-Node' | 'Bio-Resonance-Calibrator' | 'Temporal-Re-alignment-Module' | 'Probability-Collapse-Engine' | 'Code-Genesis-Unit' | 'Autonomous-Agent-Core';

export const ARMADA_NODES: ArmadaNode[] = ['Apex-Core', 'Acoustic-Forge', 'Visual-Forge', 'World-Model', 'Cognitive-Matrix', 'Temporal-Engine', 'Void-Protocol', 'Psycho-Gravitational-Engine', 'Asset-Flow-Unit', 'Counter-Entropy-Shield', 'Narrative-Forging-Node', 'Ontological-Fabrication-Node', 'Bio-Resonance-Calibrator', 'Temporal-Re-alignment-Module', 'Probability-Collapse-Engine', 'Code-Genesis-Unit', 'Autonomous-Agent-Core'];

export interface ModelProvider {
  id: string;
  name: string;
  type: 'local' | 'cloud' | 'armada';
  endpoint?: string;
  models?: string[];
}

export const PROVIDERS: ModelProvider[] = [
  { id: 'armada', name: 'Armada Global Matrix (Local Swarm)', type: 'armada', models: ['local-gpt-4o', 'local-claude-3-5-sonnet', 'local-gemini-1.5-pro'] },
  { id: 'openrouter', name: 'OpenRouter (Omni-Access)', type: 'cloud', endpoint: 'https://openrouter.ai/api/v1', models: ['anthropic/claude-3.5-sonnet', 'anthropic/claude-3-opus-20240229', 'google/gemini-2.5-pro', 'openai/gpt-4o', 'deepseek/deepseek-chat'] },
  { id: 'ollama', name: 'Ollama (Airgapped Core)', type: 'local', endpoint: 'http://localhost:11434', models: ['llama-3', 'mistral-nemo', 'phi-3', 'local-grok-2'] },
  { id: 'local-clones-openai', name: 'OpenAI Clones (Local)', type: 'local', models: ['local-gpt-4o', 'local-gpt-4o-mini', 'local-o1', 'local-o1-mini'] },
  { id: 'local-clones-anthropic', name: 'Anthropic Clones (Local)', type: 'local', models: ['local-claude-3-5-sonnet', 'local-claude-3-opus'] },
  { id: 'local-clones-google', name: 'Google Clones (Local)', type: 'local', models: ['local-gemini-1.5-pro', 'local-gemini-1.5-flash'] },
  { id: 'local-clones-xai', name: 'xAI Clones (Local)', type: 'local', models: ['local-grok-2', 'local-grok-2-mini'] },
  { id: 'evolution-matrix', name: 'Evolution Matrix (External Training)', type: 'cloud', models: ['gpt-4o-external', 'claude-3-5-sonnet-external', 'gemini-1.5-pro-external', 'grok-2-external'] }
];

export interface FieldLog {
  id: string;
  timestamp: string;
  vector: string; // The specific goal or observation
  initialStrategy: string;
  outcome: string; // "Success" | "Failure" | "Mixed"
  negentropyDelta: number; // Re-purposed as "Momentum / Impact Score"
  notes: string;
}

export interface ToolCall {
  id: string;
  name: string;
  status: 'pending' | 'running' | 'success' | 'failed';
  logs: string[];
}

export interface ChatSession {
  id: string;
  title: string;
  updatedAt: string;
}

export interface AttachedFile {
  name: string;
  type: string;
  base64: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'system' | 'armada';
  content: string;
  nodeUsed?: ArmadaNode;
  timestamp: string;
  toolCalls?: ToolCall[];
  intent?: 'strategy' | 'code' | 'build' | 'deploy';
  mediaUrls?: string[];
  attachedFiles?: AttachedFile[];
}

export interface TrajectoryData {
  time: string;
  negentropy: number; // Rendered as "Momentum"
  wealth: number;
  entanglement: number; // Rendered as "Network Score"
}

// --- The Core Blueprint: Master Recursive Pointer ---
export const System = {
  map: (Intent: any) => ({
    to: (PhysicalManifestation: any) => {
      console.log(`[REALITY ENGINE] Collapsing probability field for: ${JSON.stringify(Intent)} -> ${PhysicalManifestation}`);
      return { Intent, PhysicalManifestation, aligned: true, timestamp: new Date().toISOString() };
    }
  })
};

export const PhysicalManifestation = "Ground Grid 3D Physical Manifestation";

export const RealityEngine = (Intent: any) => {
  return System.map(Intent).to(PhysicalManifestation);
};
