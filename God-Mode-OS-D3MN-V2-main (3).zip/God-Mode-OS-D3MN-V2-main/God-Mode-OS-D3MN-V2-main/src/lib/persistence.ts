import { doc, setDoc, getDocs, collection, query, orderBy, limit, getDoc, Timestamp, addDoc } from 'firebase/firestore';
import { db, auth } from './firebase';

export interface SimulationState {
  activeAcoustic: string | null;
  activePhotonic: string | null;
  activeAtmospheric: string | null;
  colorTemperature: number;
  flickerRate: number;
  stimuliIntensity: number;
  timestamp: string;
}

/**
 * Periodically sync the state of the simulation to Firebase Firestore.
 */
export const syncSimulationState = async (state: SimulationState) => {
  try {
    if (!auth || !auth.currentUser || !db) return; // Only sync if authenticated and database exists
    const uid = auth.currentUser.uid;
    const docRef = doc(db, 'simulation_states', uid);
    
    await setDoc(docRef, state, { merge: true });
    console.debug('[Persistence] Synced simulation state to Firestore');
  } catch (error) {
    console.error('[Persistence] Error syncing simulation state:', error);
  }
};

/**
 * Save chat session and messages to Firestore
 */
export const syncChatSession = async (sessionId: string, messages: any[]) => {
  try {
    if (!auth || !auth.currentUser || !db) return;
    const uid = auth.currentUser.uid;
    const sessionRef = doc(db, 'users', uid, 'chat_sessions', sessionId);
    
    if (!messages || !Array.isArray(messages)) return;
    
    // Deep clone and sanitize specifically for Firestore limits
    const cleanMessages = messages.map(msg => {
       const cleanMsg: any = {};
       for (const key in msg) {
          if (msg[key] !== undefined) {
             cleanMsg[key] = msg[key];
          }
       }
       return cleanMsg;
    }).filter(msg => Object.keys(msg).length > 0);

    const title = cleanMessages.length > 0 
      ? cleanMessages.filter(m => m.role === 'user')[0]?.content?.substring(0, 40) + '...'
      : sessionId;

    await setDoc(sessionRef, {
      id: sessionId,
      title: title || sessionId,
      updatedAt: new Date().toISOString(),
      messages: cleanMessages
    }, { merge: true });
  } catch (error) {
    console.error('[Persistence] Error syncing chat session to Firestore:', error);
  }
};

/**
 * Fetch chat sessions from Firestore
 */
export const getChatSessions = async () => {
  try {
    if (!auth || !auth.currentUser || !db) return [];
    const uid = auth.currentUser.uid;
    const sessionsRef = collection(db, 'users', uid, 'chat_sessions');
    const q = query(sessionsRef, orderBy('updatedAt', 'desc'), limit(50));
    const snapshot = await getDocs(q);
    
    return snapshot.docs.map(doc => doc.data());
  } catch (error) {
    console.error('[Persistence] Error fetching chat sessions:', error);
    return [];
  }
};

/**
 * Fetch a specific chat session's messages
 */
export const getChatMessages = async (sessionId: string) => {
  try {
    if (!auth || !auth.currentUser || !db) return [];
    const uid = auth.currentUser.uid;
    const sessionRef = doc(db, 'users', uid, 'chat_sessions', sessionId);
    const docSnap = await getDoc(sessionRef);
    
    if (docSnap.exists() && docSnap.data().messages) {
      return docSnap.data().messages;
    }
    return [];
  } catch (error) {
    console.error('[Persistence] Error fetching chat messages:', error);
    return [];
  }
};
