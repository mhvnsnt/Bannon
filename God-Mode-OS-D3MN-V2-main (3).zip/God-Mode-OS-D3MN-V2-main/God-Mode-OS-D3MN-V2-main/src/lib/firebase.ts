import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getMessaging } from 'firebase/messaging';
import firebaseConfig from '../../firebase-applet-config.json';

let app: any = null;
let db: any = null;
let auth: any = null;
let messaging: any = null;

// True: sandbox mode / fallback, False: real Firebase mode
let offlineMode = false;

try {
  if (firebaseConfig && firebaseConfig.apiKey) {
    app = initializeApp(firebaseConfig);
    db = getFirestore(app);
    auth = getAuth(app);
  } else {
    offlineMode = true;
  }
} catch (e) {
  console.warn("[THE MYTH ENGINE] Firebase service initialization failed. Activating robust offline fallback.", e);
  offlineMode = true;
}

// In sandboxed environments or if initialization fails, use custom non-crashing mocks to support hooks
if (offlineMode || !app || !auth) {
  app = null;
  db = null;
  
  const mockUser = {
    uid: 'offline-identity-key',
    email: 'MarquisWhitacre@gmail.com',
    displayName: 'Marquis Whitacre (Offline)',
    photoURL: null,
    getIdTokenResult: async () => ({ claims: { admin: true } }),
    getIdToken: async () => 'mock-token',
  };

  auth = {
    currentUser: mockUser,
    onAuthStateChanged: (cb: any) => {
      // Trigger auth change event in tick sequence to keep React updates synchronized
      setTimeout(() => {
        cb(mockUser);
      }, 50);
      return () => {};
    },
    onIdTokenChanged: (cb: any) => {
      setTimeout(() => {
        cb(mockUser);
      }, 50);
      return () => {};
    },
    signOut: async () => {
      console.log("[THE MYTH ENGINE] Mock Signout executed successfully.");
    }
  };

  messaging = null; // Checked safely inside useFCM
} else {
  // Try to load Cloud Messaging safely; silences standard sandbox errors (e.g. unsupported Service Worker)
  try {
    messaging = getMessaging(app);
  } catch (messagingError) {
    console.warn("[THE MYTH ENGINE] Firebase Cloud Messaging is unsupported or blocked. Run-time disabled.", messagingError);
    messaging = null;
  }
}

export { app, db, auth, messaging };
