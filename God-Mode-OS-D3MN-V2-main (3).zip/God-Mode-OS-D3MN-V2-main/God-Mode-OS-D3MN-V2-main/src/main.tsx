import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import { SystemOverseer } from './components/SystemOverseer';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <SystemOverseer>
      <App />
    </SystemOverseer>
  </StrictMode>,
);
