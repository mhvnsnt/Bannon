importScripts('https://www.gstatic.com/firebasejs/10.8.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.8.0/firebase-messaging-compat.js');

// This requires your real project config to catch background notifications
// But the wrapper provides a graceful fallback if missing.
const firebaseConfig = {
    apiKey: "dummy",
    authDomain: "dummy",
    projectId: "dummy",
    storageBucket: "dummy",
    messagingSenderId: "dummy",
    appId: "dummy"
};

try {
    firebase.initializeApp(firebaseConfig);
    const messaging = firebase.messaging();

    messaging.onBackgroundMessage((payload) => {
        console.log('[FCM SW] Received background message ', payload);
        const notificationTitle = payload.notification?.title || 'Nexus Auto-Pilot';
        const notificationOptions = {
            body: payload.notification?.body || 'New operational update from daemon.',
            icon: '/icon.png'
        };

        self.registration.showNotification(notificationTitle, notificationOptions);
    });
} catch(e) { 
    console.warn("FCM SW initialization incomplete without explicit config.", e);
}
