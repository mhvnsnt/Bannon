// ============================================================================
// AUTONOMOUS ENGINE v3.0 (DEACTIVATED)
// Deactivated on boot per directive. Quantum Chat loads directly.
// ============================================================================

console.log('[THE MYTH ENGINE] Autonomous AAA Physics v3.0 disabled by system directive.');
window.BPHYS = null;
window.RK_SPIN = null;
window.RK_LOOSE = null;
