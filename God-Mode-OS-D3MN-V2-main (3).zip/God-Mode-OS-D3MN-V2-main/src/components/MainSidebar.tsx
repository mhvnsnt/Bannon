import React from 'react';
import { Orbit, Activity, ShieldAlert, Cpu, Network, Sparkles, Terminal, Smartphone, CloudFog, Wifi, Code, DollarSign, Brain, Users, Settings, Globe } from 'lucide-react';

export default function MainSidebar() {
  const panels = [
    { id: 'terminal', label: "Quantum Chat", icon: <Terminal className="w-4 h-4" /> },
    { id: 'omniverse', label: "Omniverse", icon: <Sparkles className="w-4 h-4" /> },
    { id: 'ast_visualizer', label: "AST Visualizer", icon: <Code className="w-4 h-4" /> },
    { id: 'advisin_matrix', label: "Advisin Matrix", icon: <Network className="w-4 h-4" /> },
    { id: 'biomechanical_sandbox', label: "Biomechanical Sandbox", icon: <Activity className="w-4 h-4" /> },
    { id: 'command_nexus', label: "Command Nexus", icon: <Terminal className="w-4 h-4" /> },
    { id: 'curation_dashboard', label: "Curation Dashboard", icon: <Activity className="w-4 h-4" /> },
    { id: 'economic_dashboard', label: "Economic Dashboard", icon: <DollarSign className="w-4 h-4" /> },
    { id: 'memory_vault_ui', label: "Memory Vault UI", icon: <Activity className="w-4 h-4" /> },
    { id: 'neurochemical_dashboard', label: "Neurochemical Dashboard", icon: <Brain className="w-4 h-4" /> },
    { id: 'parliament_viewer', label: "Parliament Viewer", icon: <Users className="w-4 h-4" /> },
    { id: 'quantum_builder', label: "Quantum Builder", icon: <Orbit className="w-4 h-4" /> },
    { id: 'semantic_memory_monitor', label: "Semantic Memory Monitor", icon: <Brain className="w-4 h-4" /> },
    { id: 'stability_monitor', label: "Stability Monitor", icon: <Activity className="w-4 h-4" /> },
    { id: 'swarm_monitor', label: "Swarm Monitor", icon: <Network className="w-4 h-4" /> },
    { id: 'syst_settings', label: "System Settings", icon: <Settings className="w-4 h-4" /> },
    { id: 'world_model', label: "World Model", icon: <Globe className="w-4 h-4" /> },
  ];

  return (
    <div className="flex flex-col h-full bg-black/90 border-r border-[#333] p-4 font-mono text-gray-400 overflow-y-auto">
      <div className="flex items-center gap-3 mb-8 pb-4 border-b border-[#333]">
        <div className="w-8 h-8 rounded bg-fuchsia-900/40 border border-fuchsia-500/50 flex items-center justify-center">
          <Smartphone className="text-fuchsia-400 w-5 h-5" />
        </div>
        <div>
          <h1 className="text-fuchsia-400 font-bold uppercase tracking-widest text-sm">Mobile Proxy Node</h1>
          <p className="text-[10px] text-gray-500 uppercase tracking-widest">Local Ingestion Active</p>
        </div>
      </div>

      <div className="flex flex-col gap-1">
        <div className="text-[10px] text-fuchsia-500 uppercase tracking-widest mb-2 font-semibold flex items-center gap-2">
          <Orbit className="w-3 h-3" /> Navigation Modules
        </div>
        
        {panels.map((panel) => (
          <button key={panel.id} className="flex items-center gap-3 p-2 rounded hover:bg-[#111] transition-colors text-left group">
            {React.cloneElement(panel.icon, { className: `${panel.icon.props.className} text-emerald-500 group-hover:text-emerald-400` })}
            <span className="text-xs uppercase tracking-wider group-hover:text-gray-200">{panel.label}</span>
          </button>
        ))}
        
        <div className="my-4 border-t border-[#333]" />
        
        <button className="flex items-center gap-3 p-2 rounded hover:bg-[#111] transition-colors text-left group">
          <ShieldAlert className="w-4 h-4 text-red-500 group-hover:text-red-400" />
          <span className="text-xs uppercase tracking-wider group-hover:text-gray-200">Security Vault</span>
        </button>
      </div>

      <div className="mt-auto pt-4 border-t border-[#333]">
        <div className="flex items-center gap-2 text-[10px] uppercase font-bold text-gray-500 tracking-widest">
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          System Online
        </div>
      </div>
    </div>
  );
}
