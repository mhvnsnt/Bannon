import React, { useState, useEffect } from 'react';
import { PANELS } from '../App';
import { motion } from 'framer-motion';
import { Activity, Shield, Terminal, Zap } from 'lucide-react';

export default function GodModeOS({ onNavigate }: { onNavigate: (id: string, isRightPanel: boolean) => void }) {
  const [systemTime, setSystemTime] = useState("");
  
  useEffect(() => {
     const updateTime = () => {
         const now = new Date();
         setSystemTime(now.toLocaleTimeString('en-US', { hour12: false }) + '.' + now.getMilliseconds().toString().padStart(3, '0'));
     };
     const t = setInterval(updateTime, 50);
     return () => clearInterval(t);
  }, []);

  return (
    <div className="flex flex-col p-6 w-full h-full overflow-y-auto bg-[#030303] text-gray-200 relative">
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-[0.03] pointer-events-none" />
      <div className="absolute top-0 w-full h-1 bg-gradient-to-r from-transparent via-cyan-500/50 to-transparent shadow-[0_0_15px_#06b6d4] opacity-50" />

      <div className="flex flex-col gap-6 max-w-[1600px] mx-auto w-full relative z-10 pb-20">
        
        {/* Superior Header */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 border-b border-[#222] pb-6">
           <div className="flex flex-col gap-3">
             <div className="flex items-center gap-3">
               <div className="flex items-center justify-center w-10 h-10 bg-cyan-950 border border-cyan-500/50 shadow-[0_0_20px_rgba(6,182,212,0.3)]">
                 <Terminal className="text-cyan-400 w-5 h-5" />
               </div>
               <div>
                  <h1 className="text-3xl font-black tracking-[0.2em] text-white flex items-center gap-3 uppercase">
                    GOD MODE <span className="text-cyan-400 font-light">OS</span>
                  </h1>
                  <p className="text-xs text-gray-500 font-mono mt-1 tracking-widest uppercase">
                    Select a module to commence operations across the Prime Network.
                  </p>
               </div>
             </div>
           </div>

           <div className="flex gap-4 items-center">
              <div className="flex flex-col items-end">
                 <span className="text-[10px] text-gray-500 tracking-widest uppercase font-mono mb-1">LOCAL SIDEREAL TIME</span>
                 <span className="text-xl font-mono font-light tracking-[0.2em] text-cyan-500">{systemTime}</span>
              </div>
              <div className="h-10 w-px bg-[#333]" />
              <div className="flex flex-col gap-1 items-end">
                 <div className="flex items-center gap-2 text-[10px] tracking-widest uppercase text-emerald-500 font-bold">
                    <Activity className="w-3 h-3" /> Core Node Online
                 </div>
                 <div className="flex items-center gap-2 text-[10px] tracking-widest uppercase text-amber-500 font-bold">
                    <Shield className="w-3 h-3" /> Defenses Minted
                 </div>
              </div>
           </div>
        </div>

        {/* Modules Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
          {PANELS.filter(p => p.id !== 'god_mode_os').map((p, idx) => (
            <motion.button
              key={p.id}
              initial={{ opacity: 0, y: 15, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ delay: idx * 0.015, duration: 0.3, ease: 'easeOut' }}
              onClick={() => onNavigate(p.id, !p.isMain)}
              className={`flex flex-col items-start gap-4 p-5 border transition-all text-left group relative overflow-hidden backdrop-blur-sm
                 ${p.isMain ? 'bg-[#0a0a0f]/80 border-indigo-900/40 hover:bg-[#0f0f1a] hover:border-indigo-500/60 shadow-[0_4px_20px_rgba(0,0,0,0.5)] hover:shadow-[0_4px_30px_rgba(99,102,241,0.2)] rounded-lg' 
                 : 'bg-[#111111]/80 border-[#333] hover:bg-[#1a1a1a] hover:border-[#555] rounded-lg'}
              `}
            >
              {/* Decoration Line */}
              {p.isMain && (
                 <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-indigo-500 to-cyan-400 opacity-0 group-hover:opacity-100 transition-opacity" />
              )}
              
              <div className="flex justify-between w-full items-start">
                 <div className={`p-3 rounded flex items-center justify-center transition-transform group-hover:scale-110 shadow-sm ${p.isMain ? 'bg-indigo-950/50 border border-indigo-500/30' : 'bg-[#222] border border-[#333]'}`}>
                   {p.icon}
                 </div>
                 <div className="flex items-center gap-1 opacity-20 group-hover:opacity-100 transition-opacity">
                    <div className={`w-1 h-1 rounded-full ${p.isMain ? 'bg-cyan-400' : 'bg-gray-400'}`} />
                    <div className={`w-1 h-1 rounded-full ${p.isMain ? 'bg-indigo-400' : 'bg-gray-500'}`} />
                 </div>
              </div>

              <div className="flex flex-col gap-1.5 mt-2">
                <span className={`font-bold tracking-wide uppercase text-xs ${p.isMain ? 'text-indigo-100' : 'text-gray-300'}`}>{p.label}</span>
                <span className={`text-[10px] tracking-widest uppercase font-mono ${p.isMain ? 'text-indigo-400/80' : 'text-gray-500'}`}>
                  {p.isMain ? "Prime Architecture Module" : "Secondary Workspace Panel"}
                </span>
              </div>
            </motion.button>
          ))}
        </div>
      </div>
    </div>
  );
}
