import React, { useState, useEffect, useRef } from 'react';
import { Activity, Play, Square, Settings, Database, Eye } from 'lucide-react';
import { useHardwareSenses } from '../hooks/useDeviceSensors';

export function AnatomicalPhysicsRig() {
  const { triggerKineticFeedback } = useHardwareSenses();
  const [activeRig, setActiveRig] = useState('DAZ_GENESIS');
  const [facs, setFacs] = useState({ AU1: 0, AU2: 0, AU4: 0, AU12: 0 });
  const [physics, setPhysics] = useState({ gravity: 9.8, tension: 50, dampening: 20 });
  const [fluidSim, setFluidSim] = useState(false);
  const [simulationResult, setSimulationResult] = useState(0);
  const workerRef = useRef<Worker | null>(null);

  useEffect(() => {
    workerRef.current = new Worker(new URL('../physics/physicsWorker.ts', import.meta.url));
    workerRef.current.onmessage = (e) => {
      if (e.data.type === 'UPDATE') {
        const force = e.data.simulation.force;
        if (force > 490) triggerKineticFeedback([100, 50, 100]);
        setSimulationResult(force);
      }
    };
    return () => workerRef.current?.terminate();
  }, []);

  useEffect(() => {
    workerRef.current?.postMessage({ type: 'UPDATE_CONFIG', physics });
  }, [physics]);
  
  return (
    <div className="w-full h-full bg-[#050505] text-fuchsia-500 font-mono p-4 flex flex-col border-l border-fuchsia-900/40 overflow-hidden">
        <div className="border-b border-fuchsia-900/50 pb-3 mb-4 shrink-0">
           <h2 className="text-sm font-bold uppercase tracking-widest text-fuchsia-400 flex items-center gap-2">
             <Database className="w-4 h-4" /> Tomodachi Simulation Sandbox
           </h2>
           <p className="text-[10px] text-fuchsia-700 mt-1">1000+ Bone Kinematics, FACS, and Bio-Mechanical Physics Mesh.</p>
        </div>

        <div className="flex-1 grid grid-cols-2 gap-4 pb-4 overflow-y-auto custom-scrollbar">
            <div className="bg-[#0a0a0a] border border-fuchsia-900/30 rounded p-4 flex flex-col gap-4">
                <h3 className="text-xs uppercase font-bold text-fuchsia-500 flex items-center gap-2">
                  <Eye className="w-3 h-3" /> FACS Morph Targets
                </h3>
                <div className="space-y-4">
                   {Object.entries(facs).map(([au, val]) => (
                      <div key={au}>
                         <div className="flex justify-between text-[10px] uppercase text-fuchsia-600 mb-1">
                            <span>{au} {au === 'AU1' ? '(Inner Brow)' : au === 'AU2' ? '(Outer Brow)' : au === 'AU4' ? '(Brow Lowerer)' : '(Lip Corner Puller)'}</span>
                            <span>{(val * 100).toFixed(0)}%</span>
                         </div>
                         <input 
                            type="range" min="0" max="1" step="0.01" value={val}
                            onChange={e => setFacs({...facs, [au as keyof typeof facs]: parseFloat(e.target.value)})}
                            className="w-full accent-fuchsia-500"
                         />
                      </div>
                   ))}
                </div>
            </div>

            <div className="bg-[#0a0a0a] border border-fuchsia-900/30 rounded p-4 flex flex-col gap-4">
                <h3 className="text-xs uppercase font-bold text-fuchsia-500 flex items-center gap-2">
                  <Settings className="w-3 h-3" /> Soft Body & Fluid Dynamics
                </h3>
                <div className="space-y-4">
                   {Object.entries(physics).map(([prop, val]) => (
                      <div key={prop}>
                         <div className="flex justify-between text-[10px] uppercase text-fuchsia-600 mb-1">
                            <span>{prop}</span>
                            <span>{val.toFixed(1)}</span>
                         </div>
                         <input 
                            type="range" min="0" max={prop === 'gravity' ? 20 : 100} value={val}
                            onChange={e => setPhysics({...physics, [prop as keyof typeof physics]: parseFloat(e.target.value)})}
                            className="w-full accent-fuchsia-500"
                         />
                      </div>
                   ))}
                   
                   <label className="flex items-center gap-2 text-[10px] text-fuchsia-500 uppercase mt-2">
                      <input type="checkbox" checked={fluidSim} onChange={e => setFluidSim(e.target.checked)} className="accent-fuchsia-500" />
                      Enable Scientific Fluid Mesh Generation
                   </label>
                </div>
            </div>
            
            <div className="col-span-2 bg-[#0a0a0a] border border-fuchsia-900/30 rounded p-4 h-64 relative flex items-center justify-center overflow-hidden">
                <div className="absolute inset-0 bg-black" style={{ backgroundImage: 'radial-gradient(circle at center, #d946ef 1px, transparent 1px)', backgroundSize: '20px 20px', opacity: 0.1 }} />
                
                {/* Abstract wireframe visualization */}
                <svg viewBox="0 0 100 100" className="w-48 h-48 opacity-80 z-10 transition-transform" style={{ transform: `scale(${1 + facs.AU1 * 0.1})` }}>
                   <circle cx="50" cy="50" r="40" fill="none" stroke="#d946ef" strokeWidth="1" strokeDasharray="2 2" className="animate-[spin_20s_linear_infinite]" />
                   <path d={`M 30 ${40 + facs.AU4 * 10} Q 50 ${30 + facs.AU1 * 20} 70 ${40 + facs.AU4 * 10}`} fill="none" stroke="#e879f9" strokeWidth="2" />
                   <path d={`M 35 ${70 - facs.AU12 * 10} Q 50 ${80 - facs.AU12 * 20} 65 ${70 - facs.AU12 * 10}`} fill="none" stroke="#e879f9" strokeWidth="2" />
                   {fluidSim && (
                      <circle cx="50" cy="85" r={physics.gravity / 2} fill="#d946ef" className="animate-ping opacity-50" />
                   )}
                </svg>
                
                <div className="absolute bottom-2 left-2 text-[9px] text-fuchsia-700">
                   STATUS: {activeRig} KINEMATICS ACTIVE | TENSION: {physics.tension}% | PWR: {simulationResult.toFixed(0)}
                </div>
            </div>
        </div>
    </div>
  );
}
