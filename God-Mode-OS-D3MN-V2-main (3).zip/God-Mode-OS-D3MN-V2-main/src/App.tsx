import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useWorkspaceAutoSave } from "./hooks/useWorkspaceAutoSave";
import { useResponsiveOrientation } from "./hooks/useResponsiveOrientation";
import { GlobalErrorPanel } from "./components/GlobalErrorPanel";
import { usePrimeStore } from "./lib/store";
import { ErrorBoundary } from "./components/ErrorBoundary";
import { PanelErrorBoundary } from "./components/PanelErrorBoundary";
import { StatusBar } from "./components/StatusBar";
import { CommandPalette } from "./components/CommandPalette";

// Lazy loading panel components to prevent initialization timeouts and optimize bundle size
const Dashboard = React.lazy(() => import("./components/Dashboard"));
const QuantumChat = React.lazy(() => import("./components/QuantumChat"));
const FieldLogs = React.lazy(() => import("./components/FieldLogs"));
const AutonomyForge = React.lazy(() => import("./components/AutonomyForge"));
const SecurityVault = React.lazy(() => import("./components/SecurityVault"));
const AutonomousSandbox = React.lazy(() => import("./components/AutonomousSandbox"));
const AutonomousAgents = React.lazy(() => import("./components/AutonomousAgents"));
const OverseerProtocol = React.lazy(() => import("./components/OverseerProtocol"));
const TemporalMemoryVault = React.lazy(() => import("./components/TemporalMemoryVault"));
const ForgeStudio = React.lazy(() => import("./components/ForgeStudio"));
const MediaForge = React.lazy(() => import("./components/MediaForge"));
const DirectiveVault = React.lazy(() => import("./components/DirectiveVault"));
const KineticWealth = React.lazy(() => import("./components/KineticWealth"));
const KineticResistanceEngine = React.lazy(() => import("./components/KineticResistanceEngine"));
const OrbitalResonance = React.lazy(() => import("./components/OrbitalResonance"));
const PrimeDirectivesOS = React.lazy(() => import("./components/PrimeDirectivesOS"));
const BinarySigilManager = React.lazy(() => import("./components/BinarySigilManager"));
const InfluenceArcEngine = React.lazy(() => import("./components/InfluenceArcEngine"));
const SettingsModal = React.lazy(() => import("./components/SettingsModal"));
const EnvironmentalControls = React.lazy(() => import("./components/EnvironmentalControls"));
const EarthObservationGrid = React.lazy(() => import("./components/EarthObservationGrid").then(m => ({ default: m.EarthObservationGrid })));
const CellularRejuvenationMatrix = React.lazy(() => import("./components/CellularRejuvenationMatrix").then(m => ({ default: m.CellularRejuvenationMatrix })));
const MasterBlueprintAtlas = React.lazy(() => import("./components/MasterBlueprintAtlas").then(m => ({ default: m.MasterBlueprintAtlas })));
const EnvironmentalTechGrid = React.lazy(() => import("./components/EnvironmentalTechGrid").then(m => ({ default: m.EnvironmentalTechGrid })));
const EmbodiedRoboticsInterface = React.lazy(() => import("./components/EmbodiedRoboticsInterface").then(m => ({ default: m.EmbodiedRoboticsInterface })));
const OneBitCompressionEngine = React.lazy(() => import("./components/OneBitCompressionEngine").then(m => ({ default: m.OneBitCompressionEngine })));
const AgenticSwarmMatrix = React.lazy(() => import("./components/AgenticSwarmMatrix").then(m => ({ default: m.AgenticSwarmMatrix })));
const TrendlineForecaster = React.lazy(() => import("./components/TrendlineForecaster").then(m => ({ default: m.TrendlineForecaster })));
const KineticHapticEngine = React.lazy(() => import("./components/KineticHapticEngine").then(m => ({ default: m.KineticHapticEngine })));
const AnatomicalPhysicsRig = React.lazy(() => import("./components/AnatomicalPhysicsRig").then(m => ({ default: m.AnatomicalPhysicsRig })));
const PrimeArchitectIDE = React.lazy(() => import("./components/PrimeArchitectIDE").then(m => ({ default: m.PrimeArchitectIDE })));
const QuantumFieldVisualizer = React.lazy(() => import("./components/QuantumFieldVisualizer"));
const SectorMatrixHub = React.lazy(() => import("./components/SectorMatrixHub"));
const ContextCuratorUI = React.lazy(() => import("./components/ContextCuratorUI").then(m => ({ default: m.ContextCuratorUI })));

const BiologicalOverride = React.lazy(() => import("./components/BiologicalOverride").then(m => ({ default: m.BiologicalOverride })));
const CrucibleProtocol = React.lazy(() => import("./components/CrucibleProtocol").then(m => ({ default: m.CrucibleProtocol })));
const NeuroplasticityEngine = React.lazy(() => import("./components/NeuroplasticityEngine").then(m => ({ default: m.NeuroplasticityEngine })));
const OmniSingularityNexus = React.lazy(() => import("./components/OmniSingularityNexus").then(m => ({ default: m.OmniSingularityNexus })));
const MetaconsciousApotheosis = React.lazy(() => import("./components/MetaconsciousApotheosis").then(m => ({ default: m.MetaconsciousApotheosis })));
import { OmniverseHyperStructure } from "./components/OmniverseHyperStructure";
const AutonomousNavigationMatrix = React.lazy(() => import("./components/AutonomousNavigationMatrix").then(m => ({ default: m.AutonomousNavigationMatrix })));
const ApexCoreOS = React.lazy(() => import("./components/ApexCore").then(m => ({ default: m.ApexCoreOS })));
const AbundanceCompiler = React.lazy(() => import("./components/AbundanceCompiler").then(m => ({ default: m.AbundanceCompiler })));
const KineticVisualizer = React.lazy(() => import("./components/KineticVisualizer").then(m => ({ default: m.KineticVisualizer })));
const KineticCreativeControl = React.lazy(() => import("./components/KineticCreativeControl").then(m => ({ default: m.KineticCreativeControl })));
const MlabStudio = React.lazy(() => import("./components/MlabStudio"));
const TelemetryGrid = React.lazy(() => import("./components/TelemetryGrid").then(m => ({ default: m.TelemetryGrid })));
const CodeSurgeonPanel = React.lazy(() => import("./components/CodeSurgeonPanel"));
const NexusOperatingSystem = React.lazy(() => import("./components/NexusOperatingSystem"));
const GodModeOS = React.lazy(() => import("./components/GodModeOS"));
const CognitiveArchitectureNexus = React.lazy(() => import("./components/CognitiveArchitectureNexus"));
const SpatialCommandArchitecture = React.lazy(() => import("./components/SpatialCommandArchitecture"));
const MotorolaHardwareBridge = React.lazy(() => import("./components/MotorolaHardwareBridge"));
const EvolutionRoadmap = React.lazy(() => import("./components/EvolutionRoadmap"));
const MotorolaDataGrid = React.lazy(() => import("./components/MotorolaDataGrid"));
const RealityCompiler = React.lazy(() => import("./components/RealityCompiler"));
const NeurospatialWormhole = React.lazy(() => import("./components/NeurospatialWormhole"));
const FractalExpansionEngine = React.lazy(() => import("./components/FractalExpansionEngine"));
const MythEngine = React.lazy(() => import("./components/MythEngine").then(m => ({ default: m.MythEngine })));
const HarmonicStateEngine = React.lazy(() => import("./components/HarmonicStateEngine").then(m => ({ default: m.HarmonicStateEngine })));
const MultiverseTimelineGrid = React.lazy(() => import("./components/MultiverseTimelineGrid").then(m => ({ default: m.MultiverseTimelineGrid })));
const GravitonControlNode = React.lazy(() => import("./components/GravitonControlNode").then(m => ({ default: m.GravitonControlNode })));
const ArtifactVault = React.lazy(() => import("./components/ArtifactVault").then(m => ({ default: m.ArtifactVault })));

const ASTVisualizer = React.lazy(() => import("./components/ASTVisualizer").then(m => ({ default: m.ASTVisualizer })));
const AdvisinMatrix = React.lazy(() => import("./components/AdvisinMatrix"));
const BiomechanicalSandbox = React.lazy(() => import("./components/BiomechanicalSandbox"));
const BroadcastEngine = React.lazy(() => import("./components/BroadcastEngine"));
const CanvasEngine = React.lazy(() => import("./components/CanvasEngine"));
const CommandMatrix = React.lazy(() => import("./components/CommandMatrix").then(m => ({ default: m.CommandMatrix })));
const CommandNexus = React.lazy(() => import("./components/CommandNexus"));
const CurationDashboard = React.lazy(() => import("./components/CurationDashboard"));
const D3FlowVisualizer = React.lazy(() => import("./components/D3FlowVisualizer"));
const DirectorInterface = React.lazy(() => import("./components/DirectorInterface").then(m => ({ default: m.DirectorInterface })));
const EconomicDashboard = React.lazy(() => import("./components/EconomicDashboard"));
const GameBridgeMonitor = React.lazy(() => import("./components/GameBridgeMonitor").then(m => ({ default: m.GameBridgeMonitor })));
const HealingMonitor = React.lazy(() => import("./components/HealingMonitor"));
const MemoryVaultUI = React.lazy(() => import("./components/MemoryVaultUI").then(m => ({ default: m.MemoryVaultUI })));
const NeurochemicalDashboard = React.lazy(() => import("./components/NeurochemicalDashboard").then(m => ({ default: m.NeurochemicalDashboard })));
const OvernightReport = React.lazy(() => import("./components/OvernightReport").then(m => ({ default: m.OvernightReport })));
const ParliamentViewer = React.lazy(() => import("./components/ParliamentViewer"));
const QuantumBuilder = React.lazy(() => import("./components/QuantumBuilder"));
const RazorMonitor = React.lazy(() => import("./components/RazorMonitor").then(m => ({ default: m.RazorMonitor })));
const SemanticMemoryMonitor = React.lazy(() => import("./components/SemanticMemoryMonitor"));
const SysSettings = React.lazy(() => import("./components/Settings"));
const StabilityMonitor = React.lazy(() => import("./components/StabilityMonitor").then(m => ({ default: m.StabilityMonitor })));
const SwarmMonitor = React.lazy(() => import("./components/SwarmMonitor").then(m => ({ default: m.SwarmMonitor })));
const SystemHealthMonitor = React.lazy(() => import("./components/SystemHealthMonitor").then(m => ({ default: m.SystemHealthMonitor })));
const VoidMonitor = React.lazy(() => import("./components/VoidMonitor").then(m => ({ default: m.VoidMonitor })));
const WorldModel = React.lazy(() => import("./components/WorldModel"));
const MainSidebarPanel = React.lazy(() => import("./components/MainSidebar"));

import { ARMADA_NODES, PROVIDERS, ArmadaNode, ModelProvider } from "./types";
import {
  Hexagon,
  LayoutDashboard,
  Database,
  Cpu,
  Settings,
  PanelLeftClose,
  PanelLeft,
  PanelRightClose,
  Globe,
  Menu,
  X,
  ShieldAlert,
  Fingerprint,
  Power,
  Volume2,
  VolumeX,
  LogOut,
  Eye,
  Code2,
  Music,
  Clock,
  Laptop,
  Camera,
  Terminal,
  Activity,
  ChevronDown,
  Network,
  Check,
  Orbit,
  DollarSign,
  Users,
  Trophy,
  Focus,
  Wind,
  Dumbbell,
  Brain,
  Thermometer,
  Infinity as InfinityIcon,
  Sparkles,
  Smartphone,
  Code,
  Zap
} from "lucide-react";
import { Map as MapIcon } from "lucide-react";
import { useAuthState } from "react-firebase-hooks/auth";
import { auth, db } from "./lib/firebase";
import {
  GoogleAuthProvider,
  GithubAuthProvider,
  signInWithPopup,
  signOut,
  OAuthProvider,
} from "firebase/auth";
import { doc, getDoc, setDoc, addDoc, collection } from "firebase/firestore";
import { useFCM } from "./hooks/useFCM";

export function useViewportSensing() {
  useEffect(() => {
    const lockPerimeter = () => {
      const currentWidth = document.documentElement.clientWidth;
      usePrimeStore.getState().setGlassWidth(currentWidth);
      document.documentElement.style.setProperty(
        "--absolute-bound",
        `${currentWidth}px`,
      );
    };

    window.addEventListener("resize", lockPerimeter);
    lockPerimeter();

    return () => window.removeEventListener("resize", lockPerimeter);
  }, []);
}

const NavItem = React.memo(function NavItem({ active, icon, label, onClick, id, isPinned, onTogglePin }: any) {
  return (
    <div className="relative w-full flex items-center group">
      <button
        onClick={onClick}
        draggable={!!id}
        onDragStart={(e) => {
          if (id) {
            e.dataTransfer.setData("text/plain", id);
          }
        }}
        className={`flex items-center gap-3 w-full p-2.5 pr-8 rounded-xl border transition-all cursor-pointer ${active ? "bg-[#1a1a1a] border-fuchsia-500/30 text-white font-semibold shadow-lg shadow-black/50" : "bg-[#0c0c0c] border-[#1a1a1a] text-gray-400 hover:text-gray-200 hover:bg-[#111] hover:border-[#333]"}`}
      >
        <div className="shrink-0">{icon}</div>
        <span className="text-sm font-medium truncate">{label}</span>
      </button>
      {id && onTogglePin && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            onTogglePin(id);
          }}
          title={isPinned ? "Unpin Panel" : "Pin Panel"}
          className={`absolute right-2 opacity-0 group-hover:opacity-100 transition-opacity p-1 ${isPinned ? "opacity-100 text-fuchsia-400" : "text-gray-500 hover:text-gray-300"}`}
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill={isPinned ? "currentColor" : "none"} stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="17" x2="12" y2="22"></line><path d="M5 17h14v-1.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.68V6a3 3 0 0 0-3-3 3 3 0 0 0-3 3v4.68a2 2 0 0 1-1.11 1.87l-1.78.89A2 2 0 0 0 5 15.24Z"></path></svg>
        </button>
      )}
    </div>
  );
});

export const PANELS = [
  { id: 'prime_architect', label: "Prime Architect IDE", icon: <Code className="text-cyan-400" />, isMain: true },
  { id: 'code_surgeon', label: "Code Surgeon", icon: <Sparkles className="text-fuchsia-400" />, isMain: true },
  { id: 'nexus_os', label: "Nexus Operating System", icon: <Orbit className="text-emerald-500" />, isMain: true },
  { id: 'god_mode_os', label: "God Mode OS", icon: <LayoutDashboard className="text-amber-400" />, isMain: true },
  { id: 'cog_nexus', label: "Cognitive Nexus", icon: <Brain className="text-fuchsia-400" />, isMain: true },
  { id: 'spatial_command', label: "Spatial Command Architecture", icon: <Hexagon className="text-teal-400" />, isMain: true },
  { id: 'motorola_bridge', label: "Motorola Hardware Bridge", icon: <Smartphone className="text-emerald-400" />, isMain: true },
  { id: 'motorola_grid', label: "Motorola Data Grid", icon: <Network className="text-emerald-500" />, isMain: true },
  { id: 'fractal_expansion', label: "Fractal Expansion Engine", icon: <Orbit className="text-emerald-400" />, isMain: true },
  { id: 'myth_engine', label: "The Myth Engine", icon: <Database className="text-blue-500" />, isMain: true },
  { id: 'reality_compiler', label: "Reality Compiler", icon: <Code className="text-fuchsia-400" />, isMain: true },
  { id: 'neuro_wormhole', label: "Neurospatial Wormhole", icon: <Orbit className="text-purple-500" />, isMain: true },
  { id: 'evolution_roadmap', label: "Evolution Roadmap", icon: <MapIcon className="text-cyan-400" />, isMain: true },
  { id: 'terminal', label: "Quantum Chat & Strategy", icon: <Terminal className="text-purple-400" />, isMain: true },
  { id: 'omniverse', label: "Omniverse HyperStructure", icon: <Sparkles className="text-fuchsia-400" />, isMain: true },
  { id: 'apex', label: "Apex CoreOS", icon: <Cpu className="text-teal-400" />, isMain: true },
  { id: 'abundance', label: "Abundance Compiler", icon: <LayoutDashboard className="text-yellow-400" />, isMain: true },
  { id: 'quantum_reality', label: "Quantum Reality", icon: <Globe className="text-indigo-400" />, isMain: true },
  { id: 'mlab', label: "MLab DAW Music Studio", icon: <Music className="text-pink-400" />, isMain: true },
  // And the rest which were right panels...
  { id: 'dashboard', label: "Dashboard Overview", icon: <LayoutDashboard /> },
  { id: 'device_sensors', label: "Hardware/Sensor Bridge", icon: <Smartphone className="text-emerald-400" /> },
  { id: 'sector_matrix', label: "Sector Matrix Hub", icon: <Network className="text-indigo-400" /> },
  { id: 'metaconscious', label: "Metaconscious Apotheosis", icon: <Sparkles className="text-cyan-300" /> },
  { id: 'omni_nexus', label: "Omni-Singularity Nexus", icon: <InfinityIcon className="text-fuchsia-500" /> },
  { id: 'neuroplasticity', label: "Neuroplasticity Engine", icon: <Brain className="text-cyan-400" /> },
  { id: 'environmental', label: "Environmental OS (God Mode)", icon: <Thermometer className="text-red-400" /> },
  { id: 'earth_grid', label: "Earth Observation Grid", icon: <Globe className="text-emerald-500" /> },
  { id: 'cellular', label: "Cellular Rejuvenation Matrix", icon: <Thermometer className="text-rose-400" /> },
  { id: 'atlas', label: "Master Blueprint Atlas", icon: <MapIcon className="text-indigo-400" /> },
  { id: 'environmental_tech', label: "Environmental Tech Grid", icon: <Globe className="text-emerald-400" /> },
  { id: 'robotics', label: "Embodied Physical Robotics", icon: <Cpu className="text-cyan-400" /> },
  { id: 'compression', label: "One-Bit Compression Engine", icon: <Zap className="text-amber-400" /> },
  { id: 'swarms', label: "Agentic Swarm Matrix", icon: <Network className="text-indigo-400" /> },
  { id: 'forecaster', label: "Predictive Reality Forecaster", icon: <Activity className="text-cyan-400" /> },
  { id: 'haptics', label: "Kinetic Haptic Engine", icon: <Smartphone className="text-rose-400" /> },
  { id: 'physics', label: "Tomodachi Simulation Sandbox", icon: <Database className="text-fuchsia-400" /> },
  { id: 'harmonic_engine', label: "Harmonic State Engine", icon: <Music className="text-emerald-400" /> },
  { id: 'multiverse_grid', label: "Multiverse Timeline Grid", icon: <Network className="text-indigo-400" /> },
  { id: 'artifact_vault', label: "The Master Blueprint Archives", icon: <Database className="text-emerald-400" /> },
  { id: 'graviton_node', label: "Graviton Control Node Alpha", icon: <Orbit className="text-emerald-500" /> },
  { id: 'crucible', label: "The Crucible Protocol", icon: <Dumbbell className="text-amber-500" /> },
  { id: 'override', label: "Biological Override", icon: <Activity className="text-emerald-500" /> },
  { id: 'arc_engine', label: "Influence Arc Engine", icon: <Orbit className="text-fuchsia-400" /> },
  { id: 'wealth', label: "Kinetic Wealth", icon: <DollarSign /> },
  { id: 'resistance', label: "Kinetic Resistance", icon: <Activity className="text-emerald-500" /> },
  { id: 'resonance', label: "Orbital Resonance", icon: <Users /> },
  { id: 'directives_architect', label: "Prime Architect", icon: <Trophy /> },
  { id: 'logs', label: "Activity Logs", icon: <Database className="text-blue-400" /> },
  { id: 'memory', label: "Temporal Memory Vault", icon: <Activity className="text-purple-400" /> },
  { id: 'sandbox', label: "Autonomous Sandbox", icon: <Terminal className="text-emerald-400" /> },
  { id: 'forge_studio', label: "Forge Studio (IDE)", icon: <Laptop className="text-cyan-400" /> },
  { id: 'media_forge', label: "Media Forge (Tensor)", icon: <Camera className="text-indigo-400" /> },
  { id: 'directives', label: "Directive Vault", icon: <Terminal className="text-white" /> },
  { id: 'vault', label: "Security Vault", icon: <ShieldAlert className="text-red-500/80" /> },
  { id: 'curator', label: "Quantum Context Curator", icon: <Globe className="text-cyan-400" /> },
  { id: 'overseer', label: "Overseer Protocol", icon: <Eye className="w-5 h-5 text-indigo-400" />, adminOnly: true },
  
  // New Integrations
  { id: 'ast_visualizer', label: "AST Visualizer", icon: <Code /> },
  { id: 'advisin_matrix', label: "Advisin Matrix", icon: <Network /> },
  { id: 'biomechanical_sandbox', label: "Biomechanical Sandbox", icon: <Activity /> },
  { id: 'broadcast_engine', label: "Broadcast Engine", icon: <Activity /> },
  { id: 'canvas_engine', label: "Canvas Engine", icon: <Activity /> },
  { id: 'command_matrix', label: "Command Matrix", icon: <Activity /> },
  { id: 'command_nexus', label: "Command Nexus", icon: <Activity /> },
  { id: 'curation_dashboard', label: "Curation Dashboard", icon: <Activity /> },
  { id: 'd3_flow_visualizer', label: "D3 Flow Visualizer", icon: <Activity /> },
  { id: 'director_interface', label: "Director Interface", icon: <Activity /> },
  { id: 'economic_dashboard', label: "Economic Dashboard", icon: <DollarSign /> },
  { id: 'game_bridge_monitor', label: "Game Bridge Monitor", icon: <Activity /> },
  { id: 'healing_monitor', label: "Healing Monitor", icon: <Activity /> },
  { id: 'memory_vault_ui', label: "Memory Vault UI", icon: <Activity /> },
  { id: 'neurochemical_dashboard', label: "Neurochemical Dashboard", icon: <Brain /> },
  { id: 'overnight_report', label: "Overnight Report", icon: <Activity /> },
  { id: 'parliament_viewer', label: "Parliament Viewer", icon: <Users /> },
  { id: 'quantum_builder', label: "Quantum Builder", icon: <Orbit /> },
  { id: 'razor_monitor', label: "Razor Monitor", icon: <Activity /> },
  { id: 'semantic_memory_monitor', label: "Semantic Memory Monitor", icon: <Brain /> },
  { id: 'sys_settings', label: "System Settings", icon: <Settings /> },
  { id: 'stability_monitor', label: "Stability Monitor", icon: <Activity /> },
  { id: 'swarm_monitor', label: "Swarm Monitor", icon: <Network /> },
  { id: 'system_health_monitor', label: "System Health Monitor", icon: <Activity /> },
  { id: 'void_monitor', label: "Void Monitor", icon: <Activity /> },
  { id: 'world_model', label: "World Model", icon: <Globe /> },
  { id: 'main_sidebar_panel', label: "Main Sidebar UI", icon: <Network /> }
];

const SidebarNavList = React.memo(function SidebarNavList({
  mainView,
  rightPanel,
  isPrimeNode,
  user,
  setMainView,
  setRightPanel,
  toggleRightPanel,
  onSignOut,
  onLogin,
}: {
  mainView: string;
  rightPanel: string | null;
  isPrimeNode: boolean;
  user: any;
  setMainView: (v: any) => void;
  setRightPanel: (v: string | null) => void;
  toggleRightPanel: (v: string) => void;
  onSignOut?: () => void;
  onLogin?: () => void;
}) {
  const [pinned, setPinned] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem("workspace-pinned-panels");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const togglePin = React.useCallback((id: string) => {
    setPinned(prev => {
      const next = prev.includes(id) ? prev.filter(p => p !== id) : [...prev, id];
      localStorage.setItem("workspace-pinned-panels", JSON.stringify(next));
      return next;
    });
  }, []);

  const pinnedPanels = PANELS.filter(p => pinned.includes(p.id) && (!p.adminOnly || isPrimeNode));
  const unpinnedPanels = PANELS.filter(p => !pinned.includes(p.id) && (!p.adminOnly || isPrimeNode));

  return (
    <div className="flex flex-col gap-1 p-3 flex-1 overflow-y-auto no-scrollbar pb-24">
      {pinnedPanels.length > 0 && (
        <>
          <div className="text-[10px] font-semibold text-fuchsia-500 px-3 py-2 mb-1 uppercase tracking-widest flex items-center gap-1.5 opacity-80">
            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="17" x2="12" y2="22"></line><path d="M5 17h14v-1.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.68V6a3 3 0 0 0-3-3 3 3 0 0 0-3 3v4.68a2 2 0 0 1-1.11 1.87l-1.78.89A2 2 0 0 0 5 15.24Z"></path></svg>
            Pinned Panels
          </div>
          {pinnedPanels.map((p) => (
            <NavItem
              key={p.id}
              id={p.id}
              active={p.isMain ? mainView === p.id : rightPanel === p.id}
              icon={p.icon}
              label={p.label}
              isPinned={true}
              onTogglePin={togglePin}
              onClick={() => {
                if (p.isMain) {
                  setMainView(p.id);
                  setRightPanel(null);
                } else {
                  toggleRightPanel(p.id);
                }
              }}
            />
          ))}
          <div className="my-2 px-3">
            <div className="h-px w-full bg-[#222]" />
          </div>
        </>
      )}

      <div className="text-[10px] font-semibold text-gray-500 px-3 py-2 mb-1 uppercase tracking-widest opacity-80">
        Interface Panels
      </div>
      
      {unpinnedPanels.map((p) => (
        <NavItem
          key={p.id}
          id={p.id}
          active={p.isMain ? mainView === p.id : rightPanel === p.id}
          icon={p.icon}
          label={p.label}
          isPinned={false}
          onTogglePin={togglePin}
          onClick={() => {
            if (p.isMain) {
              setMainView(p.id);
              setRightPanel(null);
            } else {
              toggleRightPanel(p.id);
            }
          }}
        />
      ))}

      <div className="mt-8 mb-2 px-3">
        <div className="h-px w-full bg-[#222]" />
      </div>
      <NavItem
        active={rightPanel === "vault"}
        icon={<ShieldAlert className="w-5 h-5 text-red-500/80" />}
        label="Security Vault"
        onClick={() => toggleRightPanel("vault")}
        id="vault"
      />
      <div className="mt-auto pt-4 border-t border-[#222222]/60 px-3">
        {user ? (
          <div className="flex flex-col gap-2">
            <div className="flex items-center gap-2 mb-2 px-2">
              <div className="w-8 h-8 rounded-full bg-purple-500/20 text-purple-400 flex items-center justify-center text-xs border border-purple-500/50">
                {user.email?.[0]?.toUpperCase() || "A"}
              </div>
              <div className="flex flex-col overflow-hidden">
                <span className="text-xs text-gray-300 truncate">{user.displayName || "Architect"}</span>
                <span className="text-[10px] text-gray-500 truncate">{user.email}</span>
              </div>
            </div>
            <NavItem
              active={false}
              icon={<LogOut className="w-5 h-5 text-red-400/80 hover:text-red-400 transition-colors" />}
              label="Disconnect Session"
              onClick={async () => {
                if (auth) {
                  try {
                    await signOut(auth);
                  } catch (e) {
                    console.warn("[AUTH] SignOut failed:", e);
                  }
                  console.log("[AUTH LOG] Clean session sign-out executed.");
                }
                if (onSignOut) onSignOut();
              }}
            />
          </div>
        ) : (
          <div className="flex flex-col gap-2 px-2">
            <button
              onClick={() => onLogin && onLogin()}
              className="flex items-center gap-2 bg-white text-black px-4 py-2 rounded-lg font-semibold w-full hover:bg-gray-200 transition-colors"
            >
              <div className="w-4 h-4 bg-black rounded-full" />
              <span>Google Connect</span>
            </button>
            <div className="text-[10px] text-gray-500 text-center mt-1">Authenticate to access Prime Network</div>
          </div>
        )}
      </div>
    </div>
  );
});

export default function App() {
  useViewportSensing();
  useFCM();

  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [firebaseConnected, setFirebaseConnected] = useState(false);

  useEffect(() => {
    if (!auth) {
      setUser(null);
      setFirebaseConnected(false);
      setLoading(false);
      return;
    }
    const unsub = auth.onAuthStateChanged((currentUser: any) => {
      if (currentUser) {
        setUser(currentUser);
        if (
          currentUser.uid !== "offline-identity-key" &&
          currentUser.uid !== "offline-architect"
        ) {
          setFirebaseConnected(true);
        } else {
          setFirebaseConnected(false);
        }
      } else {
        setUser(null);
        setFirebaseConnected(false);
      }
      setLoading(false);
    });
    return () => {
      if (unsub) unsub();
    };
  }, []);

  const [mainView, setMainView] = useState<string>("terminal");
  const [isSplitWorkspace, setIsSplitWorkspace] = useState(false);
  const [splitViewRight, setSplitViewRight] = useState<string>("omniverse");
  const [isCmdPaletteOpen, setIsCmdPaletteOpen] = useState(false);
  const [isHoveringLeft, setIsHoveringLeft] = useState(false);
  const [isHoveringRight, setIsHoveringRight] = useState(false);
  const isLandscape = useResponsiveOrientation();

  // Auto-collapse sidebar if in landscape
  useEffect(() => {
    if (isLandscape) setLeftSidebarOpen(false);
  }, [isLandscape]);

  const [presets, setPresets] = useState<{id: string, name: string, main: string, right: string, split: boolean}[]>(() => {
    try {
      const saved = localStorage.getItem("workspace-layout-presets");
      if (saved) return JSON.parse(saved);
      return [
        { id: 'dev-preset', name: "Development Layout", main: "terminal", right: "forge_studio", split: true },
        { id: 'analytics-preset', name: "Analytics Layout", main: "abundance", right: "wealth", split: true }
      ];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    // Machine Learning heuristic: Track user interaction patterns and auto-suggest layout presets based on time and hardware bridge load
    const interval = setInterval(() => {
      const hour = new Date().getHours();
      
      // Simulate detecting a high load on the hardware bridge
      const simulateBridgeLoad = () => Math.random() > 0.85;
      const isHighLoad = simulateBridgeLoad();

      setPresets((prev) => {
        let next = [...prev];
        if (isHighLoad && !next.some(p => p.id === 'bridge-ops-auto')) {
          next.push({ id: 'bridge-ops-auto', name: 'Bridge Max Load (Heuristic)', main: 'motorola_bridge', right: 'motorola_grid', split: true });
        }
        if ((hour >= 22 || hour <= 4) && !next.some(p => p.id === 'night-ops-auto')) {
          next.push({ id: 'night-ops-auto', name: 'Night Ops (Heuristic)', main: 'terminal', right: 'vault', split: true });
        } else if ((hour >= 9 && hour <= 17) && !next.some(p => p.id === 'day-ops-auto')) {
          next.push({ id: 'day-ops-auto', name: 'Day Ops (Heuristic)', main: 'god_mode_os', right: 'abundance', split: true });
        }
        return next;
      });
    }, 10000); // Check every 10 seconds

    return () => clearInterval(interval);
  }, []);

  const onSavePreset = () => {
    const name = `Preset: ${mainView} ${isSplitWorkspace ? `+ ${splitViewRight}` : ''}`;
    const next = [...presets, { id: Date.now().toString(), name, main: mainView, right: splitViewRight, split: isSplitWorkspace }];
    setPresets(next);
    localStorage.setItem("workspace-layout-presets", JSON.stringify(next));
  };

  const onLoadPreset = (preset: any) => {
    setMainView(preset.main);
    setSplitViewRight(preset.right);
    setIsSplitWorkspace(preset.split);
  };

  useEffect(() => {
    const handleGlobalKeys = (e: KeyboardEvent) => {
      // Cmd/Ctrl + K (Command Palette)
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setIsCmdPaletteOpen((prev) => !prev);
      }
      // Cmd/Ctrl + B (Toggle Left Sidebar)
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "b") {
        e.preventDefault();
        setLeftSidebarOpen((prev) => !prev);
      }
      // Cmd/Ctrl + S (Toggle Split View)
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "s") {
        e.preventDefault();
        setIsSplitWorkspace((prev) => !prev);
      }
    };
    window.addEventListener("keydown", handleGlobalKeys);
    return () => window.removeEventListener("keydown", handleGlobalKeys);
  }, []);

  const renderWorkspacePanel = (name: string) => {
    switch (name) {
      case "prime_architect":
        return <PrimeArchitectIDE />;
      case "code_surgeon":
        return (
          <PanelErrorBoundary panelName="Code Surgeon">
            <CodeSurgeonPanel />
          </PanelErrorBoundary>
        );
      case "nexus_os":
        return <NexusOperatingSystem />;
      case "god_mode_os":
        return <GodModeOS onNavigate={(id, isRight) => {
          if (isRight) {
            setIsSplitWorkspace(true);
            setSplitViewRight(id);
          } else {
            setMainView(id);
          }
        }} />;
      case "cog_nexus":
        return <CognitiveArchitectureNexus />;
      case "spatial_command":
        return <SpatialCommandArchitecture />;
      case "motorola_bridge":
        return <MotorolaHardwareBridge />;
      case "motorola_grid":
        return <MotorolaDataGrid />;
      case "fractal_expansion":
        return <FractalExpansionEngine />;
      case "myth_engine":
        return <MythEngine />;
      case "reality_compiler":
        return <RealityCompiler />;
      case "neuro_wormhole":
        return <NeurospatialWormhole />;
      case "evolution_roadmap":
        return <EvolutionRoadmap />;
      case "mlab":
        return <MlabStudio />;
      case "terminal":
        return <QuantumChat />;
      case "omniverse":
        return <OmniverseHyperStructure />;
      case "apex":
        return <ApexCoreOS />;
      case "abundance":
        return <AbundanceCompiler />;
      case "quantum_reality":
        return <QuantumFieldVisualizer />;
      case "dashboard":
        return <Dashboard />;
      case "logs":
        return <FieldLogs />;
      case "vault":
        return <SecurityVault />;
      case "curator":
        return <ContextCuratorUI />;
      case "sandbox":
        return <AutonomousSandbox />;
      case "agents":
        return <AutonomousAgents />;
      case "overseer":
        return <OverseerProtocol />;
      case "memory":
        return <TemporalMemoryVault />;
      case "forge_studio":
        return <ForgeStudio />;
      case "media_forge":
        return <MediaForge />;
      case "directives":
        return <DirectiveVault />;
      case "wealth":
        return <KineticWealth />;
      case "resistance":
        return <KineticResistanceEngine />;
      case "resonance":
        return <OrbitalResonance />;
      case "directives_architect":
        return <PrimeDirectivesOS />;
      case "sigils":
        return <BinarySigilManager />;
      case "arc_engine":
        return <InfluenceArcEngine />;
      case "environmental":
        return <EnvironmentalControls />;
      case "earth_grid":
        return <EarthObservationGrid />;
      case "cellular":
        return <CellularRejuvenationMatrix />;
      case "robotics":
        return <EmbodiedRoboticsInterface />;
      case "compression":
        return <OneBitCompressionEngine />;
      case "swarms":
        return <AgenticSwarmMatrix />;
      case "forecaster":
        return <TrendlineForecaster />;
      case "haptics":
        return <KineticHapticEngine />;
      case "physics":
        return <AnatomicalPhysicsRig />;
      case "atlas":
        return <MasterBlueprintAtlas />;
      case "environmental_tech":
        return <EnvironmentalTechGrid />;
      case "override":
        return <BiologicalOverride />;
      case "crucible":
        return <CrucibleProtocol />;
      case "neuroplasticity":
        return <NeuroplasticityEngine />;
      case "omni_nexus":
        return <OmniSingularityNexus />;
      case "metaconscious":
        return <MetaconsciousApotheosis />;
      case "sector_matrix":
        return <SectorMatrixHub />;
      case "device_sensors":
        return (
          <TelemetryGrid 
            flickerRate={60} 
            colorTemperature={5000} 
            intensity={80} 
            activeAcoustic="Stereo Monitor" 
            activePhotonic="Photonic Matrix" 
            activeAtmospheric="Standard" 
          />
        );
      case "ast_visualizer": return <ASTVisualizer />;
      case "advisin_matrix": return <AdvisinMatrix />;
      case "biomechanical_sandbox": return <BiomechanicalSandbox />;
      case "broadcast_engine": return <BroadcastEngine />;
      case "canvas_engine": return <CanvasEngine />;
      case "command_matrix": return <CommandMatrix />;
      case "command_nexus": return <CommandNexus />;
      case "curation_dashboard": return <CurationDashboard />;
      case "d3_flow_visualizer": return <D3FlowVisualizer />;
      case "director_interface": return <DirectorInterface />;
      case "economic_dashboard": return <EconomicDashboard />;
      case "game_bridge_monitor": return <GameBridgeMonitor />;
      case "healing_monitor": return <HealingMonitor />;
      case "memory_vault_ui": return <MemoryVaultUI />;
      case "neurochemical_dashboard": return <NeurochemicalDashboard />;
      case "overnight_report": return <OvernightReport />;
      case "parliament_viewer": return <ParliamentViewer />;
      case "quantum_builder": return <QuantumBuilder />;
      case "razor_monitor": return <RazorMonitor />;
      case "semantic_memory_monitor": return <SemanticMemoryMonitor />;
      case "sys_settings": return <SysSettings />;
      case "stability_monitor": return <StabilityMonitor />;
      case "swarm_monitor": return <SwarmMonitor />;
      case "system_health_monitor": return <SystemHealthMonitor />;
      case "void_monitor": return <VoidMonitor />;
      case "world_model": return <WorldModel />;
      case "main_sidebar_panel": return <MainSidebarPanel />;
      default:
        return <QuantumChat />;
    }
  };

  const [leftSidebarOpen, setLeftSidebarOpen] = useState(true);
  const [rightPanel, setRightPanel] = useState<string | null>(null);
  const [isFingerprintPrompt, setIsFingerprintPrompt] = useState(false);
  const [showPrimeSync, setShowPrimeSync] = useState(false);
  const [showOmniPortal, setShowOmniPortal] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [bridgeLoad, setBridgeLoad] = useState(0);

  useEffect(() => {
     // Cognitive Field Depth of Field heuristic simulate bridge load
     const loadInterval = setInterval(() => {
        setBridgeLoad(prev => Math.max(0, Math.min(1, prev + (Math.random() - 0.4) * 0.3)));
     }, 2000);
     return () => clearInterval(loadInterval);
  }, []);

  // Centralized state-to-Firestore auto-save sync debounced at 5 seconds
  useWorkspaceAutoSave(
    user?.uid,
    { mainView, splitViewRight, rightPanel, isSplitWorkspace, leftSidebarOpen },
    { setMainView, setSplitViewRight, setRightPanel, setIsSplitWorkspace, setLeftSidebarOpen }
  );

  const handlePortalNavigation = (type: "main" | "panel", id: any) => {
    if (type === "main") {
      setMainView(id);
    } else {
      setRightPanel(id);
    }
    setShowOmniPortal(false);
  };
  const [isAdmin, setIsAdmin] = useState(false);
  const activeNode = usePrimeStore((state) => state.activeNode);
  const setActiveNode = usePrimeStore((state) => state.setActiveNode);
  const activeProvider = usePrimeStore((state) => state.activeProvider);
  const setActiveProvider = usePrimeStore((state) => state.setActiveProvider);
  const daemonInsight = usePrimeStore((state) => state.daemonInsight);

  const [providerDropdownOpen, setProviderDropdownOpen] = useState(false);
  const [nodeDropdownOpen, setNodeDropdownOpen] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [tier, setTier] = useState<"free" | "Apex">("free");

  const userEmail = user?.email;
  const userUid = user?.uid;

  useEffect(() => {
    async function initializeUserNode() {
      if (userUid) {
        const isPrime = userEmail === "MarquisWhitacre@gmail.com";
        setTier(isPrime ? "Apex" : "free");
        if (isPrime) setIsAdmin(true);
      }
    }
    initializeUserNode();
  }, [userEmail, userUid, firebaseConnected]);

  const toggleRightPanel = (panel: string) => {
    if (rightPanel === panel) {
      setRightPanel(null);
    } else {
      setRightPanel(panel);
    }
  };

  const handleLogin = async (providerName: "google" | "github" | "discord") => {
    setLoading(true);
    try {
      const isOfflineMode = !auth || typeof auth.signInWithPopup !== "function";
      if (isOfflineMode) {
        setUser({
          uid: "offline-identity-key",
          email: "MarquisWhitacre@gmail.com",
          displayName: "Marquis Whitacre (Offline)",
          photoURL: null,
        });
        setFirebaseConnected(false);
      } else {
        const provider = new GoogleAuthProvider();
        provider.setCustomParameters({ prompt: "select_account" });
        const result = await signInWithPopup(auth, provider);
        const loggedUser = result.user;
        setUser(loggedUser);
        setFirebaseConnected(true);
        console.log("[AUTH LOG] Real Google Account handshake complete:", loggedUser.email);
      }
    } catch (err) {
      console.warn("[AUTH WARNING] Real Google auth canceled or restricted. Activating offline fallback:", err);
      setUser({
        uid: "offline-identity-key",
        email: "MarquisWhitacre@gmail.com",
        displayName: "Marquis Whitacre (Offline)",
        photoURL: null,
      });
      setFirebaseConnected(false);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex h-[100dvh] bg-[#0a0a0a] text-white items-center justify-center font-mono">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-2 border-dashed border-fuchsia-500 border-t-transparent animate-[spin_3s_linear_infinite] rounded-full flex items-center justify-center">
            <div className="w-6 h-6 border-2 border-purple-400 border-b-transparent animate-[spin_1.5s_linear_infinite_reverse] rounded-full" />
          </div>
          <div className="text-sm tracking-widest text-fuchsia-400 font-bold uppercase mt-4">Nexus OS Daemon IS WAKING...</div>
          <div className="text-[10px] text-gray-500 font-mono">Calibrating Sector Matrix Hubs...</div>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="flex flex-col h-[100dvh] bg-[#0a0a0a] text-white items-center justify-center font-sans px-4 relative overflow-hidden">
        <div className="bg-grid-pulse" />
        <h1 className="text-3xl font-bold tracking-tight mb-2 z-10 text-center flex items-center gap-3">
          <span className="text-fuchsia-500 font-mono">❖</span> Identity Access Matrix
        </h1>
        <p className="text-gray-400 text-sm mb-6 z-10 font-mono tracking-widest uppercase">Awaiting Quantum Biometric Sync</p>
        <div className="flex flex-col gap-3 w-full max-w-[280px] z-10">
          <button
            onClick={() => handleLogin("google")}
            className="flex items-center justify-center gap-3 bg-white hover:bg-gray-200 text-black px-6 py-3 rounded-lg font-semibold w-full transition-all hover:scale-[1.02] shadow-[0_0_20px_rgba(255,255,255,0.1)] hover:shadow-[0_0_30px_rgba(255,255,255,0.2)]"
          >
            <svg viewBox="0 0 24 24" className="w-5 h-5">
               <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
               <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
               <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
               <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
             </svg>
            Connect via Google
          </button>
        </div>
      </div>
    );
  }

  const isPrimeNode = isAdmin;

  const handleKillswitch = async () => {
    setIsFingerprintPrompt(true);
    setTimeout(() => {
      setIsFingerprintPrompt(false);
      alert(
        "✅ BIOMETRIC SIGNATURE VERIFIED.\n\nOBSIDIAN DEAD MAN SWITCH ACTIVATED.",
      );
    }, 1500);
  };

  return (
    <div 
      className="flex h-[100dvh] bg-[#0a0a0a] text-gray-200 font-sans overflow-hidden relative w-full"
      style={{
        paddingTop: "env(safe-area-inset-top, 0px)",
        paddingBottom: "env(safe-area-inset-bottom, 0px)"
      }}
    >
      <div className="bg-grid-pulse" />
      {leftSidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-20 md:hidden backdrop-blur-sm"
          onClick={() => setLeftSidebarOpen(false)}
        />
      )}

      <AnimatePresence initial={false}>
        {leftSidebarOpen && (
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: 256 }}
            exit={{ width: 0 }}
            transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
            className="absolute md:relative inset-y-0 left-0 flex flex-col bg-[#111111] border-r border-[#222222] z-30 shrink-0 overflow-hidden shadow-2xl md:shadow-none"
          >
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3, delay: 0.1, ease: "easeOut" }}
              className="w-64 flex flex-col h-full"
            >
              <div className="p-4 flex items-center justify-between border-b border-[#222222] h-14 shrink-0">
                <h1 className="font-semibold text-fuchsia-400 text-xs tracking-widest uppercase flex items-center gap-2">
                  <Orbit className="w-4 h-4 flex-shrink-0" />
                  God Mode OS
                </h1>
                <button
                  className="md:hidden p-1 text-gray-400 hover:text-white"
                  onClick={() => setLeftSidebarOpen(false)}
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <SidebarNavList
                mainView={mainView}
                rightPanel={rightPanel}
                isPrimeNode={isPrimeNode}
                user={user}
                onLogin={() => handleLogin("google")}
                setMainView={setMainView}
                setRightPanel={setRightPanel}
                toggleRightPanel={toggleRightPanel}
                onSignOut={() => {
                  setUser(null);
                  setFirebaseConnected(false);
                }}
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex-1 flex flex-col min-w-0 bg-[#0a0a0a] w-full relative h-[100dvh] overflow-hidden">
        <header className="min-h-[56px] flex items-center justify-between px-3 md:px-4 py-2 border-b border-[#222222] shrink-0 bg-[#070707] z-10 w-full relative gap-3 shadow-md max-w-full">
          <div className="flex items-center gap-2 md:gap-3 flex-wrap p-1 no-scrollbar flex-1">
            <button
              onClick={() => setLeftSidebarOpen(!leftSidebarOpen)}
              className="px-3 py-2 shrink-0 flex items-center gap-2 border border-[#444] tracking-widest text-[11px] uppercase font-bold text-gray-200 hover:text-white bg-[#1a1a1a] hover:bg-[#2a2a2a] rounded-lg transition-all shadow-md focus:ring-2 focus:ring-fuchsia-500/50"
              title="Open God Mode OS Sidebar"
            >
              <Menu className="w-4 h-4 text-fuchsia-500" />
              <span>GOD MODE OS</span>
            </button>

            <button
              onClick={() => setMainView("terminal")}
              className={`shrink-0 flex items-center gap-2 px-3 py-2 border rounded-lg transition-all shadow-md focus:ring-2 focus:ring-cyan-500/50 ${mainView === "terminal" ? "bg-cyan-900/60 border-cyan-400 text-white" : "bg-[#111] border-[#444] text-gray-300 hover:bg-[#1a1a1a] hover:border-[#555]"}`}
              title="Open Quantum Chat"
            >
              <Orbit className={`w-4 h-4 ${mainView === "terminal" ? "text-cyan-300" : "text-fuchsia-400"}`} />
              <span className="font-bold text-[11px] tracking-widest uppercase">
                QUANTUM CHAT
              </span>
            </button>

            <button
              onClick={() => setMainView("omniverse")}
              className={`shrink-0 flex items-center gap-2 px-3 py-2 border rounded-lg transition-all font-bold text-[11px] uppercase tracking-widest shadow-md focus:ring-2 focus:ring-amber-500/50 ${mainView === "omniverse" ? "bg-fuchsia-900/60 border-fuchsia-400 text-fuchsia-200" : "bg-[#111] border-[#444] text-gray-300 hover:text-white hover:bg-[#1a1a1a] hover:border-[#555]"}`}
              title="Open Omniverse Dashboard"
            >
              <Sparkles className={`w-4 h-4 ${mainView === "omniverse" ? "text-fuchsia-300" : "text-amber-500"}`} />
              <span>OMNIVERSE</span>
            </button>
          </div>
          
          <div className="flex items-center gap-3 shrink-0 ml-auto pointer-events-auto">
            {daemonInsight ? (
              <div className="hidden lg:flex items-center gap-2 px-3 py-1.5 rounded-lg border border-purple-500/50 bg-[#110522] text-[10px] font-mono shadow-[0_0_10px_rgba(168,85,247,0.3)]">
                <span className="w-2 h-2 rounded-full bg-purple-500 animate-pulse shadow-[0_0_8px_#a855f7] inline-block" />
                <span className="text-purple-300 tracking-widest leading-none drop-shadow-[0_0_3px_rgba(168,85,247,0.5)]">
                  {daemonInsight}
                </span>
              </div>
            ) : null}

            {/* Real-time Device Sync Heartbeat */}
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg border border-[#333] bg-[#0a0a0a] text-xs font-mono font-medium">
              <div className="relative flex items-center justify-center w-3 h-3">
                <span className="absolute inline-flex w-full h-full rounded-full bg-emerald-400 opacity-75 animate-ping" />
                <span className="relative inline-flex w-2 h-2 rounded-full bg-emerald-500" />
              </div>
              <span className="text-gray-400">EDGE_NODE:</span>
              <span className="text-emerald-400">SYNCED</span>
            </div>

            <button
              onClick={() => setIsSplitWorkspace((prev) => !prev)}
              className={`px-3 py-1.5 rounded-lg border text-xs font-mono font-medium transition-all flex items-center gap-1.5 ${
                isSplitWorkspace
                  ? "bg-purple-900/40 border-purple-500/50 text-purple-300 shadow-md shadow-purple-500/10"
                  : "bg-[#111] border-[#333] text-gray-400 hover:text-white"
              }`}
              title="Toggle Parallel Split-View Workspace"
            >
              <LayoutDashboard className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{isSplitWorkspace ? "SPLIT ACTIVE" : "SPLIT VIEW"}</span>
            </button>
            <StatusBar />
          </div>
        </header>

        <div className="flex-1 overflow-hidden relative flex">
          <ErrorBoundary>
            <React.Suspense fallback={
              <div className="flex h-full w-full flex-col items-center justify-center font-mono text-purple-400 gap-3 bg-[#0a0a0a]">
                <div className="w-5 h-5 border-2 border-purple-500 border-t-transparent animate-spin rounded-full"></div>
                <div className="h-0.5 w-32 bg-gray-800 rounded-full overflow-hidden">
                   <div className="h-full bg-purple-500 animate-[pulse_1s_ease-in-out_infinite]" style={{ width: '100%' }}></div>
                </div>
                <span className="text-xs">Loading panel module...</span>
              </div>
            }>
              <div className={`w-full h-full flex flex-col md:flex-row overflow-hidden ${isSplitWorkspace ? 'divide-y md:divide-y-0 md:divide-x divide-[#222]' : ''}`}>
                <motion.div
                  layout
                  transition={{ type: "spring", stiffness: 300, damping: 30 }}
                  className={`relative overflow-hidden transition-all ${
                    isSplitWorkspace ? "flex-1" : "w-full"
                  } ${isHoveringLeft ? "bg-purple-950/25 ring-2 ring-purple-500 ring-dashed" : ""}`}
                  onDragOver={(e) => e.preventDefault()}
                  onDragEnter={() => setIsHoveringLeft(true)}
                  onDragLeave={() => setIsHoveringLeft(false)}
                  onDrop={(e) => {
                    e.preventDefault();
                    setIsHoveringLeft(false);
                    const draggedId = e.dataTransfer.getData("text/plain");
                    if (draggedId) setMainView(draggedId as any);
                  }}
                >
                  {isSplitWorkspace && (
                    <div className="absolute top-2 right-2 z-10 px-2 py-0.5 rounded bg-black/60 border border-[#222]/80 text-[10px] text-gray-400 font-mono select-none uppercase tracking-wider shadow-lg">
                      Panel A • {mainView}
                    </div>
                  )}
                  <div className={`w-full h-full overflow-y-auto ${isSplitWorkspace ? "pt-8" : ""}`}>
                    <AnimatePresence mode="wait">
                      <motion.div
                        key={mainView}
                        initial={{ opacity: 0, scale: isSplitWorkspace ? 0.95 : 0.7, filter: isSplitWorkspace ? 'blur(10px)' : 'blur(30px)' }}
                        animate={{ opacity: 1, scale: 1, filter: `blur(0px)` }}
                        exit={{ opacity: 0, scale: isSplitWorkspace ? 1.05 : 1.3, filter: isSplitWorkspace ? 'blur(10px)' : 'blur(30px)' }}
                        transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                        className="w-full h-full origin-center"
                      >
                        {renderWorkspacePanel(mainView)}
                      </motion.div>
                    </AnimatePresence>
                  </div>
                </motion.div>

                <AnimatePresence>
                  {isSplitWorkspace && (
                    <motion.div
                      layout
                      initial={{ opacity: 0, flex: 0 }}
                      animate={{ opacity: 1, flex: 1 }}
                      exit={{ opacity: 0, flex: 0 }}
                      transition={{ type: "spring", stiffness: 300, damping: 30 }}
                      className={`relative overflow-hidden transition-all ${
                        isHoveringRight ? "bg-indigo-950/25 ring-2 ring-indigo-500 ring-dashed" : ""
                      }`}
                      onDragOver={(e) => e.preventDefault()}
                      onDragEnter={() => setIsHoveringRight(true)}
                      onDragLeave={() => setIsHoveringRight(false)}
                      onDrop={(e) => {
                        e.preventDefault();
                        setIsHoveringRight(false);
                        const draggedId = e.dataTransfer.getData("text/plain");
                        if (draggedId) setSplitViewRight(draggedId);
                      }}
                    >
                      <div className="absolute top-2 right-2 z-10 px-2 py-0.5 rounded bg-black/60 border border-[#222]/80 text-[10px] text-gray-400 font-mono select-none uppercase tracking-wider shadow-lg">
                        Panel B • {splitViewRight}
                      </div>
                      <div className="w-full h-full overflow-y-auto pt-8">
                        <AnimatePresence mode="wait">
                          <motion.div
                            key={splitViewRight}
                            initial={{ opacity: 0, scale: 0.95, filter: 'blur(10px)' }}
                            animate={{ opacity: 1, scale: 1, filter: `blur(0px)` }}
                            exit={{ opacity: 0, scale: 1.05, filter: 'blur(10px)' }}
                            transition={{ duration: 0.3, ease: 'circOut' }}
                            className="w-full h-full origin-center"
                          >
                            {renderWorkspacePanel(splitViewRight)}
                          </motion.div>
                        </AnimatePresence>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </React.Suspense>
          </ErrorBoundary>
        </div>
      </div>

      {rightPanel && (
        <div className="w-[450px] border-l border-[#222] bg-[#111] overflow-y-auto shrink-0 z-20">
          <div className="flex justify-between p-4 border-b border-[#222]">
            <h2 className="font-semibold text-gray-300 uppercase tracking-widest text-xs font-mono">
              {rightPanel === "device_sensors" ? "Hardware & Sensor Bridge" : String(rightPanel).replace("_", " ")}
            </h2>
            <button onClick={() => setRightPanel(null)}>
              <PanelRightClose className="w-5 h-5 text-gray-400 hover:text-white" />
            </button>
          </div>
          <div className="flex-1 w-full h-[calc(100vh-60px)] overflow-y-auto">
            <ErrorBoundary>
              <React.Suspense fallback={
                <div className="flex h-40 w-full flex-col items-center justify-center font-mono text-xs text-[#a855f7] gap-2.5">
                  <div className="w-3 h-3 border border-purple-500 border-t-transparent animate-spin rounded-full"></div>
                  <span>Reconstructing Vector Node...</span>
                </div>
              }>
                {rightPanel === "dashboard" && <Dashboard />}
                {rightPanel === "logs" && <FieldLogs />}
                {rightPanel === "vault" && <SecurityVault />}
                {rightPanel === "sandbox" && <AutonomousSandbox />}
                {rightPanel === "agents" && <AutonomousAgents />}
                {rightPanel === "overseer" && <OverseerProtocol />}
                {rightPanel === "memory" && <TemporalMemoryVault />}
                {rightPanel === "forge_studio" && <ForgeStudio />}
                {rightPanel === "media_forge" && <MediaForge />}
                {rightPanel === "directives" && <DirectiveVault />}
                {rightPanel === "wealth" && <KineticWealth />}
                {rightPanel === "resistance" && <KineticResistanceEngine />}
                {rightPanel === "resonance" && <OrbitalResonance />}
                {rightPanel === "directives_architect" && <PrimeDirectivesOS />}
                {rightPanel === "sigils" && <BinarySigilManager />}
                {rightPanel === "arc_engine" && <InfluenceArcEngine />}
                {rightPanel === "settings_modal" && <SettingsModal onClose={() => setRightPanel(null)} />}
                {rightPanel === "environmental" && <EnvironmentalControls />}
                {rightPanel === "override" && <BiologicalOverride />}
                {rightPanel === "crucible" && <CrucibleProtocol />}
                {rightPanel === "neuroplasticity" && <NeuroplasticityEngine />}
                {rightPanel === "omni_nexus" && <OmniSingularityNexus />}
                {rightPanel === "metaconscious" && <MetaconsciousApotheosis />}
                {rightPanel === "harmonic_engine" && <HarmonicStateEngine />}
                {rightPanel === "multiverse_grid" && <MultiverseTimelineGrid />}
                {rightPanel === "artifact_vault" && <ArtifactVault />}
                {rightPanel === "graviton_node" && <GravitonControlNode />}
                {rightPanel === "sector_matrix" && <SectorMatrixHub />}
                {rightPanel === "device_sensors" && (
                  <TelemetryGrid 
                    flickerRate={60} 
                    colorTemperature={5000} 
                    intensity={80} 
                    activeAcoustic="Stereo Monitor" 
                    activePhotonic="Photonic Matrix" 
                    activeAtmospheric="Standard" 
                  />
                )}
              </React.Suspense>
            </ErrorBoundary>
          </div>
        </div>
      )}

      {showOmniPortal && (
        <AutonomousNavigationMatrix
          onClose={() => setShowOmniPortal(false)}
          onNavigate={handlePortalNavigation}
          activeMain={mainView}
          activePanel={rightPanel}
        />
      )}

      <CommandPalette
        isOpen={isCmdPaletteOpen}
        onClose={() => setIsCmdPaletteOpen(false)}
        onNavigate={(viewId, isRight) => {
          if (isRight) {
            setRightPanel(viewId);
          } else {
            setMainView(viewId as any);
          }
        }}
        onToggleLeftSidebar={() => setLeftSidebarOpen(!leftSidebarOpen)}
        onToggleSplitView={() => setIsSplitWorkspace(!isSplitWorkspace)}
        onTriggerKillSwitch={() => handleKillswitch()}
        presets={presets}
        onLoadPreset={onLoadPreset}
        onSavePreset={onSavePreset}
      />

      <GlobalErrorPanel />
    </div>
  );
}
