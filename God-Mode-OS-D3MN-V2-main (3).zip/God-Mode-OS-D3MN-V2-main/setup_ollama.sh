#!/bin/bash
set -e

# Nexus God Mode OS OLLAMA Setup
echo "[NEXUS] Bootstrapping local AI Vector Grid..."

# 1. Install Ollama
curl -fsSL https://ollama.com/install.sh | sh

# Enable CORS for browser requests
export OLLAMA_ORIGINS="*"

# 2. Start Server (if systemd isn't already running it)
if ! systemctl is-active --quiet ollama; then
    echo "[NEXUS] Activating local LLM server..."
    ollama serve &
    # Wait for server to be ready
    sleep 5
else
    echo "[NEXUS] Ollama service already running."
fi

# 3. Pull specialized models
echo "[NEXUS] Pulling BANNON-optimized base model (qwen2.5-coder:14b)..."
ollama pull qwen2.5-coder:14b

# 4. Create Bannon Custom Model
echo "[NEXUS] Fusing custom model bannon-nexus..."
ollama create bannon-nexus -f ./Bannon.Modelfile

echo "[SUCCESS] Nexus local brain operational on port 11434 with model bannon-nexus."
