  // pitch, which reads as the body briefly popping right-side-up ("I-pose") mid-drop. These three
  // are TOSS-tier inversion arcs, not slam-tier, regardless of their damage `type` classification.
  const _vsuplexFamily = (this.grapplePos==='VERTICAL_SUPLEX'||this.grapplePos==='TIGER_SUPLEX'||this.grapplePos==='DRAGON_SUPLEX');
  const _eliteCovered = (window.ELITE_MOVES && ['CANADIAN_DESTROYER','DDT','BUTTERFLY_DDT','TIGER_DRIVER','BRAINBUSTER','VERTICAL_SUPLEX','ELECTRIC_CHAIR'].indexOf(this.grapplePos)>=0);
  if ((this.isPlayer || this.opts) && !_eliteCovered) announce(variant.label + (isBridge?' — BRIDGE':''), this.isPlayer?'BANNON':this.opts.name);
