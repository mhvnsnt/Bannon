const fs = require('fs');
let code = fs.readFileSync('index.html', 'utf8');

// We will inject new bricks at the end, just before </body></html>.
let bricks = `<script>
/* BANNON SYSTEM BRICK 69 — OPEN DYNAMICS ENGINE (ODE) ABSOLUTE STABILITY DAEMON */
(function() {
  if (typeof Fighter === 'undefined') return;

  const _origUR = Fighter.prototype.updateRagdoll;
  if (_origUR) {
    Fighter.prototype.updateRagdoll = function(dt) {
      
      // NaN EXORCIST FIREWALL
      if (this.V) {
         for (const j in this.V) {
            const v = this.V[j];
            if (v && v.pos) {
               if (!isFinite(v.pos.x) || !isFinite(v.pos.y) || !isFinite(v.pos.z)) {
                  const safeWp = this.worldJoint ? this.worldJoint(j) : {x: this.x, y: 1.0, z: this.z};
                  
                  if (safeWp && isFinite(safeWp.x) && isFinite(safeWp.y) && isFinite(safeWp.z)) {
                     v.pos.x = safeWp.x; v.pos.y = safeWp.y; v.pos.z = safeWp.z;
                     v.old.x = safeWp.x; v.old.y = safeWp.y; v.old.z = safeWp.z;
                  } else {
                     v.pos.x = this.x || 0; v.pos.y = 1.0; v.pos.z = this.z || 0;
                     v.old.x = this.x || 0; v.old.y = 1.0; v.old.z = this.z || 0;
                  }
               }
            }
         }
      }

      _origUR.call(this, dt);
      
      if (this.V) {
         for (const j in this.V) {
            const v = this.V[j];
            if (v && v.pos) {
               if (!isFinite(v.pos.x) || !isFinite(v.pos.y) || !isFinite(v.pos.z)) {
                  v.pos.x = this.x || 0; v.pos.y = 1.0; v.pos.z = this.z || 0;
                  v.old.x = v.pos.x; v.old.y = v.pos.y; v.old.z = v.pos.z;
               }
            }
         }
      }
    };
  }
  try {
    window.MANIFESTO && window.MANIFESTO.register({
      key: 'brick69.ode_stability_daemon',
      kind: 'physics-stability',
      summary: 'Open Dynamics Engine absolute NaN / Infinity firewall. Completely eradicates game-breaking structural explosions / spaghetti limbs.',
      call: 'Fighter.prototype.updateRagdoll matrix sanitize'
    });
  } catch(e) {}
  console.log('%c[BANNON · BRICK 69] OPEN DYNAMICS ENGINE: NaN / INFINITY FIREWALL ONLINE', 'color:#00ffcc;font-weight:bold;background:#000;padding:3px 8px');
})();

/* BANNON SYSTEM BRICK 70 — OVERGROWTH JOINT STRESS DEFORMATION */
(function() {
  if (typeof Fighter === 'undefined') return;

  const _origAR = Fighter.prototype.updateActiveRagdoll;
  if (_origAR) {
    Fighter.prototype.updateActiveRagdoll = function(dt) {
      
      _origAR.call(this, dt);
      
      if (this.J && this._arV) {
         if (this.state === 'hurt' || this.state === 'flinch' || this.state === 'stumble') {
             const stressMultiplier = Math.min(1.0, (this._stumbleMag || 0.5) * 1.5);
             
             for (const h of ['haL', 'haR', 'ftL', 'ftR']) {
                 const kinematic = this.J[h];
                 const physical = this._arV[h];
                 if (kinematic && physical && physical.pos && isFinite(physical.pos.x)) {
                     kinematic.pos.lerp(physical.pos, stressMultiplier * 0.3 * dt);
                 }
             }
         }
      }
    };
  }
  try {
    window.MANIFESTO && window.MANIFESTO.register({
      key: 'brick70.overgrowth_stress_deformation',
      kind: 'physics-stability',
      summary: 'Overgrowth joint stress mapping. Physically pulls the visible kinematic skeleton toward the active ragdoll coordinates during stagger states.',
      call: 'Fighter.prototype.updateActiveRagdoll append'
    });
  } catch(e) {}
  console.log('%c[BANNON · BRICK 70] OVERGROWTH: JOINT STRESS DEFORMATION ONLINE', 'color:#00ffcc;font-weight:bold;background:#000;padding:3px 8px');
})();

/* BANNON SYSTEM BRICK 71 — TORIBASH KINETIC ENERGY SLAM INJECTION */
(function() {
  if (typeof Fighter === 'undefined') return;

  const _origSlamKin = Fighter.prototype._slamVictimKin;
  if (_origSlamKin) {
    Fighter.prototype._slamVictimKin = function(by) {
      _origSlamKin.call(this, by);
      if (this.V && this.ragdoll) {
          const dt = 1/60;
          const e = by.grappleStage;
          if (e > 0.5) { 
             const chest = this.V['chest'];
             const head = this.V['head'];
             const oppMass = by.spec && by.spec.build ? by.spec.build : 1.0;
             const ballisticForce = 1.2 * oppMass;
             
             if (chest) chest.impulse(0, -ballisticForce * dt, 0);
             if (head) head.impulse(0, -(ballisticForce * 1.5) * dt, 0);
          }
      }
    };
  }
  try {
    window.MANIFESTO && window.MANIFESTO.register({
      key: 'brick71.toribash_kinetic_slams',
      kind: 'physics-stability',
      summary: 'Toribash kinetic energy slam injection. Pre-loads physical momentum into the victims ragdoll nodes at the apex of a slam.',
      call: 'Fighter.prototype._slamVictimKin append'
    });
  } catch(e) {}
  console.log('%c[BANNON · BRICK 71] TORIBASH: KINETIC ENERGY SLAM INJECTION ONLINE', 'color:#00ffcc;font-weight:bold;background:#000;padding:3px 8px');
})();

/* BANNON SYSTEM BRICK 72 — BARE METTLE CENTER OF MASS WEAPONIZATION V2 */
(function() {
  if (typeof Fighter === 'undefined') return;

  const _origHit = Fighter.prototype.applyHit;
  if (_origHit) {
    Fighter.prototype.applyHit = function(dmg, region, atk) {
      _origHit.call(this, dmg, region, atk);
      if (dmg > 8.0 && region === 'HEAD' && !this.ragdoll && this._arSeed) {
         if (this._arV && this._arV['head'] && this._arV['chest']) {
             const dx = (atk.dir && atk.dir.x) ? -atk.dir.x : (Math.random() > 0.5 ? 1 : -1);
             const dz = (atk.dir && atk.dir.z) ? -atk.dir.z : -1;
             const violence = (dmg / 10.0) * 0.15;
             this._arV['head'].impulse(dx * violence, 0.05, dz * violence);
             this._arV['chest'].impulse(dx * (violence * 0.5), -0.02, dz * (violence * 0.5));
         }
      }
    };
  }
  try {
    window.MANIFESTO && window.MANIFESTO.register({
      key: 'brick72.baremettle_com_disruption',
      kind: 'physics-stability',
      summary: 'Bare Mettle Exanima motor disruption. Severe head trauma temporarily disables upper-body kinematic matching, allowing unscripted knockback snaps.',
      call: 'Fighter.prototype.applyHit active-ragdoll disruption'
    });
  } catch(e) {}
  console.log('%c[BANNON · BRICK 72] BARE METTLE (EXANIMA): CORE MOTOR SHUTDOWN ONLINE', 'color:#00ffcc;font-weight:bold;background:#000;padding:3px 8px');
})();

/* BANNON SYSTEM BRICK 73 — UNITY CONFIGURABLE JOINTS (ROTATION CLAMP) */
(function() {
  if (typeof Fighter === 'undefined') return;
  const _origSolveIK = Fighter.prototype.solveLimbIK;
  if (_origSolveIK) {
     Fighter.prototype.solveLimbIK = function() {
       _origSolveIK.call(this);
       if (this.J && this.state === 'attack' && this.attackPhase > 0.5) {
          const hL = this.J['haL']; const shL = this.J['shL'];
          const hR = this.J['haR']; const shR = this.J['shR'];
          
          if (hL && shL && hL.pos.distanceTo(shL.pos) > 0.4) {
              if (this.J['elL'] && this.J['elL'].pos.z > shL.pos.z + 0.1) {
                  this.J['elL'].pos.z -= 0.05;
              }
          }
          if (hR && shR && hR.pos.distanceTo(shR.pos) > 0.4) {
              if (this.J['elR'] && this.J['elR'].pos.z > shR.pos.z + 0.1) {
                  this.J['elR'].pos.z -= 0.05;
              }
          }
       }
     };
  }
  try {
    window.MANIFESTO && window.MANIFESTO.register({
      key: 'brick73.unity_angular_clamp',
      kind: 'physics-stability',
      summary: 'Unity configurable joint angular clamping. Locks arm rotational planes during maximum extension of strikes to prohibit inward-snapped elbow glitches.',
      call: 'Fighter.prototype.solveLimbIK append'
    });
  } catch(e) {}
  console.log('%c[BANNON · BRICK 73] UNITY CONFIGURABLE JOINTS: ANGULAR CLAMP ONLINE', 'color:#00ffcc;font-weight:bold;background:#000;padding:3px 8px');
})();

/* BANNON SYSTEM BRICK 74 — ACTIVE RAGDOLL ABSOLUTE FIREWALL */
(function() {
  if (typeof Fighter === 'undefined') return;

  const _origAR = Fighter.prototype.updateActiveRagdoll;
  if (_origAR) {
    Fighter.prototype.updateActiveRagdoll = function(dt) {
      if (this._arV) {
         for (const j in this._arV) {
            const v = this._arV[j];
            if (v && v.pos) {
               if (!isFinite(v.pos.x) || !isFinite(v.pos.y) || !isFinite(v.pos.z)) {
                  const safeWp = this.worldJoint ? this.worldJoint(j) : {x: this.x, y: 1.0, z: this.z};
                  if (safeWp && isFinite(safeWp.x) && isFinite(safeWp.y) && isFinite(safeWp.z)) {
                     v.pos.x = safeWp.x; v.pos.y = safeWp.y; v.pos.z = safeWp.z;
                     v.old.x = safeWp.x; v.old.y = safeWp.y; v.old.z = safeWp.z;
                  } else {
                     v.pos.x = this.x || 0; v.pos.y = 1.0; v.pos.z = this.z || 0;
                     v.old.x = this.x || 0; v.old.y = 1.0; v.old.z = this.z || 0;
                  }
               }
            }
         }
      }
      _origAR.call(this, dt);
      if (this._arV) {
         for (const j in this._arV) {
            const v = this._arV[j];
            if (v && v.pos) {
               if (!isFinite(v.pos.x) || !isFinite(v.pos.y) || !isFinite(v.pos.z)) {
                  v.pos.x = this.x || 0; v.pos.y = 1.0; v.pos.z = this.z || 0;
                  v.old.x = v.pos.x; v.old.y = v.pos.y; v.old.z = v.pos.z;
               }
            }
         }
      }
    };
  }
  try {
    window.MANIFESTO && window.MANIFESTO.register({
      key: 'brick74.ar_stability_daemon',
      kind: 'physics-stability',
      summary: 'Active Ragdoll NaN Exorcist. Applies the Open Dynamics Engine absolute stability daemon to the persistent active ragdoll layer as well as the fallback layer.',
      call: 'Fighter.prototype.updateActiveRagdoll matrix sanitize'
    });
  } catch(e) {}
  console.log('%c[BANNON · BRICK 74] ACTIVE RAGDOLL FIREWALL ONLINE', 'color:#00ffcc;font-weight:bold;background:#000;padding:3px 8px');
})();
</script>`;

code = code.replace('</body></html>', bricks + '\n</body></html>');
fs.writeFileSync('index.html', code);
console.log("Injected Bricks 69-74 cleanly.");
