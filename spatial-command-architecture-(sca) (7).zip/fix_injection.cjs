const fs = require('fs');
let code = fs.readFileSync('index.html', 'utf8');

const startIdx = code.indexOf('/* BANNON SYSTEM BRICK 69');
const endMarker = '/* BANNON SYSTEM BRICK 73';
let endIdx = code.indexOf('})();\n', code.indexOf(endMarker));

if (endIdx !== -1 && startIdx !== -1) {
    endIdx += 6; // length of '})();\n'
    let bricksCode = code.substring(startIdx, endIdx);
    
    // Remove from top
    code = code.substring(0, startIdx) + code.substring(endIdx);
    
    // Remove the early </body></html>
    code = code.replace('</body></html>', '');
    
    // Put at the very bottom
    code = code.replace('</script>\n</body></html>', '\n' + bricksCode + '\n</script>\n</body></html>');
    
    fs.writeFileSync('index.html', code);
    console.log("Moved bricks successfully");
} else {
    console.log("Could not find bricks");
}
