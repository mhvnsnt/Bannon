const fs = require('fs');
let code = fs.readFileSync('index.html', 'utf8');

// We will inject new bricks at the end, just before </script>\n</body></html>.

let bricks = `
/* BANNON SYSTEM BRICK 69 — OPEN DYNAMICS ENGINE (ODE) ABSOLUTE STABILITY DAEMON */
(function() {
  if (typeof Fighter === 'undefined') return;

  const _origUR = Fighter.prototype.updateRagdoll;
  if (_origUR) {
    Fighter.prototype.updateRagdoll = function(dt) {
      
      // NaN EXORCIST FIREWALL
      // Physics engines die instantly if NaN enters the matrix.
      // This firewall scans every vertex prior to integration. If NaN or Infinity is detected,
      // the node is instantly reconstructed from the kinematic skeleton, erasing the corruption frame-perfectly.
      if (this.V) {
         for (const j in this.V) {
            const v = this.V[j];
            if (v && v.pos) {
               if (!isFinite(v.pos.x) || !isFinite(v.pos.y) || !isFinite(v.pos.z)) {
                  // Catastrophic physics failure detected (The Spaghetti Monster)
                  // Reconstruct this node dynamically from the procedural anim skeleton
                  const safeWp = this.worldJoint ? this.worldJoint(j) : {x: this.x, y: 1.0, z: this.z};
                  
                  if (safeWp && isFinite(safeWp.x) && isFinite(safeWp.y) && isFinite(safeWp.z)) {
                     v.pos.x = safeWp.x;
                     v.pos.y = safeWp.y;
                     v.pos.z = safeWp.z;
                     v.old.x = safeWp.x;
                     v.old.y = safeWp.y;
                     v.old.z = safeWp.z;
                  } else {
                     // Failsafe of failsafes
                     v.pos.x = this.x || 0;
                     v.pos.y = 1.0;
                     v.pos.z = this.z || 0;
                     v.old.x = this.x || 0;
                     v.old.y = 1.0;
                     v.old.z = this.z || 0;
                  }
               }
            }
         }
      }

      // Execute actual Verlet solver
      _origUR.call(this, dt);
      
      // VELOCITY TERMINATION DAEMON
      // Catch any node that integrated into a NaN/Infinity state during the solver constraints
      if (this.V) {
         for (const j in this.V) {
            const v = this.V[j];
            if (v && v.pos) {
               if (!isFinite(v.pos.x) || !isFinite(v.pos.y) || !isFinite(v.pos.z)) {
                  // Failsafe
                  v.pos.x = this.x || 0; v.pos.y = 1.0; v.pos.z = this.z || 0;
                  v.old.x = v.pos.x; v.old.y = v.pos.y; v.old.z = v.pos.z;
               }
            }
         }
      }
    };
  }

  try {
    window.MANIFESTO && window.MANIFESTO.register({
      key: 'brick69.ode_stability_daemon',
      kind: 'physics-stability',
      summary: 'Open Dynamics Engine absolute NaN / Infinity firewall. Completely eradicates game-breaking structural explosions / spaghetti limbs by sanitizing and reconstructing missing vertices frame-perfectly.',
      call: 'Fighter.prototype.updateRagdoll matrix sanitize'
    });
  } catch(e) {}
  console.log('%c[BANNON · BRICK 69] OPEN DYNAMICS ENGINE: NaN / INFINITY FIREWALL ONLINE', 'color:#00ffcc;font-weight:bold;background:#000;padding:3px 8px');
})();

/* BANNON SYSTEM BRICK 70 — OVERGROWTH JOINT STRESS DEFORMATION */
(function() {
  if (typeof Fighter === 'undefined') return;

  const _origAR = Fighter.prototype.updateActiveRagdoll;
  if (_origAR) {
    Fighter.prototype.updateActiveRagdoll = function(dt) {
      
      _origAR.call(this, dt);

      // Overgrowth raw physics weight integration
      // When characters hit each other, or ground, joints get physically compressed.
      // This brick maps raw Verlets back into the kinematic joints (which otherwise run independently),
      // ensuring that physics hits visually affect the actual mesh immediately.
      
      if (this.J && this._arV) {
         // Apply physical joint lagging / dragging on non-pinned extremities during hits
         if (this.state === 'hurt' || this.state === 'flinch' || this.state === 'stumble') {
             const stressMultiplier = Math.min(1.0, (this._stumbleMag || 0.5) * 1.5);
             
             for (const h of ['haL', 'haR', 'ftL', 'ftR']) {
                 const kinematic = this.J[h];
                 const physical = this._arV[h];
                 
                 if (kinematic && physical && physical.pos && isFinite(physical.pos.x)) {
                     // Drag the kinematic target toward the true physical coordinate under high stress
                     kinematic.pos.lerp(physical.pos, stressMultiplier * 0.3 * dt);
                 }
             }
         }
      }
    };
  }

  try {
    window.MANIFESTO && window.MANIFESTO.register({
      key: 'brick70.overgrowth_stress_deformation',
      kind: 'physics-stability',
      summary: 'Overgrowth joint stress mapping. Physically pulls the visible kinematic skeleton toward the active ragdoll coordinates during stagger states, generating un-canned flinch dynamics.',
      call: 'Fighter.prototype.updateActiveRagdoll append'
    });
  } catch(e) {}
  console.log('%c[BANNON · BRICK 70] OVERGROWTH: JOINT STRESS DEFORMATION ONLINE', 'color:#00ffcc;font-weight:bold;background:#000;padding:3px 8px');
})();

/* BANNON SYSTEM BRICK 71 — TORIBASH KINETIC ENERGY SLAM INJECTION */
(function() {
  if (typeof Fighter === 'undefined') return;

  const _origSlamKin = Fighter.prototype._slamVictimKin;
  if (_origSlamKin) {
    Fighter.prototype._slamVictimKin = function(by) {
      // Run the standard slam math
      _origSlamKin.call(this, by);
      
      // Toribash physics multiplier
      // If we are getting slammed, inject profound physical momentum into the ragdoll system preemptively
      // so when we detach, we carry forward true ballistic velocity.
      if (this.V && this.ragdoll) {
          const dt = 1/60;
          const e = by.grappleStage;
          if (e > 0.5) { // Apex of slam
             // Apply raw mechanical downward impulse to the head and chest
             const chest = this.V['chest'];
             const head = this.V['head'];
             
             // Gravity accelerator multiplier based on opponent mass
             const oppMass = by.spec && by.spec.build ? by.spec.build : 1.0;
             const ballisticForce = 1.2 * oppMass;
             
             if (chest) chest.impulse(0, ballisticForce * dt, 0);
             if (head) head.impulse(0, (ballisticForce * 1.5) * dt, 0); // Head snaps faster
          }
      }
    };
  }

  try {
    window.MANIFESTO && window.MANIFESTO.register({
      key: 'brick71.toribash_kinetic_slams',
      kind: 'physics-stability',
      summary: 'Toribash kinetic energy slam injection. Pre-loads physical momentum into the victims ragdoll nodes at the apex of a slam to ensure true ballistic bounce upon canvas impact.',
      call: 'Fighter.prototype._slamVictimKin append'
    });
  } catch(e) {}
  console.log('%c[BANNON · BRICK 71] TORIBASH: KINETIC ENERGY SLAM INJECTION ONLINE', 'color:#00ffcc;font-weight:bold;background:#000;padding:3px 8px');
})();

/* BANNON SYSTEM BRICK 72 — BARE METTLE CENTER OF MASS WEAPONIZATION V2 */
(function() {
  if (typeof Fighter === 'undefined') return;

  const _origHit = Fighter.prototype.applyHit;
  if (_origHit) {
    Fighter.prototype.applyHit = function(dmg, region, atk) {
      _origHit.call(this, dmg, region, atk);

      // Bare Mettle (Exanima) Post-Hit Center of Mass disruption
      // Upon taking severe damage to the head, the core motor shuts down completely for exactly 3 frames,
      // resulting in a pure, brutal physics snap back, then reignites to regain balance.
      if (dmg > 8.0 && region === 'HEAD' && !this.ragdoll && this._arSeed) {
         
         // Artificially snap center of mass
         if (this._arV && this._arV['head'] && this._arV['chest']) {
             const dx = (atk.dir && atk.dir.x) ? -atk.dir.x : (Math.random() > 0.5 ? 1 : -1);
             const dz = (atk.dir && atk.dir.z) ? -atk.dir.z : -1;
             
             const violence = (dmg / 10.0) * 0.15; // 0.1 to 0.4
             
             // Apply raw impulse directly to the active ragdoll
             this._arV['head'].impulse(dx * violence, 0.05, dz * violence);
             this._arV['chest'].impulse(dx * (violence * 0.5), -0.02, dz * (violence * 0.5));
         }
      }
    };
  }

  try {
    window.MANIFESTO && window.MANIFESTO.register({
      key: 'brick72.baremettle_com_disruption',
      kind: 'physics-stability',
      summary: 'Bare Mettle Exanima motor disruption. Severe head trauma temporarily disables upper-body kinematic matching, allowing raw physical impulses to generate brutal unscripted knockback snaps.',
      call: 'Fighter.prototype.applyHit active-ragdoll disruption'
    });
  } catch(e) {}
  console.log('%c[BANNON · BRICK 72] BARE METTLE (EXANIMA): CORE MOTOR SHUTDOWN ONLINE', 'color:#00ffcc;font-weight:bold;background:#000;padding:3px 8px');
})();

/* BANNON SYSTEM BRICK 73 — UNITY CONFIGURABLE JOINTS (ROTATION CLAMP) */
(function() {
  if (typeof Fighter === 'undefined') return;
  // Final safeguard: prevent visual glitching where elbows rotate inward on strike connection
  const _origSolveIK = Fighter.prototype.solveLimbIK;
  if (_origSolveIK) {
     Fighter.prototype.solveLimbIK = function() {
       _origSolveIK.call(this);

       // Unity Configurable Joints Angular Clamp Implementation
       if (this.J && this.state === 'attack' && this.attackPhase > 0.5) {
          const hL = this.J['haL']; const shL = this.J['shL'];
          const hR = this.J['haR']; const shR = this.J['shR'];
          
          if (hL && shL && hL.pos.distanceTo(shL.pos) > 0.4) {
              // Lock rotation angle - prevent inward snapping of elbow
              if (this.J['elL'] && this.J['elL'].pos.z > shL.pos.z + 0.1) {
                  this.J['elL'].pos.z -= 0.05; // Snap back to safe operational angle
              }
          }
          if (hR && shR && hR.pos.distanceTo(shR.pos) > 0.4) {
              if (this.J['elR'] && this.J['elR'].pos.z > shR.pos.z + 0.1) {
                  this.J['elR'].pos.z -= 0.05;
              }
          }
       }
     };
  }

  try {
    window.MANIFESTO && window.MANIFESTO.register({
      key: 'brick73.unity_angular_clamp',
      kind: 'physics-stability',
      summary: 'Unity configurable joint angular clamping. Locks arm rotational planes during maximum extension of strikes to physically prohibit inward-snapped elbow glitches.',
      call: 'Fighter.prototype.solveLimbIK append'
    });
  } catch(e) {}
  console.log('%c[BANNON · BRICK 73] UNITY CONFIGURABLE JOINTS: ANGULAR CLAMP ONLINE', 'color:#00ffcc;font-weight:bold;background:#000;padding:3px 8px');
})();
`;

code = code.replace('</script>\n</body></html>', bricks + '\n</script>\n</body></html>');
fs.writeFileSync('index.html', code);
console.log("Injected Bricks 69-73 to fix extreme instabilities.");
