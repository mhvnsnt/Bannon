export class CreationSuite {
  constructor() {
    console.log("[Node 11] Creation Suite Initialized");
  }
}
