export class HUDOverlay {
  constructor() {
    console.log("[Node 10] HUD Overlay Initialized");
  }
}
