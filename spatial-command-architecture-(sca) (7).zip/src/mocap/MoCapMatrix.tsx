export class MoCapMatrix {
  constructor() {
    console.log("[Node 13] MoCap Matrix Initialized");
  }

  public parseFBX() {
    // FBXLoader parsing logic will be injected here
  }
}
