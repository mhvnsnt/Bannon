export class AppRouter {
  constructor() {
    console.log("[Node 1] App Router Initialized");
  }
}
