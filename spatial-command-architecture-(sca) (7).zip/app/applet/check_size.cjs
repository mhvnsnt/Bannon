const fs = require('fs');
const files = fs.readdirSync('.');
files.forEach(f => {
  try {
    const stats = fs.statSync(f);
    if (stats.isFile()) console.log(f, stats.size);
  } catch(e) {}
});
