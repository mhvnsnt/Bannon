const fs = require('fs');
const lines = fs.readFileSync('index.html', 'utf8').split('\n');
let max = 0;
let maxIdx = -1;
lines.forEach((l, i) => {
  if (l.length > max) { max = l.length; maxIdx = i; }
});
console.log('Max line length:', max, 'at line:', maxIdx);
